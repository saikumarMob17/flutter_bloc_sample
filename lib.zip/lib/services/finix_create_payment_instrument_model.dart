class FinixPaymentInstrumentModel {
  String customerIdentity;
  String cardHolderName;
  String cardNumber;
  String cvv;
  int expiryMonth;
  int expiryYear;
  String city;
  String line1;
  String postalCode;
  String region;

  FinixPaymentInstrumentModel({
    required this.customerIdentity,
    required this.cardNumber,
    required this.expiryMonth,
    required this.expiryYear,
    required this.cvv,
    required this.cardHolderName,
    this.city = '',
    this.line1 = '',
    this.postalCode = '',
    this.region = '',
  });


  Map get toJson => {
    "address": {
      "city": city,
      "country": "USA",
      "line1": line1,
      "postal_code": postalCode,
      "region": region
    },
    "expiration_month": expiryMonth,
    "expiration_year": expiryYear,
    "identity": customerIdentity,
    "name": cardHolderName,
    "number": cardNumber,
    "security_code": cvv,
    "type": "PAYMENT_CARD"
  };

}
