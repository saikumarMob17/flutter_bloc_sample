import '../utils/app_extension_method.dart';

class FinixCreateIdentityModel {
  String phone;
  String firstName;
  String lastName;
  String email;
  String city;
  String country;
  String region;
  String line1;
  String line2;
  String postalCode;

  FinixCreateIdentityModel({
    required this.firstName,
    required this.lastName,
    this.phone = '',
    this.email = '',
    this.city = '',
    this.country = 'USA',
    this.region = '',
    this.line1 = '',
    this.line2 = '',
    this.postalCode = ''
  }) : assert((!phone.isBlank || !email.isBlank) && !firstName.isBlank && !lastName.isBlank, 'Atleast phone or email should be provide to uniquely identify user');

  Map get toJson => {
    "entity": {
      "phone": phone,
      "first_name": firstName,
      "last_name": lastName,
      "email": email,
      "personal_address": {
        "city": city,
        "country": country,
        "region": region,
        "line2": line2,
        "line1": line1,
        "postal_code": postalCode
      }
    }
  };

}