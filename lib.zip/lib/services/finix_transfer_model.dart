class FinixTransferModel {
  double amount;
  String paymentInstrumentId;

  FinixTransferModel({
    required this.amount,
    required this.paymentInstrumentId
  });

  Map get toJson => {
    "amount": amount,
    "currency": "USD",
    "merchant": "MUsTiLPXehcqo6wjdVHQn2jT",
    "source": paymentInstrumentId
  };
}