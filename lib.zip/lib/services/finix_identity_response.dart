
import 'dart:convert';

FinixIntityResponse finixIntityResponseFromJson(String str) => FinixIntityResponse.fromJson(json.decode(str));

class FinixIntityResponse {
  final Embedded? embedded;
  final FinixIntityResponseLinks? links;
  final Page? page;

  FinixIntityResponse({
    this.embedded,
    this.links,
    this.page,
  });

  factory FinixIntityResponse.fromJson(Map<String, dynamic> json) => FinixIntityResponse(
    embedded: json["_embedded"] == null ? null : Embedded.fromJson(json["_embedded"]),
    links: json["_links"] == null ? null : FinixIntityResponseLinks.fromJson(json["_links"]),
    page: json["page"] == null ? null : Page.fromJson(json["page"]),
  );
}

class Embedded {
  final List<Identity>? identities;

  Embedded({
    this.identities,
  });

  factory Embedded.fromJson(Map<String, dynamic> json) => Embedded(
    identities: json["identities"] == null ? [] : List<Identity>.from(json["identities"]!.map((x) => Identity.fromJson(x))),
  );
}

class Identity {
  final String? id;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? application;
  final Entity? entity;
  final List<String>? identityRoles;
  final Tags? tags;
  final String? type;
  final IdentityLinks? links;

  Identity({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.application,
    this.entity,
    this.identityRoles,
    this.tags,
    this.type,
    this.links,
  });

  factory Identity.fromJson(Map<String, dynamic> json) => Identity(
    id: json["id"] ?? '',
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    application: json["application"] ?? '',
    entity: json["entity"] == null ? null : Entity.fromJson(json["entity"]),
    identityRoles: json["identity_roles"] == null ? [] : List<String>.from(json["identity_roles"]!.map((x) => x)),
    tags: json["tags"] == null ? null : Tags.fromJson(json["tags"]),
    type: json["type"],
    links: json["_links"] == null ? null : IdentityLinks.fromJson(json["_links"]),
  );
}


class Entity {
  final int? achMaxTransactionAmount;
  final dynamic amexMid;
  final int? annualCardVolume;
  final Address? businessAddress;
  final String? businessName;
  final String? businessPhone;
  final bool? businessTaxIdProvided;
  final String? businessType;
  final dynamic defaultStatementDescriptor;
  final dynamic discoverMid;
  final String? dob;
  final String? doingBusinessAs;
  final String? email;
  final String? firstName;
  final bool? hasAcceptedCreditCardsPreviously;
  final dynamic incorporationDate;
  final String? lastName;
  final int? maxTransactionAmount;
  final dynamic mcc;
  final dynamic ownershipType;
  final Address? personalAddress;
  final String? phone;
  final dynamic principalPercentageOwnership;
  final dynamic shortBusinessName;
  final dynamic taxAuthority;
  final bool? taxIdProvided;
  final String? title;
  final String? url;

  Entity({
    this.achMaxTransactionAmount,
    this.amexMid,
    this.annualCardVolume,
    this.businessAddress,
    this.businessName,
    this.businessPhone,
    this.businessTaxIdProvided,
    this.businessType,
    this.defaultStatementDescriptor,
    this.discoverMid,
    this.dob,
    this.doingBusinessAs,
    this.email,
    this.firstName,
    this.hasAcceptedCreditCardsPreviously,
    this.incorporationDate,
    this.lastName,
    this.maxTransactionAmount,
    this.mcc,
    this.ownershipType,
    this.personalAddress,
    this.phone,
    this.principalPercentageOwnership,
    this.shortBusinessName,
    this.taxAuthority,
    this.taxIdProvided,
    this.title,
    this.url,
  });

  factory Entity.fromJson(Map<String, dynamic> json) => Entity(
    achMaxTransactionAmount: json["ach_max_transaction_amount"],
    amexMid: json["amex_mid"],
    annualCardVolume: json["annual_card_volume"],
    businessAddress: json["business_address"] == null ? null : Address.fromJson(json["business_address"]),
    businessName: json["business_name"],
    businessPhone: json["business_phone"],
    businessTaxIdProvided: json["business_tax_id_provided"],
    businessType: json["business_type"],
    defaultStatementDescriptor: json["default_statement_descriptor"],
    discoverMid: json["discover_mid"],
    dob: json["dob"],
    doingBusinessAs: json["doing_business_as"],
    email: json["email"] ?? '',
    firstName: json["first_name"] ?? '',
    hasAcceptedCreditCardsPreviously: json["has_accepted_credit_cards_previously"],
    incorporationDate: json["incorporation_date"],
    lastName: json["last_name"] ?? '',
    maxTransactionAmount: json["max_transaction_amount"],
    mcc: json["mcc"],
    ownershipType: json["ownership_type"],
    personalAddress: json["personal_address"] == null ? null : Address.fromJson(json["personal_address"]),
    phone: json["phone"] ?? '',
    principalPercentageOwnership: json["principal_percentage_ownership"],
    shortBusinessName: json["short_business_name"],
    taxAuthority: json["tax_authority"],
    taxIdProvided: json["tax_id_provided"],
    title: json["title"],
    url: json["url"],
  );
}

class Address {
  final String? line1;
  final String? line2;
  final String? city;
  final String? region;
  final String? postalCode;
  final String? country;

  Address({
    this.line1,
    this.line2,
    this.city,
    this.region,
    this.postalCode,
    this.country,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    line1: json["line1"],
    line2: json["line2"],
    city: json["city"],
    region: json["region"],
    postalCode: json["postal_code"],
    country: json["country"],
  );
}


class IdentityLinks {
  final Next? self;
  final Next? application;
  final Next? verifications;
  final Next? merchants;
  final Next? settlements;
  final Next? authorizations;
  final Next? transfers;
  final Next? paymentInstruments;
  final Next? associatedIdentities;
  final Next? disputes;

  IdentityLinks({
    this.self,
    this.application,
    this.verifications,
    this.merchants,
    this.settlements,
    this.authorizations,
    this.transfers,
    this.paymentInstruments,
    this.associatedIdentities,
    this.disputes,
  });

  factory IdentityLinks.fromJson(Map<String, dynamic> json) => IdentityLinks(
    self: json["self"] == null ? null : Next.fromJson(json["self"]),
    application: json["application"] == null ? null : Next.fromJson(json["application"]),
    verifications: json["verifications"] == null ? null : Next.fromJson(json["verifications"]),
    merchants: json["merchants"] == null ? null : Next.fromJson(json["merchants"]),
    settlements: json["settlements"] == null ? null : Next.fromJson(json["settlements"]),
    authorizations: json["authorizations"] == null ? null : Next.fromJson(json["authorizations"]),
    transfers: json["transfers"] == null ? null : Next.fromJson(json["transfers"]),
    paymentInstruments: json["payment_instruments"] == null ? null : Next.fromJson(json["payment_instruments"]),
    associatedIdentities: json["associated_identities"] == null ? null : Next.fromJson(json["associated_identities"]),
    disputes: json["disputes"] == null ? null : Next.fromJson(json["disputes"]),
  );
}

class Next {
  final String? href;

  Next({
    this.href,
  });

  factory Next.fromJson(Map<String, dynamic> json) => Next(
    href: json["href"],
  );
}

class Tags {
  Tags();
  factory Tags.fromJson(Map<String, dynamic> json) => Tags();
}


class FinixIntityResponseLinks {
  final Next? self;
  final Next? next;

  FinixIntityResponseLinks({
    this.self,
    this.next,
  });

  factory FinixIntityResponseLinks.fromJson(Map<String, dynamic> json) => FinixIntityResponseLinks(
    self: json["self"] == null ? null : Next.fromJson(json["self"]),
    next: json["next"] == null ? null : Next.fromJson(json["next"]),
  );
}

class Page {
  final int? limit;
  final String? nextCursor;

  Page({
    this.limit,
    this.nextCursor,
  });

  factory Page.fromJson(Map<String, dynamic> json) => Page(
    limit: json["limit"],
    nextCursor: json["next_cursor"],
  );
}

