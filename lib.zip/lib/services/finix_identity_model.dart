import 'package:cliqtechnologies_retl/services/finix_identity_response.dart';

class FinixIdentityModel {
  String appId;
  String identityId;
  String email;
  String phone;
  String name;
  Address? personalAddress;
  Address? businessAddress;

  FinixIdentityModel({
    required this.appId,
    required this.identityId,
    required this.email,
    required this.phone,
    required this.name,
    this.personalAddress,
    this.businessAddress
  });
}