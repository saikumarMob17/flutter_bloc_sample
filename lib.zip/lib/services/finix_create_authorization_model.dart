class FinixCreateAuthorizationModel {
  int amount;
  String paymentInstrumentId;


  FinixCreateAuthorizationModel({
    required this.amount,
    required this.paymentInstrumentId
  });


  Map<String, dynamic> get toJson => {
    "amount": amount,
    "currency": "USD",
    "merchant": "MUsTiLPXehcqo6wjdVHQn2jT",
    "source": paymentInstrumentId
  };
}