// To parse this JSON data, do
//
//     final finixPaymentInstrumentResponse = finixPaymentInstrumentResponseFromJson(jsonString);

import 'dart:convert';

FinixPaymentInstrumentResponse finixPaymentInstrumentResponseFromJson(String str) => FinixPaymentInstrumentResponse.fromJson(json.decode(str));

class FinixPaymentInstrumentResponse {
    final Embedded? embedded;
    final FinixPaymentInstrumentResponseLinks? links;
    final Page? page;

    FinixPaymentInstrumentResponse({
        this.embedded,
        this.links,
        this.page,
    });

    factory FinixPaymentInstrumentResponse.fromJson(Map<String, dynamic> json) => FinixPaymentInstrumentResponse(
        embedded: json["_embedded"] == null ? null : Embedded.fromJson(json["_embedded"]),
        links: json["_links"] == null ? null : FinixPaymentInstrumentResponseLinks.fromJson(json["_links"]),
        page: json["page"] == null ? null : Page.fromJson(json["page"]),
    );
}

class Embedded {
    final List<PaymentInstrument>? paymentInstruments;

    Embedded({
        this.paymentInstruments,
    });

    factory Embedded.fromJson(Map<String, dynamic> json) => Embedded(
        paymentInstruments: json["payment_instruments"] == null ? [] : List<PaymentInstrument>.from(json["payment_instruments"]!.map((x) => PaymentInstrument.fromJson(x))),
    );
}

class PaymentInstrument {
    final String? id;
    final DateTime? createdAt;
    final DateTime? updatedAt;
    final String? application;
    final String? createdVia;
    final String? currency;
    final String? disabledCode;
    final String? disabledMessage;
    final bool? enabled;
    final String? fingerprint;
    final String? identity;
    final String? instrumentType;
    final Address? address;
    final String? addressVerification;
    final String? bin;
    final String? brand;
    final String? cardType;
    final int? expirationMonth;
    final int? expirationYear;
    final String? issuerCountry;
    final String? lastFour;
    final String? name;
    final String? securityCodeVerification;
    final Tags? tags;
    final String? thirdParty;
    final String? thirdPartyToken;
    final String? type;
    final PaymentInstrumentLinks? links;
    final String? accountType;
    final String? bankAccountValidationCheck;
    final String? bankCode;
    final String? country;
    final String? institutionNumber;
    final String? maskedAccountNumber;
    final String? transitNumber;

    PaymentInstrument({
        this.id,
        this.createdAt,
        this.updatedAt,
        this.application,
        this.createdVia,
        this.currency,
        this.disabledCode,
        this.disabledMessage,
        this.enabled,
        this.fingerprint,
        this.identity,
        this.instrumentType,
        this.address,
        this.addressVerification,
        this.bin,
        this.brand,
        this.cardType,
        this.expirationMonth,
        this.expirationYear,
        this.issuerCountry,
        this.lastFour,
        this.name,
        this.securityCodeVerification,
        this.tags,
        this.thirdParty,
        this.thirdPartyToken,
        this.type,
        this.links,
        this.accountType,
        this.bankAccountValidationCheck,
        this.bankCode,
        this.country,
        this.institutionNumber,
        this.maskedAccountNumber,
        this.transitNumber,
    });

    factory PaymentInstrument.fromJson(Map<String, dynamic> json) => PaymentInstrument(
        id: json["id"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        application: json["application"],
        createdVia: json["created_via"],
        currency: json["currency"],
        disabledCode: json["disabled_code"],
        disabledMessage: json["disabled_message"],
        enabled: json["enabled"],
        fingerprint: json["fingerprint"],
        identity: json["identity"],
        instrumentType: json["instrument_type"],
        address: json["address"] == null ? null : Address.fromJson(json["address"]),
        addressVerification: json["address_verification"],
        bin: json["bin"],
        brand: json["brand"],
        cardType: json["card_type"],
        expirationMonth: json["expiration_month"],
        expirationYear: json["expiration_year"],
        issuerCountry: json["issuer_country"],
        lastFour: json["last_four"],
        name: json["name"],
        securityCodeVerification: json["security_code_verification"],
        tags: json["tags"] == null ? null : Tags.fromJson(json["tags"]),
        thirdParty: json["third_party"],
        thirdPartyToken: json["third_party_token"],
        type: json["type"],
        links: json["_links"] == null ? null : PaymentInstrumentLinks.fromJson(json["_links"]),
        accountType: json["account_type"],
        bankAccountValidationCheck: json["bank_account_validation_check"],
        bankCode: json["bank_code"],
        country: json["country"],
        institutionNumber: json["institution_number"],
        maskedAccountNumber: json["masked_account_number"],
        transitNumber: json["transit_number"],
    );
}

class Address {
    final String? line1;
    final String? line2;
    final String? city;
    final String? region;
    final String? postalCode;
    final String? country;

    Address({
        this.line1,
        this.line2,
        this.city,
        this.region,
        this.postalCode,
        this.country,
    });

    factory Address.fromJson(Map<String, dynamic> json) => Address(
        line1: json["line1"],
        line2: json["line2"],
        city: json["city"],
        region: json["region"],
        postalCode: json["postal_code"],
        country: json["country"],
    );
}

class PaymentInstrumentLinks {
    final Next? application;
    final Next? self;
    final Next? authorizations;
    final Next? transfers;
    final Next? verifications;
    final Next? identity;

    PaymentInstrumentLinks({
        this.application,
        this.self,
        this.authorizations,
        this.transfers,
        this.verifications,
        this.identity,
    });

    factory PaymentInstrumentLinks.fromJson(Map<String, dynamic> json) => PaymentInstrumentLinks(
        application: json["application"] == null ? null : Next.fromJson(json["application"]),
        self: json["self"] == null ? null : Next.fromJson(json["self"]),
        authorizations: json["authorizations"] == null ? null : Next.fromJson(json["authorizations"]),
        transfers: json["transfers"] == null ? null : Next.fromJson(json["transfers"]),
        verifications: json["verifications"] == null ? null : Next.fromJson(json["verifications"]),
        identity: json["identity"] == null ? null : Next.fromJson(json["identity"]),
    );
}

class Next {
    final String? href;

    Next({
        this.href,
    });

    factory Next.fromJson(Map<String, dynamic> json) => Next(
        href: json["href"],
    );
}

class Tags {
    Tags();

    factory Tags.fromJson(Map<String, dynamic> json) => Tags(
    );
}

class FinixPaymentInstrumentResponseLinks {
    final Next? self;
    final Next? next;

    FinixPaymentInstrumentResponseLinks({
        this.self,
        this.next,
    });

    factory FinixPaymentInstrumentResponseLinks.fromJson(Map<String, dynamic> json) => FinixPaymentInstrumentResponseLinks(
        self: json["self"] == null ? null : Next.fromJson(json["self"]),
        next: json["next"] == null ? null : Next.fromJson(json["next"]),
    );
}

class Page {
    final int? limit;
    final String? nextCursor;

    Page({
        this.limit,
        this.nextCursor,
    });

    factory Page.fromJson(Map<String, dynamic> json) => Page(
        limit: json["limit"],
        nextCursor: json["next_cursor"],
    );
}

