import 'dart:developer';
import 'api_service.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart';
import '../../utils/app_extension_method.dart';
import '../../utils/shared_pref.dart';
import '../network_constants.dart';

/*
 * Created by - Chetu India
 * Description - This class is used for handling api request.
 */
class ApiClient implements ApiService {
  ///Singleton instance variable
  static ApiClient? _instance;

  ///header passed during api call
  var headers = <String, String>{
    NetworkConstants.contentTypeKey: NetworkConstants.contentType
  };

  ///factory constructor
  factory ApiClient() {
    _instance ??= ApiClient._internal();
    return _instance!;
  }

  ///Internal named constructor
  ApiClient._internal();

  // ///overridden http getRequest
  // ///endPoint required
  @override
  Future<Response> getRequest(
      {required String endPoint, Map<String, String>? customHeader}) async {
    if (!Preferences.getString(key: AppStrings.prefToken).isBlank) {
      headers[NetworkConstants.authKey] = NetworkConstants.bearer +
          Preferences.getString(key: AppStrings.prefToken);
    }
    headers[NetworkConstants.tenant] =
        Preferences.getString(key: AppStrings.prefTenantId);
    if (customHeader != null) {
      headers.clear();
      headers.addAll(customHeader);
    }
    printRequest(url: endPoint, type: NetworkConstants.get, headers: headers);
    var response = await get(Uri.parse(endPoint), headers: headers).timeout(
        const Duration(seconds: 30),
        onTimeout: () =>
            Response(NetworkConstants.timeout, HttpStatus.requestTimeout));
    printResponse(statusCode: response.statusCode, body: response.body);
    return response;
  }

  ///overridden http postRequest
  ///endPoint and body are required
  @override
  Future<Response> postRequest(
      {required String endPoint,
      required body,
      Map<String, String>? customHeader}) async {
    if (!Preferences.getString(key: AppStrings.prefToken).isBlank) {
      headers[NetworkConstants.authKey] = NetworkConstants.bearer +
          Preferences.getString(key: AppStrings.prefToken);
    }
    headers[NetworkConstants.tenant] =
        Preferences.getString(key: AppStrings.prefTenantId);
    if (customHeader != null) {
      headers.clear();
      headers.addAll(customHeader);
    }
    printRequest(
        url: endPoint,
        type: NetworkConstants.post,
        headers: headers,
        body: body);
    var response = await post(Uri.parse(endPoint),
            body: body == null ? null : jsonEncode(body), headers: headers)
        .timeout(const Duration(seconds: 30),
            onTimeout: () =>
                Response(NetworkConstants.timeout, HttpStatus.requestTimeout));
    printResponse(statusCode: response.statusCode, body: response.body);
    return response;
  }

  //below method used to print the response after API calling
  void printResponse({
    required int statusCode,
    required String body,
  }) =>
      log('<-- $statusCode $body');

  //below method used to print the request before API calling
  void printRequest(
      {required String url,
      required String type,
      required dynamic headers,
      dynamic body}) {
    body == null
        ? log('--> $type $url\n $headers')
        : log('--> $type $url\n $headers\n $body');
  }

  @override
  Future<Response> multiPartRequest(
      {required String endPoint,
      Map<String, String>? body,
      Map<String, String>? files}) async {
    headers[NetworkConstants.authKey] = NetworkConstants.bearer +
        Preferences.getString(key: AppStrings.prefToken);
    headers[NetworkConstants.tenant] =
        Preferences.getString(key: AppStrings.prefTenantId);
    var request = MultipartRequest(NetworkConstants.post, Uri.parse(endPoint));
    request.headers.addAll(headers);
    if (body != null) {
      request.fields.addAll(body);
    }
    if (files != null) {
      files.forEach((key, value) async {
        request.files.add(await MultipartFile.fromPath(key, value));
      });
    }
    var response = await request.send();
    return Response.fromStream(response);
  }

  @override
  Future<Response> putRequest(
      {required String endPoint,
      required body,
      Map<String, String>? customHeader}) async {
    if (!Preferences.getString(key: AppStrings.prefToken).isBlank) {
      headers[NetworkConstants.authKey] = NetworkConstants.bearer +
          Preferences.getString(key: AppStrings.prefToken);
    }
    headers[NetworkConstants.tenant] =
        Preferences.getString(key: AppStrings.prefTenantId);
    if (customHeader != null) {
      headers.clear();
      headers.addAll(customHeader);
    }
    printRequest(
        url: endPoint,
        type: NetworkConstants.post,
        headers: headers,
        body: body);
    var response = await put(Uri.parse(endPoint),
            body: body == null ? null : jsonEncode(body), headers: headers)
        .timeout(const Duration(seconds: 30),
            onTimeout: () =>
                Response(NetworkConstants.timeout, HttpStatus.requestTimeout));
    printResponse(statusCode: response.statusCode, body: response.body);
    return response;
  }
}
