import 'package:http/http.dart';
/*
 * Created by - Chetu India
 * Description - This class is used as the base class for api client
 */
abstract class ApiService {

  ///abstract http postRequest method
  Future<Response> postRequest({required String endPoint,required dynamic body});

  Future<Response> putRequest({required String endPoint, required dynamic body});

  ///abstract http getRequest method
  Future<Response> getRequest({required String endPoint});

  ///Multipart Request
  Future<Response> multiPartRequest({required String endPoint});

}