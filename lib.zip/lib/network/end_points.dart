/*
 * Created by - Chetu India.
 * Description - This class is used for defining all the end point of api.
 */
class EndPoints {

  EndPoints._();
  ///Add base URL here
  static const String baseUrl = 'https://cliqtechnologies-retl-api.chetu.com/api/';

  ///FINIX Payment BaseUrl
  //Sandbox Account
  static const String finixBaseUrl = 'https://finix.sandbox-payments-api.com/';

  ///Add all end point here
  static const String login = '${baseUrl}Account/LoginUser';
  static const String dashboardMenuItem = '${baseUrl}POS_DashboardMenu/GetDashboardItem';
  static const String productCategory = '${baseUrl}Inventory/GetProductSubCatrgories';
  static const String addFloorPlan = '${baseUrl}FloorPlan/AddFloorPlanDetails';
  static const String getAllFloorPlan = '${baseUrl}FloorPlan/GetAllFloorPlanDetails';
  static const String getFloorPlan = '${baseUrl}FloorPlan/GetFloorPlanDetailsById';
  static const String updateFloorPlan = '${baseUrl}FloorPlan/UpdateFloorPlanDetails';
  static const String placeOrder = '${baseUrl}placeOrder/AddPlaceOrderDetails';
  static const String kitchenDisplay = '${baseUrl}placeOrder/GetKitchenDisplayDetails';
  static const String updateFloorPlanById = '${baseUrl}FloorPlan/UpdateTableAvailabilityStatus';
  static const String getAllPendingOrders = '${baseUrl}placeOrder/GetAllPendingOrderDetails';
  static const String finishKitchenOrder = '${baseUrl}placeorder/FinishOrderByOrderNumberAndSequence';
  static const String updateKitchenOrderStatus = '${baseUrl}PlaceOrder/UpdateProductStatusByKitchenPerson';
  static const String paymentTerminal = '${baseUrl}placeorder/GetPaymentTerminalDetails';
  static const String lookupCustomer = '${baseUrl}LookupCustomer/';
  static const String updateOrder = '${baseUrl}placeorder/UpdateAddOnsOfCustomer';
  static const String updatePaymentStatus = '${baseUrl}placeorder/UpdateSplitCheckPaymentStatus';
  static const String updatePaymentStatusByCheckSequence = '${baseUrl}placeorder/UpdateSplitCheckPaymentStatusBySequence';
  static const String clockIn = '${baseUrl}Employee/ClockIn';
  static const String clockOut = '${baseUrl}Employee/ClockOut';
  static const String timeCardDetails = '${baseUrl}Employee/FindTimeCardDetails';
  static const String timeCardDetailsById = '${baseUrl}Employee/FindTimeCardDetailsByEmpId';
  static const String allShiftDetails = '${baseUrl}Employee/GetEmployeeShiftDetailsByDate';
  static const String employeeShiftDetails = '${baseUrl}Employee/GetEmployeeShiftDetailsByEmpId';
  static const String searchCheckByCheckNumber = '${baseUrl}Checks/FindCheckDetailsByOrderNumber';
  static const String searchCheckByCustomerName = '${baseUrl}Checks/FindCheckDetailsByCustomerName';
  static const String searchCheckByCardNumber = '${baseUrl}Checks/FindCheckDetailsByCardNumber';
  static const String advanceCheckSearch = '${baseUrl}Checks/FindCheckDetailsByAmmountRangeAndDate';
  static const String searchCheckByDate = '${baseUrl}Checks/FindCheckDetailsByDate';
  static const String closeOutDayByDate = '${baseUrl}CloseOutDay/FindCloseOutDayDetailsbyDate';
  static const String closeOutDay = '${baseUrl}CloseOutDay/FindCloseOutDayDetails';
  static const String allEmployees = '${baseUrl}Employee/GetAllEmployeeDetailsWithRole';
  static const String assignOrder = '${baseUrl}PlaceOrder/AssignOrderToAnOtherEmployee';
  static const String authorizeManager = '${baseUrl}Account/ValidateUserRole';
  static const String logActivityServer = '${baseUrl}Employee/LogActivityOfServer';

  ///Finix End Point
  static const String identities = '${finixBaseUrl}identities';
  static const String paymentInstruments = '${finixBaseUrl}payment_instruments';
  static const String transfers = '${finixBaseUrl}transfers';
  static const String authorizations = '${finixBaseUrl}authorizations';

}