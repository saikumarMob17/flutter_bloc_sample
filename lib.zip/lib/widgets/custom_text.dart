import '../routes/route.dart';
import '../constants/app_colors.dart';
import '../constants/app_style.dart';

class CustomText extends StatelessWidget {
  final String title;
  final Color? color;
  final double? fontSize;
  final TextAlign? textAlign;
  final TextStyle? textStyle;
  final int? maxLines;
  final TextOverflow? textOverflow;
  final Function()? onTap;
  final bool? toolTipVisible;
  final bool isMandatory;

  const CustomText({
    required this.title,
    this.color,
    this.onTap,
    this.textAlign,
    this.fontSize,
    this.textStyle,
    this.maxLines,
    this.textOverflow,
    this.toolTipVisible,
    this.isMandatory = false,
    super.key
  });

  @override
  Widget build(BuildContext context){
    return TooltipVisibility(
      visible: toolTipVisible ?? false,
      child: Tooltip(
        message: title,
        child: isMandatory
        ? RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: title,
                  style: textStyle 
                  ?? getRegularStyle(
                    color: 
                    color ?? (Helper.isDark ? AppColors.white : AppColors.black), 
                    fontSize: fontSize
                  ),
                ),
                const TextSpan(
                  text: '  *', 
                  style: TextStyle(color: AppColors.red)
                ),
              ]
            ),
          )
        : Text(
          title,
          textAlign: textAlign,
          maxLines: maxLines,
          overflow: textOverflow,
          style: textStyle 
          ?? getRegularStyle(
            color: 
            color ?? (Helper.isDark ? AppColors.white : AppColors.black), 
            fontSize: fontSize
          ),
        ),
      ),
    );
  }
}