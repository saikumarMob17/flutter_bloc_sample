import '../constants/app_colors.dart';
import 'package:flutter/material.dart';
import '../constants/app_size.dart';

class CustomIconButton extends StatelessWidget {

  final Widget widget;
  final double? verPadding;
  final double? horPadding;
  final Function()? onPressed;

  const CustomIconButton({
    super.key,
    required this.widget,
    this.verPadding,
    this.horPadding,
    this.onPressed
  });

  @override
  Widget build(BuildContext context) {
    return IconButton.outlined(
      onPressed: onPressed, 
      icon: widget,
      style: ButtonStyle(
        padding: MaterialStateProperty.all(EdgeInsets.symmetric(
          horizontal: horPadding ?? 8.0,
          vertical: verPadding ?? 8.0
        )),
        foregroundColor: MaterialStateProperty.all(AppColors.primaryColor),
        shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s5))),
        side: MaterialStateProperty.all(const BorderSide(color: Colors.blue, width: 1.0,style: BorderStyle.solid))
      ),
    );
  }
}