import 'package:cliqtechnologies_retl/routes/route.dart';

class IconTitleModel {

  String title;
  String imagePath;
  IconData? icon;
  Color? color;

  IconTitleModel({
    required this.title,
    this.imagePath = '',
    this.icon,
    this.color
  });
}