import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class CustomSwitchWidget extends StatelessWidget {
  final bool value;
  final double scale;
  final Function(bool)? onChange;

  const CustomSwitchWidget({
    required this.value,
    this.onChange,
    this.scale = 0.7,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scale: scale,
      child: Switch(
        value: value, 
        onChanged: onChange,
        thumbColor: MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
          if (states.contains(MaterialState.selected)) {
            return AppColors.white;
          }
          if(states.contains(MaterialState.disabled)) {
            return Colors.grey;
          }
          return Colors.grey;
        }),
        trackOutlineColor: MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
          if (states.contains(MaterialState.selected)) {
            return AppColors.primaryColor;
          }
          if(states.contains(MaterialState.disabled)) {
            return Colors.grey;
          }
          return Colors.grey;
        }),
      ),
    );
  }
}