import 'package:flutter/foundation.dart';
import '../constants/app_colors.dart';
import '../routes/route.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomImageView extends StatelessWidget {

  final String? imagePath;
  final Uint8List? imgBytes;
  final double? height;
  final double? width;
  final Color? color;
  final BoxFit? fit;
  final String? placeHolder;
  final Alignment? alignment;
  final VoidCallback? onTap;
  final BorderRadius? radius;
  final BlendMode? blendMode;
  final EdgeInsets? margin;
  final BoxBorder? border;

  const CustomImageView({
    super.key,
    this.imagePath,
    this.imgBytes,
    this.height,
    this.width,
    this.color,
    this.fit,
    this.blendMode,
    this.placeHolder,
    this.alignment,
    this.onTap,
    this.radius,
    this.margin,
    this.border
  });

  @override
  Widget build(BuildContext context){
    return alignment != null
    ? Align(
        alignment: alignment!,
        child: _buildWidget,
      )
    : _buildWidget;
  }


  Widget get _buildWidget => Padding(
    padding: margin ?? EdgeInsets.zero,
    child: InkWell(
      onTap: onTap,
      child: _buildCircleImage,
    ),
  );

  Widget get _buildCircleImage {
    if(radius != null){
      return ClipRRect(
        borderRadius: radius ?? BorderRadius.zero,
        child: _buildImageWithBorder,
      );
    }
    return _buildImageWithBorder;
  }

  Widget get _buildImageWithBorder {
    if(border != null){
      return Container(
        decoration: BoxDecoration(
          border: border,
          borderRadius: radius,
        ),
        child: _buildImageView
      );
    }
    return _buildImageView;
  }

  Widget get _buildImageView {
    if(imagePath != null){
      switch (imagePath!.imageType) {
        case ImageType.svg:
          return SvgPicture.asset(
            imagePath!,
            height: height,
            width: width,
            fit: fit ?? BoxFit.contain,
            colorFilter: ColorFilter.mode(
              color ?? (Helper.isDark ? AppColors.white : AppColors.black), 
              blendMode ?? BlendMode.srcIn
            )
          );
        case ImageType.network:
          return Image.network(
            imagePath!,
            fit: fit,
            color: color,
            loadingBuilder: (_, child, progress) {
              if(progress == null) return child;
              return SizedBox(
                height: 30,
                width: 30,
                child: CircularProgressIndicator(
                  color: Colors.grey.shade200,
                  backgroundColor: Colors.grey.shade100,
                ),
              );
            },
            errorBuilder: (_, __, ___) => Image.asset(
              placeHolder ?? "",
              height: height,
              width: width,
              fit: fit ?? BoxFit.cover,
            ),
          );
        case ImageType.png:
        default:
          return Image.asset(
            imagePath!,
            height: height,
            width: width,
            fit: fit ?? BoxFit.cover,
            color: color,
            errorBuilder: (_, __, ___) => const SizedBox()
          );
      }
    }
    if(imgBytes != null) {
      return Image.memory(
        imgBytes!,
        height: height,
        width: width,
        fit: fit ?? BoxFit.cover,
        color: color,
        errorBuilder: (_, __, ___) => const SizedBox(),
      );
    }
    return const SizedBox();
  }
}

extension ImageTypeExtension on String {

  ImageType get imageType {
    if(startsWith('http') || startsWith('https')){
      return ImageType.network;
    } else if(endsWith('.svg')) {
      return ImageType.svg;
    } else if(startsWith('file://')){
      return ImageType.file;
    } else {
      return ImageType.png;
    }
  }

}

enum ImageType {svg, png, network, file, unknown}