import 'package:flutter/material.dart';
import 'custom_image_view.dart';
import 'custom_text.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';
import '../utils/helper.dart';

class CustomEmptyWidget extends StatelessWidget {

  final String imagePath;
  final String emptyTitle;
  final bool isMobileView;
  final Color? imageColor;
  final bool isVisible;

  const CustomEmptyWidget({
    super.key,
    required this.imagePath,
    required this.emptyTitle,
    this.isMobileView = false,
    this.imageColor,
    this.isVisible = true
  });

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: isVisible,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CustomImageView(
            imagePath: imagePath, 
            height: isMobileView ? AppSize.s38 : AppSize.s60, 
            width: isMobileView ? AppSize.s38 : AppSize.s60,
            color: imageColor,
          ),
          const SizedBox(height: AppSize.s2),
          CustomText(
            title: emptyTitle,
            textStyle: getRegularStyle(
              fontWeight: FontWeight.w400,
              color: Helper.isDark 
              ? AppColors.white 
              : AppColors.black,
              fontSize: isMobileView
              ? AppSize.s12
              : AppSize.s14
            ),
          ),
        ],
      ),
    );
  }
}