class DropdownMenuModel {

  String value;
  String item;

  DropdownMenuModel({
    required this.value,
    required this.item
  });
}