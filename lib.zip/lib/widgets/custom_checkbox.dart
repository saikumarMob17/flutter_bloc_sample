import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import 'package:flutter/material.dart';

class CustomCheckBox extends StatelessWidget {

  final double? checkBoxSize;
  final bool value;
  final OutlinedBorder? shape;
  final double? size;
  final Function(bool?)? onChange;

  const CustomCheckBox({
    super.key,
    required this.value,
    this.shape,
    this.size,
    this.checkBoxSize = 0.8,
    this.onChange
  });

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scale: checkBoxSize,
      child: SizedBox(
        width: size ?? AppSize.s24,
        height: size ?? AppSize.s24,
        child: Checkbox(
          shape: shape,
          value: value,
          checkColor: AppColors.white,
          onChanged: onChange,
        ),
      ),
    );
  }
}