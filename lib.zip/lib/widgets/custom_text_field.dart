import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'custom_text.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_strings.dart';
import '../constants/app_style.dart';
import 'custom_image_view.dart';
import '../utils/helper.dart';

class CustomTextField extends StatelessWidget {

  final TextEditingController? textController;
  final String? hint;
  final double? horPadding;
  final double? verPadding;
  final double? prefixImageSize;
  final TextStyle? labelStyle;
  final String? prefixImagePath;
  final String? suffixImagePath;
  final Color? prefixImageColor;
  final List<TextInputFormatter>? inputFormatter;
  final TextCapitalization? textCapitalization;
  final String? label;
  final String? errorText;
  final bool? obscureText;
  final bool? isMandatory;
  final int? maxLength;
  final bool? readOnly;
  final bool? isEnable;
  final TextInputType? textInputType;
  final Color? backgroundColor;
  final Function()? onTap;
  final Function(String)? onChange;
  final Function()? suffixCallBack;
  final TextAlign? textAlign;
  final FontWeight? fontWeight;
  final double? textSize;
  final Color? borderColor;

  const CustomTextField({
    this.textController,
    this.hint,
    this.horPadding,
    this.verPadding,
    this.prefixImagePath,
    this.suffixCallBack,
    this.prefixImageSize,
    this.prefixImageColor,
    this.backgroundColor,
    this.labelStyle,
    this.label,
    this.errorText,
    this.maxLength,
    this.obscureText,
    this.readOnly = false,
    this.isEnable = true,
    this.isMandatory = false,
    this.onChange,
    this.onTap,
    this.textCapitalization = TextCapitalization.none,
    this.textInputType,
    this.inputFormatter,
    this.suffixImagePath,
    this.textAlign,
    this.fontWeight,
    this.textSize,
    this.borderColor,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Visibility(
          visible: label == null ? false : true,
          child: Column(
            children: [
              Row(
                children: [
                  CustomText(
                    title: label ?? AppStrings.emptyString, 
                    textStyle: labelStyle,
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                  Visibility(
                    visible: isMandatory!,
                    child: CustomText(
                      title: ' * ', 
                      textStyle: getMediumStyle(color: AppColors.red)
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s4),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(
            horizontal: horPadding ?? 0.0,
            vertical: verPadding ?? 0.0
          ),
          decoration: BoxDecoration(
            color: backgroundColor ?? (Helper.isDark ? AppColors.topDarkColor : AppColors.white),
            borderRadius: BorderRadius.circular(AppSize.s5),
            border: Border.all(
              color: borderColor ?? (Helper.isDark 
              ? AppColors.topDarkColor 
              : const Color(0xFFC9DAE8)), 
              width: 0.8
            ),
            boxShadow: const [BoxShadow(color: AppColors.lightGrey, blurRadius: AppSize.s1)]
          ),
          child: Row(
            children: [
              Visibility(
                visible: prefixImagePath == null ? false : true,
                child: Row(
                  children: [
                    CustomImageView(
                      imagePath: prefixImagePath,
                      color: prefixImageColor ?? (Helper.isDark ? AppColors.white : AppColors.lightTextGrey),
                      height: prefixImageSize ?? AppSize.s22,
                      width: prefixImageSize ?? AppSize.s22,
                    ),
                    const SizedBox(width: AppSize.s8),
                  ],
                ),
              ),
              Expanded(
                child: TextField(
                  obscureText: obscureText == null || !obscureText! ? false : true,
                  controller: textController,
                  onChanged: onChange,
                  inputFormatters: inputFormatter,
                  keyboardType: textInputType,
                  readOnly: readOnly!,
                  onTap: onTap,
                  enabled: isEnable!,
                  textAlign: textAlign ?? TextAlign.start,
                  textCapitalization: textCapitalization!,
                  maxLength: maxLength,
                  buildCounter: (_, {required int currentLength, int? maxLength, required bool isFocused}) => null,
                  decoration: InputDecoration.collapsed(
                    hintText: hint ?? label ?? AppStrings.enter,
                    hintStyle: getRegularStyle(
                      color: Helper.isDark 
                      ? AppColors.grey 
                      : AppColors.lightTextGrey, 
                      fontSize: AppSize.s14
                    ),
                    // counterText: ''
                  ),
                  style: getRegularStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black, 
                    fontSize: textSize ?? AppSize.s14,
                    fontWeight: fontWeight
                  ),
                ),
              ),
              Visibility(
                visible: suffixImagePath == null ? false : true,
                child: Row(
                  children: [
                    const SizedBox(width: AppSize.s10),
                    CustomImageView(
                      imagePath: suffixImagePath,
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.lightTextGrey,
                      height: AppSize.s22,
                      width: AppSize.s22,
                      onTap: onTap ?? suffixCallBack
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Visibility(
          visible: errorText == null || errorText!.isEmpty ? false : true,
          child: Column(
            children: [
              const SizedBox(height: AppSize.s4),
              Padding(
                padding: const EdgeInsets.only(left: AppSize.s12),
                child: CustomText(
                  title: errorText ?? AppStrings.emptyString, 
                  textStyle: getRegularStyle(color: AppColors.red)
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}