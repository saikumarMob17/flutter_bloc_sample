import 'package:flutter/material.dart';
import '../utils/helper.dart';
import 'custom_text.dart';
import '../constants/app_size.dart';
import '../constants/app_colors.dart';
import '../constants/app_icons.dart';
import '../constants/app_strings.dart';
import 'dropdownmenu_model.dart';

class CustomDropdownWidget extends StatelessWidget {
  
  final List<DropdownMenuModel> items;
  final String value;
  final String? label;
  final TextStyle? labelStyle;
  final Color? backgroundColor;
  final Color? labelColor;
  final Color? borderColor;
  final bool isExpanded;
  final double? verPad;
  final double? horPad;
  final Function(String?)? onChange;

  const CustomDropdownWidget({
    required this.items,
    required this.value,
    this.label,
    this.labelStyle,
    this.backgroundColor,
    this.labelColor,
    this.borderColor,
    this.isExpanded = false,
    this.onChange,
    this.verPad,
    this.horPad,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Visibility(
          visible: label == null ? false : true,
          child: Column(
            children: [
              CustomText(
                title: label ?? AppStrings.emptyString, 
                textStyle: labelStyle
              ),
              const SizedBox(height: AppSize.s4)
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(
            vertical: verPad ?? AppSize.s10,
            horizontal: horPad ?? AppSize.s12
          ),
          decoration: BoxDecoration(
            color: backgroundColor ?? (Helper.isDark ? AppColors.topDarkColor : AppColors.white),
            borderRadius: BorderRadius.circular(AppSize.s8),
            border: Border.all(
              color: borderColor ?? const Color(0xFFC9DAE8),
              width: AppSize.s1
            ),
          ),
          child: DropdownButton<String>(
            isExpanded: isExpanded,
            isDense: true,
            dropdownColor: Helper.isDark 
            ? AppColors.headerColorDark 
            : AppColors.white,
            underline: Container(color: AppColors.transparent),
            icon: Icon(
              AppIcons.expandMoreIcon, 
              color: labelColor ?? (Helper.isDark ? AppColors.white : AppColors.black)
            ),
            value: value,
            items: List.generate(items.length, (index) {
              var data = items[index];
              return DropdownMenuItem(
                value: data.value, 
                child: CustomText(
                  title: data.item, 
                  color: labelColor
                ),
              );
            }),
            onChanged: onChange
          ),
        ),
      ],
    );
  }

}