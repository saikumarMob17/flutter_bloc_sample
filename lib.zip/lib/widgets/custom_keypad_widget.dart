import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';
import '../utils/app_extension_method.dart';
import 'custom_text.dart';
import '../utils/helper.dart';

class CustomKeypadWidget extends StatelessWidget {

  final Function(int) onTap;
  const CustomKeypadWidget({
    super.key,
    required this.onTap
  });

  @override
  Widget build(BuildContext context){
    int buttonIndex = 0;
    final items = List<Widget>.generate(
      4,
      (index) {
        final subItem =  List<Widget>.generate(
          3, 
          (subIndex) {
            buttonIndex+=1;
            return InkWell(
              onTap: buttonIndex == 10
              ? null
              : () => onTap('$index$subIndex'.getDialValue),
              borderRadius: BorderRadius.circular(30),
              child: Ink(
                height: 56,
                width: 56,
                decoration: ShapeDecoration(
                  color: buttonIndex == 10 
                    ? AppColors.transparent 
                    : Helper.isDark 
                      ? AppColors.topDarkColor 
                      : AppColors.white,
                  shape: const CircleBorder(),
                  shadows: Helper.isDark || buttonIndex == 10 
                  ? null 
                  : [BoxShadow(color: const Color.fromARGB(255, 21, 21, 21).withOpacity(0.2), blurRadius: AppSize.s4)]
                ),
                child: Center(
                  child: buttonIndex == 12
                  ? const Icon(Icons.backspace, size: AppSize.s20, color: AppColors.red)
                  : CustomText(
                    title: buttonIndex == 11 ? '0' : '$buttonIndex',
                    textStyle: getMediumStyle(
                      color: buttonIndex == 10 
                      ? AppColors.transparent 
                      : Helper.isDark ? AppColors.white : AppColors.black, 
                      fontSize: AppSize.s18,
                      fontWeight: FontWeight.w500
                    ),
                  ),
                ),
              ),
            );
          } 
        );
        return Padding(
          padding: const EdgeInsets.only(top: AppSize.s18),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: subItem
          ),
        );
      }
    );
    return Column(mainAxisSize: MainAxisSize.min, children: items);
  }
}