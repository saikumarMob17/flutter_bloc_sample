import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../utils/app_extension_method.dart';
import 'custom_text.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';
import '../utils/helper.dart';

class TableWidget extends StatelessWidget {

  final int tableSize;
  final String tableLabel;
  final TableAvailableStatus availableStatus; 
  final bool? isSelected;
  final Function()? onTap;

  const TableWidget({
    super.key,
    this.onTap,
    this.isSelected,
    required this.tableSize,
    required this.tableLabel,
    required this.availableStatus
  }) : assert(tableSize > 0, 'Table size cannot be zero');

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: tableSize * 100,
      height: 100,
      child: Stack(
        children: [
          Row(
            children: List.generate(
              tableSize, 
              (_) => Transform.rotate(
                angle: math.pi / 4,
                child: Container(
                  width: 100, 
                  height: 100, 
                  decoration: BoxDecoration(
                    color: AppColors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(AppSize.s26)
                  ),
                ),
              ),
            ),
          ),
          InkWell(
            onTap: onTap,
            child: Container(
              margin: const EdgeInsets.only(top: 5, left: 5, right: 5),
              decoration: BoxDecoration(
                color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                borderRadius: BorderRadius.circular(AppSize.s12),
                border: Border.all(
                  color: isSelected == null || !isSelected! 
                  ? AppColors.grey.withOpacity(0.4) 
                  : AppColors.primaryColor, 
                  width: 1.5
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  tableSize, 
                  (_) => const SizedBox(
                    width: 87, 
                    height: 87
                  ),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: IgnorePointer(
              child: CustomText(
                title: tableLabel,
                textStyle: getMediumStyle(
                  fontSize: AppSize.s20, 
                  color: Helper.isDark 
                  ? AppColors.white 
                  : AppColors.black
                ),
              ),
            ),
          ),
          Positioned(
            top: 13,
            left: 13,
            child: IgnorePointer(
              child: CircleAvatar(
                radius: 7, 
                backgroundColor: availableStatus.tableAvailableStatusColor
              ),
            ),
          ),
        ],
      ),
    );
  }
}