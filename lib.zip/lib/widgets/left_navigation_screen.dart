import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../utils/helper.dart';
import 'custom_image_view.dart';

class LeftNavigationScreen extends StatelessWidget {

  final int selectedLeftNavigationItem;
  final Function()? onTap;

  const LeftNavigationScreen({
    super.key,
    required this.selectedLeftNavigationItem,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Helper.isDark ? AppColors.black : AppColors.white,
      padding: const EdgeInsets.only(
        left: AppSize.s6,
        top: AppSize.s14,
        bottom: AppSize.s14
      ),
      child: Column(
        children: [
          const SizedBox(height: AppSize.s40),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(
              Helper.leftNavigationItemList.length, 
              (index) {
                var data = Helper.leftNavigationItemList[index];
                return GestureDetector(
                  onTap: onTap,
                  child: Tooltip(
                    message: data.title,
                    child: Container(
                      padding: const EdgeInsets.all(AppSize.s6),
                      margin: const EdgeInsets.only(bottom: AppSize.s10),
                      decoration: BoxDecoration(
                        color: selectedLeftNavigationItem == index 
                        ? AppColors.primaryColor
                        : AppColors.transparent,
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(AppSize.s6),
                          bottomLeft: Radius.circular(AppSize.s6)
                        )
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(AppSize.s6),
                        decoration: BoxDecoration(
                          color: selectedLeftNavigationItem == index 
                          ? AppColors.sideBarSelectedColor
                          : AppColors.transparent,
                          borderRadius: BorderRadius.circular(AppSize.s4),
                        ),
                        child: CustomImageView(
                          imagePath: data.imagePath,
                          height: AppSize.s16,
                          width: AppSize.s16,
                          color: selectedLeftNavigationItem == index
                          ? AppColors.white
                          : AppColors.grey
                        ),
                      ),
                    ),
                  ),
                );
              }
            ),
          ),
        ],
      ),
    );
  }
}

class LeftNavigationItemsModel {
  String title;
  String imagePath;

  LeftNavigationItemsModel({
    required this.title,
    required this.imagePath
  });
}