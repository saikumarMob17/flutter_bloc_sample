import 'package:flutter/material.dart';
import '../constants/app_strings.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';

class CustomOutlinedButton extends StatelessWidget {

  final String? text;
  final Color? textColor;
  final Color? borderColor;
  final double? textSize;
  final double? topPadding;
  final double? bottomPadding;
  final double? leftPadding;
  final double? rightPadding;
  final Widget? widget;
  final Color? backgroundColor;
  final double? widgetSpacing;
  final Widget? preFixWidget;
  final Widget? suffixWidget;
  final Function()? onPressed;

  const CustomOutlinedButton({
    super.key,
    this.text,
    this.textColor,
    this.borderColor,
    this.textSize,
    this.onPressed,
    this.topPadding,
    this.bottomPadding,
    this.backgroundColor,
    this.leftPadding,
    this.rightPadding,
    this.suffixWidget,
    this.widgetSpacing,
    this.preFixWidget,
    this.widget
  });

  @override
  Widget build(BuildContext context){
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        visualDensity: VisualDensity.compact,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s5)),
        backgroundColor: backgroundColor,
        side: BorderSide(
          color: onPressed == null 
          ? AppColors.grey 
          : borderColor ?? AppColors.blue
        ),
        padding: EdgeInsets.only(
          top: topPadding ?? AppSize.s16,
          bottom: bottomPadding ?? AppSize.s16,
          left: leftPadding ?? AppSize.s16,
          right: rightPadding ?? AppSize.s16
        ),
      ),
      child: childWidget
    );
  }

  Widget get childWidget {
    if(widget != null){
      return widget!;
    } else if(preFixWidget != null){
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          preFixWidget!,
          SizedBox(width: widgetSpacing ?? AppSize.s4),
          Text(
            text ?? AppStrings.emptyString, 
            overflow: TextOverflow.ellipsis,
            style: getMediumStyle(
              color: onPressed == null ? AppColors.grey : textColor ?? AppColors.blue, 
              fontSize: textSize ?? AppSize.s14
            ),
          ),
        ],
      );
    } else if(suffixWidget != null){
      return Row(
        children: [
          Text(
            text ?? AppStrings.emptyString, 
            overflow: TextOverflow.ellipsis,
            style: getMediumStyle(
              color: onPressed == null ? AppColors.grey : textColor ?? AppColors.blue, 
              fontSize: textSize ?? AppSize.s14
            ),
          ),
          SizedBox(width: widgetSpacing ?? AppSize.s4),
          suffixWidget!,
        ],
      );
    } else {
      return Text(
        text ?? AppStrings.emptyString, 
        overflow: TextOverflow.ellipsis,
        style: getMediumStyle(
          color: onPressed == null ? AppColors.grey : textColor ?? AppColors.blue,
          fontSize: textSize ?? AppSize.s14
        )
      );
    }
  }
}