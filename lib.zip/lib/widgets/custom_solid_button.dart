import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';

class CustomSolidButton extends StatelessWidget {

  final String text;
  final Color? textColor;
  final double? textSize;
  final double? verPadding;
  final double? horPadding;
  final Color? backgroundColor;
  final Function()? onPressed;
  final bool? centerAlignment;
  final Widget? prefix;
  final Widget? childWidget;
  final double? space;
  final double? borderRadius;

  const CustomSolidButton({
    super.key,
    required this.text,
    this.textColor,
    this.textSize,
    this.onPressed,
    this.verPadding,
    this.horPadding,
    this.prefix,
    this.space,
    this.childWidget,
    this.borderRadius,
    this.centerAlignment,
    this.backgroundColor
  });

  @override
  Widget build(BuildContext context){
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        visualDensity: VisualDensity.compact,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(borderRadius ?? AppSize.s5)),
        backgroundColor: onPressed == null ? AppColors.grey : backgroundColor ?? AppColors.primaryColor,
        padding: EdgeInsets.symmetric(
          vertical: verPadding ?? AppSize.s16, 
          horizontal: horPadding ?? AppSize.s16
        ),
      ),
      child: childWidget != null
      ? childWidget!
      : prefix == null 
        ? Text(
          text, 
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: getMediumStyle(
            color: textColor ?? (onPressed == null ? AppColors.grey : AppColors.white), 
            fontSize: textSize ?? AppSize.s14
          ),
        )
        : Row(
          mainAxisAlignment: centerAlignment == null || !centerAlignment! 
          ? MainAxisAlignment.start 
          : MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            prefix!,
            SizedBox(width: space ?? AppSize.s4),
            Text(
              text, 
              style: getMediumStyle(
                color: onPressed == null ? AppColors.grey : textColor ?? AppColors.white, 
                fontSize: textSize ?? AppSize.s14
              ),
            ),
          ],
        ),
    );
  }
}