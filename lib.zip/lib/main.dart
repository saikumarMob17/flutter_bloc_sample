import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../utils/main_bloc/main_bloc.dart';
import '../utils/main_bloc/main_bloc_state.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../routes/app_routes.dart';
import '../utils/shared_pref.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Preferences.init();
  runApp(const MyApp());
}


class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  late ThemeMode themeMode;

  // This widget is the root widget of the application.
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => MainBloc(),
      child: BlocBuilder<MainBloc, MainBlocState>(
        builder: (context, state){
          switch (state.runtimeType) {
            case MainBlocThemeState:
              state = state as MainBlocThemeState;
              themeMode = state.themeMode;
              break;
            default:
          }
          return MaterialApp.router(
            debugShowCheckedModeBanner: false,
            title: AppStrings.appName,
            themeMode: themeMode,
            darkTheme: ThemeData(
              scaffoldBackgroundColor: Colors.black,
              colorScheme: const ColorScheme.dark(primary: AppColors.primaryColor),
              appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
              useMaterial3: true
            ),
            theme: ThemeData(
              scaffoldBackgroundColor: Colors.white,
              colorScheme: const ColorScheme.light(primary: AppColors.primaryColor),
              appBarTheme: const AppBarTheme(backgroundColor: Colors.white),
              useMaterial3: true
            ),
            routerConfig: AppRoutes.router,
          );
        },
      )
    );
  }
}
