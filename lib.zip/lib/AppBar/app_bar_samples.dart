import 'package:flutter/material.dart';

class AppBarMenu extends StatefulWidget {
  const AppBarMenu({super.key});

  @override
  State<AppBarMenu> createState() => _AppBarMenuState();
}

class _AppBarMenuState extends State<AppBarMenu> {
  var icon = const Icon(Icons.search);

  late Widget title ;

  late TextEditingController textEditingController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    icon = const Icon(Icons.search);
    title = const Text("Search");



    textEditingController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text("AppBar exmaple"),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppBar(
            //title: const Text("AppBar with SearchBar"),
            actions: [

              IconButton(onPressed: () {

                icon = const Icon(Icons.remove);

                title = TextField(
                  controller: textEditingController,
                  decoration:  const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderSide: BorderSide.none)),
                );
                setState(() {

                });







              }, icon: const Icon(Icons.search))
            ],
          ),
          AppBar(
            title: const Text("AppBar with SearchBar"),

          ),

        ],
      ),
    ));
  }
}
