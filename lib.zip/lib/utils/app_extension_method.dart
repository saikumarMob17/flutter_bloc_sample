import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../features/pending_orders/domain/pending_orders_model.dart';
import 'shared_pref.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import 'helper.dart';

extension StringExtension on String {

  bool get isBlank {
    try {
      return trim().isEmpty ? true : false;
    } catch (e) {
      return false;
    }
  }

  bool get isValidEmail {
    try {
      var regExp = RegExp(r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
      return regExp.hasMatch(this);
    } catch (e) {
      return false;
    }
  }

  int get getDialValue {
    try {
      return Helper.keypadShelPosition[this]!;
    } catch (e) {
      return -1;
    }
  }

  ThemeMode get getThemeMode {
    var data = this;
    switch (data) {
      case 'dark':
        return ThemeMode.dark;
      case 'light':
        return ThemeMode.light;
      default:
        Preferences.setString(key: AppStrings.prefThemeMode, value: 'system');
        return ThemeMode.system;
    }
  }

  bool get checkTableAvailability {
    var data = this;
    try {
      if(data == 'available'){
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  Color get tableAvailableStatusColor  {
    switch (this) {
      case 'available':
        return AppColors.primaryColor;
      case 'unavailable':
        return AppColors.red;
      default:
        return AppColors.orange;
    }
  }

  TableShape get getTableShape {
    var data = this;
    switch (data) {
      case 'circle':
        return TableShape.circle;
      case 'square':
        return TableShape.square;
      case 'rectangle':
        return TableShape.rectangle;
      default:
        return TableShape.triangle;
    }
  }

  String get convertTimeClockOut {
    var dateTime = this;
    try {
      dateTime+='Z';
      return DateFormat.jm().format(DateTime.parse(dateTime).toLocal());
    } catch (e) {
      return dateTime;
    }
  }

  String get convertDateTimeClockOut {
    var dateTime = this;
    try {
      dateTime+='Z';
      return '${DateFormat.yMMMd().format(DateTime.parse(dateTime).toLocal())} ${DateFormat.jm().format(DateTime.parse(dateTime).toLocal())}';
    } catch (e) {
      return dateTime;
    }
  }

  String get captializedWord {
    try {
      var word = this;
      word = word.replaceAll('/', '');
      word = word.replaceAll('_', ' ');
      return word.split(' ').map((e) => e.substring(0,1).toUpperCase()+e.substring(1)).join(' ');
    } catch (e) {
      return this;
    }
  }

  String get formatDateMMDDYYY {
    try {
      var date = this;
      var tempDate = date.split('-');
      return '${tempDate[1]}-${tempDate[2]}-${tempDate[0]}';
    } catch (e) {
      return this;
    }
  }

  String get formatDateYYYYMMDD {
    try {
      var date = this;
      var tempDate = date.split('-');
      return '${tempDate[2]}-${tempDate[0]}-${tempDate[1]}';
    } catch (e) {
      return this;
    }
  }

  List<String> get firstLastName {
    try {
      var data = split(' ');
      if(data.length == 1) {
        return [...data, ''];
      } else {
        return data;
      }
    } catch (e) {
      return [this,''];
    }
  }
  
}

extension EnumExtension on Enum {

  Color get tableAvailableStatusColor  {
    switch (this) {
      case TableAvailableStatus.available:
        return AppColors.primaryColor;
      case TableAvailableStatus.unavailable:
        return AppColors.red;
      default:
        return AppColors.orange;
    }
  }

}

extension ScreenBuildContext on BuildContext {

  double get screenWidth => MediaQuery.of(this).size.width;

  double get screenHeight => MediaQuery.of(this).size.height;

  double get statusBarHeight => MediaQuery.of(this).viewPadding.top;
}

extension ScreenDimension on num {

  ScreenType get screenType {
    var screenDimension = this;
    if(screenDimension <= 600.0) {
      return ScreenType.mobile;
    } else if(screenDimension > 600 && screenDimension <= 720) {
      return ScreenType.smallTablet;
    } else if(screenDimension > 720 && screenDimension <= 1200) {
      return ScreenType.largeTablet;
    } else {
      return ScreenType.desktop;
    }
  }

  double get roundTwo {
    var data = this;
    try {
      return double.parse(data.toStringAsFixed(2));
    } catch (e) {
      return data.toDouble();
    }
  }

  int get dashboardItemCount {
    var data = this;
    try{
      int rowMaxItem = 6;
      if(data%rowMaxItem == 0) {
        return data~/rowMaxItem;
      } else {
        return data~/rowMaxItem + 1;
      }
    } catch (e) {
      return data.toInt();
    }
  }

  int get orderItemCount {
    var data = toInt();
    try {
      var remainder = data % 2;
      var quotient = data ~/ 2;
      return remainder + quotient;
    } catch (e) {
      return data;
    }
  }

  int get squareSittingCalculation {
    var data = toInt();
    try {
      return ((4 * data) - (2 * (data - 1)));
    } catch (e) {
      return data;
    }
  }

  String get calculatePaymentSalesAmount {
    var amount = this;
    try {
      amount = amount.roundTwo;
      if(amount.isNegative) {
        return "- \$${amount.abs()}";
      } else {
        return "\$$amount";
      }
    } catch (e) {
      return amount.toStringAsFixed(2);
    }
  }

  List<PendingOrdersModel> pendingOrderIndex(List<PendingOrdersModel> data) {
    try {
      var tabIndex = this;
      if(tabIndex == 0){
        return data.where((element) => !element.isOrderFinished).toList();
      } else {
        return data.where((element) => element.isOrderFinished).toList();
      } 
    } catch (e) {
      return [];
    }
  }
  
}
