import 'package:connectivity_plus/connectivity_plus.dart';

class CheckConnectivity {

  ///named internal constructor
  CheckConnectivity._internal();

  static CheckConnectivity? singleton;

  ///factory constructor
  factory CheckConnectivity() {
    singleton ??= CheckConnectivity._internal();
    return singleton!;
  }

  ///method used to check the internet connection
  Future<bool> get hasConnection async {
    var connectionResult = await (Connectivity().checkConnectivity());
    switch (connectionResult) {
      case ConnectivityResult.wifi:
      case ConnectivityResult.mobile:
      case ConnectivityResult.bluetooth:
      case ConnectivityResult.ethernet:
      case ConnectivityResult.vpn:
        return true;
      default:
        return false;
    }
  }

}