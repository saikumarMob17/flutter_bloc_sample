import 'package:flutter/material.dart';

sealed class MainBlocEvent {}

class MainBlocChangeThemeEvent extends MainBlocEvent {
  ThemeMode themeMode;
  MainBlocChangeThemeEvent({required this.themeMode});
}