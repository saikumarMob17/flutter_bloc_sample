import 'package:flutter_bloc/flutter_bloc.dart';
import '../app_extension_method.dart';
import 'main_bloc_event.dart';
import 'main_bloc_state.dart';
import '../shared_pref.dart';
import '../../constants/app_strings.dart';

class MainBloc extends Bloc<MainBlocEvent, MainBlocState>{


  MainBloc() : super(MainBlocThemeState(themeMode: Preferences.getString(key: AppStrings.prefThemeMode).getThemeMode)){
    on<MainBlocChangeThemeEvent>(_onChangeTheme);
  }

  void _onChangeTheme(MainBlocChangeThemeEvent event, Emitter emit){
    var temp = event.themeMode.toString().split('.')[1];
    Preferences.setString(key: AppStrings.prefThemeMode, value: temp);
    emit(MainBlocThemeState(themeMode: event.themeMode));
  }
}