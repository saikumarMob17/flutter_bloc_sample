import 'package:flutter/material.dart';

sealed class MainBlocState {}

class MainBlocThemeState extends MainBlocState {
  ThemeMode themeMode;
  MainBlocThemeState({required this.themeMode});
}