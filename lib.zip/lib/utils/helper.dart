import 'dart:convert';
import 'dart:io';
import 'package:intl/intl.dart';
import '../network/api/api_client.dart';
import '../network/end_points.dart';
import '../routes/route.dart';
import '../constants/app_colors.dart';
import '../constants/app_images.dart';
import '../constants/app_size.dart';
import '../constants/app_style.dart';
import '../network/custom_exception.dart';
import '../widgets/custom_text.dart';
import '../widgets/left_navigation_screen.dart';
import '../routes/app_routes.dart';
import 'app_extension_method.dart';
import '../widgets/custom_outlined_button.dart';

enum LoginType{pin, pattern, fingerPrint, faceID, userName}

enum TableAvailableStatus{available, unavailable, availableSoon}

enum ScreenType {mobile, smallTablet, largeTablet, desktop }

enum TableShape {circle, rectangle, square, triangle}

enum KitchenOrderItemStatus {prepared, process, cancel}

mixin Helper {

  bool isLoadingVisible = false;
  
  static bool isDark = false;

  static double screenWidth = 1706.6666666666667;
  static double screenHeight = 855;

  static double floorWidth = 1228.8;  
  static double floorHeight = 648.0;

  ///Regular Expression to restrict space
  static RegExp restrictSpaceRegExp = RegExp(r'\s');

  void showSnackBar({
    required BuildContext context, 
    required String title,
    ScreenType? screenType,
    String? message, 
    Color? color
  }){
    screenType ??= ScreenType.mobile;
    var snackBar = SnackBar(
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 2),
      padding: EdgeInsets.zero,
      elevation: AppSize.s0,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(AppSize.s5))
      ),
      margin: EdgeInsets.only(
        bottom: AppSize.s20, 
        left: screenType != ScreenType.mobile 
        ? context.screenWidth * 0.50 + AppSize.s20 
        : AppSize.s65, 
        right: AppSize.s20
      ),
      content: Container(
        padding: const EdgeInsets.all(AppSize.s12),
        decoration: BoxDecoration(
          color: color != null 
          ? color.withOpacity(0.2) 
          : AppColors.red.withOpacity(0.2),
          borderRadius: const BorderRadius.all(Radius.circular(AppSize.s5)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            color != null
            ? Icon(Icons.check_circle, color: color, size: AppSize.s20)
            : const Icon(Icons.warning_rounded, color: AppColors.red, size: AppSize.s20),
            const SizedBox(width: AppSize.s10),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    title: title,
                    textStyle: getRegularStyle(
                      fontSize: AppSize.s15, 
                      color: color ?? AppColors.red
                    ),
                  ),
                  Visibility(
                    visible: message != null,
                    child: Padding(
                      padding: const EdgeInsets.only(top: AppSize.s2),
                      child: CustomText(
                        title: message ?? AppStrings.emptyString,
                        textStyle: getRegularStyle(
                          fontSize: AppSize.s14, 
                          color: AppColors.black
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    ScaffoldMessenger.of(context)
      ..removeCurrentSnackBar()
      ..showSnackBar(snackBar);
  }

  int dashboardItemCount(int data) {
    try{
      int rowMaxItem = 6;
      if(data%rowMaxItem == 0){
        return data~/rowMaxItem;
      } else{
        return data~/rowMaxItem + 1;
      }
    } catch (e) {
      return data.toInt();
    }
  }

  int orderCategoryPageCount(int data){
    try{
      int rowMaxItem = 12;
      if(data%rowMaxItem == 0){
        return data~/rowMaxItem;
      } else{
        return data~/rowMaxItem + 1;
      }
    } catch (e) {
      return data.toInt();
    }
  }

  String subTitle(List subMenu, int index){
    try {
      return subMenu[index].subMenuItem;
    } catch (e) {
      return '';
    }
  }

  String dashboardMenuItemRoute(List subMenu, int index){
    try {
      return dashboardItemRoute[subMenu[index].subMenuId];
    } catch (e) {
      return '';
    }
  }

  static Map keypadShelPosition = {'00': 1, '01': 2, '02': 3, '10': 4, '11': 5, '12': 6, '20': 7, '21': 8, '22': 9, '30': -1, '31': 0, '32': -1};

  static List leftNavigationItemList = <LeftNavigationItemsModel>[
    LeftNavigationItemsModel(title: 'Home', imagePath: AppImages.homeIcon),
    LeftNavigationItemsModel(title: 'Profit', imagePath: AppImages.profileIcon),
    LeftNavigationItemsModel(title: 'Dashboard', imagePath: AppImages.dashboardIcon),
    LeftNavigationItemsModel(title: 'Message', imagePath: AppImages.messageIcon),
    LeftNavigationItemsModel(title: 'Notification', imagePath: AppImages.notificationIcon),
    LeftNavigationItemsModel(title: 'Settings', imagePath: AppImages.settingIcon)
  ];

  static Map dashboardItemRoute  = {
    ///Mode
    1 : AppRoutes.tableViewScreen,
    2 : AppRoutes.ordersScreen,
    3 : AppRoutes.paymentTerminalScreen,
    4 : AppRoutes.orderHubScreen,
    5 : AppRoutes.fastServiceScreen,
    6 : AppRoutes.kitchenDisplayScreen,
    7 : AppRoutes.pendingOrderScreen,
    8 : AppRoutes.wasteTrackingScreen,
    ///Manager Activities
    9 : AppRoutes.closeOutDayScreen,
    10 : AppRoutes.checkSearchScreen,
    11 : AppRoutes.employeeShiftScreen,
    12 : AppRoutes.timeCardScreen,
    13 : AppRoutes.emptyRoute,
    14 : AppRoutes.lookUpCustomerScreen,
    ///Cash Management
    15 : AppRoutes.cashDrawerScreen,
    16 : AppRoutes.emptyRoute,
    17 : AppRoutes.depositsScreen,
    ///Report
    18 : AppRoutes.salesReportScreen,
    19 : AppRoutes.menuReportScreen,
    20 : AppRoutes.laborReportScreen,
    ///Setup
    21 : AppRoutes.emptyRoute,
    22 : AppRoutes.createFloorPlanScreen,
    23 : AppRoutes.emptyRoute,
    24 : AppRoutes.emptyRoute,
    25 : AppRoutes.emptyRoute,
    26 : AppRoutes.printerSetupScreen,
    ///Support
    27 : AppRoutes.emptyRoute,
    28 : AppRoutes.serviceStatusScreen,
    29 : AppRoutes.emptyRoute,
  };

  static Map dashboardItemIconMobile  = {
    ///Mode
    1 : AppImages.restaurantTableIcon,
    2 : AppImages.foodRestaurantOrder,
    3 : AppImages.paymentHistory,
    4 : AppImages.restaurantTableIcon,
    5 : AppImages.kitchenware,
    6 : AppImages.kitchenware,
    7 : AppImages.kitchenware,
    8 : AppImages.kitchenware,
    ///Manager Activities
    9 : AppImages.closeOutDayIcon,
    10 : AppImages.checkAllIcon,
    11 : AppImages.reviewShiftIcon,
    12 : AppImages.timeCardIcon,
    13 : AppImages.registerSwipeCardIcon,
    14 : AppImages.barcodeSearchIcon,
    ///Cash Management
    15 : AppImages.closeOutDayIcon,
    16 : AppImages.timeCardIcon,
    17 : AppImages.registerSwipeCardIcon,
    ///Report
    18 : AppImages.salesReportIcon,
    19 : AppImages.menuReportIcon,
    20 : AppImages.labourReportIcon,
    ///Setup
    21 : AppImages.supportSiteIcon,
    22 : AppImages.statusPageIcon,
    23 : AppImages.screenShareIcon,
    24 : AppImages.screenShareIcon,
    25 : AppImages.screenShareIcon,
    26 : AppImages.screenShareIcon,
    ///Support
    27 : AppImages.supportSiteIcon,
    28 : AppImages.statusPageIcon,
    29 : AppImages.restaurantTableIcon,
  };

  static List<String> getFormattedDateTime({DateTime? dateTime}) {
    var currentDateTime = dateTime ?? DateTime.now();
    var formatedDate = DateFormat().format(currentDateTime);
    var temp = formatedDate.split(' ');
    var date = 'Today, ${temp[0].substring(0,3)} ${temp[1].substring(0,temp[1].length - 1)}';
    var time = '${temp[3].substring(0, temp[3].length-6)} ${temp[3].substring(temp[3].length - 2)}';
    return [date, time];
  }

  static String getDayFormattedDate({DateTime? dateTime}) {
    var currentDateTime = dateTime ?? DateTime.now();
    return DateFormat('EEE, d MMM, yyyy').format(currentDateTime);
  }

  void showLoadingDialog({required BuildContext context}) {
    if(!isLoadingVisible) {
      isLoadingVisible = true;
      showDialog(
        context: context,
        barrierColor: Colors.black26,
        builder: (_){
          return PopScope(
            // onWillPop: () async {
            //   isLoadingVisible = false;
            //   return Future.value(true);
            // },
            canPop: true,
            onPopInvoked: (bool didPop) {
              isLoadingVisible = false;
              // if (didPop) {
              //   return;
              // }
              // final bool shouldPop = await _showBackDialog() ?? false;
              // if (context.mounted && shouldPop) {
              //   Navigator.pop(context);
              // }
            },
            child: AlertDialog(
              elevation: AppSize.s0,
              contentPadding: EdgeInsets.zero,
              insetPadding: EdgeInsets.zero,
              backgroundColor: AppColors.transparent,
              content: SizedBox(
                width: double.maxFinite,
                height: double.maxFinite,
                child: Center(
                  child: CircularProgressIndicator(
                    color: AppColors.primaryColor,
                    backgroundColor: AppColors.black.withOpacity(0.1),
                    strokeCap: StrokeCap.round
                  )
                ),
              ),
            ),
          );
        }
      );
    } else {
      debugPrint(AppStrings.dialogShowingMessage);
    }
  }

  static Future<bool> showConfirmationDialog({
    required BuildContext context,
    String title = AppStrings.logout,
    String message = AppStrings.logoutMsg,
    bool showActionButton = true
  }) async {
    return await showDialog(
      context: context, 
      builder: (_){
        return AlertDialog.adaptive(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s10)),
          title: CustomText(
            title: title, 
            textStyle: getMediumStyle(
              fontSize: AppSize.s24, 
              color: Helper.isDark 
              ? AppColors.white 
              : AppColors.black
            ),
          ),
          content: CustomText(
            title: message, 
            textStyle: getRegularStyle(
              fontSize: AppSize.s16, 
              color: Helper.isDark 
              ? AppColors.white 
              : AppColors.black
            ),
          ),
          actions: showActionButton
          ? [
            CustomOutlinedButton(
              onPressed: () => context.pop(false),
              text: AppStrings.no,
              textColor: AppColors.red,
              borderColor: AppColors.grey,
              textSize: AppSize.s16,
              topPadding: AppSize.s10,
              bottomPadding: AppSize.s10
            ),
            const SizedBox(width: AppSize.s0),
            CustomOutlinedButton(
              onPressed: () => context.pop(true),
              text: AppStrings.yes,
              textColor: AppColors.blue,
              borderColor: AppColors.grey,
              textSize: AppSize.s16,
              topPadding: AppSize.s10,
              bottomPadding: AppSize.s10
            ),
          ]
          : null,
        );
      }
    ) ?? false;
  }

  void hideLoadingDialog({required BuildContext context}) {
    if(isLoadingVisible) {
      isLoadingVisible = false;
      context.pop();
    } else {
      debugPrint(AppStrings.dialogNotShowingMessage);
    }
  }

  static Future<bool> clockOut({required ApiClient apiClient}) async {
    try {
      var userId = Preferences.getString(key: AppStrings.prefUserId);
      var response = await apiClient.getRequest(endPoint: "${EndPoints.clockOut}?employeeId=$userId");
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            return true;
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}