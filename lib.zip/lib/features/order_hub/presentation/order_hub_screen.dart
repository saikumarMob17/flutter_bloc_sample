import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_icon_button.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../constants/app_icons.dart';
import 'bloc/order_hub_bloc.dart';
import 'bloc/order_hub_state.dart';

class OrderHubScreen extends StatefulWidget {

  const OrderHubScreen({super.key});

  @override
  State<OrderHubScreen> createState() => _OrderHubScreenState();
}

class _OrderHubScreenState extends State<OrderHubScreen> {

  var tabTitleList = [
    'Need Approval (6)',
    'Scheduled (0)',
    'Active',
    'Order Ready (0)',
    'Completed (0)'
  ];

  var subTabTitleList = [
    'Takeout',
    'Delivery',
    'Curbside'
  ];

  int tabSelectedIndex = 0;

  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<OrderHubBloc, OrderHubState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            // case DashboardChangeTabState:
            //   state = state as DashboardChangeTabState;
            //   selectedItem = state.index;
            //   modeItem.clear();
            //   modeItem.addAll(Helper.dashboardMenuItems[selectedItem]);
            //   break;
            // default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => context.pop(),
                        icon: const Icon(Icons.west)
                      ),
                      const SizedBox(width: AppSize.s4),
                      CustomText(
                        title: AppStrings.orderHub,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s18,
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      CustomImageView(
                        imagePath: AppImages.shoppingCart,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to cart screen'),
                      ),
                      const SizedBox(width: AppSize.s5),
                      CustomImageView(
                        imagePath: AppImages.menuDeep,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to menu screen'),
                      ),
                      const SizedBox(width: AppSize.s5),
                      CustomImageView(
                        imagePath: AppImages.menuVertical,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to more options'),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s20),
              Container(
                height: 44,
                width: context.screenWidth,
                decoration: BoxDecoration(
                  color: Helper.isDark
                  ? AppColors.contentColorDark
                  : AppColors.white,
                  borderRadius: BorderRadius.circular(AppSize.s10),
                  boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: 1.0, offset: const Offset(0, 2))]
                ),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                  children: List.generate(
                    tabTitleList.length, 
                    (index) => GestureDetector(
                      //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                        margin: const EdgeInsets.only(right: AppSize.s20),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              width: 3.0, 
                              color: tabSelectedIndex == index 
                              ? AppColors.primaryColor 
                              : AppColors.transparent
                            ),
                          ),
                        ),
                        child: Align(
                          alignment: Alignment.center,
                          child: CustomText(
                            title: tabTitleList[index],
                            textStyle: getMediumStyle(
                              color: tabSelectedIndex == index 
                              ? AppColors.primaryColor 
                              : Helper.isDark ? AppColors.white : AppColors.black,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s20),
              Expanded(
                child: ListView(
                  //physics: const NeverScrollableScrollPhysics(),
                  children: [
                    // Row(
                    //   children: List.generate(
                    //     subTabTitleList.length, 
                    //     (index) {
                    //       return Container(
                    //         margin: const EdgeInsets.only(right: AppSize.s10),
                    //         padding: const EdgeInsets.symmetric(
                    //           vertical: AppSize.s5,
                    //           horizontal: AppSize.s10
                    //         ),
                    //         color: AppColors.white,
                    //         child: CustomText(
                    //           title: subTabTitleList[index],
                    //           textStyle: getRegularStyle(fontSize: AppSize.s14),
                    //         ),
                    //       );
                    //     }
                    //   ),
                    // ),
                    // const SizedBox(height: AppSize.s40),
                    ///2D Scrolling
                    Scrollbar(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        physics: const NeverScrollableScrollPhysics(),
                        child: Scrollbar(
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: SizedBox(
                              height: 350, 
                              width: context.screenWidth * 2, 
                              child: Column(
                                children: [
                                  Container(
                                    color: AppColors.transparent,
                                    padding: const EdgeInsets.symmetric(
                                      vertical: AppSize.s15,
                                      horizontal: AppSize.s8
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: CustomText(
                                            title: 'Order Id', 
                                            textStyle: getMediumStyle(
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'Name', 
                                            textStyle: getMediumStyle(
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'Cost', 
                                            textStyle: getMediumStyle(
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'Status', 
                                            textStyle: getMediumStyle(
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'Qty', 
                                            textStyle: getMediumStyle(
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(child: CustomText(title: '', textStyle: getMediumStyle())),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: 100,
                                      padding: EdgeInsets.zero,
                                      itemBuilder: (_, index){
                                        return Container(
                                          color: Helper.isDark 
                                          ? index%2 == 1 ? AppColors.transparent : AppColors.contentColorDark
                                          : index%2 == 1 ? AppColors.transparent : AppColors.white,
                                          padding: const EdgeInsets.symmetric(
                                            vertical: AppSize.s10,
                                            horizontal: AppSize.s8
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: CustomText(
                                                  title: '#25645', 
                                                  textStyle: getMediumStyle(
                                                    fontSize: AppSize.s12,
                                                    color: Helper.isDark
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  )
                                                ),
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: 'John Doe', 
                                                  textStyle: getMediumStyle(
                                                    fontSize: AppSize.s12,
                                                    color: Helper.isDark
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  )
                                                ),
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$200', 
                                                  textStyle: getMediumStyle(
                                                    fontSize: AppSize.s12,
                                                    color: Helper.isDark
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  )
                                                ),
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: 'Deliver by 12:35 PM', 
                                                  textStyle: getMediumStyle(
                                                    fontSize: AppSize.s12,
                                                    color: Helper.isDark
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  )
                                                ),
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '4', 
                                                  textStyle: getMediumStyle(
                                                    fontSize: AppSize.s12,
                                                    color: Helper.isDark
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  )
                                                ),
                                              ),
                                              Expanded(
                                                child: Align(
                                                  alignment: Alignment.centerLeft,
                                                  child: Container(
                                                    padding: const EdgeInsets.symmetric(
                                                      horizontal: AppSize.s10,
                                                      vertical: AppSize.s5
                                                    ),
                                                    decoration: BoxDecoration(
                                                      color: AppColors.primaryColor,
                                                      borderRadius: BorderRadius.circular(AppSize.s8)
                                                    ),
                                                    child: CustomText(
                                                      title: AppStrings.select,
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12,
                                                        color: AppColors.white
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s40),
                    Container(
                      color: Helper.isDark 
                      ? AppColors.contentColorDark
                      : AppColors.white,
                      padding: const EdgeInsets.symmetric(vertical: AppSize.s10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: AppSize.s5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomText(
                                  title: 'Selected Order', 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: AppSize.s40),
                          /// UI for no selected order
                          // const CustomImageView(
                          //   imagePath: AppImages.shoppingBagIcon, 
                          //   color: AppColors.black
                          // ),
                          // const SizedBox(height: AppSize.s10),
                          // const Padding(
                          //   padding: EdgeInsets.symmetric(vertical: AppSize.s10),
                          //   child: CustomText(title: 'No Selected Order'),
                          // ),
                          ///UI for selected order
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  title: 'John Doe', 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s22, 
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: 'Pick up at 11:45 AM', 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s12, 
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                const SizedBox(height: AppSize.s5),
                                CustomText(
                                  title: '#25645', 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s12, 
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                const SizedBox(height: AppSize.s30),
                                ListView.separated(
                                  itemCount: 5,
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemBuilder: (_, index){
                                    return InkWell(
                                      onTap: () => debugPrint('Click here to select'),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.all(AppSize.s15),
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Helper.isDark
                                              ? AppColors.black
                                              : AppColors.backgroundColor
                                            ),
                                            child: const CustomImageView(
                                              imagePath: AppImages.orangeJuice,
                                              color: AppColors.primaryColor,
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              CustomText(
                                                title: 'Apple Juice', 
                                                textStyle: getMediumStyle(
                                                  fontSize: AppSize.s16,
                                                  color: Helper.isDark 
                                                  ? AppColors.white 
                                                  : AppColors.black
                                                ),
                                              ),
                                              const SizedBox(height: AppSize.s12),
                                              CustomText(
                                                title: '\$ 2.29', 
                                                textStyle: getMediumStyle(
                                                  fontSize: AppSize.s20, 
                                                  color: AppColors.grey
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                  separatorBuilder: (_,__) => const Divider(
                                    color: AppColors.grey, 
                                    thickness: AppSize.s05, 
                                    height: AppSize.s20
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.orderHub,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark 
                                ? AppColors.white 
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomText(
                              title: 'Takeout 15-20 Min',
                              textStyle: getMediumStyle(color: AppColors.primaryColor),
                            ),
                            const SizedBox(width: AppSize.s20),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              text: AppStrings.newOrder,
                              textColor: AppColors.primaryColor,
                              preFixWidget: const Icon(
                                AppIcons.addIcon, 
                                size: AppSize.s18, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              text: AppStrings.manageOnlineOrder,
                              textColor: AppColors.primaryColor,
                              widgetSpacing: AppSize.s8,
                              preFixWidget: const CustomImageView(
                                imagePath: AppImages.reportCardIcon, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                              horPadding: AppSize.s10,
                              verPadding: AppSize.s10,
                              text: AppStrings.switchUser
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomIconButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s10,
                              verPadding: AppSize.s10,
                              widget: const CustomImageView(imagePath: AppImages.menuHorizontalColor, blendMode: BlendMode.dstIn),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s30),
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 44,
                            width: context.screenWidth,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                              children: List.generate(
                                tabTitleList.length, 
                                (index) => GestureDetector(
                                  //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                    margin: const EdgeInsets.only(right: AppSize.s30),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: 3.0, 
                                          color: tabSelectedIndex == index 
                                          ? AppColors.primaryColor 
                                          : AppColors.transparent
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: CustomText(
                                        title: tabTitleList[index],
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s16,
                                          color: tabSelectedIndex == index 
                                          ? AppColors.primaryColor 
                                          : Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: context.screenWidth * 0.18,
                          child: CustomTextField(
                            textController: TextEditingController(),
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.grey,
                            horPadding: AppSize.s20,
                            verPadding: AppSize.s10,
                            hint: AppStrings.search,
                          ),
                        ),
                        const SizedBox(width: AppSize.s10),
                        InkWell(
                          onTap: () => debugPrint(''),
                          child: const Icon(AppIcons.swapVerIcon),
                        ),
                        const SizedBox(width: AppSize.s10),
                        InkWell(
                          onTap: () => debugPrint(''),
                          child: const Icon(AppIcons.tuneIcon),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ////Order Hub View
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(AppSize.s20),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: List.generate(
                                subTabTitleList.length, 
                                (index) {
                                  return Container(
                                    margin: const EdgeInsets.only(right: AppSize.s20),
                                    padding: const EdgeInsets.symmetric(
                                      vertical: AppSize.s5,
                                      horizontal: AppSize.s10
                                    ),
                                    color: Helper.isDark 
                                    ? AppColors.headerColorDark
                                    : AppColors.white,
                                    child: CustomText(
                                      title: subTabTitleList[index],
                                      textStyle: getRegularStyle(
                                        fontSize: AppSize.s14,
                                        color: Helper.isDark
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  );
                                }
                              )
                            ),
                            const SizedBox(height: AppSize.s40),
                            Container(
                              color: AppColors.transparent,
                              padding: const EdgeInsets.symmetric(
                                vertical: AppSize.s15,
                                horizontal: AppSize.s8
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: CustomText(
                                      title: 'Order Id', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: CustomText(
                                      title: 'Name', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: CustomText(
                                      title: 'Cost', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: CustomText(
                                      title: 'Status', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: CustomText(
                                      title: 'Qty', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: CustomText(
                                      title: '', 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: AppSize.s15),
                            Expanded(
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: 6,
                                padding: EdgeInsets.zero,
                                itemBuilder: (_, index){
                                  return Container(
                                    color: index%2 == 1 
                                    ? AppColors.transparent 
                                    : Helper.isDark 
                                      ? AppColors.headerColorDark 
                                      : AppColors.white,
                                    padding: const EdgeInsets.symmetric(
                                      vertical: AppSize.s15,
                                      horizontal: AppSize.s8
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: CustomText(
                                            title: '#25645', 
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s12,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'John Doe', 
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s12,
                                              color: Helper.isDark ? AppColors.white : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: '\$200', 
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s12,
                                              color: Helper.isDark ? AppColors.white : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: 'Deliver by 12:35 PM', 
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s12,
                                              color: Helper.isDark ? AppColors.white : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: '4', 
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s12,
                                              color: Helper.isDark ? AppColors.white : AppColors.black
                                            )
                                          )
                                        ),
                                        Expanded(
                                          child: Align(
                                            alignment: Alignment.centerLeft,
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(
                                                horizontal: AppSize.s10,
                                                vertical: AppSize.s5
                                              ),
                                              decoration: BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius: BorderRadius.circular(AppSize.s8)
                                              ),
                                              child: CustomText(
                                                title: 'Select',
                                                textStyle: getRegularStyle(color: AppColors.white),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: AppSize.s40),
                      Container(
                        width: context.screenWidth * 0.20, 
                        color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                        padding: const EdgeInsets.all(AppSize.s15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              title: 'Selected Order', 
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s16,
                                color: Helper.isDark ? AppColors.white : AppColors.black
                              ),
                            ),
                            const SizedBox(height: AppSize.s20),
                            CustomText(
                              title: 'John Doe', 
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark ? AppColors.white : AppColors.black
                              ),
                            ),
                            const SizedBox(height: AppSize.s12),
                            CustomText(
                              title: 'Pick up at 11:45 AM',
                              color: Helper.isDark ? AppColors.white : AppColors.black,
                            ),
                            const SizedBox(height: AppSize.s10),
                            CustomText(
                              title: '#25645',
                              color: Helper.isDark ? AppColors.white : AppColors.black,
                            ),
                            const SizedBox(height: AppSize.s30),
                            Expanded(
                              child: ListView.separated(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: 3,
                                itemBuilder: (_, index){
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: AppSize.s18, top: AppSize.s15),
                                    padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(AppSize.s12),
                                          decoration: const BoxDecoration(
                                            color: AppColors.primaryColor,
                                            shape: BoxShape.circle
                                          ),
                                          child: const CustomImageView(
                                            imagePath: AppImages.orangeJuice,
                                            color: AppColors.white,
                                          ),
                                        ),
                                        const SizedBox(width: AppSize.s15),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                title: 'Apple Juice',
                                                textStyle: getMediumStyle(
                                                  fontSize: AppSize.s16,
                                                  color: Helper.isDark ? AppColors.white : AppColors.black,
                                                ),
                                              ),
                                              const SizedBox(height: AppSize.s10),
                                              CustomText(
                                                title: '\$ 2.29',
                                                textStyle: getMediumStyle(
                                                  fontSize: AppSize.s18,
                                                  color: AppColors.grey.withOpacity(0.9)
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                                separatorBuilder: (_, index) => const Divider(
                                  color: AppColors.grey, 
                                  height: AppSize.s1, 
                                  thickness: AppSize.s1
                                ),
                              ),
                            ),
                            const SizedBox(height: AppSize.s30),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: AppStrings.total,
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: '\$4500',
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: AppSize.s30),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: CustomOutlinedButton(
                                    onPressed: () => debugPrint('Click here to cancel here'),
                                    text: AppStrings.cancel,
                                    textColor: AppColors.primaryColor
                                  ),
                                ),
                                const SizedBox(width: AppSize.s10),
                                Expanded(
                                  child: CustomSolidButton(
                                    onPressed: () => debugPrint('Click here to submit'),
                                    text: AppStrings.accept,
                                    verPadding: AppSize.s12,
                                    horPadding: AppSize.s18,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}