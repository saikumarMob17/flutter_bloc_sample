sealed class OrderHubState {}

class OrderHubInitialState extends OrderHubState {}