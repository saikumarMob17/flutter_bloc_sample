import 'package:cliqtechnologies_retl/features/order_hub/presentation/bloc/order_hub_event.dart';
import 'package:cliqtechnologies_retl/features/order_hub/presentation/bloc/order_hub_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class OrderHubBloc extends Bloc<OrderHubEvent, OrderHubState>{

  OrderHubBloc() : super(OrderHubInitialState());
}