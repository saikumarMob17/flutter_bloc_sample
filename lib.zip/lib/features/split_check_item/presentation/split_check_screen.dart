import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../constants/app_icons.dart';
import 'split_item_quantity_dialog.dart';
import 'bloc/split_check_bloc.dart';
import 'bloc/split_check_state.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../orders/domain/order_model.dart';
import 'bloc/split_check_event.dart';

class SplitCheckScreen extends StatefulWidget {
  
  const SplitCheckScreen({super.key});

  @override
  State createState() => _SplitCheckScreenState();
}

class _SplitCheckScreenState extends State<SplitCheckScreen> with Helper {

  List<List<OrderModel>> orderList = [];
  String tableName = "";
  String customerName = '';
  int checkIndex = -1;
  late SplitCheckBloc _splitCheckBloc;

  @override
  void initState() {
    _splitCheckBloc = context.read<SplitCheckBloc>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.black 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<SplitCheckBloc, SplitCheckState>(
        builder: (context, state) {
          switch (state) {
            case OnSelectCheckItemState _:
              checkIndex = state.checkIndex;
              break;
            case OnSplitCheckState _:
              orderList.clear();
              orderList.addAll(state.orderList);
              checkIndex = state.checkIndex;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case SplitCheckSuccessState _:
              hideLoadingDialog(context: context);
              context.pop(orderList);
              break;
            case SplitCheckLoadingState _:
              showLoadingDialog(context: context);
              break;
            case OnSwitchUserSplitCheckState _:
              hideLoadingDialog(context: context);
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            case SplitCheckFailedState _:
              if(!state.msg.isBlank){
                showSnackBar(context: context, title: state.msg);
              }
              break;
            case OnFetchProductDetailsState _:
              tableName = state.tableName;
              customerName = state.customerName;
              orderList.clear();
              orderList.addAll(state.orderList);
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () => context.pop(),
                  icon: const Icon(Icons.west)
                ),
                CustomText(
                  title: AppStrings.splitItems,
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s18,
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ),
              ],
            ),
            Row(
              children: [
                IconButton(
                  onPressed: () => _splitCheckBloc.add(OnSubmitSplitCheckEvent()), 
                  icon: const Icon(
                    Icons.done, 
                    color: AppColors.primaryColor
                  ),
                ),
                CustomImageView(
                  imagePath: AppImages.switchIcon,
                  height: AppSize.s24,
                  width: AppSize.s24,
                  onTap: () => debugPrint('go to cart screen'),
                  color: Helper.isDark
                  ? AppColors.white
                  : AppColors.black
                ),
                const SizedBox(width: AppSize.s8),
                CustomImageView(
                  imagePath: AppImages.menuVertical,
                  height: AppSize.s24,
                  width: AppSize.s24,
                  onTap: () => debugPrint('go to more options'),
                  color: Helper.isDark
                  ? AppColors.white
                  : AppColors.black
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: AppSize.s10),
        Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.5,
              mainAxisSpacing: AppSize.s6,
              crossAxisSpacing: AppSize.s6
            ), 
            shrinkWrap: true,
            itemCount: orderList.length + 2,
            itemBuilder: (_, index){
              return index == (orderList.length + 2) - 1
              ? Container(
                  padding: const EdgeInsets.all(AppSize.s10),
                  width: context.screenWidth * 0.22,
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    border: Border.all(style: BorderStyle.solid, color: AppColors.black)
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(AppIcons.qrCodeIcon, color: AppColors.primaryColor, size: AppSize.s28),
                        const SizedBox(height: AppSize.s5),
                        CustomText(
                          title: AppStrings.lookupCheck, 
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s14,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : index == (orderList.length + 2) - 2
              ? Container(
                  padding: const EdgeInsets.all(AppSize.s10),
                  width: context.screenWidth * 0.22,
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    border: Border.all(style: BorderStyle.solid, color: AppColors.black),
                  ),
                  child: Center(
                    child: InkWell(
                      onTap: () => context.read<SplitCheckBloc>().add(OnSplitCheckEvent(checkIndex: index)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(AppIcons.addCircleIcon, color: AppColors.primaryColor, size: AppSize.s28),
                          const SizedBox(height: AppSize.s5),
                          CustomText(
                            title: AppStrings.newCheck, 
                            textStyle: getRegularStyle(
                              fontSize: AppSize.s14,
                              color: Helper.isDark 
                              ? AppColors.white 
                              : AppColors.black
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              : Container(
                padding: const EdgeInsets.all(AppSize.s10),
                width: context.screenWidth * 0.22,
                decoration: BoxDecoration(
                  color: Helper.isDark
                  ? AppColors.contentColorDark
                  : AppColors.white,
                  borderRadius: BorderRadius.circular(AppSize.s10)
                ),
                child: Stack(
                  children: [
                    Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s10,
                            vertical: AppSize.s5
                          ),
                          decoration: const BoxDecoration(
                            color: AppColors.primaryColor,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(AppSize.s5),
                              topRight: Radius.circular(AppSize.s5)
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: '#${index+1}', color: AppColors.white),
                              CustomText(title: 'Table : $tableName', color: AppColors.white),
                              CustomText(title: customerName, color: AppColors.white)
                            ],
                          ),
                        ),
                        Expanded(
                          child: ListView.separated(
                            shrinkWrap: true,
                            itemCount: orderList[index].length,
                            itemBuilder: (_, subIndex) {
                              var data = orderList[index][subIndex];
                              return Container(
                                padding: const EdgeInsets.only(
                                  left: AppSize.s4,
                                  right: AppSize.s8,
                                  top: AppSize.s8,
                                  bottom: AppSize.s8
                                ),
                                color: Helper.isDark
                                ? subIndex%2 == 0 ? AppColors.transparent : AppColors.backgroundColorDark
                                : subIndex%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Row(
                                        children: [
                                          CustomCheckBox(
                                            value: orderList[index][subIndex].isSelected,
                                            onChange: (value) => context.read<SplitCheckBloc>().add(OnSelectCheckItemEvent(
                                              itemIndex: subIndex, 
                                              checkIndex: index, 
                                              isSelected: value!
                                            )),
                                          ),
                                          const SizedBox(width: AppSize.s4),
                                          Expanded(
                                            child: CustomText(
                                              title: data.title,
                                              maxLines: 1,
                                              textOverflow: TextOverflow.ellipsis,
                                              color: Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: AppSize.s4),
                                    CustomText(
                                      title: data.quantity.toString(), 
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ],
                                ),
                              );
                            },
                            separatorBuilder: (_, index) => Divider(
                              thickness: AppSize.s1, 
                              height: AppSize.s1,
                              color: Helper.isDark
                              ? AppColors.grey
                              : AppColors.white,
                            ), 
                          ),
                        ),
                      ],
                    ),
                    Visibility(
                      visible: checkIndex.isNegative
                      ? false
                      : checkIndex == index ? false : true,
                      child: Container(
                        color: AppColors.black.withOpacity(0.2),
                        child: Center(
                          child: InkWell(
                            onTap: () => context.read<SplitCheckBloc>().add(OnSplitCheckEvent(checkIndex: index)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  AppIcons.addCircleIcon, 
                                  color: AppColors.primaryColor, 
                                  size: AppSize.s28
                                ),
                                const SizedBox(height: AppSize.s5),
                                CustomText(
                                  title: AppStrings.clickHereToAddItem, 
                                  textAlign: TextAlign.center,
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }
          ),
        ),
      ],
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.backgroundColorDark 
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.splitCheckItem,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s20,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                             CustomOutlinedButton(
                              onPressed: () => _splitCheckBloc.add(OnSubmitSplitCheckEvent()),
                              text: AppStrings.done,
                              textColor: AppColors.blue,
                              preFixWidget: const Icon(
                                AppIcons.rightCheckOutlineIcon, 
                                color: AppColors.blue
                              ),
                            ),
                            const SizedBox(width: AppSize.s8),
                            CustomSolidButton(
                              onPressed: () => _splitCheckBloc.add(OnSwitchUserSplitCheckEvent()),
                              text: AppStrings.switchUser,
                              prefix: const Icon(
                                Icons.swap_horiz_rounded, 
                                color: AppColors.white
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(AppSize.s15),
                  width: double.maxFinite,
                  height: double.maxFinite,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: orderList.where((element) => element.isNotEmpty).toList().length + 2,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (_, index) {
                      return index == (orderList.where((element) => element.isNotEmpty).toList().length + 2) - 1
                      ///Lookup Check 
                      ? Container(
                          padding: const EdgeInsets.all(AppSize.s10),
                          width: context.screenWidth * 0.22,
                          margin: const EdgeInsets.only(right: AppSize.s15),
                          decoration: BoxDecoration(
                            color: Helper.isDark
                            ? AppColors.contentColorDark
                            : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10),
                            border: Border.all(
                              style: BorderStyle.solid, 
                              color: AppColors.grey,
                              width: 0.8
                            ),
                          ),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(AppIcons.qrCodeIcon, color: AppColors.primaryColor, size: AppSize.s30),
                                const SizedBox(height: AppSize.s5),
                                CustomText(
                                  title: AppStrings.lookupCheck, 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : index == (orderList.where((element) => element.isNotEmpty).toList().length + 2) - 2
                      ///New Check 
                      ? Container(
                          padding: const EdgeInsets.all(AppSize.s10),
                          margin: const EdgeInsets.only(right: AppSize.s15),
                          width: context.screenWidth * 0.22,
                          decoration: BoxDecoration(
                            color: Helper.isDark
                            ? AppColors.contentColorDark
                            : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10),
                            border: Border.all(
                              style: BorderStyle.solid, 
                              color: AppColors.grey, 
                              width: 0.8
                            ),
                          ),
                          child: Center(
                            child: InkWell(
                              onTap: () => _splitCheckBloc.add(OnSplitCheckEvent(checkIndex: index)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    AppIcons.addCircleIcon, 
                                    color: AppColors.primaryColor, 
                                    size: AppSize.s30
                                  ),
                                  const SizedBox(height: AppSize.s5),
                                  CustomText(
                                    title: AppStrings.newCheck, 
                                    textStyle: getMediumStyle(
                                      fontSize: AppSize.s16,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                        ///Existing Check
                      : Container(
                        padding: const EdgeInsets.all(AppSize.s10),
                        margin: const EdgeInsets.only(right: AppSize.s15),
                        width: context.screenWidth * 0.22,
                        decoration: BoxDecoration(
                          color: Helper.isDark
                          ? AppColors.contentColorDark
                          : AppColors.white,
                          borderRadius: BorderRadius.circular(AppSize.s10)
                        ),
                        child: Stack(
                          children: [
                            Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: AppSize.s10,
                                    vertical: AppSize.s5
                                  ),
                                  decoration: const BoxDecoration(
                                    color: AppColors.primaryColor,
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(AppSize.s5),
                                      topRight: Radius.circular(AppSize.s5)
                                    )
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(title: '#${index+1}', color: AppColors.white),
                                      CustomText(title: 'Table : $tableName', color: AppColors.white),
                                      CustomText(title: customerName, color: AppColors.white)
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: ListView.separated(
                                    shrinkWrap: true,
                                    itemCount: orderList[index].length,
                                    itemBuilder: (_, subIndex) {
                                      var data = orderList[index][subIndex];
                                      return Material(
                                        child: InkWell(
                                          onLongPress: data.quantity <= 1
                                          ? null
                                          : () => showSplitCheckByItem(
                                            orderModel: data, 
                                            splitSequence: index, 
                                            totalSplitSequence: orderList.length,
                                            subIndex: subIndex
                                          ),
                                          child: Ink(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: AppSize.s10,
                                              vertical: AppSize.s8
                                            ),
                                            color: Helper.isDark
                                            ? subIndex%2 == 0 ? AppColors.transparent : AppColors.backgroundColorDark
                                            : subIndex%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Row(
                                                  children: [
                                                    CustomCheckBox(
                                                      value: orderList[index][subIndex].isSelected,
                                                      onChange: (value) => _splitCheckBloc.add(OnSelectCheckItemEvent(
                                                        itemIndex: subIndex, 
                                                        checkIndex: index, 
                                                        isSelected: value!
                                                      )),
                                                    ),
                                                    const SizedBox(width: AppSize.s5),
                                                    CustomText(
                                                      title: data.title,
                                                      textStyle: getRegularStyle(fontWeight: FontWeight.w500)
                                                    ),
                                                  ],
                                                ),
                                                CustomText(
                                                  title: data.quantity.toString(), 
                                                  textStyle: getRegularStyle(fontWeight: FontWeight.w500)
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                    separatorBuilder: (_, index) => Divider(
                                      thickness: AppSize.s1, 
                                      height: AppSize.s1,
                                      color: Helper.isDark
                                      ? AppColors.grey
                                      : AppColors.white,
                                    ), 
                                  ),
                                ),
                              ],
                            ),
                            ///Show UI to add item to existing check
                            Visibility(
                              visible: checkIndex.isNegative
                              ? false
                              : checkIndex == index ? false : true,
                              child: Container(
                                color: Helper.isDark 
                                ? AppColors.black.withOpacity(0.5)
                                : AppColors.black.withOpacity(0.2),
                                child: Center(
                                  child: InkWell(
                                    onTap: () => _splitCheckBloc.add(OnSplitCheckEvent(checkIndex: index)),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(
                                          AppIcons.addCircleIcon, 
                                          color: AppColors.primaryColor, 
                                          size: AppSize.s30
                                        ),
                                        const SizedBox(height: AppSize.s5),
                                        CustomText(
                                          title: AppStrings.clickHereToAddItem, 
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s16,
                                            color: Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void showSplitCheckByItem({
    required OrderModel orderModel, 
    required int splitSequence,
    required int totalSplitSequence,
    required int subIndex
  }) {
    showDialog(
      context: context,
      builder: (_) {
        return SplitItemQuantityDialog(
          subIndex: subIndex,
          splitCheckBloc: _splitCheckBloc, 
          orderModel: orderModel,
          currentSplitSequence: splitSequence,
          totalSplitSequence: totalSplitSequence
        );
      }
    );
  }

}
