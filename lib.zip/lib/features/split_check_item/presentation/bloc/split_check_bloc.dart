import '../../../../network/custom_exception.dart';
import '../../../../routes/route.dart';
import '../../../payment/domain/payment_request_model.dart';
import '../../../payment_terminal/domain/payment_terminal_response.dart' as payment_terminal;
import '../../data/split_repository.dart';
import '../../../../utils/app_extension_method.dart';
import '../../../../utils/check_connectivity.dart';
import 'split_check_event.dart';
import 'split_check_state.dart';
import '../../../orders/domain/order_model.dart';

class SplitCheckBloc extends Bloc<SplitCheckEvent, SplitCheckState>{

  final PaymentModel paymentDetails;
  late SplitRepository _splitRepository;
  late CheckConnectivity _checkConnectivity;

  List<List<OrderModel>> orderList = [];
  String tableName = '';
  String customerName = '';

  SplitCheckBloc({required this.paymentDetails}) : super(SplitCheckInitialState()) {
    _checkConnectivity = CheckConnectivity();
    _splitRepository = SplitRepository();
    on<OnSelectCheckItemEvent>(_onSelectCheckItem);
    on<OnSplitCheckEvent>(_onSplitCheck);
    on<OnSubmitSplitCheckEvent>(_onSubmitSplitCheck);
    on<OnSwitchUserSplitCheckEvent>(_onSwitchUser);
    on<OnChangeQuantityDropdownItemEvent>(_onChangeQuantity);
    on<OnChangeSplitDropdownItemEvent>(_onChangeSplit);
    on<OnSplitNewSequenceEvent>(_onSplitNewSequence);
    on<OnFetchProductDetailsEvent>(_onFetchProductDetailsEvent);
    on<OnSplitItemByQuantityEvent>(_onSplitItemByQuantity);
  }

  void _onSplitItemByQuantity(OnSplitItemByQuantityEvent event, Emitter emit) {
    if(event.isCreateNewSequence || (event.splitNumber != event.index)) {
      if(event.orderModel.quantity == event.quantity) {
        var tempCheckIndex = event.isCreateNewSequence ? orderList.length : event.splitNumber; 
        orderList[event.index][event.subIndex].isSelected = false;
        if(orderList.length == tempCheckIndex) {
          var temp = orderList[event.index][event.subIndex];
          orderList.add([temp]);
          orderList[event.index].removeAt(event.subIndex);
          orderList.removeWhere((element) => element.isEmpty);
        } else {
          _addItemToExistingSequence(checkIndex: tempCheckIndex, event: event);
          orderList[event.index].removeAt(event.subIndex);
          orderList.removeWhere((element) => element.isEmpty);
        }
      } else {
        var tempCheckIndex = event.isCreateNewSequence ? orderList.length : event.splitNumber;
        orderList[event.index][event.subIndex].quantity -= event.quantity;
        orderList[event.index][event.subIndex].isSelected = false;
        if(orderList.length == tempCheckIndex) {
          var temp = orderList[event.index][event.subIndex];
          var newOrderModel = OrderModel(
            imagePath: temp.imagePath,
            isSelected: false,
            itemId: temp.itemId,
            itemMaxQuantity: temp.itemMaxQuantity,
            price: temp.price,
            quantity: event.quantity,
            totalPrice: temp.totalPrice,
            title: temp.title
          );
          orderList.add([newOrderModel]);
        } else {
          _addItemToExistingSequence(checkIndex: tempCheckIndex, event: event);
        }
      }
      emit(OnSplitCheckState(checkIndex: -1, orderList: orderList));
    } else {
      emit(SplitCheckFailedState(msg: 'Please select valid check sequence or create new sequence to split item'));
    }
  }

  void _addItemToExistingSequence({required int checkIndex, required OnSplitItemByQuantityEvent event}) {
    bool itemPresentInDestinationSequence = false;
    for(var item in orderList[checkIndex]) {
      if(item.itemId == orderList[event.index][event.subIndex].itemId) {
        item.quantity += event.quantity;
        itemPresentInDestinationSequence = true;
        break;
      }
    }
    if(!itemPresentInDestinationSequence) {
      var temp = orderList[event.index][event.subIndex];
      var newOrderModel = OrderModel(
        imagePath: temp.imagePath,
        isSelected: false,
        itemId: temp.itemId,
        itemMaxQuantity: temp.itemMaxQuantity,
        price: temp.price,
        quantity: event.quantity,
        totalPrice: temp.totalPrice,
        title: temp.title
      );
      orderList[checkIndex].add(newOrderModel);
    }
  }

  void _onFetchProductDetailsEvent(OnFetchProductDetailsEvent event, Emitter emit) {
    tableName = paymentDetails.tableName;
    customerName = paymentDetails.customerName;
    orderList.clear();
    orderList.add([...paymentDetails.orderedItem]);
    emit(OnFetchProductDetailsState(orderList: orderList, tableName: tableName, customerName: customerName));
  }

  void _onSplitNewSequence(OnSplitNewSequenceEvent event, Emitter emit) {
    emit(OnSplitNewSequenceState(splitNewSequence: event.splitNewSequence));
  }

  void _onChangeQuantity(OnChangeQuantityDropdownItemEvent event, Emitter emit) {
    emit(OnChangeQuantityDropdownItemState(selectedItem: event.selectedItem));
  }

  void _onChangeSplit(OnChangeSplitDropdownItemEvent event, Emitter emit) {
    emit(OnChangeSplitDropdownItemState(selectedItem: event.selectedItem));
  }

  void _onSelectCheckItem(OnSelectCheckItemEvent event, Emitter emit) {
    int checkIndex = -1;
    if(orderList.isNotEmpty) {
      orderList[event.checkIndex][event.itemIndex].isSelected = event.isSelected;
      if(orderList.any((element) => element.any((element) => element.isSelected))) {
        checkIndex = event.checkIndex;
      }
    }
    emit(OnSelectCheckItemState(checkIndex: checkIndex));
  }

  void _onSplitCheck(OnSplitCheckEvent event, Emitter emit) {
    if(orderList.any((element) => element.any((element) => element.isSelected))) {
      var tempOrderList = <OrderModel>[];
      for(var item in orderList) {
        var temp = item.where((element) => element.isSelected).toList();
        if(temp.isNotEmpty) {
          tempOrderList.addAll(temp);
        }
        item.removeWhere((element) => element.isSelected);
      }
      for(var item in tempOrderList) {
        item.isSelected = false;
      }
      if(orderList.length == event.checkIndex) {
        orderList.add([]);
        orderList[event.checkIndex].addAll(tempOrderList);
      } else {
        for (var i = 0; i < tempOrderList.length; i++) {
          var tempOrder = tempOrderList[i];
          bool isPresent = false;
          for (var j = 0; j < orderList[event.checkIndex].length; j++) {
            if(orderList[event.checkIndex][j].itemId == tempOrder.itemId) {
              orderList[event.checkIndex][j].quantity += tempOrder.quantity;
              isPresent = true;
              break;
            }
          } 
          if(!isPresent) {
            orderList[event.checkIndex].add(tempOrder);
          }
        }
      }
      orderList.removeWhere((element) => element.isEmpty);
      emit(OnSplitCheckState(checkIndex: -1, orderList: orderList));
    }
  }

  Future<void> _onSubmitSplitCheck(OnSubmitSplitCheckEvent event, Emitter emit) async {
    try {
      List<CheckDetails> checkDetails = [];
      var checkSequence = 1;
      var totalSubTotal = 0.0;
      for(var item in orderList) {
        if(item.isNotEmpty) {
          var splitItems = <SplitItem>[];
          double subTotal = 0.0;
          for(var subItem in item) {
            splitItems.add(SplitItem(
              productId: subItem.itemId, 
              productName: subItem.title, 
              quantity: subItem.quantity, 
              productPrice: subItem.price
            ));
            subTotal+=(subItem.quantity * subItem.price);
          }
          subTotal = subTotal.roundTwo;
          double tax = (subTotal * 10) / 100;
          tax = tax.roundTwo;
          double grandTotal = (subTotal + tax).roundTwo;
          checkDetails.add(CheckDetails(
            customerName: paymentDetails.customerName,
            customerIdentity: paymentDetails.customerIdentity,
            checkSequence: checkSequence, 
            splitItems: splitItems, 
            subBillingDetails: SubBillingDetails(
              discount: 0.0,
              subTotal: subTotal,
              tip: 0.0,
              tax: tax,
              grandTotal: grandTotal,
              paymentStatus: false,
              balanceDue: grandTotal
            )
          ));
          totalSubTotal+=subTotal;
          checkSequence+=1;
        }
      }
      
      var totalTax = (totalSubTotal * 10) / 100;
      totalTax = totalTax.roundTwo;
      double totalGrandTotal = (totalSubTotal + totalTax).roundTwo;
      var totalBillingDetails = payment_terminal.BillingDetails(
        subTotal: totalSubTotal, 
        discount: 0.0, 
        tax: totalTax, 
        tip: 0.0, 
        grandTotal: totalGrandTotal, 
        paymentStatus: false, 
        balanceDue: totalGrandTotal
      );

      var paymentRequestModel = PaymentRequestModel(
        orderId: paymentDetails.orderId,
        customerId: paymentDetails.customerId, 
        paymentStatus: false, 
        totalBillingDetails: totalBillingDetails, 
        checkDetails: checkDetails,
        isPreAuth: paymentDetails.isPreAuth
      ).toJson; 

      if(await _checkConnectivity.hasConnection){
        emit(SplitCheckLoadingState());
        var response = await _splitRepository.onSplitCheckByItem(payload: paymentRequestModel);
        if(response.isNotEmpty){
          emit(SplitCheckSuccessState(msg: response['status']));
        } else{
          emit(SplitCheckFailedState(msg: "Unable to split items"));
        }
      } else {
        emit(SplitCheckFailedState(msg: AppStrings.noInternetConnection));
      }
    } on CustomException catch (e) {
      debugPrint(e.message);
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserSplitCheckEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(SplitCheckLoadingState());
        var response = await _splitRepository.onClockOutUser();
        emit(OnSwitchUserSplitCheckState(isLogout: response));
      } on CustomException catch (e) {
        emit(SplitCheckFailedState(msg: e.message));
      }
    }
  }

}
