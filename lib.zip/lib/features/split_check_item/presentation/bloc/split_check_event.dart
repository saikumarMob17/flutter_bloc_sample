import '../../../payment/domain/payment_model.dart';
import '../../../orders/domain/order_model.dart';

sealed class SplitCheckEvent {}

class OnSelectCheckItemEvent extends SplitCheckEvent {
  int itemIndex;
  int checkIndex;
  bool isSelected;

  OnSelectCheckItemEvent({
    required this.itemIndex, 
    required this.checkIndex,
    required this.isSelected
  });
}

class OnSplitCheckEvent extends SplitCheckEvent {
  int checkIndex;
  OnSplitCheckEvent({required this.checkIndex});
}

class OnSubmitSplitCheckEvent extends SplitCheckEvent {}

class OnFetchProductDetailsEvent extends SplitCheckEvent {}


class OnSwitchUserSplitCheckEvent extends SplitCheckEvent {}

class OnChangeQuantityDropdownItemEvent extends SplitCheckEvent {
  int selectedItem;

  OnChangeQuantityDropdownItemEvent({this.selectedItem = -1});
}

class OnChangeSplitDropdownItemEvent extends SplitCheckEvent {
  int selectedItem;

  OnChangeSplitDropdownItemEvent({this.selectedItem = -1});
}

class OnSplitNewSequenceEvent extends SplitCheckEvent {
  bool splitNewSequence;

  OnSplitNewSequenceEvent({this.splitNewSequence = false});
}

class OnSplitItemByQuantityEvent extends SplitCheckEvent {
  int quantity;
  int splitNumber;
  bool isCreateNewSequence;
  int subIndex;
  int index;
  final OrderModel orderModel;

  OnSplitItemByQuantityEvent({
    required this.quantity,
    required this.subIndex,
    required this.index,
    required this.orderModel,
    this.splitNumber = -1,
    this.isCreateNewSequence = false
  });
}


