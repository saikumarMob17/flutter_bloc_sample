import '../../../orders/domain/order_model.dart';

abstract class SplitCheckState {}

class SplitCheckInitialState extends SplitCheckState {}

class OnSelectCheckItemState extends SplitCheckState {
  int checkIndex;

  OnSelectCheckItemState({
    this.checkIndex = -1
  });

}

class OnFetchProductDetailsState extends SplitCheckState {
  List<List<OrderModel>> orderList = [];
  String tableName;
  String customerName;
  OnFetchProductDetailsState({required this.orderList, this.customerName = '', this.tableName = ''});
}

class OnSplitCheckState extends SplitCheckState {
  List<List<OrderModel>> orderList = [];
  int checkIndex;
  OnSplitCheckState({required this.orderList, required this.checkIndex});
}

class OnSubmitSplitCheckState extends SplitCheckState {}

class SplitCheckSuccessState extends SplitCheckState {
  String msg;

  SplitCheckSuccessState({required this.msg});
}

class SplitCheckFailedState extends SplitCheckState {
  String msg;

  SplitCheckFailedState({required this.msg});
}

class SplitCheckLoadingState extends SplitCheckState {}

class OnSwitchUserSplitCheckState extends SplitCheckState {
  bool isLogout;

  OnSwitchUserSplitCheckState({this.isLogout = false});
}

class OnChangeQuantityDropdownItemState extends SplitCheckState {
  int selectedItem;

  OnChangeQuantityDropdownItemState({this.selectedItem = -1});
}

class OnChangeSplitDropdownItemState extends SplitCheckState {
  int selectedItem;

  OnChangeSplitDropdownItemState({this.selectedItem = -1});
}

class OnSplitNewSequenceState extends SplitCheckState {
  bool splitNewSequence;

  OnSplitNewSequenceState({this.splitNewSequence = false});
}