import '../../../routes/route.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import 'bloc/split_check_event.dart';
import 'bloc/split_check_state.dart';
import '../../../utils/app_extension_method.dart';
import '../../orders/domain/order_model.dart';

class SplitItemQuantityDialog extends StatelessWidget {
  
  final SplitCheckBloc splitCheckBloc;
  final OrderModel orderModel;
  final int currentSplitSequence;
  final int totalSplitSequence;
  final int subIndex;
  
  const SplitItemQuantityDialog({
    super.key,
    required this.subIndex,
    required this.splitCheckBloc,
    required this.orderModel,
    required this.currentSplitSequence,
    required this.totalSplitSequence
  });

  @override
  Widget build(BuildContext context) {
    int quantityInitialValue = 1;
    int splitInitialValue = 1;
    bool splitNew = false;
    var quantityDropdownMenuItem = List.generate(
      orderModel.quantity,
      (index) => DropdownMenuItem<int>(
        value: index + 1, 
        child: Text('${index + 1}'),
      ),
    );
    var sequenceDropdownMenuItem = List.generate(
      totalSplitSequence,
      (index) => DropdownMenuItem<int>(
        value: index + 1, 
        enabled: index != currentSplitSequence , 
        child: Text(
          '${index + 1}', 
          style: TextStyle(
            color: index != currentSplitSequence 
            ? null
            : AppColors.grey
          ),
        ),
      ),
    );
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s10)),
      insetPadding: EdgeInsets.zero,
      contentPadding: EdgeInsets.zero,
      titlePadding: EdgeInsets.zero,
      content: Container(
        width: context.screenWidth * 0.50,
        padding: const EdgeInsets.symmetric(
          horizontal: AppSize.s18,
          vertical: AppSize.s14
        ),
        decoration: BoxDecoration(
          color: Helper.isDark
          ? AppColors.contentColorDark
          : AppColors.white,
          borderRadius: BorderRadius.circular(AppSize.s10)
        ),
        child: BlocProvider.value(
          value: splitCheckBloc,
          child: BlocConsumer<SplitCheckBloc, SplitCheckState>(
            builder: (context, state) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: 'Split Item by quantity',
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s18
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(5, 0),
                        child: IconButton(
                          onPressed: () => context.pop(), 
                          icon: const Icon(Icons.close)
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s20),
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: CustomText(
                          title: orderModel.title,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s18
                          ),
                        ),
                      ),
                      Expanded(
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            contentPadding: EdgeInsets.symmetric(horizontal: AppSize.s15),
                            border: OutlineInputBorder(),
                            label: Text('Quantity')
                          ),
                          child: DropdownButton<int>(
                            items: quantityDropdownMenuItem,
                            value: quantityInitialValue,
                            isExpanded: true,
                            isDense: true,
                            underline: const SizedBox(),
                            onChanged: (value) => splitCheckBloc.add(OnChangeQuantityDropdownItemEvent(selectedItem: value!))
                          ),
                        ),
                      ),
                      const SizedBox(width: AppSize.s15),
                      Expanded(
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            contentPadding: EdgeInsets.symmetric(horizontal: AppSize.s15),
                            border: OutlineInputBorder(),
                            label: Text('Split Number')
                          ),
                          child: DropdownButton(
                            items: sequenceDropdownMenuItem, 
                            value: splitInitialValue,
                            isExpanded: true,
                            isDense: true,
                            underline: const SizedBox(),
                            onChanged: (value) => splitCheckBloc.add(OnChangeSplitDropdownItemEvent(selectedItem: value!))
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          CustomCheckBox(
                            value: splitNew,
                            checkBoxSize: 0.9,
                            onChange: (value) => splitCheckBloc.add(OnSplitNewSequenceEvent(splitNewSequence: value!)),
                          ),
                          const CustomText(title: '  Split New', fontSize: AppSize.s16),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          CustomOutlinedButton(
                            onPressed: () => context.pop(),
                            borderColor: AppColors.red,
                            textColor: AppColors.red,
                            text: AppStrings.cancel
                          ),
                          const SizedBox(width: AppSize.s10),
                          CustomSolidButton(
                            onPressed: () {
                              splitCheckBloc.add(OnSplitItemByQuantityEvent(
                                quantity: quantityInitialValue, 
                                splitNumber: splitInitialValue - 1,  
                                isCreateNewSequence: splitNew,
                                subIndex: subIndex,
                                orderModel: orderModel,
                                index: currentSplitSequence
                              ));
                              context.pop();
                            },
                            text: AppStrings.done
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              );
            },
            listener: (context, state) {
              switch (state) {
                case OnChangeQuantityDropdownItemState _:
                  quantityInitialValue = state.selectedItem;
                  break;
                case OnChangeSplitDropdownItemState _:
                  splitInitialValue = state.selectedItem;
                  break;
                case OnSplitNewSequenceState _:
                  splitNew = state.splitNewSequence;
                  break;
                default:
              }
            },
          ),
        ),
      ),
    );
  }
}