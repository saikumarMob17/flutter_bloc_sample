import 'dart:convert';
import 'dart:io';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../../utils/helper.dart';

class SplitRepository {
  late ApiClient _apiClient;

  SplitRepository() {
    _apiClient = ApiClient();
  }

  Future<Map> onSplitCheckByItem({required Map payload}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updatePaymentStatus, body: payload);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          return jsonResponse;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}