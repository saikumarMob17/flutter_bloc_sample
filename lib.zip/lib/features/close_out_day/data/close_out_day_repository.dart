import 'dart:convert';
import 'dart:io';
import '../../../constants/app_strings.dart';
import '../../../network/api/api_client.dart';
import '../../../network/end_points.dart';
import '../../../network/custom_exception.dart';
import '../../../utils/helper.dart';
import '../domain/close_out_day_response.dart';

class CloseOutDayRepository {

  late ApiClient _apiClient;

  CloseOutDayRepository(){
    _apiClient = ApiClient();
  }

  Future<CloseOutDayDetails?> getAllCloseOutDayDetails() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.closeOutDay);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = closeOutDayResponseFromJson(response.body);
            return data.data;
          } else {
            throw CustomException(message: jsonDecode(response.body)['message']);
          }
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<CloseOutDayDetails?> getCloseOutDayByDate({required String date}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.closeOutDayByDate}?date=$date");
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = closeOutDayResponseFromJson(response.body);
            return data.data;
          } else {
            throw CustomException(message: jsonDecode(response.body)['message']);
          }
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}