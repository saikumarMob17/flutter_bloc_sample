import '../../../routes/route.dart';
import '../../../utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_text.dart';
import '../domain/close_out_day_response.dart';

class ClockInUserWidget extends StatelessWidget {
  final String date;
  final List<ClockedInEmployeeDetailList> clockedInUser;

  const ClockInUserWidget({
    super.key, 
    required this.clockedInUser,
    required this.date
  });

  @override
  Widget build(BuildContext context) {
    final screenType = context.screenWidth.screenType;
    return Container(
      width: screenType == ScreenType.mobile 
      ? context.screenWidth
      : context.screenWidth * 0.80,
      height: context.screenHeight * 0.50,
      padding: const EdgeInsets.symmetric(
        vertical: AppSize.s16,
        horizontal: AppSize.s16
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppSize.s12),
        color: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: 'Clocked-in Employees',
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16, 
                  color: Helper.isDark 
                  ? AppColors.white 
                  : AppColors.black
                ),
              ),
              IconButton(
                onPressed: () => context.pop(), 
                icon: const Icon(Icons.clear_sharp)
              )
            ],
          ),
          const SizedBox(height: AppSize.s10),
          Expanded(
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s12,
                    horizontal: AppSize.s20
                  ),
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.backgroundColorDark
                    : const Color(0xFFE3ECFF),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(AppSize.s6),
                      topRight: Radius.circular(AppSize.s6)
                    )
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: CustomText(
                          title: AppStrings.name, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          title: AppStrings.role, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          title: AppStrings.location, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          title: AppStrings.dateTime, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    children: List.generate(
                      clockedInUser.length, 
                      (index) {
                        var data = clockedInUser[index];
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s10,
                            horizontal: AppSize.s20
                          ),
                          decoration: BoxDecoration(
                            color: Helper.isDark
                            ? index%2 == 0 ?  AppColors.transparent : AppColors.contentColorDark
                            : index%2 == 0 ?  AppColors.white : AppColors.lightGrey,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: CustomText(
                                  title: data.employeeName ?? '', 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ),
                              Expanded(
                                child: CustomText(
                                  title: data.role ?? '', 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ),
                              Expanded(
                                child: CustomText(
                                  title: data.location ?? '', 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ),
                              Expanded(
                                child: CustomText(
                                  title: data.lastClockedIn == null
                                    ? ''
                                    : "$date ${data.lastClockedIn!}".convertDateTimeClockOut, 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}