import 'package:flutter/material.dart';
import '../../../utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_text.dart';

class CloseOutStatusWidget extends StatelessWidget {
  
  final int viewCount;
  final String statusTitle;
  final Function()? onClickView;

  const CloseOutStatusWidget({
    super.key, 
    required this.statusTitle,
    required this.viewCount,
    this.onClickView
  });

  @override
  Widget build(BuildContext context) {
    final screenType = context.screenWidth.screenType;
    return Container(
      width: screenType == ScreenType.mobile 
      ? context.screenWidth * 0.35
      : context.screenWidth * 0.11,
      height: screenType == ScreenType.mobile 
      ? context.screenHeight * 0.18
      : context.screenHeight * 0.21,
      margin: const EdgeInsets.only(right: AppSize.s15, bottom: AppSize.s18),
      padding: const EdgeInsets.all(AppSize.s12),
      decoration: BoxDecoration(
        color: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
        borderRadius: BorderRadius.circular(AppSize.s6),
        boxShadow: Helper.isDark 
        ? null
        : [BoxShadow(color: AppColors.grey.withOpacity(0.4), blurRadius: AppSize.s4)]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            viewCount == 0 ? Icons.check_circle : Icons.warning_rounded, 
            color: viewCount == 0 ? AppColors.green : AppColors.amber,
            size: AppSize.s28,
          ),
          const SizedBox(height: AppSize.s10),
          Expanded(
            child: CustomText(
              title: "$viewCount $statusTitle",
              maxLines: 2,
              textOverflow: TextOverflow.ellipsis,
              textStyle: getMediumStyle(
                fontSize: AppSize.s14,
                color: Helper.isDark 
                ? AppColors.white
                : AppColors.black
              ),
            ),
          ),
          const SizedBox(height: AppSize.s10),
          CustomOutlinedButton(
            text: AppStrings.view,
            textColor: AppColors.blue,
            topPadding: AppSize.s8,
            bottomPadding: AppSize.s8,
            leftPadding: AppSize.s8,
            rightPadding: AppSize.s8,
            onPressed: onClickView,
          ),
        ],
      ),
    );
  }
}