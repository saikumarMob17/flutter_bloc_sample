import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/close_out_day_details_model.dart';
import '../../../../constants/app_strings.dart';
import '../../data/close_out_day_repository.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../../network/custom_exception.dart';
part 'close_out_day_event.dart';
part 'close_out_day_state.dart';


class CloseOutDayBloc extends Bloc<CloseOutDayEvent, CloseOutDayState>{

  late CheckConnectivity _checkConnectivity;
  late CloseOutDayRepository _repository;

  CloseOutDayBloc() : super(CloseOutDayInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = CloseOutDayRepository();
    on<OnSwitchUserCloseOutDayEvent>(_onSwitchUser);
    on<CloseOutDayDetailsEvent>(_onFetchCloseOutDayDetails);
    on<CloseOutDayDetailsByDateEvent>(_onFetchCloseOutDayDetailsByDate);
  }

  Future<void> _onSwitchUser(OnSwitchUserCloseOutDayEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(CloseOutDayLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserCloseOutDayState(isLogout: response));
      } on CustomException catch (e) {
        emit(CloseOutDayFailedState(message: e.message));
      }
    }
  }

  Future<void> _onFetchCloseOutDayDetailsByDate(CloseOutDayDetailsByDateEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        var selectedDate = event.selectedDate.toString().toString().substring(0,11);
        emit(CloseOutDayLoadingState());
        var closeOutData = await _repository.getCloseOutDayByDate(date: selectedDate);
        if(closeOutData != null){
          emit(CloseOutDayDetailsState(
              closeOutDayDetails: CloseOutDayDetailsModel(
              openCheckCount: closeOutData.unpaidCheckCount ?? 0,
              clockedInEmployeeCount: closeOutData.clockedInEmployees ?? 0,
              totalNetSales: closeOutData.totalNetSales ?? 0.0,
              tax: closeOutData.tax ?? 0.0,
              totalPayment: closeOutData.totalPayment ?? 0.0,
              openCheckDetails: closeOutData.unpaidChecksDetails ?? [], 
              clockedInEmployeeDetails: closeOutData.clockedInEmployeeDetailList ?? [],
              dateTime: closeOutData.dateTime
            )
          ));
        } else {
          emit(CloseOutDayDetailsState(closeOutDayDetails: CloseOutDayDetailsModel(openCheckDetails: [], clockedInEmployeeDetails: [])));
        }
      } on CustomException catch(e) {
        emit(CloseOutDayFailedState(message: e.message));
      }
    } else {
      emit(CloseOutDayFailedState(message: AppStrings.noInternetConnection));
    }
  }
  
  Future<void> _onFetchCloseOutDayDetails(CloseOutDayDetailsEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(CloseOutDayLoadingState());
        var closeOutData = await _repository.getAllCloseOutDayDetails();
        if(closeOutData != null){
          emit(CloseOutDayDetailsState(
              closeOutDayDetails: CloseOutDayDetailsModel(
              openCheckCount: closeOutData.unpaidCheckCount ?? 0,
              clockedInEmployeeCount: closeOutData.clockedInEmployees ?? 0,
              totalNetSales: closeOutData.totalNetSales ?? 0.0,
              tax: closeOutData.tax ?? 0.0,
              totalPayment: closeOutData.totalPayment ?? 0.0,
              openCheckDetails: closeOutData.unpaidChecksDetails ?? [], 
              clockedInEmployeeDetails: closeOutData.clockedInEmployeeDetailList ?? [],
              dateTime: closeOutData.dateTime
            )
          ));
        } else {
          emit(CloseOutDayDetailsState(closeOutDayDetails: CloseOutDayDetailsModel(openCheckDetails: [], clockedInEmployeeDetails: [])));
        }
      } on CustomException catch(e) {
        emit(CloseOutDayFailedState(message: e.message));
      }
    } else {
      emit(CloseOutDayFailedState(message: AppStrings.noInternetConnection));
    }
  }
}