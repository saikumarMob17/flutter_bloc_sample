part of 'close_out_day_bloc.dart';

sealed class CloseOutDayEvent {}

class OnSwitchUserCloseOutDayEvent extends CloseOutDayEvent {}

class CloseOutDayDetailsEvent extends CloseOutDayEvent {}

class CloseOutDayDetailsByDateEvent extends CloseOutDayEvent {
  DateTime selectedDate;

  CloseOutDayDetailsByDateEvent({required this.selectedDate});
}