part of 'close_out_day_bloc.dart';

sealed class CloseOutDayState {}

class CloseOutDayInitialState extends CloseOutDayState {}

class CloseOutDayLoadingState extends CloseOutDayState {}

class CloseOutDayFailedState extends CloseOutDayState {
  String message;
  CloseOutDayFailedState({this.message = ''});
}

class OnSwitchUserCloseOutDayState extends CloseOutDayState {
  bool isLogout;
  OnSwitchUserCloseOutDayState({this.isLogout = false});
}

class CloseOutDayDetailsState extends CloseOutDayState {
  CloseOutDayDetailsModel closeOutDayDetails;

  CloseOutDayDetailsState({required this.closeOutDayDetails});
}