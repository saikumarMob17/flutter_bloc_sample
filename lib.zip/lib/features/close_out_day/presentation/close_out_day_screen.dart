import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_icon_button.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'bloc/close_out_day_bloc.dart';
import '../domain/close_out_day_details_model.dart';
import 'clocked_in_user_widget.dart';
import 'close_out_status_widget.dart';
import 'open_check_widget.dart';
import '../../../widgets/custom_empty_widget.dart';
import '../../../widgets/icon_title_model.dart';
import '../domain/close_out_day_response.dart';

class CloseOutDayScreen extends StatefulWidget {

  const CloseOutDayScreen({super.key});

  @override
  State createState() => _CloseOutDayScreenState();
}

class _CloseOutDayScreenState extends State<CloseOutDayScreen> with Helper {

  var currentStatusTagList = <IconTitleModel>[];
  late DateTime initialDate;
  bool isLoading = true;
  CloseOutDayDetailsModel? closeOutDayDetails;

  @override
  void initState() {
    initialDate = DateTime.now().subtract(const Duration(days: 1));
    currentStatusTagList.add(IconTitleModel(title: 'Unpaid Checks', icon: Icons.check_circle, color: AppColors.green));
    currentStatusTagList.add(IconTitleModel(title: 'Clocked-in employees', icon: Icons.warning, color: AppColors.amber));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<CloseOutDayBloc, CloseOutDayState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case CloseOutDayDetailsState:
              state = state as CloseOutDayDetailsState;
              closeOutDayDetails = null;
              closeOutDayDetails = state.closeOutDayDetails;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state.runtimeType) {
            case CloseOutDayDetailsState:
              isLoading = false;
              hideLoadingDialog(context: context);
              break;
            case CloseOutDayLoadingState:
              showLoadingDialog(context: context);
              break;
            case CloseOutDayFailedState:
              isLoading = false;
              hideLoadingDialog(context: context);
              state = state as CloseOutDayFailedState;
              if(state.message.isNotEmpty) {
                showSnackBar(context: context, title: state.message);
              }
              break;
            case OnSwitchUserCloseOutDayState:
              hideLoadingDialog(context: context);
              state = state as OnSwitchUserCloseOutDayState;
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.closeOutDay,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.printIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s10),
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => context.read<CloseOutDayBloc>().add(OnSwitchUserCloseOutDayEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s10),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => showMoreOption(context: context),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s30),
          Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                CustomText(
                  title: AppStrings.currentStatus,
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s16, 
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ),
                const SizedBox(height: AppSize.s12),
                Row(
                  children: [
                    CloseOutStatusWidget(
                      statusTitle: "Unpaid Checks", 
                      viewCount: closeOutDayDetails == null 
                      ? 0
                      : closeOutDayDetails!.openCheckCount,
                      onClickView: closeOutDayDetails == null || closeOutDayDetails!.openCheckDetails.isEmpty
                      ? null
                      : () => showOpenCheckDetails(openCheckList: closeOutDayDetails!.openCheckDetails),
                    ),
                    CloseOutStatusWidget(
                      statusTitle: "Clocked-in employees", 
                      viewCount: closeOutDayDetails == null 
                      ? 0
                      : closeOutDayDetails!.clockedInEmployeeCount,
                      onClickView: closeOutDayDetails == null || closeOutDayDetails!.clockedInEmployeeDetails.isEmpty
                      ? null
                      : () => showClockedInUser(
                        clockedInUser: closeOutDayDetails!.clockedInEmployeeDetails,
                        date: closeOutDayDetails!.dateTime.toString().substring(0,10)
                      ),
                    )
                  ],
                ),
                const SizedBox(height: AppSize.s10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'z Index',
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16, 
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black
                      ),
                    ),
                    CustomText(
                      title: closeOutDayDetails == null || closeOutDayDetails!.dateTime == null
                      ? ''
                      : Helper.getDayFormattedDate(dateTime: closeOutDayDetails!.dateTime),
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s20),
                Container(
                  padding: const EdgeInsets.all(AppSize.s15),
                  decoration: BoxDecoration(
                    color:  Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: 'Sales and Taxes Summary',
                        textStyle: getMediumStyle(
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s5),
                      Container(
                        height: AppSize.s2,
                        color: AppColors.primaryColor,
                        width: AppSize.s45,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: 'Total Net Sales',
                              textStyle: getRegularStyle(fontSize: AppSize.s14) 
                            ),
                            CustomText(
                              title: closeOutDayDetails == null
                              ? '\$0.00'
                              : '\$${(closeOutDayDetails!.totalNetSales - closeOutDayDetails!.tax).roundTwo}',
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.tax,
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                            CustomText(
                              title: closeOutDayDetails == null
                              ? '\$0.00'
                              : '\$${closeOutDayDetails!.tax.roundTwo}',
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.totalSales,
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                            CustomText(
                              title: closeOutDayDetails == null
                              ? '\$0.00'
                              : '\$${closeOutDayDetails!.totalNetSales.roundTwo}',
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                Container(
                  padding: const EdgeInsets.all(AppSize.s15),
                  decoration: BoxDecoration(
                    color:  Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: AppStrings.paymentDetails,
                        textStyle: getMediumStyle(
                          color:  Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s5),
                      Container(
                        height: AppSize.s2,
                        color: AppColors.primaryColor,
                        width: AppSize.s45,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.total,
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                            CustomText(
                              title: closeOutDayDetails == null
                              ? '\$0.00'
                              : '\$${closeOutDayDetails!.totalPayment.roundTwo}',
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: 'Total Payment - Total Sales =',
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                            CustomText(
                              title: closeOutDayDetails == null
                              ? '\$0.00'
                              : (closeOutDayDetails!.totalPayment - closeOutDayDetails!.totalNetSales).calculatePaymentSalesAmount,
                              textStyle: getRegularStyle(fontSize: AppSize.s14)
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                Container(
                  padding: const EdgeInsets.all(AppSize.s15),
                  decoration: BoxDecoration(
                    color:  Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: 'Server Tipouts',
                        textStyle: getMediumStyle(
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s5),
                      Container(
                        height: AppSize.s2,
                        color: AppColors.primaryColor,
                        width: AppSize.s45,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: 'Cash before Tipouts',
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            CustomText(
                              title: '\$0.00',
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: '(Total Tips and fees Tipped out: \$0.00)',
                              textStyle: getMediumStyle(fontStyle: FontStyle.italic,color: AppColors.grey),
                            ),
                            CustomText(
                              title: '',
                              textStyle: getMediumStyle(),
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.totalNetSales,
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            CustomText(
                              title: '\$0.00',
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                Container(
                  padding: const EdgeInsets.all(AppSize.s15),
                  decoration: BoxDecoration(
                    color:  Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: AppStrings.depositSummary,
                        textStyle: getMediumStyle(
                          color:  Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s5),
                      Container(
                        height: AppSize.s2,
                        color: AppColors.primaryColor,
                        width: AppSize.s45,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.expectedDeposit,
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            CustomText(
                              title: '\$0.00',
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.actualDeposit,
                              textStyle: getMediumStyle(fontStyle: FontStyle.italic,color: AppColors.grey),
                            ),
                            CustomText(
                              title: '-',
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: AppSize.s15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: AppStrings.overageShortage,
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            CustomText(
                              title: '-',
                              textStyle: getMediumStyle(
                                color:  Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.closeOutDay,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s22,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        CustomOutlinedButton(
                          onPressed: () => debugPrint(''),
                          textColor: AppColors.blue,
                          text: AppStrings.fullSalesReport,
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomOutlinedButton(
                          onPressed: () => debugPrint(''),
                          text: AppStrings.print,
                          textColor: AppColors.blue,
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomSolidButton(
                          onPressed: () => context.read<CloseOutDayBloc>().add(OnSwitchUserCloseOutDayEvent()),
                          text: AppStrings.switchUser,
                          prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                        ),
                        const SizedBox(width: AppSize.s5),
                        CustomIconButton(
                          onPressed: () => showMoreOption(context: context),
                          horPadding: AppSize.s8,
                          verPadding: AppSize.s8,
                          widget: const CustomImageView(
                            imagePath: AppImages.menuHorizontalColor, 
                            blendMode: BlendMode.dstIn
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: closeOutDayDetails == null
                ? CustomEmptyWidget(
                    imagePath: AppImages.notFound, 
                    emptyTitle: AppStrings.noRecordFound,
                    isVisible: !isLoading
                  )
                : ListView(
                  padding: const EdgeInsets.all(AppSize.s24),
                  children: [
                    CustomText(
                      title: AppStrings.currentStatus,
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                    ),
                    const SizedBox(height: AppSize.s12),
                    Row(
                      children: [
                        CloseOutStatusWidget(
                          statusTitle: "Unpaid Checks", 
                          viewCount: closeOutDayDetails == null 
                          ? 0
                          : closeOutDayDetails!.openCheckCount,
                          onClickView: closeOutDayDetails == null || closeOutDayDetails!.openCheckDetails.isEmpty
                          ? null
                          : () => showOpenCheckDetails(openCheckList: closeOutDayDetails!.openCheckDetails),
                        ),
                        CloseOutStatusWidget(
                          statusTitle: "Clocked-in employees", 
                          viewCount: closeOutDayDetails == null 
                          ? 0
                          : closeOutDayDetails!.clockedInEmployeeCount,
                          onClickView: closeOutDayDetails == null || closeOutDayDetails!.clockedInEmployeeDetails.isEmpty
                          ? null
                          : () => showClockedInUser(
                            clockedInUser: closeOutDayDetails!.clockedInEmployeeDetails,
                            date: closeOutDayDetails!.dateTime.toString().substring(0,10)
                            ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: 'z Index',
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16
                          ),
                        ),
                        CustomText(
                          title: closeOutDayDetails == null || closeOutDayDetails!.dateTime == null
                          ? ''
                          : Helper.getDayFormattedDate(dateTime: closeOutDayDetails!.dateTime),
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s15),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ///Sales and Taxes Summary
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(AppSize.s15),
                            decoration: BoxDecoration(
                              color: Helper.isDark
                              ? AppColors.contentColorDark
                              : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10),
                              boxShadow: Helper.isDark
                              ? null
                              : [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: AppSize.s28,
                                  decoration: const BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: AppColors.primaryColor, 
                                        width: AppSize.s2
                                      ),
                                    ),
                                  ),
                                  child: CustomText(
                                    title: AppStrings.salesTaxSummary,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.totalNetSales,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: closeOutDayDetails == null
                                        ? '\$0.00'
                                        : '\$${(closeOutDayDetails!.totalNetSales - closeOutDayDetails!.tax).roundTwo}',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.tax,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: closeOutDayDetails == null
                                        ? '\$0.00'
                                        : '\$${closeOutDayDetails!.tax.roundTwo}',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.totalSales,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: closeOutDayDetails == null
                                        ? '\$0.00'
                                        : '\$${closeOutDayDetails!.totalNetSales.roundTwo}',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: AppSize.s15),
                        ///Server Tipouts
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(AppSize.s15),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.contentColorDark
                              : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10),
                              boxShadow: Helper.isDark 
                              ? null
                              : [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: AppSize.s28,
                                  decoration: const BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: AppColors.primaryColor, 
                                        width: AppSize.s2
                                      ),
                                    ),
                                  ),
                                  child: CustomText(
                                    title: AppStrings.serverTipout,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: 'Cash before Tipouts',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: '\$0.00',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s5),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: '(Total Tips and fees Tipped out: \$0.00)',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          fontStyle: FontStyle.italic, 
                                          color: AppColors.grey
                                        ),
                                      ),
                                      CustomText(
                                        title: '',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.totalNetSales,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: '\$0.00',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s15),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ///Payment Details
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(AppSize.s15),
                            decoration: BoxDecoration(
                              color: Helper.isDark
                              ? AppColors.contentColorDark
                              : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10),
                              boxShadow: Helper.isDark 
                              ? null
                              : [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: AppSize.s28,
                                  decoration: const BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: AppColors.primaryColor, 
                                        width: AppSize.s2
                                      ),
                                    ),
                                  ),
                                  child: CustomText(
                                    title: AppStrings.paymentDetails,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.total,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: closeOutDayDetails == null
                                        ? '\$0.00'
                                        : '\$${closeOutDayDetails!.totalPayment.roundTwo}',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: 'Total Payment - Total Sales =',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: closeOutDayDetails == null
                                        ? '\$0.00'
                                        : (closeOutDayDetails!.totalPayment - closeOutDayDetails!.totalNetSales).calculatePaymentSalesAmount,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: AppSize.s15),
                        ///Deposit Summary
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(AppSize.s15),
                            decoration: BoxDecoration(
                              color: Helper.isDark
                              ? AppColors.contentColorDark
                              : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10),
                              boxShadow: Helper.isDark
                              ? null
                              : [BoxShadow(color: AppColors.grey.withOpacity(0.8), blurRadius: AppSize.s4)]
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: AppSize.s28,
                                  decoration: const BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: AppColors.primaryColor, 
                                        width: AppSize.s2
                                      ),
                                    ),
                                  ),
                                  child: CustomText(
                                    title: AppStrings.depositSummary,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.expectedDeposit,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: '\$0.00',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s5),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.actualDeposit,
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          fontStyle: FontStyle.italic,
                                          color: AppColors.grey
                                        ),
                                      ),
                                      CustomText(
                                        title: '--',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: AppSize.s15),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.overageShortage,
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                      CustomText(
                                        title: '--',
                                        textStyle: getRegularStyle(fontSize: AppSize.s14)
                                      ),
                                    ],
                                  ),
                                ),
                              ]
                            ),
                          ),
                        ),
                      ],
                    ),
                  ]
                ),
              ),
            ]
          ),
        ),
      ]
    );
  }

  void showMoreOption({required BuildContext context}) {
    final width = context.screenWidth;
    final height = context.screenHeight;
    showMenu(
      context: context, 
      position: RelativeRect.fromLTRB(
        width * 0.50, 
        height * 0.12, 
        width * 0.015, 
        10
      ),
      items: [
        PopupMenuItem<int>(
          value: 3,
          child: const Text('Change Date'),
          onTap: () => showDatePickerDialog(context),
        ),
      ]
    );
  }

  Future<void> showDatePickerDialog(BuildContext context) async {
    var tempDate = await showDatePicker(
      context: context, 
      firstDate: DateTime.parse('2012-02-27'), 
      lastDate: DateTime.now(),
      initialDate: initialDate
    );
    if(tempDate != null && context.mounted){
      initialDate = tempDate;
      context.read<CloseOutDayBloc>().add(CloseOutDayDetailsByDateEvent(selectedDate: initialDate));
    }
  }

  void showClockedInUser({required List<ClockedInEmployeeDetailList> clockedInUser, required String date}){
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: ClockInUserWidget(
            clockedInUser: clockedInUser,
            date: date
          ),
        );
      }
    );
  }

  void showOpenCheckDetails({required List<UnpaidChecksDetail> openCheckList}){
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: OpenCheckWidget(
            openCheckList: openCheckList,
          ),
        );
      }
    );
  }
}