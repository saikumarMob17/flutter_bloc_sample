import 'close_out_day_response.dart';

class CloseOutDayDetailsModel {
  int openCheckCount;
  int clockedInEmployeeCount;
  double totalNetSales;
  double tax;
  DateTime? dateTime;
  double totalPayment;
  List<UnpaidChecksDetail> openCheckDetails;
  List<ClockedInEmployeeDetailList> clockedInEmployeeDetails;

  CloseOutDayDetailsModel({
    this.openCheckCount = 0,
    this.clockedInEmployeeCount = 0,
    this.totalNetSales = 0.0,
    this.tax = 0.0,
    this.dateTime,
    this.totalPayment = 0.0,
    required this.openCheckDetails,
    required this.clockedInEmployeeDetails
  });
}