// To parse this JSON data, do
//
//     final closeOutDayResponse = closeOutDayResponseFromJson(jsonString);

import 'dart:convert';

CloseOutDayResponse closeOutDayResponseFromJson(String str) => CloseOutDayResponse.fromJson(json.decode(str));

class CloseOutDayResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final CloseOutDayDetails? data;

  CloseOutDayResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory CloseOutDayResponse.fromJson(Map<String, dynamic> json) => CloseOutDayResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : CloseOutDayDetails.fromJson(json["data"]),
  );
}

class CloseOutDayDetails {
  final int? unpaidCheckCount;
  final int? clockedInEmployees;
  final List<ClockedInEmployeeDetailList>? clockedInEmployeeDetailList;
  final double? totalNetSales;
  final DateTime? dateTime;
  final double? tax;
  final double? totalPayment;
  final List<UnpaidChecksDetail>? unpaidChecksDetails;

  CloseOutDayDetails({
    this.unpaidCheckCount,
    this.clockedInEmployees,
    this.clockedInEmployeeDetailList,
    this.dateTime,
    this.totalNetSales,
    this.tax,
    this.totalPayment,
    this.unpaidChecksDetails,
  });

  factory CloseOutDayDetails.fromJson(Map<String, dynamic> json) => CloseOutDayDetails(
    unpaidCheckCount: json["unpaidCheckCount"],
    clockedInEmployees: json["clockedInEmployees"],
    clockedInEmployeeDetailList: json["clockedInEmployeeDetailList"] == null ? [] : List<ClockedInEmployeeDetailList>.from(json["clockedInEmployeeDetailList"]!.map((x) => ClockedInEmployeeDetailList.fromJson(x))),
    totalNetSales: json["totalNetSales"]?.toDouble(),
    tax: json["tax"]?.toDouble(),
    dateTime: json['date'] == null ? null :  DateTime.parse(json['date']),
    totalPayment: json["totalPayment"].toDouble(),
    unpaidChecksDetails: json["unpaidChecksDetails"] == null ? [] : List<UnpaidChecksDetail>.from(json["unpaidChecksDetails"]!.map((x) => UnpaidChecksDetail.fromJson(x))),
  );
}

class ClockedInEmployeeDetailList {
  final String? employeeId;
  final String? employeeName;
  final String? location;
  final String? role;
  final String? lastClockedIn;

  ClockedInEmployeeDetailList({
    this.employeeId,
    this.employeeName,
    this.location,
    this.role,
    this.lastClockedIn,
  });

  factory ClockedInEmployeeDetailList.fromJson(Map<String, dynamic> json) => ClockedInEmployeeDetailList(
    employeeId: json["employeeId"],
    employeeName: json["employeeName"],
    location: json["location"],
    role: json["role"],
    lastClockedIn: json["lastClockedIn"],
  );
}

class UnpaidChecksDetail {
  final String? orderId;
  final String? orderNumber;
  final DateTime? orderDate;
  final List<TableDetail>? tableDetails;
  final String? customerId;
  final String? customerName;
  final int? totalGuest;
  final bool? paymentStatus;
  final int? quantity;
  final List<OrderedProductDetailsByOrderSequence>? orderedProductDetailsByOrderSequence;
  final TotalBillingDetail? totalBillingDetail;
  final List<dynamic>? checkDetails;

  UnpaidChecksDetail({
    this.orderId,
    this.orderNumber,
    this.orderDate,
    this.tableDetails,
    this.customerId,
    this.customerName,
    this.totalGuest,
    this.paymentStatus,
    this.quantity,
    this.orderedProductDetailsByOrderSequence,
    this.totalBillingDetail,
    this.checkDetails,
  });

  factory UnpaidChecksDetail.fromJson(Map<String, dynamic> json) => UnpaidChecksDetail(
    orderId: json["orderId"],
    orderNumber: json["orderNumber"],
    orderDate: json["orderDate"] == null ? null : DateTime.parse(json["orderDate"]),
    tableDetails: json["tableDetails"] == null ? [] : List<TableDetail>.from(json["tableDetails"]!.map((x) => TableDetail.fromJson(x))),
    customerId: json["customerId"],
    customerName: json["customerName"],
    totalGuest: json["totalGuest"],
    paymentStatus: json["paymentStatus"],
    quantity: json["quantity"],
    orderedProductDetailsByOrderSequence: json["orderedProductDetailsByOrderSequence"] == null ? [] : List<OrderedProductDetailsByOrderSequence>.from(json["orderedProductDetailsByOrderSequence"]!.map((x) => OrderedProductDetailsByOrderSequence.fromJson(x))),
    totalBillingDetail: json["totalBillingDetail"] == null ? null : TotalBillingDetail.fromJson(json["totalBillingDetail"]),
    checkDetails: json["checkDetails"] == null ? [] : List<dynamic>.from(json["checkDetails"]!.map((x) => x)),
  );
}

class OrderedProductDetailsByOrderSequence {
  final int? orderSequence;
  final bool? isFinished;
  final List<ProductDetail>? productDetails;
  final TotalBillingDetail? billingDetails;

  OrderedProductDetailsByOrderSequence({
    this.orderSequence,
    this.isFinished,
    this.productDetails,
    this.billingDetails,
  });

  factory OrderedProductDetailsByOrderSequence.fromJson(Map<String, dynamic> json) => OrderedProductDetailsByOrderSequence(
    orderSequence: json["orderSequence"],
    isFinished: json["isFinished"],
    productDetails: json["productDetails"] == null ? [] : List<ProductDetail>.from(json["productDetails"]!.map((x) => ProductDetail.fromJson(x))),
    billingDetails: json["billingDetails"] == null ? null : TotalBillingDetail.fromJson(json["billingDetails"]),
  );
}

class TotalBillingDetail {
  final double? subTotal;
  final double? discount;
  final double? tax;
  final double? tip;
  final double? grandTotal;
  final bool? paymentStatus;
  final dynamic paymentMode;
  final double? balanceDue;

  TotalBillingDetail({
    this.subTotal,
    this.discount,
    this.tax,
    this.tip,
    this.grandTotal,
    this.paymentStatus,
    this.paymentMode,
    this.balanceDue,
  });

  factory TotalBillingDetail.fromJson(Map<String, dynamic> json) => TotalBillingDetail(
    subTotal: json["subTotal"].toDouble(),
    discount: json["discount"].toDouble(),
    tax: json["tax"]?.toDouble(),
    tip: json["tip"].toDouble(),
    grandTotal: json["grandTotal"]?.toDouble(),
    paymentStatus: json["paymentStatus"],
    paymentMode: json["paymentMode"],
    balanceDue: json["balanceDue"]?.toDouble(),
  );
}

class ProductDetail {
  final int? productId;
  final String? productName;
  final int? quantity;
  final int? productPrice;

  ProductDetail({
    this.productId,
    this.productName,
    this.quantity,
    this.productPrice,
  });

  factory ProductDetail.fromJson(Map<String, dynamic> json) => ProductDetail(
    productId: json["productId"],
    productName: json["productName"],
    quantity: json["quantity"],
    productPrice: json["productPrice"],
  );
}

class TableDetail {
  final String? tableName;
  final int? tableId;

  TableDetail({
    this.tableName,
    this.tableId,
  });

  factory TableDetail.fromJson(Map<String, dynamic> json) => TableDetail(
    tableName: json["tableName"],
    tableId: json["tableId"],
  );
}
