// To parse this JSON data, do
//
//     final productCategoryResponse = productCategoryResponseFromJson(jsonString);

import 'dart:convert';

ProductCategoryResponse productCategoryResponseFromJson(String str) => ProductCategoryResponse.fromJson(json.decode(str));

String productCategoryResponseToJson(ProductCategoryResponse data) => json.encode(data.toJson());

class ProductCategoryResponse {
    int? statusCode;
    String? status;
    String? message;
    List<ProductCategory>? data;

    ProductCategoryResponse({
        this.statusCode,
        this.status,
        this.message,
        this.data,
    });

    factory ProductCategoryResponse.fromJson(Map<String, dynamic> json) => ProductCategoryResponse(
        statusCode: json["statusCode"],
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? [] : List<ProductCategory>.from(json["data"]!.map((x) => ProductCategory.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "statusCode": statusCode,
        "status": status,
        "message": message,
        "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
    };
}

class ProductCategory {
    int? mainCategoryProductId;
    String? mainCategoryProduct;
    List<SubCategoryProduct>? subCategoryProduct;

    ProductCategory({
        this.mainCategoryProductId,
        this.mainCategoryProduct,
        this.subCategoryProduct,
    });

    factory ProductCategory.fromJson(Map<String, dynamic> json) => ProductCategory(
        mainCategoryProductId: json["mainCategoryProductId"],
        mainCategoryProduct: json["mainCategoryProduct"],
        subCategoryProduct: json["subCategoryProduct"] == null ? [] : List<SubCategoryProduct>.from(json["subCategoryProduct"]!.map((x) => SubCategoryProduct.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "mainCategoryProductId": mainCategoryProductId,
        "mainCategoryProduct": mainCategoryProduct,
        "subCategoryProduct": subCategoryProduct == null ? [] : List<dynamic>.from(subCategoryProduct!.map((x) => x.toJson())),
    };
}

class SubCategoryProduct {
    int? productSecondCategorieId;
    String? productSecondCategorieName;
    String? productDescription;
    int? quantity;
    double? unitPrice;
    double? totalValue;
    DateTime? dateAdded;
    DateTime? dateUpdated;
    bool? isDeleted;
    int? productMainCategorieId;
    ProductMainCategorie? productMainCategorie;

    SubCategoryProduct({
        this.productSecondCategorieId,
        this.productSecondCategorieName,
        this.productDescription,
        this.quantity,
        this.unitPrice,
        this.totalValue,
        this.dateAdded,
        this.dateUpdated,
        this.isDeleted,
        this.productMainCategorieId,
        this.productMainCategorie,
    });

    factory SubCategoryProduct.fromJson(Map<String, dynamic> json) => SubCategoryProduct(
        productSecondCategorieId: json["productSecondCategorieId"],
        productSecondCategorieName: json["productSecondCategorieName"] ?? '',
        productDescription: json["productDescription"],
        quantity: json["quantity"],
        unitPrice: json["unitPrice"].toDouble(),
        totalValue: json["totalValue"].toDouble(),
        dateAdded: json["dateAdded"] == null ? null : DateTime.parse(json["dateAdded"]),
        dateUpdated: json["dateUpdated"] == null ? null : DateTime.parse(json["dateUpdated"]),
        isDeleted: json["isDeleted"],
        productMainCategorieId: json["productMainCategorieId"],
        productMainCategorie: json["productMainCategorie"] == null ? null : ProductMainCategorie.fromJson(json["productMainCategorie"]),
    );

    Map<String, dynamic> toJson() => {
        "productSecondCategorieId": productSecondCategorieId,
        "productSecondCategorieName": productSecondCategorieName,
        "productDescription": productDescription,
        "quantity": quantity,
        "unitPrice": unitPrice,
        "totalValue": totalValue,
        "dateAdded": dateAdded?.toIso8601String(),
        "dateUpdated": dateUpdated?.toIso8601String(),
        "isDeleted": isDeleted,
        "productMainCategorieId": productMainCategorieId,
        "productMainCategorie": productMainCategorie?.toJson(),
    };
}

class ProductMainCategorie {
    int? productMainCategorieId;
    String? productMainCategorieName;
    bool? isDeleted;

    ProductMainCategorie({
        this.productMainCategorieId,
        this.productMainCategorieName,
        this.isDeleted,
    });

    factory ProductMainCategorie.fromJson(Map<String, dynamic> json) => ProductMainCategorie(
        productMainCategorieId: json["productMainCategorieId"],
        productMainCategorieName: json["productMainCategorieName"],
        isDeleted: json["isDeleted"],
    );

    Map<String, dynamic> toJson() => {
        "productMainCategorieId": productMainCategorieId,
        "productMainCategorieName": productMainCategorieName,
        "isDeleted": isDeleted,
    };
}
