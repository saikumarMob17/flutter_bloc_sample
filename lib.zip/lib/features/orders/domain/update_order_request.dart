import 'order_place_request.dart';

class UpdateOrderRequest {
  String orderId;
  int orderSequence;
  List<OrderDetails> orderDetails;
  BillingDetails billingDetails;
  Map<String, dynamic> totalBillingDetails;

  UpdateOrderRequest({
    required this.orderId,
    required this.orderSequence,
    required this.orderDetails,
    required this.billingDetails,
    required this.totalBillingDetails
  });

  Map<String, dynamic> get toJson => {
    "orderId": orderId,
    "orderSequence": orderSequence,
    "orderDetails": List.from(orderDetails.map((item) => item.toJson)),
    "billingDetails": billingDetails.toJson,
    'totalBilling': totalBillingDetails
  };
}

class OrderDetails {
  int productId;
  String productName;
  int quantity;
  double productPrice;
  

  OrderDetails({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.productPrice
  });

  Map<String, dynamic> get toJson => {
    "productId": productId,
    "productName": productName,
    "quantity": quantity,
    "productPrice": productPrice
  };
}