class OrderBillingModel {
  String title;
  double amount;

  OrderBillingModel({
    this.title = '',
    this.amount = 0.0
  });
}