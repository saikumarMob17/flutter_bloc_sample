class OrderModel {

  int itemId;
  String title;
  String imagePath;
  double price;
  double totalPrice;
  int quantity;
  int itemMaxQuantity;
  bool isSelected;

  OrderModel({
    this.itemId = 0,
    this.title = '',
    this.imagePath = '',
    this.price = 0.0,
    this.totalPrice = 0.0,
    this.quantity = 0,
    this.itemMaxQuantity = 0,
    this.isSelected = false
  });
}