class OrderPlaceRequest {
  String employeeId;
  int totalGuest;
  List<TableDetails> tableList;
  int orderSequence;
  PreAuthDetails? isPreAuth;
  CustomerDetails customerDetails;
  BillingDetails billingDetails;
  List<ProductDetails> productDetails;

  OrderPlaceRequest({
    required this.employeeId,
    required this.totalGuest,
    required this.tableList,
    this.isPreAuth,
    required this.orderSequence,
    required this.customerDetails,
    required this.billingDetails,
    required this.productDetails
  });

  Map<String, dynamic> get toJson => {
    "employeeId": employeeId,
    "totalGuest": totalGuest,
    'preAuthDetails': isPreAuth == null ? isPreAuth : isPreAuth!.toJson,
    "order_Sequence": orderSequence,
    "tables": List.from(tableList.map((item) => item.toJson)),
    "customerDetails": customerDetails.toJson,
    'orderDetails': List.from(productDetails.map((item) => item.toJson)),
    'billingDetails': billingDetails.toJson
  };
}

class TableDetails {
  int tableId;
  String tableName;


  TableDetails({
    required this.tableId, 
    required this.tableName
  });

  Map get toJson => {
    "tableId": tableId,
    "tableName": tableName
  };
}

class CustomerDetails {
  String customerName;
  String email;
  String customerPhone;
  String creditCardNumber;
  String customerIdentity;

  CustomerDetails({
    required this.customerName,
    this.email = '',
    this.customerPhone = '',
    this.creditCardNumber = '',
    this.customerIdentity = ''
  });

  Map get toJson => {
    "customerName": customerName,
    "customerEmail": email,
    "customerPhone": customerPhone,
    "creditCardNumber": creditCardNumber,
    "customerIdentity": customerIdentity
  };
}

class BillingDetails {
  double subTotal;
  double discount;
  double tax;
  double tip;
  double grandTotal;
  bool paymentStatus;
  String? paymentMode;

  BillingDetails({
    this.subTotal = 0.0,
    this.discount = 0.0,
    this.tax = 0.0,
    this.tip = 0.0,
    this.grandTotal = 0.0,
    this.paymentStatus = false,
    this.paymentMode
  });

  Map get toJson => {
    "subTotal": subTotal,
    "discount": discount,
    "tax": tax,
    "tip": tip,
    "grandTotal": grandTotal,
    'paymentStatus': paymentStatus,
    'paymentMode': paymentMode
  };
}

class ProductDetails {
  int productId;
  String productName;
  int quantity;
  double productPrice;

  ProductDetails({
    this.productId = -1,
    this.productName = '',
    this.quantity = -1,
    this.productPrice = 0.0
  });

  Map get toJson => {
    "productId": productId,
    "productName": productName,
    "quantity": quantity,
    'productPrice': productPrice
  };
}

class PreAuthDetails {
  bool isPreAuth;
  String authorizationId;
  String paymentInstrumentId;
  String cardLastFourDigit;

  PreAuthDetails({
    this.isPreAuth = false,
    required this.authorizationId,
    this.paymentInstrumentId = '',
    required this.cardLastFourDigit
  });

  Map get toJson => {
    "isPreAuth": isPreAuth,
    "authId": authorizationId,
    "paymentInstrumentId": paymentInstrumentId,
    "cardLastFourDegit": cardLastFourDigit
  };
}