import 'dart:convert';
import 'dart:io';
import 'package:cliqtechnologies_retl/constants/app_strings.dart';
import 'package:cliqtechnologies_retl/services/finix_payment_instrument_response.dart';
import 'package:http/http.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../../utils/helper.dart';
import '../domain/product_category_response.dart';

class OrderRepository {

  late ApiClient _apiClient;

  OrderRepository(){
    _apiClient = ApiClient();
  }

  Future<List<ProductCategory>> productCategory() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.productCategory);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data =  productCategoryResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Map> placeOrder({required Map body, bool isFirst = false}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.placeOrder, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode) {
        case HttpStatus.ok:
          if(isFirst) {
            for(var item in body['tables']){
              await updateTableStatus(id: item['tableId'].toString());
            }
          }
          return jsonResponse;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> updateTableStatus({required String id}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: '${EndPoints.updateFloorPlanById}?id=$id', body: null);
      switch(response.statusCode) {
        case HttpStatus.ok:
          return AppStrings.success;
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException  catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Map> updateOrder({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updateOrder, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode) {
        case HttpStatus.created:
          return jsonResponse;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<PaymentInstrument>> getAllFinixPaymentInstrument() async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      var response = await _apiClient.getRequest(endPoint: EndPoints.paymentInstruments, customHeader: customHeader);
      switch (response.statusCode) {
        case HttpStatus.ok:
          var data = finixPaymentInstrumentResponseFromJson(response.body);
          return data.embedded == null ? [] : data.embedded!.paymentInstruments!;
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Response> createPaymentInstrument({required Map body}) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      return await _apiClient.postRequest(endPoint: EndPoints.paymentInstruments, body: body, customHeader: customHeader);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Response> createAuthorization(Map<String, dynamic> body) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      return await _apiClient.postRequest(endPoint: EndPoints.authorizations, customHeader: customHeader,body: body);
      // switch (response.statusCode) {
      //   case HttpStatus.ok:
      //     var data = finixPaymentInstrumentResponseFromJson(response.body);
      //     return data.embedded == null ? [] : data.embedded!.paymentInstruments!;
      //   case HttpStatus.badRequest:
      //     throw CustomException(message: jsonDecode(response.body)['message']);
      //   case HttpStatus.notFound:
      //     throw CustomException(message: jsonDecode(response.body)['message']);
      //   case HttpStatus.internalServerError:
      //     throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
      //   default:
      //     throw CustomException(message: AppStrings.someThingWentWrong);
      // }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
  
}