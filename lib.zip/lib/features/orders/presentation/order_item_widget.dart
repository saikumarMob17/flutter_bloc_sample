import 'package:flutter/material.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_text.dart';
import '../../../utils/helper.dart';
import '../../../utils/app_extension_method.dart';
import '../domain/product_category_response.dart';

class OrderItemWidget extends StatelessWidget {

  final Function(int) onTap;
  final List<SubCategoryProduct> itemList;

  const OrderItemWidget({
    super.key,
    required this.onTap,
    required this.itemList
  });

  @override
  Widget build(BuildContext context) {
    int itemIndex = 0;
    return Column(
      children: List.generate(
        itemList.length.orderItemCount,
        (index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: AppSize.s20),
            child: Row(
              children: List.generate(
                2, 
                (subIndex) {
                  itemIndex+=1;
                  return itemIndex <= itemList.length
                  ? Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(
                        right: subIndex == 0 ? AppSize.s5 : 0, 
                        left: subIndex == 1 ? AppSize.s5 : 0
                      ),
                      child: GestureDetector(
                        onTap: () => onTap(index*2 + subIndex),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s5,
                            horizontal: AppSize.s10
                          ),
                          decoration: BoxDecoration(
                            color: Helper.isDark
                            ? AppColors.contentColorDark
                            : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10)
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(AppSize.s15),
                                decoration: BoxDecoration(
                                  color: Helper.isDark
                                  ? AppColors.headerColorDark
                                  : AppColors.backgroundColor,
                                  shape: BoxShape.circle
                                ),
                                child: const CustomImageView(
                                  imagePath: AppImages.beerBottle,
                                  blendMode: BlendMode.dstIn, 
                                  color: AppColors.primaryColor,
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomText(
                                      title: itemList[itemIndex - 1].productSecondCategorieName!, 
                                      textStyle: getMediumStyle(
                                        fontSize: AppSize.s12,
                                        color: Helper.isDark 
                                        ? AppColors.white
                                        : AppColors.black
                                      )
                                    ),
                                    const SizedBox(height: AppSize.s5),
                                    CustomText(
                                      title: itemList[itemIndex - 1].quantity!.toString(),
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                  : const Expanded(child: SizedBox());
                }
              ),
            ),
          );
        }
      ),
    );
  }
}