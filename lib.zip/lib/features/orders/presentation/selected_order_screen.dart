import '../../../constants/app_icons.dart';
import '../../../constants/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';

class SelectedOrderScreen extends StatefulWidget {

  const SelectedOrderScreen({super.key});

  @override
  State<SelectedOrderScreen> createState() => _SelectedOrderScreenState();

}

class _SelectedOrderScreenState extends State<SelectedOrderScreen> {

  var billingConstantLabel = [
    'Sub Total',
    'Product Discount',
    'Tax (10%)',
    'Extra Discount',
    'Total'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: Container(
        //duration: const Duration(milliseconds: 250), 
        //width: 0,
        color: AppColors.white,
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s25,
          horizontal: AppSize.s20
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomImageView(
                  imagePath: AppImages.arrowLeft,
                  blendMode: BlendMode.dstIn,
                  color: AppColors.black,
                  height: AppSize.s20,
                  width: AppSize.s20,
                  onTap: () => context.pop(),
                ),
                CustomText(
                  title: 'Order ID #1',
                  textStyle: getMediumStyle(fontSize: AppSize.s20),
                ),
              ],
            ),
            const SizedBox(height: AppSize.s30),
            Expanded(
              child: ListView(
                shrinkWrap: true,
                children: [
                  Container(
                    margin: const EdgeInsets.only(bottom: AppSize.s10),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(AppSize.s16),
                          decoration: const BoxDecoration(
                            color: AppColors.primaryColor,
                            shape: BoxShape.circle
                          ),
                          child: const CustomImageView(
                            imagePath: AppImages.orangeJuice,
                          ),
                        ),
                        const SizedBox(width: AppSize.s18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                title: 'Apple Juice',
                                textStyle: getMediumStyle(fontSize: AppSize.s16),
                              ),
                              const SizedBox(height: AppSize.s8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    title: '\$ 2.29',
                                    textStyle: getMediumStyle(
                                      fontSize: AppSize.s18,
                                      color: AppColors.grey.withOpacity(0.9)
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: AppSize.s4,
                                          vertical: AppSize.s4
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppColors.grey.withOpacity(0.3),
                                          borderRadius: BorderRadius.circular(AppSize.s8)
                                        ),
                                        child: const Icon(
                                          AppIcons.removeIcon,
                                          color: AppColors.black, 
                                          size: AppSize.s22
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s14),
                                        child: CustomText(
                                          title: '1',
                                          textStyle: getMediumStyle(fontSize: AppSize.s16),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: AppSize.s4,
                                          vertical: AppSize.s4
                                        ),
                                        decoration: BoxDecoration(
                                          color: AppColors.primaryColor,
                                          borderRadius: BorderRadius.circular(AppSize.s8)
                                        ),
                                        child: const Icon(
                                          Icons.add,
                                          color: AppColors.white, 
                                          size: AppSize.s22
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSize.s30),
            Column(
              children: List.generate(
                billingConstantLabel.length, 
                (index) {
                  var data = billingConstantLabel[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: AppSize.s20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: data,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                        CustomText(
                          title: '\$123',
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                      ],
                    ),
                  );
                }
              ),
            ),
            const SizedBox(height: AppSize.s10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomOutlinedButton(
                  onPressed: () => debugPrint('Click here to cancel here'),
                  text: AppStrings.cancelOrder,
                  textColor: AppColors.primaryColor,
                  // verPadding: AppSize.s12,
                  // horPadding: AppSize.s18,
                ),
                CustomSolidButton(
                  onPressed: () => context.push(AppRoutes.paymentScreen, extra: {'orderId': '', 'pageIndex': ''}),
                  text: AppStrings.placeOrder,
                  verPadding: AppSize.s12,
                  horPadding: AppSize.s18,
                ),
              ],
            ),
            const SizedBox(height: AppSize.s30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                3, 
                (index) {
                  return Container(
                    padding: const EdgeInsets.all(AppSize.s18),
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.circular(AppSize.s8)
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const CustomImageView(
                          imagePath: AppImages.printIcon,
                        ),
                        const SizedBox(height: AppSize.s8),
                        CustomText(
                          title: 'Add\nAccount',
                          textAlign: TextAlign.center,
                          textStyle: getMediumStyle(color: AppColors.white),
                        ),
                      ],
                    ),
                  );
                }
              ),
            ),
          ],
        ),
      ),
    );
  }
}