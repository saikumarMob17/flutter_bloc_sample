import 'package:cliqtechnologies_retl/features/orders/presentation/orders_add_new_card_dialog.dart';

import '../../../widgets/custom_empty_widget.dart';
import '../../payment/presentation/payment_add_new_card_dialog.dart';
import '../domain/billing_model.dart';
import '../domain/order_model.dart';
import '../domain/product_category_response.dart';
import '../../../constants/app_icons.dart';
import '../../../routes/route.dart';
import 'order_item_widget.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../../../widgets/left_navigation_screen.dart';

class OrdersScreen extends StatefulWidget {

  const OrdersScreen({super.key});

  @override
  State createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> with Helper, SingleTickerProviderStateMixin {

  int selectedItem = 0;
  int orderSequence = 1;
  String customerName = '';
  String customerEmail = '';
  String customerPhone = '';
  String customerCreditCard = '';
  int guestCount = 0;
  String tableName = '';
  var selectedTableList = <Map>[];
  PaymentModel? paymentDetails;
  bool isOrderUpdate = false;

  var orderBillingLabel = <OrderBillingModel>[
    OrderBillingModel(title: 'Sub Total', amount: 0.0),
    OrderBillingModel(title: 'Product Discount', amount: 0.0),
    OrderBillingModel(title: 'Tax (10%)', amount: 0.0),
    OrderBillingModel(title: 'Extra Discount', amount: 0.0),
    OrderBillingModel(title: 'Total', amount: 0.0)
  ];

  var drinkOption = <DropdownMenuModel>[];
  List<List<OrderModel>> selectOrderItem = [];
  String drinkCategory = '';
  int selectedDrinkIndex = 0;
  var productSubCategoryList = <SubCategoryProduct>[];
  int orderItemsLength = 0;
  int pageViewIndex = 0;
  String currentDateTime = "";
  int selectedTableIndex =  0;
  int tabIndex = 0;
  // String orderId = '';
  // String customerId = '';
  bool isStayed = false;
  bool isLoading = true;
  bool isPreAuth = false;
  String preAuthId = "";
  String lastFourDigit = "";
  late OrdersBloc _ordersBloc;
  List<DropdownMenuModel> stateList = [];

  @override
  void initState() {
    _ordersBloc = context.read<OrdersBloc>();
    currentDateTime = Helper.getDayFormattedDate();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.black 
      : AppColors.backgroundColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(toolbarHeight: 0),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () => showPaymentSuccessDialog(context: context),
      //   child: const Icon(Icons.add),
      // ),
      body: BlocConsumer<OrdersBloc, OrdersState>(
        builder: (context, state) {
          switch (state) {
            case OrderSelectState _:
              selectOrderItem.clear();
              selectOrderItem.addAll(state.item);
              //Calculate Billing Amount
              calculateBillingAmount(getSelectedOrder(tabIndex));
              break;
            case OrdersProductSubCategoryState _:
              productSubCategoryList.clear();
              drinkOption.clear();
              selectOrderItem.clear();
              stateList.clear();
              stateList.addAll(state.stateMenuList);
              if(state.productSubCategoryList.isNotEmpty) {
                productSubCategoryList.addAll(state.productSubCategoryList);
              }
              if(state.drinkDropDownList.isNotEmpty) {
                drinkOption.addAll(state.drinkDropDownList);
                drinkCategory = state.drinkDropDownList.first.item;
              }
              if(state.selectedOrder.isNotEmpty) {
                selectOrderItem.addAll(state.selectedOrder);
              }
              selectedDrinkIndex = 0;
              //Calculate Billing Amount
              calculateBillingAmount(getSelectedOrder(tabIndex));
              ///Tab Information
              customerName = state.customerName;
              customerEmail = state.customerEmail;
              customerPhone = state.customerPhone;
              customerCreditCard = state.customerCreditCard;
              guestCount = state.guestCount;
              tableName = state.tableName;
              orderSequence = state.orderSequence;
              selectedTableList = state.selectedTableList;
              isOrderUpdate = state.isUpdate;
              isStayed = state.isStayed;
              // orderId = state.orderId;
              break;
            case OrdersChangeDropDownSubCategoryState _:
              selectedDrinkIndex = state.selectedValue;
              drinkCategory = state.selectedItem;
              productSubCategoryList.clear();
              productSubCategoryList.addAll(state.productSubCategoryList);
              break;
            case OrdersProductChangePageViewState _:
              pageViewIndex = state.pageIndex;
              break;
            case OnChangeTabPageIndexState _:
              tabIndex = state.pageIndex;
              calculateBillingAmount(getSelectedOrder(tabIndex));
              break;
            case OrdersSelectTableState _:
              selectedTableIndex = state.selectedIndex;
              break;
            case OrdersFinixErrorState _:
              if(state.isSuccess) {
                isPreAuth = true;
                preAuthId = state.authorizationId;
                lastFourDigit = state.cardLastFourDigit;
              }
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case OrdersLoadingState _:
              showLoadingDialog(context: context);
              break;
            case OrdersProductSubCategoryState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              break;
            case OrdersFailedState _ :
              isLoading = false;
              hideLoadingDialog(context: context);
              if(state.message.isNotEmpty) {
                showSnackBar(context: context, title: state.message);
              }
              break;
            case OrdersOpenCartState _:
              showOrderCart(bContext: context, value: context.read<OrdersBloc>());
              break;
            case OrdersPlaceOrderSuccessState _:
              // orderId = state.orderId;
              // customerId = state.customerId;
              hideLoadingDialog(context: context);
              showPaymentSuccessDialog(context: context);
              break;
            case SuccessState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              if(context.mounted){
                while (GoRouter.of(context).canPop()) {
                  GoRouter.of(context).pop();
                }
                GoRouter.of(context).pushReplacement(AppRoutes.dashboardScreen);
              }
              break;
            case OnSwitchUserOrdersState _:
              hideLoadingDialog(context: context);
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            case OrderContinueForNewPaymentState _:
              context.pop();
              context.push(AppRoutes.paymentScreen, extra: {'orderId': state.orderId, 'pageIndex': 0});
              break;
            default:
          }
        },
      ),
    );
  }

  void calculateBillingAmount(List<OrderModel> selectOrderItem) {
    if(selectOrderItem.isNotEmpty){
      ///calculate billing
      double subTotal = 0.0;
      for(var item in selectOrderItem){
        subTotal+=item.totalPrice;
      }
      subTotal = subTotal.roundTwo;
      ///calculate tax
      double tax = (subTotal * 10) / 100;
      tax = tax.roundTwo;
      orderBillingLabel[0].amount = subTotal;
      orderBillingLabel[1].amount = 0.0;
      orderBillingLabel[2].amount = tax;
      orderBillingLabel[3].amount = 0.0;
      orderBillingLabel[4].amount = (subTotal + tax).roundTwo;
    } else {
      orderBillingLabel[0].amount = 0.0;
      orderBillingLabel[1].amount = 0.0;
      orderBillingLabel[2].amount = 0.0;
      orderBillingLabel[3].amount = 0.0;
      orderBillingLabel[4].amount = 0.0;
    }
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: () => context.pop(),
                        icon: const Icon(Icons.west)
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            title: AppStrings.order,
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s18,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                          CustomText(title: currentDateTime)
                        ],
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      CustomImageView(
                        imagePath: AppImages.shoppingCart,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to cart screen'),
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                      const SizedBox(width: AppSize.s5),
                      CustomImageView(
                        imagePath: AppImages.menuDeep,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to menu screen'),
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                      const SizedBox(width: AppSize.s5),
                      CustomImageView(
                        imagePath: AppImages.menuVertical,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => debugPrint('go to more options'),
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s15),
              CustomTextField(
                textController: TextEditingController(),
                hint: AppStrings.orderSearchHint,
                prefixImagePath: AppImages.searchIcon,
                verPadding: AppSize.s14,
                horPadding: AppSize.s14,
                prefixImageSize: AppSize.s20,
              ),
              const SizedBox(height: AppSize.s10),
              SizedBox(
                height: 44,
                width: context.screenWidth,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: List.generate(
                    drinkOption.length, 
                    (index) {
                      var data = drinkOption[index];
                      return GestureDetector(
                        onTap: () => _ordersBloc.add(OrdersChangeDropDownEvent(
                          selectedValue: int.parse(drinkOption[index].value), 
                          selectedIndex: index)),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                          margin: const EdgeInsets.only(right: AppSize.s20),
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                width: 3.0, 
                                color: selectedDrinkIndex == index 
                                ? AppColors.primaryColor 
                                : AppColors.transparent
                              ),
                            ),
                          ),
                          child: Align(
                            alignment: Alignment.center,
                            child: CustomText(
                              title: data.item,
                              textStyle: getMediumStyle(
                                color: selectedDrinkIndex == index 
                                ? AppColors.primaryColor 
                                : Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s10),
              Expanded(
                child: ListView(
                  children: [
                    CustomText(
                      title: drinkCategory, 
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                    ),
                    const SizedBox(height: AppSize.s15),
                    OrderItemWidget(
                      onTap: (index) => _ordersBloc.add(OrdersSelectEvent(index: index, tabIndex: tabIndex)),
                      itemList: productSubCategoryList,
                    ),
                  ],
                ),
              ),
            ],
          ),
          ///Go Add to Cart
          Visibility(
            visible: selectOrderItem.any((element) => element.isNotEmpty),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: context.screenWidth,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSize.s10,
                  vertical: AppSize.s10
                ),
                decoration: BoxDecoration(
                  color: Helper.isDark 
                  ? AppColors.contentColorDark 
                  : AppColors.white,
                  borderRadius: BorderRadius.circular(AppSize.s15)
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: AppStrings.itemAdded, 
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark ? AppColors.white : AppColors.black,
                      ),
                    ),
                    InkWell(
                      onTap: () => context.read<OrdersBloc>().add(OrdersOpenCartEvent()),
                      child: Container(
                        padding: const EdgeInsets.all(AppSize.s10),
                        decoration: BoxDecoration(
                          color: Helper.isDark ? AppColors.black : const Color(0xFFF0F0F0),
                          borderRadius: BorderRadius.circular(AppSize.s10)
                        ),
                        child: CustomText(
                          title: AppStrings.goToCart,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s18,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    orderItemsLength = 0;
    return Row(
      children: [
        ///Left Navigation Drawer
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSize.s20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: AppSize.s10,
                    right: AppSize.s30
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            onPressed: () => context.pop(),
                            icon: const Icon(Icons.west)
                          ),
                          CustomText(
                            title: AppStrings.order,
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s20,
                              color: Helper.isDark 
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          CustomSolidButton(
                            onPressed: () => _ordersBloc.add(OnSwitchUserOrdersEvent()),
                            text: AppStrings.switchUser,
                            prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                          ),
                          const SizedBox(width: AppSize.s10),
                          SizedBox(
                            width: context.screenWidth * 0.15,
                            child: CustomTextField(
                              prefixImagePath: AppImages.searchIcon,
                              horPadding: AppSize.s14,
                              verPadding: 9,
                              prefixImageSize: AppSize.s16,
                              hint: AppStrings.searchHere,
                              onChange: (text) => _ordersBloc.add(OnSearchProductsOrdersEvent(text: text)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSize.s12),
                ///Product List
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: AppSize.s20),
                  height: 166,
                  color: AppColors.transparent,
                  child: drinkOption.isEmpty
                  ? Center(
                      child: CustomEmptyWidget(
                        imagePath: AppImages.notFound, 
                        emptyTitle: AppStrings.noProductFound,
                        isVisible: !isLoading,
                      ),
                    )
                  : PageView(
                    onPageChanged: (value) => _ordersBloc.add(OrdersProductChangePageViewEvent(pageIndex: value)),
                    children: List.generate(
                      orderCategoryPageCount(drinkOption.length),
                      (pageViewIndex) {
                        return Column(
                          children: List.generate(
                            2,
                            (rowIndex) {
                              return Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: List.generate(
                                  6, 
                                  (columnIndex) {
                                    var itemIndex = ((pageViewIndex * 12) + ((rowIndex * 6) + columnIndex));
                                    orderItemsLength+=1;
                                    return Expanded(
                                      child: orderItemsLength <= drinkOption.length
                                      ? GestureDetector(
                                        onTap: () => _ordersBloc.add(OrdersChangeDropDownEvent(
                                          selectedValue: int.parse(drinkOption[itemIndex].value), 
                                          selectedIndex: itemIndex)),
                                        child: Container(
                                          height: 75,
                                          margin: const EdgeInsets.only(right: AppSize.s8, bottom: AppSize.s8),
                                          padding: const EdgeInsets.symmetric(
                                            vertical: AppSize.s8,
                                            horizontal: AppSize.s10
                                          ),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark
                                            ? selectedDrinkIndex == itemIndex 
                                              ? AppColors.primaryColor 
                                              : AppColors.contentColorDark
                                            : selectedDrinkIndex == itemIndex 
                                              ? AppColors.primaryColor 
                                              : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s8)
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                padding: const EdgeInsets.all(AppSize.s8),
                                                decoration: BoxDecoration(
                                                  color: Helper.isDark
                                                  ? selectedDrinkIndex == itemIndex 
                                                    ? AppColors.white 
                                                    : AppColors.headerColorDark
                                                  : AppColors.backgroundColor,
                                                  shape: BoxShape.circle
                                                ),
                                                child: const CustomImageView(
                                                  imagePath: AppImages.beerBottle,
                                                  blendMode: BlendMode.dstIn, 
                                                  color: AppColors.primaryColor,
                                                  height: AppSize.s26,
                                                  width: AppSize.s26
                                                ),
                                              ),
                                              const SizedBox(width: AppSize.s8),
                                              Expanded(
                                                child: CustomText(
                                                  title: drinkOption[itemIndex].item,
                                                  textStyle: getMediumStyle(
                                                    color: Helper.isDark 
                                                    ? AppColors.white
                                                    : selectedDrinkIndex == itemIndex 
                                                      ? AppColors.white 
                                                      : AppColors.black
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                      : const SizedBox()
                                    );
                                  } 
                                ),
                              );
                            }
                          ),
                        );
                      }
                    ),
                  ),
                ),
                //Page Indicator
                const SizedBox(height: AppSize.s2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    orderCategoryPageCount(drinkOption.length), 
                    (index) {
                      return Container(
                        margin: const EdgeInsets.only(right: 8),
                        width: AppSize.s30, 
                        height: 3.5, 
                        color: Helper.isDark
                        ? pageViewIndex == index 
                          ? AppColors.primaryColor 
                          : AppColors.contentColorDark
                        : pageViewIndex == index 
                          ? AppColors.primaryColor 
                          : AppColors.grey
                      );
                    }
                  ),
                ),
                const SizedBox(height: AppSize.s10),
                ///Content UI
                Expanded(
                  child: Container(
                    color: Helper.isDark 
                    ? AppColors.backgroundColorDark
                    : AppColors.white,
                    padding: const EdgeInsets.only(
                      left: AppSize.s20,
                      right: AppSize.s40
                    ),
                    child: productSubCategoryList.isEmpty
                    ? Center(
                      child: CustomEmptyWidget(
                        isVisible: !isLoading,
                        imagePath: AppImages.soldOut, 
                        emptyTitle: AppStrings.soldOut
                      ))
                    : ListView(
                      shrinkWrap: true,
                      children: [
                        const SizedBox(height: AppSize.s24),
                        CustomText(
                          title: drinkCategory, 
                          textStyle: getMediumStyle(
                          fontSize: AppSize.s14,
                          color: Helper.isDark 
                          ? AppColors.white
                          : AppColors.black
                          ),
                        ),
                        const SizedBox(height: AppSize.s15),
                        Wrap(
                          spacing: AppSize.s15,
                          runSpacing: AppSize.s30,
                          children: List.generate(
                            productSubCategoryList.length, 
                            (index) {
                              var data = productSubCategoryList[index];
                              return GestureDetector(
                                onTap: data.quantity! <= 0
                                ? null
                                : () => _ordersBloc.add(OrdersSelectEvent(index: index, tabIndex: tabIndex)),
                                child: Container(
                                  width: context.screenWidth * 0.11,
                                  height: context.screenHeight * 0.20,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: AppSize.s10,
                                    horizontal: AppSize.s10
                                  ),
                                  decoration: BoxDecoration(
                                    color: Helper.isDark 
                                    ? AppColors.contentColorDark 
                                    : AppColors.white,
                                    borderRadius: BorderRadius.circular(AppSize.s10),
                                    boxShadow: Helper.isDark 
                                    ? null
                                    : [BoxShadow(color: AppColors.primaryColor.withOpacity(0.2), blurRadius: AppSize.s2)]
                                  ),
                                  child: Column(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(AppSize.s18),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark 
                                          ? AppColors.backgroundColorDark 
                                          : AppColors.itemBackgroundColor,
                                          shape: BoxShape.circle
                                        ),
                                        child: const CustomImageView(
                                          imagePath: AppImages.orangeJuice,
                                          color: AppColors.primaryColor,
                                          height: AppSize.s22,
                                          width: AppSize.s22,
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s12),
                                      Expanded(
                                        child: CustomText(
                                          title: data.productSecondCategorieName!, 
                                          maxLines: 2,
                                          textAlign: TextAlign.center,
                                          textStyle: getRegularStyle(
                                            fontSize: AppSize.s14,
                                            color: Helper.isDark 
                                            ? AppColors.lightGrey 
                                            : AppColors.black
                                          ),
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: AppSize.s4,
                                              vertical: AppSize.s2
                                            ),
                                            alignment: Alignment.centerRight,
                                            decoration: BoxDecoration(
                                              color: data.quantity! <= 0
                                              ? AppColors.red.withOpacity(0.2) 
                                              : Helper.isDark
                                              ? AppColors.black
                                              : AppColors.lightGrey,
                                              borderRadius: BorderRadius.circular(AppSize.s2)
                                            ),
                                            child:  CustomText(
                                              title: data.quantity! <= 0
                                              ? AppStrings.outOfStock
                                              : data.quantity!.toString(), 
                                              textStyle: getMediumStyle(
                                                fontSize: 11,
                                                color: data.quantity! <= 0
                                                ? AppColors.red
                                                : Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black,
                                              ),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        ///Right Drawer for maintaining all orders
        AnimatedSize(
          duration: const Duration(milliseconds: 280),
          child: Container(
            width: selectOrderItem.any((element) => element.isNotEmpty) ? context.screenWidth * 0.27 : 0,
            decoration: BoxDecoration(
              color: Helper.isDark 
              ? AppColors.black 
              : AppColors.white,
              border: const Border(
                left: BorderSide(color: AppColors.grey, width: 0.6)
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                PageView.builder(
                  onPageChanged: (value) => _ordersBloc.add(OnChangeTabPageIndexEvent(pageIndex: value)),
                  itemCount: isOrderUpdate
                  ? orderSequence + 1
                  : orderSequence,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s10,
                            horizontal: AppSize.s12,
                          ),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: AppSize.s8,
                                      horizontal: AppSize.s10
                                    ),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark 
                                      ? AppColors.headerColorDark 
                                      : AppColors.backgroundColor,
                                      borderRadius: BorderRadius.circular(AppSize.s8)
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(
                                          AppIcons.chairIcon, 
                                          size: AppSize.s20
                                        ),
                                        CustomText(
                                          title: ' $tableName   |   #${index+1} ', 
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s16,
                                            color: Helper.isDark
                                            ? AppColors.white
                                            : AppColors.black
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Spacer(),
                                  Visibility(
                                    visible: !isOrderUpdate,
                                    child: InkWell(
                                      onTap: showPaymentProcessingDialog,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s10
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFC1FBDA),
                                          borderRadius: BorderRadius.circular(AppSize.s8)
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.credit_score, 
                                              size: AppSize.s20,
                                              color: Color.fromARGB(255, 50, 175, 54),
                                            ),
                                            CustomText(
                                              title: ' Pre-authorize', 
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: const Color.fromARGB(255, 50, 175, 54)
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(height: AppSize.s6),
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: AppSize.s8,
                                        horizontal: AppSize.s10
                                      ),
                                      decoration: BoxDecoration(
                                        color: Helper.isDark 
                                        ? AppColors.headerColorDark 
                                        : AppColors.backgroundColor,
                                        borderRadius: BorderRadius.circular(AppSize.s6)
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(
                                            AppIcons.accountCircleIcon, 
                                            size: AppSize.s20
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: ' $customerName ', 
                                              textOverflow: TextOverflow.ellipsis,
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: AppSize.s8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: AppSize.s8,
                                      horizontal: AppSize.s10
                                    ),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark 
                                      ? AppColors.headerColorDark 
                                      : AppColors.backgroundColor,
                                      borderRadius: BorderRadius.circular(AppSize.s8)
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(
                                          AppIcons.groupIcon, 
                                          size: AppSize.s20
                                        ),
                                        CustomText(
                                          title: ' ${AppStrings.guest}  $guestCount ', 
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s16,
                                            color: Helper.isDark
                                            ? AppColors.white
                                            : AppColors.black
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const Divider(height: AppSize.s1, thickness: AppSize.s1, color: AppColors.grey),
                        ///Selected Order Items
                        ////Old UI
                        Expanded(
                          child: Stack(
                            children: [
                              ListView.builder(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: getSelectedOrder(tabIndex).length,
                                itemBuilder: (_, index) {
                                  var data = getSelectedOrder(tabIndex)[index];
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: AppSize.s12, 
                                      vertical: AppSize.s8
                                    ),
                                    decoration: const BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: 0.5, 
                                          color: AppColors.grey
                                        ),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(AppSize.s8),
                                          decoration: const BoxDecoration(
                                            color: AppColors.primaryColor,
                                            shape: BoxShape.circle
                                          ),
                                          child: const CustomImageView(
                                            imagePath: AppImages.orangeJuice,
                                            color: AppColors.white,
                                            height: 24,
                                            width: 24,
                                          ),
                                        ),
                                        const SizedBox(width: AppSize.s12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                title: data.title,
                                                textStyle: getMediumStyle( 
                                                  color: Helper.isDark 
                                                  ? AppColors.white 
                                                  : AppColors.black
                                                ),
                                              ),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  CustomText(
                                                    title: '\$${data.totalPrice}',
                                                    textStyle: getMediumStyle(
                                                      color: AppColors.grey.withOpacity(0.9)
                                                    ),
                                                  ),
                                                  Row(
                                                    children: [
                                                      InkWell(
                                                        onTap: () => _ordersBloc.add(OrderItemDecrementEvent(index: index, tabIndex: tabIndex)),
                                                        child: Container(
                                                          padding: const EdgeInsets.symmetric(
                                                            horizontal: AppSize.s4,
                                                            vertical: AppSize.s4
                                                          ),
                                                          decoration: BoxDecoration(
                                                            color: AppColors.grey.withOpacity(0.3),
                                                            borderRadius: BorderRadius.circular(AppSize.s6)
                                                          ),
                                                          child: Icon(
                                                            Icons.remove,
                                                            color: Helper.isDark 
                                                            ? AppColors.white 
                                                            : AppColors.black, 
                                                            size: AppSize.s20
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                                                        child: CustomText(
                                                          title: data.quantity.toString(),
                                                          textStyle: getRegularStyle(
                                                            fontSize: AppSize.s16, 
                                                            color: Helper.isDark 
                                                            ? AppColors.white 
                                                            : AppColors.black
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: () => _ordersBloc.add(OrderItemIncrementEvent(index: index, tabIndex: tabIndex)),
                                                        child: Container(
                                                          padding: const EdgeInsets.symmetric(
                                                            horizontal: AppSize.s4,
                                                            vertical: AppSize.s4
                                                          ),
                                                          decoration: BoxDecoration(
                                                            color: AppColors.primaryColor,
                                                            borderRadius: BorderRadius.circular(AppSize.s6)
                                                          ),
                                                          child: const Icon(
                                                            Icons.add,
                                                            color: AppColors.white, 
                                                            size: AppSize.s20
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                              Visibility(
                                visible: isPreAuth,
                                child: Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Container(
                                    width: double.maxFinite,
                                    color: const Color(0xFFC1FBDA),
                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s5),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        const Icon(
                                          Icons.credit_score, 
                                          color: AppColors.green, 
                                          size: AppSize.s22
                                        ),
                                        CustomText(
                                          title: '  Pre-authorized ****$lastFourDigit',
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s12,
                                            color:const Color.fromARGB(255, 50, 175, 54)
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Divider(height: AppSize.s1, thickness: AppSize.s1, color: AppColors.grey),
                        const SizedBox(height: AppSize.s8),
                        Column(
                          children: List.generate(
                            orderBillingLabel.length, 
                            (index) {
                              var data = orderBillingLabel[index];
                              return Padding(
                                padding: const EdgeInsets.only(
                                  bottom: AppSize.s8,
                                  left: AppSize.s12, 
                                  right: AppSize.s12
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomText(
                                      title: data.title,
                                      textStyle: getRegularStyle(
                                        fontWeight: FontWeight.w400,
                                        fontSize: AppSize.s14,
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                    CustomText(
                                      title: '\$${data.amount}',
                                      textStyle: getRegularStyle(
                                        fontSize: AppSize.s14,
                                        fontWeight: FontWeight.w400,
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }
                          ),
                        ),
                        const SizedBox(height: AppSize.s4),
                        Row(
                          children: [
                            const SizedBox(width: AppSize.s12),
                            Expanded(
                              child: CustomOutlinedButton(
                                onPressed: isOrderUpdate
                                ? null
                                : () {
                                  if(isStayed) {
                                    _ordersBloc.add(OnCancelOrderEvent());
                                  } else {
                                    context.pop();
                                  }
                                },
                                text: AppStrings.cancel,
                                textColor: AppColors.red,
                                borderColor: AppColors.red,
                              ),
                            ),
                            const SizedBox(width: AppSize.s6),
                            Expanded(
                              child: CustomOutlinedButton(
                                onPressed: isOrderUpdate
                                ? null
                                : () {
                                  context.read<OrdersBloc>().add(OnStayEvent(
                                    orderSequence: orderSequence,
                                    customerName: customerName, 
                                    customerEmail: customerEmail, 
                                    customerPhone: customerPhone, 
                                    customerCreditCard: customerCreditCard, 
                                    tableName: tableName, 
                                    guestCount: guestCount,
                                    tableList: selectedTableList, 
                                    selectedOrder: selectOrderItem[tabIndex]
                                  ));
                                },
                                text: AppStrings.stay,
                                textColor: AppColors.blue,
                                borderColor: AppColors.blue,
                              ),
                            ),
                            const SizedBox(width: AppSize.s6),
                            Expanded(
                              child: CustomSolidButton(
                                onPressed: () => _ordersBloc.add(PlaceOrderEvent()),
                                text: isOrderUpdate && tabIndex < orderSequence
                                ? AppStrings.update
                                : AppStrings.place,
                              ),
                            ),
                            const SizedBox(width: AppSize.s12),
                          ],
                        ),
                        const SizedBox(height: AppSize.s18),
                      ],
                    );
                  }
                ),
                Positioned(
                  bottom: 0.0,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(isOrderUpdate ? orderSequence + 1 : 0, (index) => Container(
                      padding: const EdgeInsets.all(AppSize.s4),
                      margin: const EdgeInsets.only(right: AppSize.s4, bottom: 5.0),
                      decoration: BoxDecoration(
                        color: index == tabIndex ? AppColors.primaryColor : AppColors.grey, 
                        shape: BoxShape.circle
                      ))
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void showOrderCart({required BuildContext bContext, required OrdersBloc value}){
    tabIndex = 0;
    showModalBottomSheet(
      context: context, 
      isScrollControlled: true,
      builder: (_){
        return BlocProvider<OrdersBloc>.value(
          value: value,
          child: Container(
            color: Helper.isDark ? AppColors.black : AppColors.white,
            margin: EdgeInsets.only(top: context.statusBarHeight),
            child: BlocBuilder<OrdersBloc, OrdersState>(
              builder: (context, state){
                switch (state) {
                  case OrderSelectState _:
                    selectOrderItem.clear();
                    selectOrderItem.addAll(state.item);
                    ///calculate billing
                    double subTotal = 0.0;
                    for(var item in selectOrderItem[tabIndex]){
                      subTotal+=item.totalPrice;
                    }
                    subTotal = subTotal.roundTwo;
                    ///calculate tax
                    double tax = (subTotal * 10) / 100;
                    tax = tax.roundTwo;
                    orderBillingLabel[0].amount = subTotal;
                    orderBillingLabel[1].amount = 0.0;
                    orderBillingLabel[2].amount = tax;
                    orderBillingLabel[3].amount = 0.0;
                    orderBillingLabel[4].amount = (subTotal + tax).roundTwo;
                    break;
                  case OnChangeTabPageIndexState _:
                    tabIndex = state.pageIndex;
                    calculateBillingAmount(getSelectedOrder(tabIndex));
                    break;
                  default:
                }
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s8,
                        vertical: AppSize.s8
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () => context.pop(),
                            icon: const Icon(Icons.west)
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s8,
                              horizontal: AppSize.s10
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.headerColorDark 
                              : AppColors.backgroundColor,
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  AppIcons.groupIcon, 
                                  size: AppSize.s20
                                ),
                                const SizedBox(width: AppSize.s8),
                                CustomText(
                                  title: 'Guest  $guestCount',
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: AppSize.s8,
                        right: AppSize.s8,
                        bottom: AppSize.s8,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s8,
                              horizontal: AppSize.s10
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.headerColorDark 
                              : AppColors.backgroundColor,
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  AppIcons.accountCircleIcon, 
                                  size: AppSize.s20
                                ),
                                const SizedBox(width: AppSize.s8),
                                CustomText(
                                  title: customerName,
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s8,
                              horizontal: AppSize.s10
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.headerColorDark 
                              : AppColors.backgroundColor,
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  AppIcons.chairIcon, 
                                  size: AppSize.s20
                                ),
                                const SizedBox(width: AppSize.s8),
                                CustomText(
                                  title: tableName,
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s12), 
                                  child: CustomText(
                                    title: '|', 
                                    textStyle: getMediumStyle(
                                      fontSize: AppSize.s16,
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                CustomText(
                                  title: '#1',
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(
                      color: AppColors.backgroundColor,
                      height: AppSize.s5,
                      thickness: AppSize.s5,
                    ),
                    Expanded(
                      child: PageView.builder(
                        onPageChanged: (value) => _ordersBloc.add(OnChangeTabPageIndexEvent(pageIndex: value)),
                        itemCount: isOrderUpdate
                        ? orderSequence + 1
                        : orderSequence,
                        itemBuilder: (_, subIndex){
                          return Column(
                            children: [
                              Expanded(
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: getSelectedOrder(tabIndex).length,
                                  itemBuilder: (_, index){
                                    var data = getSelectedOrder(tabIndex)[index];
                                    return Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: AppSize.s12,
                                        vertical: AppSize.s10
                                      ),
                                      decoration: const BoxDecoration(
                                        border: Border(bottom: BorderSide(color: AppColors.grey))
                                      ),
                                      child: Row(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.all(AppSize.s8),
                                            decoration: const BoxDecoration(
                                              color: AppColors.primaryColor,
                                              shape: BoxShape.circle
                                            ),
                                            child: const CustomImageView(
                                              imagePath: AppImages.orangeJuice,
                                              color: AppColors.white,
                                              width: AppSize.s20,
                                              height: AppSize.s20,
                                            ),
                                          ),
                                          const SizedBox(width: AppSize.s12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                CustomText(
                                                  title: data.title,
                                                  textStyle: getRegularStyle(
                                                    fontSize: AppSize.s14,
                                                    color: Helper.isDark 
                                                    ? AppColors.white 
                                                    : AppColors.black,
                                                  ),
                                                ),
                                                const SizedBox(height: AppSize.s2),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    CustomText(
                                                      title: '\$ ${data.totalPrice}',
                                                      textStyle: getRegularStyle(
                                                        fontSize: AppSize.s14,
                                                        color: AppColors.grey.withOpacity(0.9)
                                                      ),
                                                    ),
                                                    Row(
                                                      children: [
                                                        InkWell(
                                                          onTap: () => _ordersBloc.add(OrderItemDecrementEvent(index: index, tabIndex: tabIndex)),
                                                          child: Container(
                                                            padding: const EdgeInsets.symmetric(
                                                              horizontal: AppSize.s4,
                                                              vertical: AppSize.s4
                                                            ),
                                                            decoration: BoxDecoration(
                                                              color: Helper.isDark
                                                              ?  AppColors.lightTextGrey
                                                              : AppColors.grey.withOpacity(0.4),
                                                              borderRadius: BorderRadius.circular(AppSize.s6)
                                                            ),
                                                            child: const Icon(
                                                              AppIcons.removeIcon,
                                                              color: AppColors.black, 
                                                              size: AppSize.s20
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets.symmetric(horizontal: AppSize.s14),
                                                          child: CustomText(
                                                            title: '${data.quantity}',
                                                            textStyle: getRegularStyle(
                                                              fontSize: AppSize.s14,
                                                              color: Helper.isDark 
                                                              ? AppColors.white 
                                                              : AppColors.black,
                                                            ),
                                                          ),
                                                        ),
                                                        InkWell(
                                                          onTap: () => _ordersBloc.add(OrderItemIncrementEvent(index: index, tabIndex: tabIndex)),
                                                          child: Container(
                                                            padding: const EdgeInsets.symmetric(
                                                              horizontal: AppSize.s4,
                                                              vertical: AppSize.s4
                                                            ),
                                                            decoration: BoxDecoration(
                                                              color: AppColors.primaryColor,
                                                              borderRadius: BorderRadius.circular(AppSize.s6)
                                                            ),
                                                            child: const Icon(
                                                              Icons.add,
                                                              color: AppColors.white, 
                                                              size: AppSize.s20
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const Divider(
                                color: AppColors.backgroundColor,
                                height: AppSize.s5,
                                thickness: AppSize.s5,
                              ),
                              const SizedBox(height: AppSize.s12),
                              Column(
                                children: List.generate(
                                  orderBillingLabel.length, 
                                  (index) {
                                    var data = orderBillingLabel[index];
                                    return Padding(
                                      padding: const EdgeInsets.only(
                                        bottom: AppSize.s12,
                                        left: AppSize.s12,
                                        right: AppSize.s12
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: data.title,
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black,
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${data.amount}',
                                            textStyle: getMediumStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }
                                ),
                              ),
                              const Divider(
                                color: AppColors.backgroundColor,
                                height: AppSize.s5,
                                thickness: AppSize.s5,
                              ),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: CustomOutlinedButton(
                                            onPressed: () => context.pop(),
                                            text: AppStrings.cancelOrder,
                                            textColor: AppColors.red,
                                            borderColor: AppColors.red,
                                          ),
                                        ),
                                        const SizedBox(width: AppSize.s6),
                                        Expanded(
                                          child: CustomOutlinedButton(
                                            onPressed: () => context.pop(),
                                            text: AppStrings.stay,
                                            textColor: AppColors.blue,
                                            borderColor: AppColors.blue,
                                          ),
                                        ),
                                        const SizedBox(width: AppSize.s6),
                                        Expanded(
                                          child: CustomSolidButton(
                                            onPressed: isOrderUpdate && tabIndex < orderSequence
                                            ? null
                                            : () {
                                              // if(widget.tableData['from'] == AppRoutes.paymentTerminalScreen) {
                                              //   paymentDetails = PaymentModel(
                                              //     isFirstOrder: false,
                                              //     orderedItem: selectOrderItem[tabIndex], 
                                              //     customerName: customerName, 
                                              //     customerEmail: customerEmail,
                                              //     customerPhone: customerPhone,
                                              //     customerCreditCard: customerCreditCard,
                                              //     totalGuest: guestCount,
                                              //     employeeId: Preferences.getString(key: AppStrings.prefUserId),
                                              //     orderId: orderId,
                                              //     customerId: customerId,
                                              //     tableName: tableName, 
                                              //     totalAmount: orderBillingLabel[4].amount,
                                              //     subTotal: orderBillingLabel[0].amount,
                                              //     discount: orderBillingLabel[1].amount,
                                              //     tax: orderBillingLabel[2].amount,
                                              //     orderSequence: orderSequence,
                                              //     selectedTableList: selectedTableList
                                              //   );
                                              // } else {
                                              //   paymentDetails = PaymentModel(
                                              //     isFirstOrder: isStayed ? false : true,
                                              //     orderedItem: selectOrderItem[tabIndex], 
                                              //     customerName: customerName, 
                                              //     orderId: orderId,
                                              //     customerId: customerId,
                                              //     customerEmail: customerEmail,
                                              //     customerPhone: customerPhone,
                                              //     customerCreditCard: customerCreditCard,
                                              //     totalGuest: guestCount,
                                              //     employeeId: Preferences.getString(key: AppStrings.prefUserId),
                                              //     tableName: tableName, 
                                              //     totalAmount: orderBillingLabel[4].amount,
                                              //     subTotal: orderBillingLabel[0].amount,
                                              //     discount: orderBillingLabel[1].amount,
                                              //     tax: orderBillingLabel[2].amount,
                                              //     orderSequence: orderSequence,
                                              //     selectedTableList: selectedTableList
                                              //   );
                                              // }
                                              // if(isOrderUpdate) {
                                              //   var subTotal = 0.0;
                                              //   var discount = 0.0;
                                              //   var tax = 0.0;
                                              //   var tip = 0.0;
                                              //   var grandTotal = 0.0;
                                              //   for(var item in selectOrderItem[tabIndex]){
                                              //     subTotal+=item.totalPrice;
                                              //   }
                                              //   subTotal = subTotal.roundTwo;
                                              //   tax = (subTotal * 10) / 100;
                                              //   tax = tax.roundTwo;
                                              //   grandTotal = (subTotal + tax).roundTwo;
                                              //   context.pop();
                                              //   context.read<OrdersBloc>().add(UpdateOrderEvent(
                                              //     orderId: orderId, 
                                              //     orderSequence: orderSequence + 1, 
                                              //     subTotal: subTotal, 
                                              //     discount: discount, 
                                              //     tax: tax, 
                                              //     tip: tip, 
                                              //     grandTotal: grandTotal, 
                                              //     productList: selectOrderItem[tabIndex]
                                              //   ));
                                              // } else if(paymentDetails != null) {
                                              //   context.pop();
                                              //   // Need to modify Here
                                              //   // context.read<OrdersBloc>().add(PlaceOrderEvent(paymentModel: paymentDetails!));
                                              // }
                                            },
                                            text: AppStrings.placeOrder,
                                            verPadding: AppSize.s20,
                                            horPadding: AppSize.s18,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      mainAxisSize: MainAxisSize.min,
                                      children: List.generate(isOrderUpdate ? orderSequence + 1 : 0, (index) => Container(
                                        padding: const EdgeInsets.all(AppSize.s5),
                                        margin: const EdgeInsets.only(right: AppSize.s4, top: 4.0),
                                        decoration: BoxDecoration(
                                          color: index == tabIndex ? AppColors.primaryColor : AppColors.grey, 
                                          shape: BoxShape.circle
                                        ))
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          );
                        }
                      ),
                    ),
                  ],
                );
              }
            ),
          ),
        );
      }
    );
  }

  void showPaymentSuccessDialog({required BuildContext context}){
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_){
        return AlertDialog(
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          content: Container(
            width: context.screenWidth <= 600
            ? context.screenWidth * 0.95
            : context.screenWidth * 0.34,
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s30,
              horizontal: AppSize.s30
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s12),
              color: Helper.isDark 
              ? AppColors.contentColorDark 
              : AppColors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const CustomImageView(
                  imagePath: AppImages.paymentSuccessGIF,
                ),
                CustomText(
                  title: AppStrings.orderPlaceSuccessfully,
                  textAlign: TextAlign.center,
                  textStyle: getBoldStyle(
                    color: AppColors.primaryColor,
                    fontSize: AppSize.s28
                  ),
                ),
                const SizedBox(height: AppSize.s8),
                CustomText(
                  title: AppStrings.thankYouForOrderMsg,
                  textAlign: TextAlign.center,
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s18,
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                Row(
                  children: [
                    Expanded(
                      child: CustomOutlinedButton(
                        text: AppStrings.home,
                        preFixWidget: const Icon(AppIcons.homeIcon),
                        widgetSpacing: AppSize.s10,
                        textSize: AppSize.s16,
                        onPressed: () {
                          if(context.mounted){
                            while (GoRouter.of(context).canPop()) {
                              GoRouter.of(context).pop();
                            }
                            GoRouter.of(context).pushReplacement(AppRoutes.dashboardScreen);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: AppSize.s10),
                    Expanded(
                      child: CustomSolidButton(
                        text: AppStrings.continuePayment,
                        textSize: AppSize.s14,
                        verPadding: AppSize.s18,
                        onPressed: () => _ordersBloc.add(OrderContinueForNewPaymentEvent()),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  List<OrderModel> getSelectedOrder(int tabIndex) {
    try {
      return selectOrderItem[tabIndex];
    } catch(e) {
      return [];
    }
  }

  void showPaymentProcessingDialog() {
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (_) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: OrdersAddNewCardDialog(
            ordersBloc: _ordersBloc,
            customerName: customerName,
            stateList: stateList,
          ),
        );
      }
    );
  }
  
}