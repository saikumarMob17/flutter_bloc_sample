// import '../../../../widgets/dropdownmenu_model.dart';
// import '../../domain/order_model.dart';
// import '../../domain/product_category_response.dart';
part of 'orders_bloc.dart';
sealed class OrdersState {}

class OrdersInitialState extends OrdersState {}

class OrderSelectState extends OrdersState {
  List<List<OrderModel>> item;
  OrderSelectState({required this.item});
}

class OrderErrorState extends OrdersState {
  String error;
  OrderErrorState({this.error = ''});
}

// class OrderPlaceState extends OrdersState {}

class OrdersProductSubCategoryState extends OrdersState {

  List<SubCategoryProduct> productSubCategoryList;
  List<DropdownMenuModel> drinkDropDownList;
  List<List<OrderModel>> selectedOrder;
  List<DropdownMenuModel> stateMenuList;
  int orderSequence;
  String orderId;
  String tableName;
  String customerName;
  int guestCount;
  String customerEmail;
  String customerPhone;
  String customerCreditCard;
  List<Map> selectedTableList;
  bool isUpdate;
  bool isStayed;
  

  OrdersProductSubCategoryState({
    required this.productSubCategoryList, 
    required this.drinkDropDownList,
    required this.selectedOrder,
    required this.orderSequence,
    required this.tableName,
    required this.customerName,
    required this.guestCount,
    required this.selectedTableList,
    required this.stateMenuList,
    this.isUpdate = false,
    this.isStayed = false,
    this.customerEmail = '',
    this.customerCreditCard = '',
    this.customerPhone = '',
    this.orderId = ''
  });
  
}

class OrdersChangeDropDownSubCategoryState extends OrdersState {

  int selectedValue;
  String selectedItem;
  List<SubCategoryProduct> productSubCategoryList;

  OrdersChangeDropDownSubCategoryState({
    required this.selectedValue, 
    required this.selectedItem, 
    required this.productSubCategoryList
  });

}

class OrdersLoadingState extends OrdersState {}
class SuccessState extends OrdersState {
  String msg;

  SuccessState({this.msg = ''});
}

class OrdersPlaceOrderSuccessState extends OrdersState {
  String message;
  OrdersPlaceOrderSuccessState({this.message = ''});
}

class OrdersFailedState extends OrdersState {
  String message;

  OrdersFailedState({this.message = ''});
}


class OrdersProductChangePageViewState extends OrdersState {
  int pageIndex;
  OrdersProductChangePageViewState({required this.pageIndex});
}

class OnChangeTabPageIndexState extends OrdersState {
  int pageIndex;
  OnChangeTabPageIndexState({required this.pageIndex});
}

class OrdersOpenCartState extends OrdersState {}

class OrdersSelectTableState extends OrdersState {
  int selectedIndex;
  OrdersSelectTableState({this.selectedIndex = -1});
}

class OnStayState extends OrdersState {
  String customerName;
  String customerEmail;
  String customerPhone;
  String customerCreditCard;
  String tableName;
  int guestCount;
  List<Map<dynamic, dynamic>> tableList;
  List<OrderModel> selectedOrder;

  OnStayState({
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.customerCreditCard,
    required this.tableName,
    required this.guestCount,
    required this.tableList,
    required this.selectedOrder,
  });
}

class OnSwitchUserOrdersState extends OrdersState {
  bool isLogout;

  OnSwitchUserOrdersState({this.isLogout = false});
}

class OrderContinueForNewPaymentState extends OrdersState {
  String orderId;

  OrderContinueForNewPaymentState({required this.orderId});
}


class OrdersFinixErrorState extends OrdersState {
  String message;
  bool isSuccess;
  String authorizationId;
  String cardLastFourDigit;

  OrdersFinixErrorState({
    this.authorizationId = '',
    this.cardLastFourDigit = '',
    this.message = '', this.isSuccess = false});
}

class OnSplitItemState extends OrdersState {
  PaymentModel paymentModel;

  OnSplitItemState({required this.paymentModel});
}

class CardOnNameChangeState extends OrdersState {
  String message;

  CardOnNameChangeState({this.message = ''});
}

class CardNumberChangeState extends OrdersState {
  String message;

  CardNumberChangeState({this.message = ''});
}

class CardExpiryChangeState extends OrdersState {
  String message;

  CardExpiryChangeState({this.message = ''});
}

class CardCvvChangeState extends OrdersState {
  String message;
  CardCvvChangeState({this.message = ''});
}

class CardZipCodeChangeState extends OrdersState {
  String message;

  CardZipCodeChangeState({this.message = ''});
}

class OnChangeStateDropDownState extends OrdersState {
  String stateCode;

  OnChangeStateDropDownState({this.stateCode = ''});
}

// class CreatePaymentInstrumentState extends OrdersState {
//   String authorizationId;
//   String cardLastFourDigit;

//   CreatePaymentInstrumentState({required this.authorizationId, required this.cardLastFourDigit});
// }