import 'dart:io';
import 'package:flutter/services.dart';
import '../../../../services/finix_create_authorization_model.dart';
import '../../../../services/finix_payment_instrument_response.dart';
import '../../../../services/finix_create_payment_instrument_model.dart';
import '../../../../utils/app_extension_method.dart';
import '../../domain/update_order_request.dart';
import '../../../../network/custom_exception.dart';
import '../../../../routes/route.dart';
import '../../data/orders_repository.dart';
import '../../../../widgets/dropdownmenu_model.dart';
import '../../domain/order_model.dart';
import '../../../../routes/app_routes.dart';
import '../../../../utils/check_connectivity.dart';
import '../../domain/order_place_request.dart' as order_place;
import '../../domain/order_place_request.dart';
import '../../domain/product_category_response.dart';
import 'dart:convert';
part 'orders_event.dart';
part 'orders_state.dart';

class OrdersBloc extends Bloc<OrdersEvent, OrdersState>{

  final Map tableData;
  List<List<OrderModel>> selectedOrderList = [];
  late CheckConnectivity _checkConnectivity;
  late OrderRepository _orderRepository;
  var productCategoryList = <ProductCategory>[];
  var productSubCategoryList = <SubCategoryProduct>[];
  var drinkDropdownList = <DropdownMenuModel>[];
  int orderSequence = 1;
  String tableName = '';
  String customerName = '';
  int guestCount = 0;
  String customerEmail = '';
  String customerPhone = '';
  String customerFinixIdentity = '';
  String customerCreditCard = '';
  var selectedTableList = <Map>[];
  bool isUpdate = false;
  bool isStayed = false;
  String orderId = '';
  int orderAvailableIndex = -1;
  int pageIndex = 0;
  PaymentModel? paymentDetails;
  String customerId = '';
  String selectedServerId = '';
  var stateMap = <String, dynamic>{};
  List<DropdownMenuModel> stateMenuList = [];
  List<PaymentInstrument> paymentInstrumentList = [];
  PreAuthDetails? isPreAuth;

  OrdersBloc({required this.tableData}) : super(OrdersInitialState()) {
    _checkConnectivity = CheckConnectivity();
    _orderRepository = OrderRepository();
    on<OrdersSelectEvent>(_onSelectOrder);
    on<OrderItemDecrementEvent>(_onDecrementOrderItem);
    on<OrderItemIncrementEvent>(_onIncrementOrderItem);
    on<OrdersProductSubCategoryEvent>(_onGetProductSubCategory);
    on<OrdersChangeDropDownEvent>(_onChangeDropDown);
    on<OrdersProductChangePageViewEvent>(_onChangePageViewIndex);
    on<OrdersOpenCartEvent>(_onOpenCartEvent);
    on<OrdersSelectTableEvent>(_onSelectTable);
    on<PlaceOrderEvent>(_onPlaceOrder);
    on<OnStayEvent>(_onStayOrder);
    on<OnChangeTabPageIndexEvent>(_onChangeTabIndex);
    on<OnCancelOrderEvent>(_onCancelOrder);
    on<OnSwitchUserOrdersEvent>(_onSwitchUser);
    on<OnSearchProductsOrdersEvent>(_onSearchProducts);
    on<OrderContinueForNewPaymentEvent>(_onContinueForNewOrderPayment);
    
    ///Below events are related to card authorization
    on<CreatePaymentInstrumentEvent>(_authorizeCard);
    on<CardNumberChangeEvent>(_onChangeCardNumber);
    on<CardOnNameChangeEvent>(_onChangeCardName);
    on<CardExpiryChangeEvent>(_onChangeExpiryDate);
    on<CardCvvChangeEvent>(_onChangeCvv);
    on<CardZipCodeChangeEvent>(_onChangeZipCode);
    on<OnChangeStateDropDownEvent>(_onChangeStateDropDown);
    on<OrderHideFinixErrorEvent>(_hideFinixError);
  }

  void _hideFinixError(OrderHideFinixErrorEvent event, Emitter emit) {
    emit(OrdersFinixErrorState());
  }

  void _onChangeCardNumber(CardNumberChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardNumberChangeState(message: 'Please provide card number'));
    } else if(event.text.length < 19) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
    } else {
      emit(CardNumberChangeState());
    }
  }

  void _onChangeCardName(CardOnNameChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardOnNameChangeState(message: 'Please provide card holder name'));
    } else {
      emit(CardOnNameChangeState());
    }
  }

  void _onChangeExpiryDate(CardExpiryChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardExpiryChangeState(message: 'Please provide card expiry date'));
    } else {
      emit(CardExpiryChangeState());
    }
  }

  void _onChangeCvv(CardCvvChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardCvvChangeState(message: 'Please provide card cvv number'));
    } else {
      emit(CardCvvChangeState());
    }
  }

  void _onChangeZipCode(CardZipCodeChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardZipCodeChangeState(message: 'Please provide postal code'));
    } else {
      emit(CardZipCodeChangeState());
    }
  }

  void _onChangeStateDropDown(OnChangeStateDropDownEvent event, Emitter emit) {
    emit(OnChangeStateDropDownState(stateCode: event.stateCode));
  }

  Future<void> _authorizeCard(CreatePaymentInstrumentEvent event, Emitter emit) async {
    if(await _addNewCardValidation(event, emit)) {
      try {
        emit(OrdersLoadingState());
        var response = await _orderRepository.getAllFinixPaymentInstrument();
        paymentInstrumentList.clear();
        for(var item in response) {
          if(item.identity == customerFinixIdentity) {
            paymentInstrumentList.add(item);
          }
        }
        String paymentInstrumentId = "";
        String cardLastFourDigit = event.cardNumber.substring(event.cardNumber.length - 4);
        var tempExpiryData = event.expiryMonthYear.replaceAll(' ', '').split('/');  
        if(paymentInstrumentList.isNotEmpty) {
          for(var item in paymentInstrumentList) {
            if(item.lastFour == cardLastFourDigit && (item.expirationMonth == int.parse(tempExpiryData[0])) && (item.expirationYear == int.parse(tempExpiryData[1]))) {
              paymentInstrumentId = item.id!;
              break;
            }
          }
        }
        if(paymentInstrumentId.isEmpty) {
          var paymentInstrumentModel = FinixPaymentInstrumentModel(
            customerIdentity: customerFinixIdentity, 
            cardNumber: event.cardNumber, 
            expiryMonth: int.parse(tempExpiryData[0]), 
            expiryYear: int.parse(tempExpiryData[1]), 
            city: event.city,
            line1: event.addressLine1,
            region: stateMap[event.region]!,
            cvv: event.cvv, 
            cardHolderName: event.cardHolderName,
            postalCode: event.postalCode
          ).toJson;
          var response = await _orderRepository.createPaymentInstrument(body: paymentInstrumentModel);
          switch (response.statusCode) {
            case HttpStatus.created:
              paymentInstrumentId = jsonDecode(response.body)['id'];
              break;
            case HttpStatus.unprocessableEntity:
              throw CustomException(message: '${jsonDecode(response.body)['_embedded']['errors'][0]['message']}');
            default:
              throw CustomException(message: "Unable to add new card");
          }
        }
        if(paymentInstrumentId.isNotEmpty) {
          var authorizationBody = FinixCreateAuthorizationModel(
            amount: 10000, 
            paymentInstrumentId: paymentInstrumentId
          ).toJson;
          var response = await _orderRepository.createAuthorization(authorizationBody);
          switch (response.statusCode) {
            case HttpStatus.created:
              isPreAuth = PreAuthDetails(
                isPreAuth: true,
                paymentInstrumentId: paymentInstrumentId,
                authorizationId: jsonDecode(response.body)['id'], 
                cardLastFourDigit: cardLastFourDigit
              );
              emit(OrdersFinixErrorState(
                message: 'Card has been authorized successfully',
                authorizationId: jsonDecode(response.body)['id'], 
                cardLastFourDigit: cardLastFourDigit,
                isSuccess: true
              ));
              break;
            case HttpStatus.paymentRequired:
            case HttpStatus.unprocessableEntity:
              var errorMap = jsonDecode(response.body)['_embedded']['errors'][0];
              var failureCode = errorMap['failure_code'] ?? '';
              throw CustomException(message: '${errorMap['message']}$failureCode');
            default:
              throw CustomException(message: AppStrings.someThingWentWrong);
          }
        }
      } on CustomException catch (e) {
        emit(OrdersFinixErrorState(message: e.message));
      }   
    }
  }

  Future<bool> _addNewCardValidation(CreatePaymentInstrumentEvent event, Emitter emit) async {
    if(event.cardHolderName.isBlank) {
      emit(CardOnNameChangeState(message: 'Please provide card holder name'));
      return false;
    } else if(event.cardNumber.isBlank) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
      return false;
    } else if(event.cardNumber.length < 16) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
      return false;
    } else if(event.expiryMonthYear.isBlank) {
      emit(CardExpiryChangeState(message: 'Please provide valid expiry date'));
      return false;
    } else if(event.cvv.isBlank) {
      emit(CardCvvChangeState(message: 'Please provide card security pin'));
      return false;
    } else if(event.postalCode.isBlank) {
      emit(CardZipCodeChangeState(message: 'Please provide postal code'));
      return false;
    } else if(!await _checkConnectivity.hasConnection) {
      emit(OrdersFinixErrorState(message: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  void _onContinueForNewOrderPayment(OrderContinueForNewPaymentEvent event, Emitter emit) {
    if(orderId.isNotEmpty) {
      emit(OrderContinueForNewPaymentState(orderId: orderId));
    }
  }

  Future<void> _getAllStateList() async {
    try {
      var data = await rootBundle.loadString('assets/json/us_state_list.json');
      stateMap.clear();
      stateMap.addAll(jsonDecode(data));
      stateMenuList.clear();
      stateMap.forEach((key, value) {
        stateMenuList.add(DropdownMenuModel(
          value: key, 
          item: value
        ));
      });
    } on CustomException catch (e) {
      debugPrint(e.message);
    }
  }

  void _onSelectOrder(OrdersSelectEvent event, Emitter emit) {
    if(productSubCategoryList.isNotEmpty) {
      var data = productSubCategoryList[event.index];
      if(data.quantity == null || data.quantity! <= 0) {
        emit(OrdersFailedState(message: '${data.productSecondCategorieName} is out of stock'));
      } else {
        orderAvailableIndex = -1;
        try {
          var tempSelectedOrder = selectedOrderList[event.tabIndex];
          orderAvailableIndex = tempSelectedOrder.indexWhere((element) => element.itemId == data.productSecondCategorieId);
          if(orderAvailableIndex < 0) {
            tempSelectedOrder.add(OrderModel(
              itemId: data.productSecondCategorieId!, 
              title: data.productSecondCategorieName!, 
              totalPrice: data.unitPrice!.toDouble(), 
              price: data.unitPrice!.toDouble(), 
              itemMaxQuantity: data.quantity ?? 0,
              quantity: 1)
            );
          } else {
            var orderItem = tempSelectedOrder[orderAvailableIndex];
            if(orderItem.quantity < data.quantity!) {
              orderItem.quantity += 1;
              orderItem.totalPrice = orderItem.price * orderItem.quantity;
              tempSelectedOrder[orderAvailableIndex] = orderItem;
            }
          }
        } catch (e) {
          selectedOrderList.add([OrderModel(
            itemId: data.productSecondCategorieId!, 
            title: data.productSecondCategorieName!, 
            totalPrice: data.unitPrice!.toDouble(), 
            price: data.unitPrice!.toDouble(), 
            itemMaxQuantity: data.quantity ?? 0,
            quantity: 1)
          ]);
        }      
        emit(OrderSelectState(item: selectedOrderList));
      }
    }
  }

  void _onIncrementOrderItem(OrderItemIncrementEvent event, Emitter emit) {
    if(selectedOrderList.isNotEmpty){
      var orderItem = selectedOrderList[event.tabIndex][event.index];
      if(orderItem.quantity < orderItem.itemMaxQuantity) {
        orderItem.quantity+=1;
        orderItem.totalPrice = orderItem.price * orderItem.quantity;
        selectedOrderList[event.tabIndex][event.index] = orderItem;
        emit(OrderSelectState(item: selectedOrderList));
      }
    }
  }

  void _onDecrementOrderItem(OrderItemDecrementEvent event, Emitter emit) {
    if(selectedOrderList.isNotEmpty){
      var orderItem = selectedOrderList[event.tabIndex][event.index];
      if(orderItem.quantity == 1){
        selectedOrderList[event.tabIndex].removeAt(event.index);
      } else {
        orderItem.quantity-=1;
        orderItem.totalPrice = orderItem.price * orderItem.quantity;
        selectedOrderList[event.tabIndex][event.index] = orderItem;
      }
      emit(OrderSelectState(item: selectedOrderList));
    }
  }

  Future<void> _onGetProductSubCategory(OrdersProductSubCategoryEvent event, Emitter emit) async {
    try {
      emit(OrdersLoadingState());
      await _getAllStateList();
      var orderCategory = await _orderRepository.productCategory();
      productCategoryList.clear();
      productCategoryList = orderCategory;
      if(productCategoryList.isNotEmpty) {
        productSubCategoryList.clear();
        productSubCategoryList.addAll(productCategoryList.first.subCategoryProduct ?? []);
        for(var item in productCategoryList) {
          drinkDropdownList.add(DropdownMenuModel(value: item.mainCategoryProductId!.toString(), item: item.mainCategoryProduct!));
        }
      }
      ///show data in case of dupliate order
      var duplicateData = event.duplicateData;
      customerName = duplicateData['customer_name'];
      customerEmail = duplicateData['customer_email'];
      // customerPhone = duplicateData['customer_phone'];
      selectedServerId = duplicateData['selected_server_id'];
      customerFinixIdentity = duplicateData['customer_identity'];
      tableName = duplicateData['selected_table'];
      guestCount = duplicateData['total_guest'];
      selectedTableList = duplicateData['table_list'] as List<Map>;

      if(duplicateData['from'] == AppRoutes.tableViewScreen && duplicateData['order_sequence'] != null) {
        orderSequence = duplicateData['order_sequence'];
        isStayed = duplicateData['stay'];
        var tempSelectedOrder = <OrderModel>[];
        for(var item in duplicateData['order_details']){
          tempSelectedOrder.add(OrderModel(
            itemId: item['itemId'],
            price: item['productPrice'].toDouble(),
            quantity: item['quantity'],
            title: item['productName'],
            totalPrice: (item['productPrice'].toDouble() * item['quantity'].toDouble())
          ));
        }
        selectedOrderList.add(tempSelectedOrder);
      }

      if(duplicateData.isNotEmpty && productSubCategoryList.isNotEmpty) {
        if(duplicateData['from'] == AppRoutes.paymentTerminalScreen && duplicateData['type'] == AppStrings.closeChecks) {
          orderSequence = 1;
          orderId = duplicateData['order_id'];
          selectedOrderList.clear();
          var tempSelectedOrder = <OrderModel>[];
          for(var item in duplicateData['order_details']){
            for(var subItem in item.productDetails){
              tempSelectedOrder.add(OrderModel(
                itemId: subItem.productId,
                price: subItem.productPrice!.toDouble(),
                quantity: subItem.quantity!,
                title: subItem.productName,
                totalPrice: (subItem.productPrice!.toDouble() * subItem.quantity!.toDouble())
              ));
            }
            selectedOrderList.add(tempSelectedOrder);
          }
        }
        if(duplicateData['type'] == AppStrings.openChecks) {
          orderSequence = duplicateData['order_sequence'];
          isUpdate = true;
          orderId = duplicateData['order_id'];
          selectedOrderList.clear();
          for(var item in duplicateData['order_details']){
            var tempSelectedOrder = <OrderModel>[];
            for(var subItem in item.productDetails){
              tempSelectedOrder.add(OrderModel(
                itemId: subItem.productId,
                price: subItem.productPrice!.toDouble(),
                quantity: subItem.quantity!,
                title: subItem.productName,
                totalPrice: (subItem.productPrice!.toDouble() * subItem.quantity!.toDouble())
              ));
            }
            selectedOrderList.add(tempSelectedOrder);
          }
        }
      }
      emit(OrdersProductSubCategoryState(
        orderId: orderId,
        productSubCategoryList: productSubCategoryList, 
        drinkDropDownList: drinkDropdownList,
        selectedOrder: selectedOrderList,
        orderSequence: orderSequence,
        guestCount: guestCount,
        customerName: customerName,
        tableName: tableName,
        isUpdate: isUpdate,
        selectedTableList: selectedTableList,
        isStayed: isStayed,
        stateMenuList: stateMenuList
        )
      );
    } on CustomException catch (e) {
      emit(OrdersFailedState(message: e.message));
    }
  }

  void _onChangeTabIndex(OnChangeTabPageIndexEvent event, Emitter emit) {
    pageIndex = event.pageIndex;
    emit(OnChangeTabPageIndexState(pageIndex: event.pageIndex));
  }

  void _onChangeDropDown(OrdersChangeDropDownEvent event, Emitter emit) {
    if(drinkDropdownList.isNotEmpty) {
      var data = drinkDropdownList.firstWhere((element) => element.value == event.selectedValue.toString());
      for(var item in productCategoryList){
        if(item.mainCategoryProductId == event.selectedValue){
          productSubCategoryList.clear();
          productSubCategoryList.addAll(item.subCategoryProduct!);
          break;
        }
      }
      emit(OrdersChangeDropDownSubCategoryState(
        selectedValue: event.selectedIndex, 
        selectedItem: data.item, 
        productSubCategoryList: productSubCategoryList)
      );
    }
  }

  void _onChangePageViewIndex(OrdersProductChangePageViewEvent event, Emitter emit){
    emit(OrdersProductChangePageViewState(pageIndex: event.pageIndex));
  }

  void _onOpenCartEvent(OrdersOpenCartEvent event, Emitter emit) {
    emit(OrdersOpenCartState());
  }

  void _onSelectTable(OrdersSelectTableEvent event, Emitter emit){
    emit(OrdersSelectTableState(selectedIndex: event.selectedIndex));
  }

  Future<void> _onPlaceOrder(PlaceOrderEvent event, Emitter emit) async {
    if(isUpdate) {
      try {
        if(selectedOrderList[pageIndex].isNotEmpty) {
          var subTotal = 0.0;
          var discount = 0.0;
          var tax = 0.0;
          var tip = 0.0;
          for(var item in selectedOrderList[pageIndex]) {
            subTotal+=item.totalPrice;
          }
          tax = (subTotal * 10) / 100;
          var billingDetails = order_place.BillingDetails(
            subTotal: subTotal.roundTwo,
            discount: discount,
            tax: tax,
            tip: tip,
            grandTotal: (subTotal + tax).roundTwo
          );
          var orderDetails = List.generate(selectedOrderList[pageIndex].length, (index) {
            var subData = selectedOrderList[pageIndex][index];
            return OrderDetails(
              productId: subData.itemId,
              productName: subData.title, 
              quantity: subData.quantity,
              productPrice: subData.price
            );
          });
          if(tableData['order_details'].isNotEmpty) {
            for(var item in tableData['order_details']) {
              if(pageIndex == orderSequence) {
                subTotal += item.billingDetails!.subTotal!;
                discount += item.billingDetails!.discount!;
                tax += item.billingDetails!.tax!;
                tip += item.billingDetails!.tip;
              } else if(item.orderSequence != pageIndex + 1) {
                subTotal += item.billingDetails!.subTotal!;
                discount += item.billingDetails!.discount!;
                tax += item.billingDetails!.tax!;
                tip += item.billingDetails!.tip;
              }
            }
          }
          var updateOrderRequest = UpdateOrderRequest(
            orderId: orderId, 
            orderSequence: pageIndex + 1, 
            orderDetails: orderDetails, 
            billingDetails: billingDetails, 
            totalBillingDetails: {
              "subTotal": subTotal,
              "discount": discount,
              "tax": tax,
              "tip": tip,
              "grandTotal": (subTotal + tax).roundTwo,
              "paymentStatus": false,
              "balanceDue": (subTotal + tax).roundTwo,
              "balanceRefund": 0
            }
          ).toJson;
          emit(OrdersLoadingState());
          try {
            var response = await _orderRepository.updateOrder(body: updateOrderRequest);
            if(response.isNotEmpty) {
              emit(OrdersPlaceOrderSuccessState(message: response['status']));
            } else {
              emit(OrdersFailedState(message: "Unable to place order"));
            }
          } on CustomException catch (e) {
            throw CustomException(message: e.message);
          }
        }
      } on CustomException catch(e) {
        emit(OrdersFailedState(message: e.message));
      } catch (e) {
        emit(OrdersFailedState(message: 'Please add some item for order add on'));
      }
    } else {
      ///Customer Details
      var customerDetails = order_place.CustomerDetails(
        customerName: customerName,
        customerPhone: customerPhone,
        email: customerEmail,
        creditCardNumber: customerCreditCard,
        customerIdentity: customerFinixIdentity
      );
      double subTotal = 0.0;
      for(var item in selectedOrderList[pageIndex]){
        subTotal+=item.totalPrice;
      }
      subTotal = subTotal.roundTwo;
      ///calculate tax
      double tax = (subTotal * 10) / 100;
      tax = tax.roundTwo;
      ///Billing Details
      var billingDetails = order_place.BillingDetails(
        subTotal: subTotal,
        discount: 0.0,
        tax: tax,
        tip: 0.0,
        grandTotal: (subTotal + tax).roundTwo,
        paymentStatus: false
      );
      //Product Details
      var productDetails = List<order_place.ProductDetails>.generate(
        selectedOrderList[pageIndex].length, 
        (index) => order_place.ProductDetails(
          productId: selectedOrderList[pageIndex][index].itemId, 
          productName: selectedOrderList[pageIndex][index].title, 
          quantity: selectedOrderList[pageIndex][index].quantity,
          productPrice: selectedOrderList[pageIndex][index].price
        )
      );

      //Table List
      var tableList = List<order_place.TableDetails>.generate(
        selectedTableList.length, 
        (index) => order_place.TableDetails(
          tableId: selectedTableList[index]['table_id'], 
          tableName: selectedTableList[index]['table_name'],
        )
      );
      ///OrderPlaceRequest
      var placeOrderData = order_place.OrderPlaceRequest(
        employeeId: selectedServerId, 
        totalGuest: guestCount, 
        tableList: tableList, 
        isPreAuth: isPreAuth,
        customerDetails: customerDetails, 
        billingDetails: billingDetails, 
        productDetails: productDetails, 
        orderSequence: orderSequence,
      ).toJson;
      emit(OrdersLoadingState());
      try {
        var response = await _orderRepository.placeOrder(body: placeOrderData, isFirst: isStayed ? false : true);
        if(response.isNotEmpty) {
          orderId = response['data']['customerDetail']['orderId'];
          customerId = response['data']['customerDetail']['customerId'];
          emit(OrdersPlaceOrderSuccessState(message: response['status']));
        } else {
          emit(OrdersFailedState(message: "Unable to place order"));
        }
        //Relese Table
        // if(tableList.isNotEmpty) {
        //   var tableId = tableList[0].tableId;
        //   var savedStayData = Preferences.getListString(key: AppStrings.prefStayOrder);
        //   var tempData = <String>[];
        //   for(var item in savedStayData) {
        //     if(!jsonDecode(item)['tableList'].every((element) => element['table_id'] == tableId)) {
        //       tempData.add(item);
        //     }
        //   }
        //   Preferences.setListString(key: AppStrings.prefStayOrder, value: tempData);
        // }
      } on CustomException catch (e) {
        emit(OrdersFailedState(message: e.message));
      }
    }
  }

  Future<void> _onStayOrder(OnStayEvent event, Emitter emit) async {
    try {
      emit(OrdersLoadingState());
      var selectedOrder = [];
      for(var item in event.selectedOrder){
        selectedOrder.add({
          'itemId': item.itemId,
          'quantity': item.quantity,
          'productPrice': item.price,
          'productName': item.title
        });
      }
      var stayData = {
        'customerName': customerName,
        'customerEmail': customerEmail,
        'customerPhone': customerPhone,
        'customerCreditCard': customerCreditCard,
        'guestCount': event.guestCount,
        'orderSequence': event.orderSequence,
        'tableName': event.tableName,
        'tableList': event.tableList,
        'selectedProduct': selectedOrder
      };
      var tempData = jsonEncode(stayData);
      var savedStayData = Preferences.getListString(key: AppStrings.prefStayOrder);
      if(savedStayData.any((element) => jsonDecode(element)['tableName'] == event.tableName)){
        var newStayedSavedData = <String>[];
        for(var item in savedStayData){
          if(jsonDecode(item)['tableName'] == event.tableName){
            newStayedSavedData.add(tempData);
          } else {
            newStayedSavedData.add(item);
          }
        }
        Preferences.setListString(key: AppStrings.prefStayOrder, value: newStayedSavedData);
      } else {
        for(var item in event.tableList){
          var response = await _orderRepository.updateTableStatus(id: item['table_id'].toString());
          if(response == AppStrings.success){
            debugPrint('Table hold successfully');
          }
        }
        savedStayData.add(tempData);
        Preferences.setListString(key: AppStrings.prefStayOrder, value: savedStayData);
      }
      emit(SuccessState());
    } catch (e) {
      debugPrint(e.toString());
    }
  } 

  Future<void> _onCancelOrder(OnCancelOrderEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      if(selectedTableList.isNotEmpty) {
        emit(OrdersLoadingState());
        bool isTaskCompleted = true;
        for(var item in selectedTableList) {
          try {
            var response = await _orderRepository.updateTableStatus(id: item['table_id'].toString());
            if(response != AppStrings.success) {
              isTaskCompleted = false;
              break;
            }
          } on CustomException catch (_) {
            isTaskCompleted = false;
            break;
          }
        }
        if(isTaskCompleted) {
          var tableName = selectedTableList.fold("", (p0, p1) => p0.isEmpty ? "${p1['table_name']}" : "$p0-${p1['table_name']}");
          var savedStayData = Preferences.getListString(key: AppStrings.prefStayOrder);
          if(savedStayData.isNotEmpty) {
            savedStayData.removeWhere((element) => jsonDecode(element)['tableName'] == tableName);
            Preferences.setListString(key: AppStrings.prefStayOrder, value: savedStayData);
          }
          emit(SuccessState());
        } else {
          emit(OrdersFailedState(message: AppStrings.someThingWentWrong));
        }
      }
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserOrdersEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(OrdersLoadingState());
        var response = await _orderRepository.onClockOutUser();
        emit(OnSwitchUserOrdersState(isLogout: response));
      } on CustomException catch (e) {
        emit(OrdersFailedState(message: e.message));
      }
    }
  }

  ///Search Product by its category name
  void _onSearchProducts(OnSearchProductsOrdersEvent event, Emitter emit) {
    if(productCategoryList.isNotEmpty) {
      productSubCategoryList.clear();
      drinkDropdownList.clear();
      if(event.text.isEmpty) {
        productSubCategoryList.addAll(productCategoryList.first.subCategoryProduct ?? []);
        for(var item in productCategoryList){
          drinkDropdownList.add(DropdownMenuModel(value: item.mainCategoryProductId!.toString(), item: item.mainCategoryProduct!));
        }
      } else {
        for(var item in productCategoryList) {
          if(item.mainCategoryProduct!.toLowerCase().contains(event.text.toLowerCase())) {
            drinkDropdownList.add(DropdownMenuModel(value: item.mainCategoryProductId!.toString(), item: item.mainCategoryProduct!));
            if(productSubCategoryList.isEmpty) {
              productSubCategoryList.addAll(item.subCategoryProduct!);
            }
          }
        }
      }
      emit(OrdersProductSubCategoryState(
          orderId: orderId,
          productSubCategoryList: productSubCategoryList, 
          drinkDropDownList: drinkDropdownList,
          selectedOrder: selectedOrderList,
          orderSequence: orderSequence,
          guestCount: guestCount,
          customerName: customerName,
          tableName: tableName,
          isUpdate: isUpdate,
          selectedTableList: selectedTableList,
          isStayed: isStayed,
          stateMenuList: stateMenuList
        )
      );
    }
  }

}