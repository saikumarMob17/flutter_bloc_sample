// import '../../../../features/payment/domain/payment_model.dart';
// import '../../domain/order_model.dart';
part of 'orders_bloc.dart';
sealed class OrdersEvent {}

class OrdersSelectEvent extends OrdersEvent {
  int index;
  int tabIndex;
  OrdersSelectEvent({required this.index, required this.tabIndex});
}

class OrderItemIncrementEvent extends OrdersEvent{
  int index;
  int tabIndex;
  OrderItemIncrementEvent({required this.index, required this.tabIndex});
}

class OrderItemDecrementEvent extends OrdersEvent{
  int index;
  int tabIndex;
  OrderItemDecrementEvent({required this.index, required this.tabIndex});
}

class OrdersProductSubCategoryEvent extends OrdersEvent {
  Map duplicateData;

  OrdersProductSubCategoryEvent({required this.duplicateData});
}

class OrdersProductChangePageViewEvent extends OrdersEvent {
  int pageIndex;
  OrdersProductChangePageViewEvent({required this.pageIndex});
}

class OnChangeTabPageIndexEvent extends OrdersEvent {
  int pageIndex;
  OnChangeTabPageIndexEvent({required this.pageIndex});
}

class OrdersChangeDropDownEvent extends OrdersEvent {
  
  int selectedValue;
  int selectedIndex;
  
  OrdersChangeDropDownEvent({
    required this.selectedValue, 
    required this.selectedIndex
  });

}

class OrdersOpenCartEvent extends OrdersEvent {}

class OrdersSelectTableEvent extends OrdersEvent {
  int selectedIndex;
  OrdersSelectTableEvent({this.selectedIndex = -1});
}

class PlaceOrderEvent extends OrdersEvent {
  // PaymentModel paymentModel;

  // PlaceOrderEvent({required this.paymentModel});
  // PlaceOrderEvent();
}

class UpdateOrderEvent extends OrdersEvent {
  String orderId;
  int orderSequence;
  double subTotal;
  double discount;
  double tax;
  double tip;
  double grandTotal;
  bool paymentStatus;
  String? paymentMode;
  List<OrderModel> productList;

  UpdateOrderEvent({
    required this.orderId,
    required this.orderSequence,
    required this.subTotal,
    required this.discount,
    required this.tax,
    required this.tip,
    required this.grandTotal,
    this.paymentStatus = false,
    this.paymentMode,
    required this.productList,
  });

}

class OnStayEvent extends OrdersEvent {
  String customerName;
  String customerEmail;
  String customerPhone;
  String customerCreditCard;
  String tableName;
  int guestCount;
  int orderSequence;
  List<Map<dynamic, dynamic>> tableList;
  List<OrderModel> selectedOrder;

  OnStayEvent({
    required this.orderSequence,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.customerCreditCard,
    required this.tableName,
    required this.guestCount,
    required this.tableList,
    required this.selectedOrder,
  });
}

class OnCancelOrderEvent extends OrdersEvent {}

class OnSwitchUserOrdersEvent extends OrdersEvent {}

class OnSearchProductsOrdersEvent extends OrdersEvent {
  String text;
  OnSearchProductsOrdersEvent({this.text = ''});
}

class OrderContinueForNewPaymentEvent extends OrdersEvent {}



class CardOnNameChangeEvent extends OrdersEvent {
  String text;

  CardOnNameChangeEvent({this.text = ''});
}

class CardNumberChangeEvent extends OrdersEvent {
  String text;

  CardNumberChangeEvent({this.text = ''});
}

class CardExpiryChangeEvent extends OrdersEvent {
  String text;

  CardExpiryChangeEvent({this.text = ''});
}

class CardCvvChangeEvent extends OrdersEvent {
  String text;

  CardCvvChangeEvent({this.text = ''});
}

class CardZipCodeChangeEvent extends OrdersEvent {
  String text;

  CardZipCodeChangeEvent({this.text = ''});
}

class OnChangeStateDropDownEvent extends OrdersEvent {
  String stateCode;

  OnChangeStateDropDownEvent({this.stateCode = ''});
}

class CreatePaymentInstrumentEvent extends OrdersEvent {
  String cardHolderName;
  String cardNumber;
  String cvv;
  String expiryMonthYear;
  String city;
  String addressLine1;
  String postalCode;
  String region;

  CreatePaymentInstrumentEvent({
    required this.cardNumber,
    required this.expiryMonthYear,
    required this.cvv,
    this.cardHolderName = '',
    this.addressLine1 = '',
    this.city = '',
    this.postalCode = '',
    this.region = ''
  });

}


class OrderHideFinixErrorEvent extends OrdersEvent {}