import '../../../../constants/app_strings.dart';
import '../../data/dashboard_repository.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../../utils/shared_pref.dart';
import '../../../../network/custom_exception.dart';
import '../../domain/dashboard_menu_response.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'dashboard_event.dart';
part 'dashboard_state.dart';

class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {

  late CheckConnectivity _checkConnectivity;
  late DashboardRepository _dashboardRepository;

  DashboardBloc() : super(DashboardInitialState()){
    _checkConnectivity = CheckConnectivity();
    _dashboardRepository = DashboardRepository();
    on<DashboardChangeTabIndexEvent>(_onChangeTabIndex);
    on<DashboardMenuItemEvent>(_onFetchDashboardMenuItems);
    on<OnSwitchUserDashboardEvent>(_onLogoutUser);
  }

  void _onChangeTabIndex(DashboardChangeTabIndexEvent event, Emitter emit){
    emit(DashboardChangeTabState(index: event.index));
  }

  Future<void> _onFetchDashboardMenuItems(DashboardMenuItemEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      emit(DashboardLoadingState());
      try {
        var dashboardMenuItems = await _dashboardRepository.fetchDashboardMenuItems(email: Preferences.getString(key: AppStrings.prefEmail));
        emit(DashboardMenuItemState(dashboardMenuList: dashboardMenuItems));
      } on CustomException catch(e) {
        emit(DashboardFailedState(errorMsg: e.message));
      }
    } else {
      emit(DashboardFailedState(errorMsg: AppStrings.noInternetConnection));
    }
  } 

  Future<void> _onLogoutUser(OnSwitchUserDashboardEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(DashboardLoadingState());
        var response = await _dashboardRepository.onClockOutUser();
        emit(OnSwitchUserDashboardState(isLogout: response));
      } on CustomException catch (e) {
        emit(DashboardFailedState(errorMsg: e.message));
      }
    }
  }
  
}