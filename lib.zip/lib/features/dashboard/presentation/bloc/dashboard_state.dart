part of 'dashboard_bloc.dart';

sealed class DashboardState {}

class DashboardInitialState extends DashboardState {}

class DashboardChangeTabState extends DashboardState {
  int index;
  DashboardChangeTabState({required this.index});
}

class DashboardLoadingState extends DashboardState {}

class DashboardFailedState extends DashboardState {
  String errorMsg;
  DashboardFailedState({this.errorMsg = ''});
}

class DashboardMenuItemState extends DashboardState {
  List<DashboardMenuResponse> dashboardMenuList;

  DashboardMenuItemState({required this.dashboardMenuList});
}

class OnSwitchUserDashboardState extends DashboardState {
  bool isLogout;

  OnSwitchUserDashboardState({this.isLogout = false});
}