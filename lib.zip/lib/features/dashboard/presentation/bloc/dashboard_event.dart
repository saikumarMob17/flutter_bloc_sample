part of 'dashboard_bloc.dart';

sealed class DashboardEvent {}

class DashboardChangeTabIndexEvent extends DashboardEvent {
  int index;
  DashboardChangeTabIndexEvent({required this.index});
}

class DashboardMenuItemEvent extends DashboardEvent {}

class OnSwitchUserDashboardEvent extends DashboardEvent {}

