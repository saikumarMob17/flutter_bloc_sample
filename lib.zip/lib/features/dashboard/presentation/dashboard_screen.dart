import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import 'bloc/dashboard_bloc.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../utils/main_bloc/main_bloc.dart';
import '../../../utils/main_bloc/main_bloc_event.dart';
import '../../../utils/shared_pref.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../domain/dashboard_menu_response.dart';

class DashboardScreen extends StatefulWidget {

  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with Helper, RouteAware {

  int selectedItem = 0;
  late ScreenType screenType;

  var modeItem = [];
  bool isLoading = true;

  List<DashboardMenuResponse> dashboardMenuList = [];

  var themeTypes = [
    'Light',
    'Dark',
    'System'
  ];

  @override
  Widget build(BuildContext context){
    return Scaffold(  
      backgroundColor: Helper.isDark 
      ? AppColors.black 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: AppSize.s0),
      body: BlocConsumer<DashboardBloc, DashboardState>(
        builder: (context, state) {
          switch (state) {
            case DashboardChangeTabState _:
              selectedItem = state.index;
              modeItem.clear();
              modeItem.addAll(dashboardMenuList[selectedItem].subMenu!);
              break;
            case DashboardMenuItemState _:
              isLoading = false;
              dashboardMenuList.clear();
              modeItem.clear();
              if(state.dashboardMenuList.isNotEmpty){
                dashboardMenuList.addAll(state.dashboardMenuList);
                modeItem.addAll(dashboardMenuList[selectedItem].subMenu!);
              }
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              screenType = constraints.maxWidth.screenType;
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case DashboardLoadingState _:
              showLoadingDialog(context: context);
              break;
            case DashboardMenuItemState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              break;
            case DashboardFailedState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.errorMsg);
              break;
            case OnSwitchUserDashboardState _:
              hideLoadingDialog(context: context);
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s18,
        vertical: AppSize.s18
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const CustomImageView(
                    imagePath: AppImages.hamburgerIcon,
                    height: 44,
                    width: 44,
                    color: AppColors.primaryColor,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: 'Jaegar Resto',
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s18,
                          color: Helper.isDark 
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      CustomText(
                        title: '743 Washington Ave',
                        textStyle: getRegularStyle(
                          fontSize: AppSize.s10,
                          color: Helper.isDark 
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                children: [
                  CustomSolidButton(
                    onPressed: () => context.read<DashboardBloc>().add(OnSwitchUserDashboardEvent()),
                    prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                    horPadding: AppSize.s12,
                    verPadding: AppSize.s14,
                    borderRadius: AppSize.s6,
                    text: AppStrings.switchUser
                  ),
                  IconButton(
                    onPressed: () => showAccountMenu(context: context), 
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.more_vert)
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s30),
          ///Header
          dashboardMenuList.isEmpty
          ? Visibility(
              visible: !isLoading,
              child: Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.dashboard_outlined, 
                      color: AppColors.grey, 
                      size: AppSize.s40
                    ),
                    const SizedBox(height: AppSize.s2),
                    const Text(
                      'Dashboard Items does not found', 
                      style: TextStyle(
                        fontSize: AppSize.s16
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    CustomSolidButton(
                      onPressed: () => AppRoutes.onClickLogout(context: context),
                      text: 'Go to Login Screen',
                      verPadding: AppSize.s14,
                      horPadding: AppSize.s14,
                      textSize: AppSize.s14,
                    ),
                  ],
                ),
              ),
            )
          : Expanded(
            child: Column(
              children: [
                Container(
                  height: 44,
                  width: context.screenWidth,
                  decoration: BoxDecoration(
                    color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.grey.withOpacity(0.2), 
                        blurRadius: 1.0, 
                        offset: const Offset(0, 2)
                      )
                    ]
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                    children: List.generate(
                      dashboardMenuList.length, 
                      (index) {
                        var data = dashboardMenuList[index];
                        return GestureDetector(
                          onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                            margin: const EdgeInsets.only(right: AppSize.s20),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  width: 3.0, 
                                  color: selectedItem == index 
                                  ? AppColors.primaryColor 
                                  : AppColors.transparent
                                ),
                              ),
                            ),
                            child: Align(
                              alignment: Alignment.center,
                              child: CustomText(
                                title: data.menuItem!,
                                textStyle: getMediumStyle(
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                ),
                              ),
                            ),
                          ),
                        );
                      }
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s10),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSize.s15,
                      vertical: AppSize.s20
                    ),
                    decoration: BoxDecoration(
                      color: Helper.isDark 
                      ? AppColors.headerColorDark 
                      : AppColors.white,
                      borderRadius: BorderRadius.circular(AppSize.s10)
                    ),
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, 
                        crossAxisSpacing: AppSize.s15, 
                        mainAxisSpacing: AppSize.s15,
                        childAspectRatio: 1.2
                      ), 
                      itemCount: modeItem.length,
                      itemBuilder: (context, index) {
                        var data = modeItem[index];
                        return GestureDetector(
                          onTap: () {
                            var path = Helper.dashboardItemRoute[data.subMenuId];
                            if(path.isNotEmpty){
                              context.push(path);
                            }
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.backgroundColorDark 
                              : AppColors.white,
                              border: Border.all(
                                color: Helper.isDark 
                                ? AppColors.lightTextColor 
                                : AppColors.borderColor,
                                width: AppSize.s2
                              ),
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(AppSize.s16),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Helper.isDark 
                                    ? AppColors.contentColorDark 
                                    : AppColors.backgroundColor
                                  ),
                                  child: CustomImageView(
                                    imagePath: Helper.dashboardItemIconMobile[data.subMenuId],
                                    width: AppSize.s28,
                                    height: AppSize.s28,
                                    color: AppColors.primaryColor,
                                  ),
                                ),
                                const SizedBox(height: AppSize.s10),
                                CustomText(
                                  title: data.subMenuItem,
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  void showAccountMenu({required BuildContext context}) {
    final width = context.screenWidth;
    final height = context.screenHeight;
    showMenu(
      context: context, 
      position: RelativeRect.fromLTRB(
        width * 0.50, 
        height * 0.12, 
        screenType == ScreenType.mobile ? width * 0.06 : width * 0.015, 
        10
      ),
      items: Preferences.getString(key: AppStrings.prefUserRole) == 'Manager'
      ? [
        const PopupMenuItem<int>(
          value: 0,
          child: Text('Shift Review'),
        ),
        const PopupMenuItem<int>(
          value: 2,
          child: Text('Time Clock'),
        ),
        PopupMenuItem<int>(
          value: 3,
          child: const Text('Change Theme'),
          onTap: () => showThemeDialog(context: context),
        ),
      ]
      : [
        const PopupMenuItem<int>(
          value: 0,
          child: Text('Shift Review'),
        ),
        const PopupMenuItem<int>(
          value: 1,
          child: Text('Sales Reports'),
        ),
        const PopupMenuItem<int>(
          value: 2,
          child: Text('Time Clock'),
        ),
        PopupMenuItem<int>(
          value: 3,
          child: const Text('Change Theme'),
          onTap: () => showThemeDialog(context: context),
        ),
      ]
    );
  }


  Widget posView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: '${Preferences.getString(key: AppStrings.prefTenantName)} - ${Preferences.getString(key: AppStrings.prefLocation)}',
                textStyle: getMediumStyle(
                  fontSize: AppSize.s20,
                  color: Helper.isDark ? AppColors.white : AppColors.black
                ),
              ),
              Row(
                children: [
                  CustomSolidButton(
                    onPressed: () => context.read<DashboardBloc>().add(OnSwitchUserDashboardEvent()),
                    prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                    text: AppStrings.switchUser
                  ),
                  const SizedBox(width: AppSize.s10),
                  CustomOutlinedButton(
                    onPressed: () => showAccountMenu(context: context),
                    text: AppStrings.myAccount,
                    widgetSpacing: AppSize.s5,
                    rightPadding: AppSize.s10,
                    leftPadding: AppSize.s14,
                    suffixWidget: const Icon(
                      AppIcons.arrowDown,
                      color: AppColors.blue
                    ),
                  ),
                ],
              ),
            ],
          ),
          Expanded(
            child: dashboardMenuList.isEmpty
            ? Visibility(
              visible: !isLoading,
              child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.dashboard_outlined, 
                        color: AppColors.grey, 
                        size: AppSize.s40
                      ),
                      const SizedBox(height: AppSize.s2),
                      const Text(
                        'Dashboard Items does not found', 
                        style: TextStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                      const SizedBox(height: AppSize.s10),
                      CustomSolidButton(
                        onPressed: () => AppRoutes.onClickLogout(context: context),
                        text: 'Go to Login Screen',
                        verPadding: AppSize.s14,
                        horPadding: AppSize.s14,
                        textSize: AppSize.s14,
                      ),
                    ],
                  ),
                ),
            )
            : ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.only(top: AppSize.s10),
              children: List.generate(
                dashboardMenuList.length, 
                (index) {
                  var itemData = dashboardMenuList[index];
                  int N = itemData.subMenu!.length;
                  var itemIndex = 0;
                  return Column(
                    children: [
                      //Header
                      Container(
                        padding: const EdgeInsets.all(AppSize.s15),
                        margin: const EdgeInsets.only(top: AppSize.s15),
                        width: context.screenWidth,
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.headerColorDark 
                          : AppColors.headerBgColor,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(AppSize.s10),
                            topRight: Radius.circular(AppSize.s10),
                          )
                        ),
                        child: CustomText(
                          title: itemData.menuItem!,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      ///Sub Header
                      Container(
                        padding: const EdgeInsets.all(AppSize.s15),
                        width: context.screenWidth,
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.backgroundColorDark 
                          : AppColors.white,
                          borderRadius: const BorderRadius.only(
                            bottomLeft: Radius.circular(AppSize.s10),
                            bottomRight: Radius.circular(AppSize.s10),
                          )
                        ),
                        child: ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: dashboardItemCount(itemData.subMenu!.length),
                          itemBuilder: (_, subItemIndex) {
                            return Row(
                              children: List.generate(
                                6, 
                                (subIndex) {
                                  itemIndex+=1;
                                  return Expanded(
                                    child: itemIndex <= N
                                    ? Material(
                                        color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                        child: InkWell(
                                          onTap: () {
                                            if(itemData.subMenu![(subItemIndex*6 + subIndex)].subMenuId == 16){
                                              showPayoutDialog(bContext: bContext);
                                            } else {
                                              var path = dashboardMenuItemRoute(itemData.subMenu!, (subItemIndex*6 + subIndex));
                                              if(path.isNotEmpty){
                                                context.push(path);
                                              }
                                            }
                                          },
                                          child: Container(
                                            alignment: Alignment.center, 
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: AppSize.s20,
                                              vertical: AppSize.s15
                                            ),
                                            decoration: BoxDecoration(
                                              color: Helper.isDark 
                                              ? AppColors.backgroundColorDark 
                                              : AppColors.white,
                                              border: Border(
                                                right: BorderSide(
                                                  color: subIndex < 6 - 1 
                                                  ? AppColors.lightGrey 
                                                  : AppColors.transparent,
                                                  width: 1.5
                                                ),
                                              ),
                                            ),
                                            child: CustomText(
                                              title: subTitle(itemData.subMenu!, itemIndex - 1),
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s14,
                                                color: Helper.isDark 
                                                ? AppColors.white 
                                                : AppColors.black
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : const SizedBox()
                                  );
                                },
                              ),
                            );
                          }, 
                          separatorBuilder: (_,__) => const Divider(height: AppSize.s1, thickness: AppSize.s1)
                        ),
                      ),
                    ],
                  );
                }
              ),
            ),
          ),
        ],
      ),
    );
  }

  void showThemeDialog({required BuildContext context}) {
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog.adaptive(
          surfaceTintColor: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
          title: CustomText(
            title: AppStrings.changeTheme, 
            textStyle: getMediumStyle(
              fontSize: AppSize.s18,
              color: Helper.isDark ? AppColors.white : AppColors.black
            )
          ),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          contentPadding: EdgeInsets.zero,
          backgroundColor: Helper.isDark
          ? AppColors.contentColorDark
          : AppColors.white,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: AppSize.s12),
              ...List.generate(
                themeTypes.length,
                (index) {
                  return Padding(
                    padding: const EdgeInsets.only(
                      bottom: AppSize.s10,
                      left: AppSize.s20,
                      right: AppSize.s20,
                    ),
                    child: InkWell(
                      onTap: () {
                        var temp = themeTypes[index].toLowerCase();
                        context.read<MainBloc>().add(MainBlocChangeThemeEvent(themeMode: temp.getThemeMode));
                        context.pop();
                      },
                      child: Row(
                        children: [
                          CustomCheckBox(
                            value: themeTypes[index].toLowerCase() == Preferences.getString(key: AppStrings.prefThemeMode) 
                            ? true 
                            : false,
                            shape: const CircleBorder(),
                            checkBoxSize: 0.9,
                            onChange: (value) {
                              var temp = themeTypes[index].toLowerCase();
                              context.read<MainBloc>().add(MainBlocChangeThemeEvent(themeMode: temp.getThemeMode));
                              context.pop();
                            }
                          ),
                          const SizedBox(width: AppSize.s8),
                          CustomText(
                            title: themeTypes[index], 
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s16,
                              color: Helper.isDark 
                              ? AppColors.white 
                              : AppColors.black
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
              ),
              const SizedBox(height: AppSize.s10),
            ],
          ),
        );
      }
    );
  }

  void showPayoutDialog({required BuildContext bContext}){
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog(
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          content: Container(
            width: bContext.screenWidth * 0.35,
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s24,
              horizontal: AppSize.s24
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s12),
              color: AppColors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  title: AppStrings.payout,
                  textStyle: getMediumStyle(fontSize: AppSize.s22),
                ),
                const SizedBox(height: AppSize.s20),
                CustomDropdownWidget(
                  label: AppStrings.selectCashDrawer,
                  isExpanded: true, 
                  items: const [], 
                  value: '0',
                  labelStyle: getRegularStyle(fontSize: AppSize.s14),
                ),
                const SizedBox(height: AppSize.s20),
                CustomTextField(
                  textController: TextEditingController(),
                  hint: AppStrings.amount,
                  label: AppStrings.amount,
                  verPadding: AppSize.s14,
                  horPadding: AppSize.s20,
                ),
                const SizedBox(height: AppSize.s20),
                CustomDropdownWidget(
                  isExpanded: true,
                  label: AppStrings.chooseUser, 
                  labelStyle: getRegularStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                  items: [DropdownMenuModel(value: '-1', item: 'Select User')], 
                  value: '-1'
                ),
                const SizedBox(height: AppSize.s20),
                CustomDropdownWidget(
                  label: AppStrings.selectPayoutReason,
                  isExpanded: true, 
                  items: const [], 
                  value: '0',
                  labelStyle: getRegularStyle(fontSize: AppSize.s14),
                ),
                const SizedBox(height: AppSize.s20),
                CustomTextField(
                  textController: TextEditingController(),
                  label: AppStrings.comments,
                  horPadding: AppSize.s10, verPadding: AppSize.s15,
                  labelStyle: getRegularStyle(fontSize: AppSize.s14),
                ),
                const SizedBox(height: AppSize.s32),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomOutlinedButton(
                      text: AppStrings.cancel,
                      onPressed: () => bContext.pop(),
                      leftPadding: AppSize.s20,
                      rightPadding: AppSize.s20,
                    ),
                    const SizedBox(width: AppSize.s12),
                    CustomSolidButton(
                      text: AppStrings.done,
                      onPressed: () => bContext.pop(),
                      horPadding: AppSize.s20,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }
    );
  }
  
}