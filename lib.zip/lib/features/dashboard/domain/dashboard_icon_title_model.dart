
class DashboardIconTitleModel {

  String title;
  String imagePath;

  DashboardIconTitleModel({
    required this.title,
    required this.imagePath
  });
}