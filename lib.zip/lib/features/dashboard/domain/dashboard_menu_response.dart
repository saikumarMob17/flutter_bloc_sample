// To parse this JSON data, do
//
//     final dashboardMenuResponse = dashboardMenuResponseFromJson(jsonString);

import 'dart:convert';

List<DashboardMenuResponse> dashboardMenuResponseFromJson(String str) => List<DashboardMenuResponse>.from(json.decode(str).map((x) => DashboardMenuResponse.fromJson(x)));

class DashboardMenuResponse {
  String? menuItem;
  List<SubMenu>? subMenu;

  DashboardMenuResponse({
    this.menuItem,
    this.subMenu,
  });

  factory DashboardMenuResponse.fromJson(Map<String, dynamic> json) => DashboardMenuResponse(
    menuItem: json["menuItem"],
    subMenu: json["subMenu"] == null ? [] : List<SubMenu>.from(json["subMenu"]!.map((x) => SubMenu.fromJson(x))),
  );
}

class SubMenu {

  int? subMenuId;
  String? subMenuItem;
  int? menuId;
  PoSDashboardMenuList? poSDashboardMenuList;

  SubMenu({
    this.subMenuId,
    this.subMenuItem,
    this.menuId,
    this.poSDashboardMenuList,
  });

  factory SubMenu.fromJson(Map<String, dynamic> json) => SubMenu(
    subMenuId: json["subMenuId"],
    subMenuItem: json["subMenuItem"],
    menuId: json["menuId"],
    poSDashboardMenuList: json["poS_DashboardMenuList"] == null ? null : PoSDashboardMenuList.fromJson(json["poS_DashboardMenuList"]),
  );

}

class PoSDashboardMenuList {
  
  int? menuId;
  String? menuItem;

  PoSDashboardMenuList({
    this.menuId,
    this.menuItem,
  });

  factory PoSDashboardMenuList.fromJson(Map<String, dynamic> json) => PoSDashboardMenuList(
    menuId: json["menuId"],
    menuItem: json["menuItem"],
  );

}
