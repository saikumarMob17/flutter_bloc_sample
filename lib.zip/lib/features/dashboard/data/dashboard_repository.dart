import 'dart:io';
import '../../../routes/route.dart';
import '../domain/dashboard_menu_response.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';

class DashboardRepository {
  late ApiClient _apiClient;

  DashboardRepository(){
    _apiClient = ApiClient();
  }

  Future<List<DashboardMenuResponse>> fetchDashboardMenuItems({required String email}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: '${EndPoints.dashboardMenuItem}?email=$email');
      switch(response.statusCode){
        case HttpStatus.ok:
          return dashboardMenuResponseFromJson(response.body);
        case HttpStatus.internalServerError:
          throw CustomException(message: AppStrings.internalServerError);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}