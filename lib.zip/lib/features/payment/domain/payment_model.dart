import '../../orders/domain/order_model.dart';

class PaymentModel {
  bool isFirstOrder;
  String employeeId;
  String orderId;
  String customerId;
  String tableName;
  String customerName;
  String customerIdentity;
  String customerEmail;
  double totalAmount;
  double subTotal;
  double discount;
  double tax;
  double balanceDue;
  bool? isPreAuth;
  int totalGuest;
  bool? hasCheckSequence;
  List<OrderModel> orderedItem;
  List<Map> selectedTableList;
  int orderSequence;

  PaymentModel({
    required this.isFirstOrder,
    this.employeeId = '',
    required this.orderId,
    this.customerId = '',
    this.tableName = '',
    this.customerName = '',
    this.customerIdentity = '',
    this.customerEmail = '',
    this.totalGuest = -1,
    this.totalAmount = 0.0,
    this.subTotal = 0.0,
    this.discount = 0.0,
    this.tax = 0.0,
    this.balanceDue = 0.0,
    this.isPreAuth = false,
    this.hasCheckSequence = false,
    required this.orderSequence,
    required this.orderedItem,
    required this.selectedTableList
  });
}