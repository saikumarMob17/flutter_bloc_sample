import 'package:cliqtechnologies_retl/features/payment_terminal/domain/payment_terminal_response.dart';

class PaymentRequestModel {
  String orderId;
  bool paymentStatus;
  String? paymentMode;
  String? customerId;
  String? cardNumber;
  String? cardType;
  bool? isPreAuth;
  BillingDetails totalBillingDetails;
  List<CheckDetails> checkDetails;

  PaymentRequestModel({
    required this.orderId,
    required this.paymentStatus,
    this.paymentMode,
    this.customerId,
    this.cardNumber,
    this.cardType,
    this.isPreAuth,
    required this.totalBillingDetails,
    required this.checkDetails
  });

  Map get toJson => {
    "orderId": orderId,
    "paymentStatus": paymentStatus,
    "paymentMode": paymentMode,
    "customerId": customerId,
    "cardNumber": cardNumber,
    "cardType": cardType,
    "isPreAuth": isPreAuth,
    "totalBillingDetail": totalBillingDetails.toJson,
    "checkDetails": List.generate(checkDetails.length, (index) => checkDetails[index].toJson)
  };

}

class CheckDetails {
  String? customerName;
  String? cardNumber;
  String? cardType;
  String? customerIdentity;
  int checkSequence;
  bool isEvenlySplit;
  List<SplitItem> splitItems;
  SubBillingDetails subBillingDetails;

  CheckDetails({
    this.customerName,
    this.cardNumber,
    this.cardType,
    this.isEvenlySplit = false,
    required this.customerIdentity,
    required this.checkSequence,
    required this.splitItems,
    required this.subBillingDetails
  });

  Map get toJson => {
    "customerName": customerName,
    "cardNumner": cardNumber,
    "cardType": cardType,
    "customerIdentity": customerIdentity,
    "check_Sequence": checkSequence,
    'isEvenlySplit': isEvenlySplit,
    "splitItems": List.generate(splitItems.length, (index) => splitItems[index].toJson),
    "billingDetails": subBillingDetails.toJson
  };

}

class SplitItem {
  int productId;
  String productName;
  int quantity;
  double productPrice;

  SplitItem({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.productPrice,
  });

  Map get toJson => {
    "productId": productId,
    "productName": productName,
    "quantity": quantity,
    "productPrice": productPrice
  };
}

class SubBillingDetails {
  double subTotal;
  double discount;
  double tax;
  double tip;
  double grandTotal;
  bool paymentStatus;
  double balanceDue;
  String? paymentMode;
  String? cardType;
  String? cardNumber;

  SubBillingDetails({
    required this.subTotal,
    required this.discount,
    required this.tax,
    required this.tip,
    required this.grandTotal,
    required this.paymentStatus,
    required this.balanceDue,
    this.paymentMode,
    this.cardType,
    this.cardNumber
  });

  Map get toJson => {
    "subTotal": subTotal,
    "discount":discount,
    "tax": tax,
    "tip": tip,
    "grandTotal": grandTotal,
    "paymentStatus": paymentStatus,
    "balanceDue": balanceDue,
    "paymentMode": paymentMode,
    "cardType": cardType,
    "cardNumber": cardNumber

  };
}