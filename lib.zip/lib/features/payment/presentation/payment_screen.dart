import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../domain/payment_model.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../services/finix_payment_instrument_response.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_strings.dart';
import '../../../utils/helper.dart';
import 'bloc/payment_bloc.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/icon_title_model.dart';
import 'payment_add_new_card_dialog.dart';
import 'payment_split_evenly_widget.dart';
import '../../payment_terminal/domain/payment_order_model.dart';
import '../../payment_terminal/domain/payment_terminal_response.dart';
import 'payment_receipt_widget.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});
  @override
  State createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> with Helper {

  var paymentOptionList = <IconTitleModel>[
    IconTitleModel(title: AppStrings.creditDebitCard, imagePath: AppImages.cashIcon),
    IconTitleModel(title: AppStrings.cash, imagePath: AppImages.dollar),
  ];

  var paymentOptions = {
    0: 'CREDIT CARD',
    1: 'CASH',
  };

  int selectedMonth = 1;
  int selectedYear = 2024;
  int selectedPaymentOption = -1;
  int tabIndex = 0;
  bool hasCheckSequence = false;

  double subTotal = 0.0;
  double tax = 0.0;
  double tip = 0.0;
  double total = 0.0;
  late TextEditingController amountTenderedController;
  late TextEditingController tipTextController;
  double amountTendered = 0.0;
  double tipAmount = 0.0;
  double balanceDue = 0.0;
  String errorAmount = '';
  String errorTip = '';
  List<PaymentOrderModel> paymentStatusList = [];
  String orderId = "";
  late PageController _pageController;
  late int currentPageIndex = 0;
  late TextEditingController cardHolderName;
  late TextEditingController cardNumber;
  late TextEditingController cvv;
  late PaymentBloc _paymentBloc;
  List<PaymentInstrument> paymentInstrumentList = [];
  int selectedCard = -1;
  String customerId = '';
  String customerName = '';
  bool isPreAuth = false;
  List<DropdownMenuModel> stateList = [];

  @override
  void initState() {
    _paymentBloc = context.read<PaymentBloc>();
    _pageController = PageController(initialPage: 0);
    amountTenderedController = TextEditingController();
    tipTextController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark ? AppColors.black : AppColors.white,
      appBar: AppBar(toolbarHeight: 0),
      resizeToAvoidBottomInset: false,
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () => showPaymentSuccessDialog(context: context),
      //   child: const Icon(Icons.add),
      // ),
      body: BlocConsumer<PaymentBloc, PaymentState>(
        builder: (context, state) {
          switch (state) {
            case PaymentSelectedOptionState _:
              selectedPaymentOption = state.selectedItem;
              break;
            case AmountTextErrorState _:
              if(state.amount.isBlank) {
                amountTendered = 0.0;
              } else {
                if(paymentStatusList.isNotEmpty) {
                  var amount = double.parse(state.amount);
                  amountTendered = amount;
                  if(amount >= paymentStatusList[tabIndex].billingDetails!.balanceDue!) {
                    amountTenderedController.text = paymentStatusList[tabIndex].billingDetails!.balanceDue!.toString();
                    amountTendered = paymentStatusList[tabIndex].billingDetails!.balanceDue!;
                  }
                }
              }
              errorAmount = state.msg;
              break;
            case TipTextErrorState _:
              errorTip  = state.msg;
              tipAmount = state.amount.isBlank ? 0.0 : double.parse(state.amount);
              break;
            case PaymentStatusState _:
              orderId = state.orderId;
              hasCheckSequence = state.hasSequence;
              currentPageIndex = state.currentPageIndex;
              customerName = state.customerName;
              stateList.clear();
              stateList.addAll(state.stateMenuList);
              paymentStatusList.clear();
              for(var item in state.orderList) {
                if(item.orderId == orderId) {
                  orderId = item.orderId;
                  customerName = item.customerName;
                  hasCheckSequence = item.hasCheckSequence ?? false;
                  paymentStatusList.add(item);
                  if(item.preAuthDetails != null) {
                    if(item.preAuthDetails!.cardLastFourDegit != null) {
                      selectedPaymentOption = 0;
                    }
                  }
                }
              }
              break;
            case ChangeTabPageIndexState _:
              amountTendered = 0.0;
              amountTenderedController.text = '';
              tabIndex = state.tabIndex;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints) {
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case PaymentStatusState _:
              hideLoadingDialog(context: context);
              if(state.isPerformPayment) {
                amountTenderedController.clear();
                tipTextController.clear();
                amountTendered = 0.0;
                tipAmount = 0.0;
                showPaymentSuccessDialog(context: context);
              }
              ///handle automatically scrolling in pageview here
              WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
                if(_pageController.hasClients) {
                  _pageController.animateToPage(currentPageIndex, duration: const Duration(milliseconds: 500), curve: Curves.linear);
                }
              });
              break;
            case PaymentLoadingState _:
              showLoadingDialog(context: context);
              break;
            case PaymentFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.message);
              break;
            case PaymentSuccessState _:
              context.read<PaymentBloc>().add(PaymentStatusEvent(isPerformPayment: true));
              break;
            case OnChangeCardMonthState _:
              selectedMonth = state.selectedMonth;
              break;
            case OnChangeCardYearState _:
              selectedYear = state.selectedYear;
              break;
            case FetchFinixPaymentInstrumentState _:
              hideLoadingDialog(context: context);
              paymentInstrumentList.clear();
              paymentInstrumentList.addAll(state.paymentInstrumentList);
              break;
            case SelectSavedCardState _:
              selectedCard = state.index;
              if(state.index == 0) {
                ///open dialog to add new card
                showPaymentProcessingDialog();
              }
              break;
            case OnSplitItemState _:
              _onNavigateSplitItem(paymentModel: state.paymentModel);
              break;
            default:
          }
        },
      ),
    );
  }

  Future<void> _onNavigateSplitItem({required PaymentModel paymentModel}) async {
    var data = await context.push(AppRoutes.splitCheckScreen, extra: paymentModel);
    if(data != null) {
      _paymentBloc.add(OnRefreshPaymentsEvent());
    }
  }

  Widget mobileView({required BuildContext bContext}) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.all(AppSize.s12),
      children: [
        const SizedBox(height: AppSize.s5),
        SizedBox(
          height: context.screenHeight * 0.28,
          child: PageView.builder(
            controller: _pageController,
            onPageChanged: (value) => _paymentBloc.add(ChangeTabPageIndexEvent(pageIndex: value)),
            itemCount: paymentStatusList.length,
            itemBuilder: (_, index) {
              var checkSequenceOrderData = paymentStatusList[index];
              return Container(
                decoration: BoxDecoration(
                  color: AppColors.backgroundColor,
                  borderRadius: BorderRadius.circular(AppSize.s10)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: AppSize.s10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s15
                          ),
                          child: Row(
                            children: [
                              CustomText(
                                title: checkSequenceOrderData.orderNumber,
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              CustomText(
                                title: '  #${index+1}',
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s15
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                AppIcons.chairIcon, 
                                size: AppSize.s18
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomText(
                                title: checkSequenceOrderData.tableList.fold("", (p0, p1) => p0.isEmpty ? p1.tableName! : "$p0-${p1.tableName!}"),
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s15
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                AppIcons.accountCircleIcon, 
                                size: AppSize.s18
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomText(
                                title: checkSequenceOrderData.customerName,
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s15
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                AppIcons.groupIcon, 
                                size: AppSize.s18
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomText(
                                title: 'Guest  ${checkSequenceOrderData.totalGuest}',
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s10),
                    const Divider(color: AppColors.white, height: AppSize.s4, thickness: AppSize.s4),
                    const Spacer(),
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            left: AppSize.s50,
                            right: AppSize.s16,
                            bottom: AppSize.s16
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    title: 'Subtotal:',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                  CustomText(
                                    title: '\$${checkSequenceOrderData.billingDetails!.subTotal!.roundTwo}',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSize.s8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    title: 'Tax:',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                  CustomText(
                                    title: '\$${checkSequenceOrderData.billingDetails!.tax!.roundTwo}',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                              const Divider(color: AppColors.grey , height: AppSize.s20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    title: 'Total:',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                  CustomText(
                                    title: '\$${checkSequenceOrderData.billingDetails!.grandTotal!.roundTwo}',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSize.s8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    title: 'Balance Due:',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                  CustomText(
                                    title: '\$${checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo}',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s10),
                          width: double.maxFinite,
                          decoration: BoxDecoration(
                            color: checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo > 0.0
                            ?AppColors.red
                            :AppColors.green,
                            borderRadius: const BorderRadius.only(
                              bottomLeft: Radius.circular(AppSize.s10),
                              bottomRight: Radius.circular(AppSize.s10)
                            )
                          ),
                          child: checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo > 0.0 
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomText(
                                  title: 'Balance Due \$${checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo}', 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14, 
                                    color: AppColors.white
                                  ),
                                )
                              ],
                            )
                          : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomText(
                                title: AppStrings.paid, 
                                textStyle: getRegularStyle(
                                  fontSize: AppSize.s14, 
                                  color: AppColors.white
                                ),
                              ),
                              const SizedBox(width: AppSize.s8),
                              const Icon(Icons.verified, color: AppColors.white, size: AppSize.s22,)
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }
          ),
        ),
        Visibility(
          visible: paymentStatusList.length > 1,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              paymentStatusList.length, 
              (index) => Container(
                height: AppSize.s8,
                width: AppSize.s8,
                margin: const EdgeInsets.only(right: AppSize.s4, top: AppSize.s6),
                decoration: BoxDecoration(
                  color: index == tabIndex
                  ? AppColors.primaryColor
                  : AppColors.grey.withOpacity(0.8),
                  shape: BoxShape.circle
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: AppSize.s14),
        CustomText(
          title: paymentStatusList.isEmpty
          ? 'Balance due: \$'
          : 'Balance due: \$${paymentStatusList[tabIndex].billingDetails!.balanceDue!.roundTwo}',
          textStyle: getSemiBoldStyle(
            fontSize: AppSize.s20, 
            color: Helper.isDark
            ? AppColors.white
            : AppColors.black
          ),
        ),
        const SizedBox(height: AppSize.s10),
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextField(
                controller: amountTenderedController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: AppSize.s20),
                textAlign: TextAlign.right,
                onChanged: (value) => context.read<PaymentBloc>().add(OnAmountTextChange(text: value)),
                decoration: InputDecoration(
                  isDense: true,
                  label: const Text('Amount tendered'),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSize.s6))
                ),
              ),
            ),
            const SizedBox(width: AppSize.s15),
            Expanded(
              child: TextField(
                controller: tipTextController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                style: const TextStyle(color: AppColors.black, fontWeight: FontWeight.bold, fontSize: AppSize.s20),
                textAlign: TextAlign.right,
                  onChanged: (value) => context.read<PaymentBloc>().add(OnTipTextChange(text: value)),
                decoration: InputDecoration(
                  isDense: true,
                  label: const Text(AppStrings.tip),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSize.s6))
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSize.s25),
        CustomText(
          title: AppStrings.paymentOptions, 
          textStyle: getMediumStyle(
            fontSize: AppSize.s16, 
            color: Helper.isDark 
            ? AppColors.white 
            : AppColors.black
          ),
        ),
        const SizedBox(height: AppSize.s8),
        InkWell(
          onTap: () => bContext.read<PaymentBloc>().add(PaymentSelectedOptionEvent(selectedIndex: 0)),
          child: Container(
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s14,
              horizontal: AppSize.s18
            ),
            decoration: BoxDecoration(
              color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
              border: Border.all(color: const Color(0xFFDCEDFB), width: AppSize.s1),
              borderRadius: BorderRadius.circular(AppSize.s8)
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(
                          selectedPaymentOption == 0 
                          ? AppIcons.radioButtonCheckedIcon
                          : AppIcons.circleOutlinedIcon, 
                          color: selectedPaymentOption == 0 
                          ? AppColors.primaryColor
                          : AppColors.grey,
                          size: AppSize.s20,
                        ),
                        const SizedBox(width: AppSize.s12),
                        const CustomImageView(
                          imagePath: AppImages.cashIcon,
                          width: AppSize.s15,
                          height: AppSize.s15,
                          blendMode: BlendMode.dstIn,
                        ),
                        const SizedBox(width: AppSize.s12),
                        CustomText(
                          title: AppStrings.creditDebitCard,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14,
                            color: Helper.isDark
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Icon(
                      AppIcons.expandMoreIcon, 
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ],
                ),
                Visibility(
                  visible: selectedPaymentOption == 0,
                  child: Column(
                    children: [
                      const SizedBox(height: AppSize.s20),
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: CustomTextField(
                              label: AppStrings.cardNumber,
                              hint: '**** **** **** ****',
                              verPadding: AppSize.s12,
                              horPadding: AppSize.s10,
                              textController: cardNumber
                            ),
                          ),
                          const SizedBox(width: AppSize.s10),
                          Flexible(
                            child: CustomTextField(
                              label: AppStrings.cvv,
                              hint: AppStrings.cvv,
                              verPadding: AppSize.s12,
                              horPadding: AppSize.s10,
                              textController: cvv
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s15),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(
                            flex: 3,
                            child: CustomTextField(
                              label: AppStrings.cardholderName,
                              verPadding: AppSize.s12,
                              horPadding: AppSize.s10,
                              textController: cardHolderName
                            ),
                          ),
                          const SizedBox(width: AppSize.s10),
                          // CustomDropdownWidget(
                          //   items: validMonth, 
                          //   value: selectedMonth,
                          //   label: AppStrings.month,
                          //   labelStyle: getRegularStyle(
                          //     color: Helper.isDark 
                          //     ? AppColors.white 
                          //     : AppColors.black
                          //   ),
                          //   onChange: (value) => context.read<PaymentBloc>().add(OnChangeCardMonthEvent(value!)),
                          // ),
                          const SizedBox(width: AppSize.s10),
                          // CustomDropdownWidget(
                          //   items: validYear, 
                          //   value: selectedYear,
                          //   label: AppStrings.year,
                          //   labelStyle: getRegularStyle(
                          //     color: Helper.isDark 
                          //     ? AppColors.white 
                          //     : AppColors.black
                          //   ),
                          //   onChange: (value) => context.read<PaymentBloc>().add(OnChangeCardYearEvent(value!)),
                          // ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height:  AppSize.s15),
        ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: List.generate(
            paymentOptionList.length, 
            (index) {
              var data = paymentOptionList[index];
              return GestureDetector(
                onTap: () => bContext.read<PaymentBloc>().add(PaymentSelectedOptionEvent(selectedIndex: index+1)),
                child: Container(
                  margin: const EdgeInsets.only(bottom: AppSize.s15),
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s14,
                    horizontal: AppSize.s18
                  ),
                  decoration: BoxDecoration(
                    color: Helper.isDark 
                    ? AppColors.headerColorDark 
                    : AppColors.white,
                    border: Border.all(color: const Color(0xFFDCEDFB), width: AppSize.s05),
                    borderRadius: BorderRadius.circular(AppSize.s8)
                  ),
                  child: Row(
                    children: [
                      Icon(
                        selectedPaymentOption == index+1 
                        ? AppIcons.radioButtonCheckedIcon
                        : AppIcons.circleOutlinedIcon, 
                        color: selectedPaymentOption == index+1 
                        ? AppColors.primaryColor
                        : AppColors.grey,
                        size: AppSize.s20,
                      ),
                      const SizedBox(width: AppSize.s12),
                      CustomImageView(
                        imagePath: data.imagePath,
                        width: AppSize.s15,
                        height: AppSize.s15,
                        blendMode: BlendMode.dstIn,
                      ),
                      const SizedBox(width: AppSize.s12),
                      CustomText(
                        title: data.title,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s14, 
                          color: Helper.isDark 
                          ? AppColors.white 
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          ),
        ),
        Visibility(
          visible: !hasCheckSequence,
          child: Column(
            children: [
              const SizedBox(height: AppSize.s10),
              Row(
                children: [
                  Expanded(
                    child: CustomOutlinedButton(
                      onPressed: () => _paymentBloc.add(OnSplitItemEvent()),
                      text: AppStrings.splitItems,
                      textColor: AppColors.blue,
                    ),
                  ),
                  const SizedBox(width: AppSize.s12),
                  Expanded(
                    child: CustomOutlinedButton(
                      onPressed: () => showSplitEvenlyDialog(
                        context: context, 
                        totalAmount: paymentStatusList[tabIndex].billingDetails!.balanceDue!,
                        totalGuest: paymentStatusList[tabIndex].totalGuest,
                        paymentBloc: bContext.read<PaymentBloc>()
                      ),
                      text: AppStrings.splitEvenly,
                      textColor: AppColors.blue,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s10),
            ],
          ),
        ),
        CustomSolidButton(
          onPressed: selectedPaymentOption < 0 || amountTendered <= 0.0
          ? null
          : () => context.read<PaymentBloc>().add(UpdatePaymentStatusEvent(
            hasCheckSequence: hasCheckSequence,
            paymentOrderModel: paymentStatusList[tabIndex],
            amountReceive: amountTendered, 
            tipReceive: tipAmount,
            paymentMode: getPaymentOption
          )),
          text: (amountTendered + tipAmount) == 0.0
          ? AppStrings.pay
          : '${AppStrings.pay} (\$${amountTendered + tipAmount})',
        ),
      ],
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //Left Screen
              Container( 
                margin: const EdgeInsets.symmetric(
                  horizontal: AppSize.s16,
                  vertical: AppSize.s16
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppSize.s10),
                  color: Helper.isDark
                  ? AppColors.contentColorDark
                  : AppColors.backgroundColor
                ),
                width: context.screenWidth * 0.35,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    PageView.builder(
                      controller: _pageController,
                      onPageChanged: (value) => _paymentBloc.add(ChangeTabPageIndexEvent(pageIndex: value)),
                      itemCount: paymentStatusList.length,
                      itemBuilder: (context, index) {
                        var checkSequenceOrderData = paymentStatusList[index];
                        return Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(AppSize.s14),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s10
                                        ),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark 
                                          ? AppColors.headerColorDark
                                          : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s6)
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              AppIcons.chairIcon, 
                                              size: AppSize.s20
                                            ),
                                            const SizedBox(width: AppSize.s8),
                                            CustomText(
                                              title: checkSequenceOrderData.orderNumber,
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                            CustomText(
                                              title: '   |   ', 
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                            CustomText(
                                              title: '#${index+1}',
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s10
                                        ),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark 
                                          ? AppColors.headerColorDark
                                          : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s6)
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              AppIcons.chairIcon, 
                                              size: AppSize.s20
                                            ),
                                            const SizedBox(width: AppSize.s8),
                                            CustomText(
                                              title: checkSequenceOrderData.tableList.fold("", (p0, p1) => p0.isBlank ? p1.tableName! : "$p0-${p1.tableName!}"),
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s6),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s10
                                        ),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark 
                                          ? AppColors.headerColorDark
                                          : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s6)
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              AppIcons.accountCircleIcon, 
                                              size: AppSize.s20
                                            ),
                                            CustomText(
                                              title: ' ${checkSequenceOrderData.customerName}',
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s10
                                        ),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark 
                                          ? AppColors.headerColorDark
                                          : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s6)
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              AppIcons.groupIcon, 
                                              size: AppSize.s20
                                            ),
                                            CustomText(
                                              title: ' ${AppStrings.guest}  ${checkSequenceOrderData.totalGuest}',
                                              textStyle: getMediumStyle(fontSize: AppSize.s16),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.black
                              : AppColors.white, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            ////Old UI
                            Expanded(
                              child: ListView.separated(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: checkSequenceOrderData.productDetails.length,
                                itemBuilder: (_, subIndex) {
                                  var data = checkSequenceOrderData.productDetails[subIndex];
                                  return Column(
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.symmetric(
                                          vertical: AppSize.s8,
                                          horizontal: AppSize.s14,
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              flex: 2,
                                              child: Row(
                                                children: [
                                                  Container(
                                                    padding: const EdgeInsets.all(AppSize.s10),
                                                    decoration: const BoxDecoration(
                                                      color: AppColors.primaryColor,
                                                      shape: BoxShape.circle
                                                    ),
                                                    child: const CustomImageView(
                                                      imagePath: AppImages.orangeJuice,
                                                      width: AppSize.s18,
                                                      height: AppSize.s18,
                                                      color: AppColors.white,
                                                    ),
                                                  ),
                                                  const SizedBox(width: AppSize.s10),
                                                  CustomText(
                                                    title: data.productName!,
                                                    textStyle: getRegularStyle(
                                                      fontSize: AppSize.s14, 
                                                      color: Helper.isDark 
                                                      ? AppColors.white 
                                                      : AppColors.black
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.end,
                                                children: [
                                                  CustomText(
                                                    title: '\$${data.productPrice}',
                                                    textStyle: getRegularStyle(
                                                      fontSize: AppSize.s14,
                                                      color: AppColors.grey
                                                    ),
                                                  ),
                                                  CustomText(
                                                    title: '  x ${data.quantity}',
                                                    textStyle: getRegularStyle(
                                                      fontSize: AppSize.s14,
                                                      color: Helper.isDark 
                                                      ? AppColors.white 
                                                      : AppColors.black
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              child: Align(
                                                alignment: Alignment.centerRight,
                                                child: CustomText(
                                                  title: '\$${data.quantity! * data.productPrice!}',
                                                  textStyle: getRegularStyle(
                                                    fontSize: AppSize.s14,
                                                    color: Helper.isDark 
                                                    ? AppColors.white 
                                                    : AppColors.black
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      Visibility(
                                        visible: subIndex == checkSequenceOrderData.productDetails.length - 1,
                                        child: const Divider(height: AppSize.s5, thickness: AppSize.s05)
                                      ),
                                    ],
                                  );
                                },
                                separatorBuilder: (_, __) => const Divider(height: AppSize.s5, thickness: AppSize.s05),
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.black
                              : AppColors.white, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: AppSize.s50,
                                    right: AppSize.s16,
                                    top: AppSize.s16,
                                    bottom: AppSize.s16
                                  ),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: AppStrings.subTotal,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${checkSequenceOrderData.billingDetails!.subTotal!.roundTwo}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: AppSize.s6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: AppStrings.tax,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${checkSequenceOrderData.billingDetails!.tax!.roundTwo}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: AppSize.s6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: AppStrings.tip,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${checkSequenceOrderData.billingDetails!.tip!.roundTwo}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                      const Divider(color: AppColors.grey, height: AppSize.s20, thickness: 0.80),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: AppStrings.total,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${calculateGrandTotal(checkSequenceOrderData.billingDetails!)}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: AppSize.s6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: AppStrings.balanceDue,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${checkSequenceOrderData.billingDetails!.balanceDue!}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                  width: double.maxFinite,
                                  color: checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo > 0.0
                                  ?AppColors.red
                                  :AppColors.green,
                                  child: checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo > 0.0 
                                  ? Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CustomText(
                                          title: '${AppStrings.balanceDue} \$${checkSequenceOrderData.billingDetails!.balanceDue!.roundTwo}', 
                                          textStyle: getRegularStyle(
                                            fontSize: AppSize.s14,
                                            color: AppColors.white
                                          ),
                                        ),
                                      ],
                                    )
                                  : Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomText(
                                        title: AppStrings.paid, 
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14, 
                                          color: AppColors.white
                                        ),
                                      ),
                                      const SizedBox(width: AppSize.s8),
                                      const Icon(Icons.verified, color: AppColors.white, size: AppSize.s20)
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.black
                              : AppColors.white, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Padding(
                              padding: const EdgeInsets.all(AppSize.s16),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: CustomOutlinedButton(
                                      onPressed: () => showPaymentReceiptDialog(
                                        context: context, 
                                        checkDetails: checkSequenceOrderData, 
                                        checkSequence: index + 1
                                      ),
                                      text: AppStrings.printReceipt,
                                      textColor: AppColors.blue,
                                    ),
                                  ),
                                  const SizedBox(width: AppSize.s12),
                                  Expanded(
                                    child: CustomOutlinedButton(
                                      onPressed: () {},
                                      text: AppStrings.adjust,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      }
                    ),
                    Positioned(
                      bottom: 0.0,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(
                          paymentStatusList.length == 1 
                          ? 0 
                          : paymentStatusList.length, 
                          (subIndex) => Container(
                            padding: const EdgeInsets.all(AppSize.s4),
                            margin: const EdgeInsets.only(right: AppSize.s6, bottom: AppSize.s5),
                            decoration: BoxDecoration(
                              color: subIndex == tabIndex ? AppColors.primaryColor : AppColors.grey, 
                              shape: BoxShape.circle
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              //Right Screen for Payment
              Expanded(
                flex: 1, 
                child: Container(
                  color: Helper.isDark 
                  ? AppColors.black 
                  : AppColors.white,
                  child: ListView(
                    padding: const EdgeInsets.all(AppSize.s50),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            title: paymentStatusList.isEmpty
                            ? "${AppStrings.balanceDue}: \$"
                            :'${AppStrings.balanceDue}: \$${paymentStatusList[tabIndex].billingDetails!.balanceDue}',
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s26, 
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                          CustomOutlinedButton(
                            onPressed: () => onNavigateHomeScreen(context: context),
                            text: AppStrings.home,
                            textColor: AppColors.blue,
                            widgetSpacing: AppSize.s5,
                            leftPadding: AppSize.s12,
                            rightPadding: AppSize.s12,
                            preFixWidget: const Icon(
                              AppIcons.homeIcon, 
                              size: AppSize.s18, 
                              color: AppColors.blue
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s10),
                      Row(
                        children: [
                          SizedBox(
                            width: context.screenWidth * 0.16,
                            child: TextField(
                              controller: amountTenderedController,
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: AppSize.s20),
                              textAlign: TextAlign.right,
                              onChanged: (value) => _paymentBloc.add(OnAmountTextChange(text: value)),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s10,
                                  horizontal: AppSize.s8
                                ),
                                prefixIcon: const Icon(Icons.attach_money_outlined, size: AppSize.s20, color: AppColors.grey),
                                label: const Text(AppStrings.amountTendered),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSize.s6))
                              ),
                            ),
                          ),
                          const SizedBox(width: AppSize.s10),
                          SizedBox(
                            width: context.screenWidth * 0.10,
                            child: TextField(
                              controller: tipTextController,
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: AppSize.s20),
                              textAlign: TextAlign.right,
                              onChanged: (value) => _paymentBloc.add(OnTipTextChange(text: value)),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s10,
                                  horizontal: AppSize.s8
                                ),
                                prefixIcon: const Icon(Icons.attach_money_outlined, size: AppSize.s20, color: AppColors.grey),
                                label: const Text(AppStrings.tip),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppSize.s6))
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s30),
                      CustomText(
                        title: AppStrings.paymentOptions, 
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16, 
                          color: Helper.isDark 
                          ? AppColors.white 
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s10),
                      Visibility(
                        visible: cardLastFourDigit(paymentStatusList).isNotEmpty,
                        child: InkWell(
                          onTap: () => _paymentBloc.add(PaymentSelectedOptionEvent(selectedIndex: 0)),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: AppSize.s12),
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s15,
                              horizontal: AppSize.s25
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.headerColorDark 
                              : AppColors.white,
                              border: Border.all(
                                color: selectedPaymentOption == 0
                                ? Colors.blue
                                : AppColors.grey, 
                                width: AppSize.s1
                              ),
                              borderRadius: BorderRadius.circular(AppSize.s8)
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  selectedPaymentOption == 0
                                  ? AppIcons.radioButtonCheckedIcon
                                  : AppIcons.circleOutlinedIcon, 
                                  color: selectedPaymentOption == 0
                                  ? AppColors.primaryColor
                                  : AppColors.grey
                                ),
                                const SizedBox(width: AppSize.s15),
                                const Icon(Icons.add_card_rounded),
                                const SizedBox(width: AppSize.s12),
                                CustomText(
                                  title: cardLastFourDigit(paymentStatusList),
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s14, 
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      ListView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        children: List.generate(
                          paymentOptionList.length, 
                          (index) {
                            var data = paymentOptionList[index];
                            return InkWell(
                              onTap: () => _paymentBloc.add(PaymentSelectedOptionEvent(selectedIndex: index + 1)),
                              child: Container(
                                margin: const EdgeInsets.only(bottom: AppSize.s12),
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s15,
                                  horizontal: AppSize.s25
                                ),
                                decoration: BoxDecoration(
                                  color: Helper.isDark 
                                  ? AppColors.headerColorDark 
                                  : AppColors.white,
                                  border: Border.all(
                                    color: selectedPaymentOption == index + 1
                                    ? Colors.blue
                                    : AppColors.grey, 
                                    width: AppSize.s1
                                  ),
                                  borderRadius: BorderRadius.circular(AppSize.s8)
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          selectedPaymentOption == index + 1
                                          ? AppIcons.radioButtonCheckedIcon
                                          : AppIcons.circleOutlinedIcon, 
                                          color: selectedPaymentOption == index + 1
                                          ? AppColors.primaryColor
                                          : AppColors.grey
                                        ),
                                        const SizedBox(width: AppSize.s15),
                                        CustomImageView(
                                          imagePath: data.imagePath,
                                          width: AppSize.s15,
                                          height: AppSize.s15,
                                          blendMode: BlendMode.dstIn,
                                        ),
                                        const SizedBox(width: AppSize.s12),
                                        CustomText(
                                          title: data.title,
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s14, 
                                            color: Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                          ),
                                        ),
                                      ],
                                    ),
                                    //paymentInstrumentList
                                    ///Show Here Card Details
                                    Visibility(
                                      visible: selectedPaymentOption == 1 && index == 0,
                                      child: Container(
                                        margin: const EdgeInsets.only(top: 10),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(AppSize.s8),
                                          border: Border.all(color: AppColors.grey, width: 1.0)
                                        ),
                                        child: ListView(
                                          shrinkWrap: true,
                                          children: List.generate(
                                            paymentInstrumentList.length + 1, 
                                            (index) {
                                              return Material(
                                                child: InkWell(
                                                  onTap: () => _paymentBloc.add(SelectSavedCardEvent(
                                                    index: index,
                                                    paymentInstrument: index == 0 ? null : paymentInstrumentList[index - 1]
                                                  )),
                                                  child: Ink(
                                                    padding: const EdgeInsets.symmetric(
                                                      vertical: 8.0,
                                                      horizontal: 14.0
                                                    ),
                                                    child: index == 0
                                                    ? CustomText(
                                                        title: '+ Add New Card', 
                                                        textStyle: getMediumStyle(color: AppColors.primaryColor)
                                                      )
                                                    : Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      children: [
                                                        Row(
                                                          children: [
                                                            const CustomImageView(imagePath: AppImages.cashIcon, blendMode: BlendMode.dstIn),
                                                            const SizedBox(width: AppSize.s8),
                                                            CustomText(
                                                              title: '${paymentInstrumentList[index - 1].bin!}******${paymentInstrumentList[index - 1].lastFour!}',
                                                              textStyle: getMediumStyle(),
                                                            ),
                                                            const SizedBox(width: AppSize.s8),
                                                            CustomText(
                                                              title: '(${paymentInstrumentList[index - 1].expirationMonth}/${paymentInstrumentList[index - 1].expirationYear})'
                                                            ),
                                                          ],
                                                        ),
                                                        Icon(
                                                          Icons.check, 
                                                          color: selectedCard == index 
                                                          ? AppColors.green
                                                          : AppColors.transparent
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }
                        ),
                      ),
                      const SizedBox(height: AppSize.s30),
                      Row(
                        children: [
                          Visibility(
                            visible: !hasCheckSequence,
                            child: Expanded(
                              flex: 2,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: CustomOutlinedButton(
                                      onPressed: () => _paymentBloc.add(OnSplitItemEvent()),
                                      text: AppStrings.splitItems,
                                      textColor: AppColors.blue,
                                      topPadding: AppSize.s18,
                                      bottomPadding: AppSize.s18
                                    ),
                                  ),
                                  const SizedBox(width: AppSize.s12),
                                  Expanded(
                                    child: CustomOutlinedButton(
                                      onPressed: () => showSplitEvenlyDialog(
                                        context: context, 
                                        totalAmount: paymentStatusList[tabIndex].billingDetails!.balanceDue!,
                                        totalGuest: paymentStatusList[tabIndex].totalGuest,
                                        paymentBloc: _paymentBloc
                                      ),
                                      text: AppStrings.splitEvenly,
                                      textColor: AppColors.blue,
                                      topPadding: AppSize.s18,
                                      bottomPadding: AppSize.s18
                                    ),
                                  ),
                                  const SizedBox(width: AppSize.s12),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomSolidButton(
                              onPressed: selectedPaymentOption < 0 || amountTendered <= 0.0
                              ? null
                              : () => _paymentBloc.add(UpdatePaymentStatusEvent(
                                hasCheckSequence: hasCheckSequence,
                                paymentOrderModel: paymentStatusList[tabIndex],
                                amountReceive: amountTendered, 
                                tipReceive: tipAmount,
                                isPreAuth: isPreAuth,
                                paymentMode: getPaymentOption,
                              )),
                              text: (amountTendered + tipAmount) == 0.0
                              ? AppStrings.pay
                              : '${AppStrings.pay} (\$${(amountTendered + tipAmount).roundTwo})',
                              verPadding: AppSize.s18,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String get getPaymentOption {
    if(cardLastFourDigit(paymentStatusList).isNotEmpty) {
      if(selectedPaymentOption == 0) {
        return 'PRE AUTH';
      } else if(selectedPaymentOption == 1) {
        return paymentOptions[0]!;
      } else {
        return paymentOptions[1]!;
      }
    } else {
      return paymentOptions[selectedPaymentOption - 1]!;
    }
  }


  void showPaymentProcessingDialog() {
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (_) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: PaymentAddNewCardDialog(
            paymentBloc: _paymentBloc,
            customerName: customerName,
            stateList: stateList,
          ),
        );
      }
    );
  }

  ///Dialog for payment receipt
  void showPaymentReceiptDialog({
    required BuildContext context, 
    required PaymentOrderModel checkDetails, 
    required int checkSequence
  }) {
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: PaymentReceiptWidget(checkDetails: checkDetails, checkSequence: checkSequence),
        );
      }
    );
  }

  String cardLastFourDigit(List<PaymentOrderModel> paymentDetails) {
    try {
      if(paymentDetails.isEmpty) {
        return '';
      } else if(paymentDetails.first.preAuthDetails == null || paymentDetails.first.preAuthDetails!.cardLastFourDegit == null) {
        return '';
      } else {
        isPreAuth = true;
        return 'Saved card (ends with ${paymentDetails.first.preAuthDetails!.cardLastFourDegit!})';
      }
    } catch (e) {
      return '';
    }
  }

  double calculateGrandTotal(BillingDetails? billingDetails){
    if(billingDetails == null){
      return 0.0;
    } else {
      try {
        var grandTotal = (billingDetails.subTotal! + billingDetails.tax! + billingDetails.tip!) - billingDetails.discount!;
        return grandTotal.roundTwo;
      } catch (e) {
        return 0.0;
      }
    }
  }

  ///Dialog For Split Check Evenly
  void showSplitEvenlyDialog({
    required BuildContext context, 
    required double totalAmount, 
    required int totalGuest,
    required PaymentBloc paymentBloc
  }) {
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (_) {
        return PaymentSplitEvenlyWidget(
          paymentBloc: paymentBloc, 
          totalAmount: totalAmount, 
          customerId: customerId,
          orderId: orderId, 
          isPreAuth: isPreAuth,
          customerName: customerName,
          totalGuest: totalGuest,
        );
      }
    );
  }

  //Dialog for Success Payment
  void showPaymentSuccessDialog({required BuildContext context}) {
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (_) {
        return AlertDialog(
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          content: Container(
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s40,
              horizontal: AppSize.s40
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s12),
              color: Helper.isDark 
              ? AppColors.contentColorDark 
              : AppColors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const CustomImageView(imagePath: AppImages.paymentSuccessGIF),
                CustomText(
                  title: AppStrings.paymentSuccessful,
                  textAlign: TextAlign.center,
                  textStyle: getBoldStyle(
                    color: AppColors.primaryColor,
                    fontSize: AppSize.s30
                  ),
                ),  
                const SizedBox(height: AppSize.s20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomOutlinedButton(
                      text: AppStrings.close,
                      widgetSpacing: AppSize.s10,
                      textSize: AppSize.s16,
                      onPressed: () => context.pop(),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  void onNavigateHomeScreen({required BuildContext context}) {
    if(context.mounted) {
      while (GoRouter.of(context).canPop()) {
        GoRouter.of(context).pop();
      }
      GoRouter.of(context).pushReplacement(AppRoutes.dashboardScreen);
    }
  }
  
}