import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import 'bloc/payment_bloc.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../utils/app_extension_method.dart';

class PaymentSplitEvenlyWidget extends StatelessWidget {

  final PaymentBloc paymentBloc;
  final double totalAmount;
  final String orderId;
  final String customerId;
  final bool isPreAuth;
  final String customerName;
  final int totalGuest;

  const PaymentSplitEvenlyWidget({
    super.key,
    required this.paymentBloc,
    required this.totalAmount,
    required this.customerId,
    required this.orderId,
    required this.isPreAuth,
    required this.customerName,
    required this.totalGuest
  });

  @override
  Widget build(BuildContext context) {
    int selectedSplitIndex = -1;
    int splitBy = 1;
    var sequenceDropdownMenuItem = List.generate(
      totalGuest,
      (index) => DropdownMenuItem<int>(
        value: index + 1,  
        child: Text('${index + 1}'),
      ),
    );
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s12)),
      contentPadding: EdgeInsets.zero,
      insetPadding: EdgeInsets.zero,
      content: Container(
        width: context.screenWidth <= 600
        ? context.screenWidth * 0.95
        : context.screenWidth * 0.34,
        padding: const EdgeInsets.all(AppSize.s20),
        decoration: BoxDecoration(
          color: Helper.isDark
          ? AppColors.headerColorDark
          : AppColors.white,
          borderRadius: BorderRadius.circular(AppSize.s12)
        ),
        child: BlocProvider<PaymentBloc>.value(
          value: paymentBloc,
          child: BlocBuilder<PaymentBloc, PaymentState>(
            builder: (_, state) {
              switch (state) {
                case OnSelectSplitState _:
                  selectedSplitIndex = state.selectedIndex;
                  break;
                case OnChangeSplitCheckState _:
                  splitBy = state.checkIndex;
                  break;
                default:
              }
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: AppStrings.splitEvenly,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16,
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          paymentBloc.add(OnSelectSplitEvent(selectedIndex: -1));
                          context.pop();
                        }, 
                        icon: const Icon(Icons.clear_sharp)
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: AppSize.s30, horizontal: AppSize.s15),
                    decoration: BoxDecoration(
                      color: AppColors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8)
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            children: [
                              CustomText(
                                title: "\$${(totalAmount / splitBy).roundTwo}",
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: 0 == selectedSplitIndex
                                  ? AppColors.white
                                  : Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                ),
                              ),
                              const CustomText(title: 'per person')
                            ],
                          ),
                        ),
                        Expanded(
                          child: InputDecorator(
                            decoration: const InputDecoration(
                              contentPadding: EdgeInsets.symmetric(horizontal: AppSize.s15),
                              border: OutlineInputBorder(),
                              label: Text('Split Check By')
                            ),
                            child: DropdownButton(
                              items: sequenceDropdownMenuItem, 
                              value: splitBy,
                              isExpanded: true,
                              isDense: true,
                              underline: const SizedBox(),
                              onChanged: (value) => paymentBloc.add(OnChangeSplitCheckEvent(checkIndex: value!))
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSize.s15),
                  Row(
                    children: [
                      Expanded(
                        child: CustomOutlinedButton(
                          onPressed: () {
                            paymentBloc.add(OnSelectSplitEvent(selectedIndex: -1));
                            context.pop();
                          },
                          text: AppStrings.cancel,
                          textColor: AppColors.red,
                          borderColor: AppColors.red,
                        ),
                      ),
                      const SizedBox(width: AppSize.s15),
                      Expanded(
                        child: CustomSolidButton(
                          onPressed: () {
                            paymentBloc.add(OnSplitEvenlyEvent(
                              splitDivision: splitBy, 
                              orderId: orderId,
                              customerId: customerId,
                              isPreAuth: isPreAuth,
                              customerName: customerName
                            ));
                            context.pop();
                          },
                          text: AppStrings.continueString
                        ),
                      ),
                    ],
                  ),
                ],
              );
            }
          ),
        ),
      ),
    );
  }
}