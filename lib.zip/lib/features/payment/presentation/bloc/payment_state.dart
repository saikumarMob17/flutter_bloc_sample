// import '../../../payment_terminal/domain/payment_order_model.dart';
part of 'payment_bloc.dart';
sealed class PaymentState{}

class PaymentInitialState extends PaymentState {}

class PaymentLoadingState extends PaymentState {}

class PaymentSuccessState extends PaymentState {
  String message;
  PaymentSuccessState({this.message = ''});
}

class PaymentFailedState extends PaymentState {
  String message;
  PaymentFailedState({this.message = ''});
}

class PaymentSelectedOptionState extends PaymentState {
  int selectedItem;
  PaymentSelectedOptionState({required this.selectedItem});
}

class AmountTextErrorState extends PaymentState {
  String msg;
  String amount;
  AmountTextErrorState({this.msg = '', this.amount = ''});
}

class TipTextErrorState extends PaymentState {
  String msg;
  String amount;

  TipTextErrorState({this.msg = '', this.amount = ''});

}

class PaymentStatusState extends PaymentState {
  List<PaymentOrderModel> orderList;
  List<DropdownMenuModel> stateMenuList;
  bool isPerformPayment;
  String orderId;
  int currentPageIndex;
  bool hasSequence;
  String customerName;
  PaymentStatusState({
    required this.orderList,
    required this.orderId,
    required this.stateMenuList,
    this.currentPageIndex = 0,
    this.hasSequence = false, 
    this.isPerformPayment = false,
    this.customerName = ''
  });
}

class ChangeTabPageIndexState extends PaymentState {
  int tabIndex;

  ChangeTabPageIndexState({this.tabIndex = 0});
}

class OnSelectSplitState extends PaymentState {
  int selectedIndex;

  OnSelectSplitState({required this.selectedIndex});
}

class OnChangeSplitCheckState extends PaymentState {
  int checkIndex;

  OnChangeSplitCheckState({required this.checkIndex});
}


class OnChangeCardMonthState extends PaymentState {
  int selectedMonth;

  OnChangeCardMonthState(this.selectedMonth);
}

class OnChangeCardYearState extends PaymentState {
  int selectedYear;

  OnChangeCardYearState(this.selectedYear);
}

class FetchFinixPaymentInstrumentState extends PaymentState {
  List<PaymentInstrument> paymentInstrumentList;

  FetchFinixPaymentInstrumentState({required this.paymentInstrumentList});  
}

class SelectSavedCardState extends PaymentState {
  PaymentInstrument? paymentInstrument;
  int index;

  SelectSavedCardState({this.paymentInstrument, required this.index});
}

class PaymentFinixErrorState extends PaymentState {
  String message;
  bool isSuccess;

  PaymentFinixErrorState({this.message = '', this.isSuccess = false});
}

class OnSplitItemState extends PaymentState {
  PaymentModel paymentModel;

  OnSplitItemState({required this.paymentModel});
}

class CardOnNameChangeState extends PaymentState {
  String message;

  CardOnNameChangeState({this.message = ''});
}

class CardNumberChangeState extends PaymentState {
  String message;

  CardNumberChangeState({this.message = ''});
}

class CardExpiryChangeState extends PaymentState {
  String message;

  CardExpiryChangeState({this.message = ''});
}

class CardCvvChangeState extends PaymentState {
  String message;
  CardCvvChangeState({this.message = ''});
}

class CardZipCodeChangeState extends PaymentState {
  String message;

  CardZipCodeChangeState({this.message = ''});
}

class OnChangeStateDropDownState extends PaymentState {
  String stateCode;

  OnChangeStateDropDownState({this.stateCode = ''});
}