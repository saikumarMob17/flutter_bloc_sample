part of 'payment_bloc.dart';

sealed class PaymentEvent{}

class PaymentSelectedOptionEvent extends PaymentEvent {
  int selectedIndex;
  PaymentSelectedOptionEvent({required this.selectedIndex});
}

class UpdatePaymentStatusEvent extends PaymentEvent {
  PaymentOrderModel paymentOrderModel;
  bool isPreAuth;
  bool hasCheckSequence;
  double amountReceive;
  double tipReceive;
  String paymentMode;
  UpdatePaymentStatusEvent({
    required this.paymentOrderModel,
    required this.amountReceive, 
    required this.hasCheckSequence,
    required this.tipReceive, 
    required this.paymentMode,
    this.isPreAuth = false
  });
}

class OnAmountTextChange extends PaymentEvent {
  String text;
  OnAmountTextChange({required this.text});
}


class OnTipTextChange extends PaymentEvent {
  String text;
  OnTipTextChange({required this.text});
}

class PaymentStatusEvent extends PaymentEvent {
  bool isPerformPayment;

  PaymentStatusEvent({this.isPerformPayment = false});
}

class ChangeTabPageIndexEvent extends PaymentEvent {
  int pageIndex;
  ChangeTabPageIndexEvent({required this.pageIndex});
}

class OnRefreshPaymentsEvent extends PaymentEvent {}

class OnSelectSplitEvent extends PaymentEvent {
  int selectedIndex;

  OnSelectSplitEvent({required this.selectedIndex});
}

class OnSplitEvenlyEvent extends PaymentEvent {
  int splitDivision;
  String orderId;
  String customerName;
  bool isPreAuth;
  String customerId;

  OnSplitEvenlyEvent({
    required this.splitDivision, 
    required this.orderId,
    required this.customerName,
    required this.isPreAuth,
    required this.customerId
  });
}

class OnChangeSplitCheckEvent extends PaymentEvent {
  int checkIndex;

  OnChangeSplitCheckEvent({required this.checkIndex});
}

class OnChangeCardMonthEvent extends PaymentEvent {
  int selectedMonth;

  OnChangeCardMonthEvent(this.selectedMonth);
}

class OnChangeCardYearEvent extends PaymentEvent {
  int selectedYear;

  OnChangeCardYearEvent(this.selectedYear);
}

class FetchFinixPaymentInstrumentEvent extends PaymentEvent {
  String finixCustomerIdentity;

  FetchFinixPaymentInstrumentEvent({this.finixCustomerIdentity = ''});  
}

class SelectSavedCardEvent extends PaymentEvent {
  PaymentInstrument? paymentInstrument;
  int index;

  SelectSavedCardEvent({this.paymentInstrument, required this.index});
}

class CreatePaymentInstrumentEvent extends PaymentEvent {
  String cardHolderName;
  String cardNumber;
  String cvv;
  String expiryMonthYear;
  String city;
  String addressLine1;
  String postalCode;
  String region;

  CreatePaymentInstrumentEvent({
    required this.cardNumber,
    required this.expiryMonthYear,
    required this.cvv,
    this.cardHolderName = '',
    this.addressLine1 = '',
    this.city = '',
    this.postalCode = '',
    this.region = ''
  });

}

class PaymentHideFinixErrorEvent extends PaymentEvent {}

class OnSplitItemEvent extends PaymentEvent {}


//Payment validation methods
class CardOnNameChangeEvent extends PaymentEvent {
  String text;

  CardOnNameChangeEvent({this.text = ''});
}

class CardNumberChangeEvent extends PaymentEvent {
  String text;

  CardNumberChangeEvent({this.text = ''});
}

class CardExpiryChangeEvent extends PaymentEvent {
  String text;

  CardExpiryChangeEvent({this.text = ''});
}

class CardCvvChangeEvent extends PaymentEvent {
  String text;

  CardCvvChangeEvent({this.text = ''});
}

class CardZipCodeChangeEvent extends PaymentEvent {
  String text;

  CardZipCodeChangeEvent({this.text = ''});
}

class OnChangeStateDropDownEvent extends PaymentEvent {
  String stateCode;

  OnChangeStateDropDownEvent({this.stateCode = ''});
}