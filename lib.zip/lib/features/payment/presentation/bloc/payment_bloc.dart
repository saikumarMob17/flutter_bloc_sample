import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../widgets/dropdownmenu_model.dart';
import '../../../orders/domain/order_model.dart';
import '../../domain/payment_model.dart';
import '../../../../services/finix_payment_instrument_response.dart';
import '../../../../services/finix_transfer_model.dart';
import '../../../payment_terminal/domain/payment_terminal_response.dart' as payment_terminal;
import '../../../../network/custom_exception.dart';
import '../../../../services/finix_create_payment_instrument_model.dart';
import '../../../../utils/app_extension_method.dart';
import '../../../../constants/app_strings.dart';
import '../../data/payment_repository.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../payment_terminal/domain/payment_order_model.dart';
import '../../domain/payment_request_model.dart';
part 'payment_event.dart';
part 'payment_state.dart';

class PaymentBloc extends Bloc<PaymentEvent, PaymentState>{

  late CheckConnectivity _checkConnectivity;
  late PaymentRepository _paymentRepository;
  var orderList = <PaymentOrderModel>[];
  var originalOrderList = <PaymentOrderModel>[];
  String customerIdentity = '';
  List<PaymentInstrument> paymentInstrumentList = [];
  final Map orderDetails;
  PaymentInstrument? selectedPaymentInstruction;
  String customerId = '';
  String customerName = '';
  int paymentOptionSelectedIndex = -1;
  var stateMap = <String, dynamic>{};
  List<DropdownMenuModel> stateMenuList = [];

  PaymentBloc({required this.orderDetails}) : super(PaymentInitialState()) {
    _checkConnectivity = CheckConnectivity();
    _paymentRepository = PaymentRepository();
    on<PaymentSelectedOptionEvent>(_onChangePaymentOption);
    on<UpdatePaymentStatusEvent>(_onPlaceOrderEvent);
    on<OnAmountTextChange>(_onAmountChange);
    on<OnTipTextChange>(_onTipAmountChange);
    on<PaymentStatusEvent>(_onFetchPaymentStatus);
    on<ChangeTabPageIndexEvent>(_onChangeTabPageIndex);
    on<OnRefreshPaymentsEvent>((event, emit) => add(PaymentStatusEvent()));
    on<OnSelectSplitEvent>(_onSelectSplitItem);
    on<OnSplitEvenlyEvent>(_onSplitEvenly);
    on<OnChangeSplitCheckEvent>(_onChangeSplitSequence);
    on<OnChangeCardMonthEvent>(_onChangeCardMonth);
    on<OnChangeCardYearEvent>(_onChangeCardYear);
    on<FetchFinixPaymentInstrumentEvent>(_onFetchPaymentInstrument);
    on<SelectSavedCardEvent>(_onSelectSavedCard);
    on<CreatePaymentInstrumentEvent>(_onAddFinixNewCard);
    on<PaymentHideFinixErrorEvent>(_hideFinixError);
    on<OnSplitItemEvent>(_onSplitItemEvent);
    on<CardNumberChangeEvent>(_onChangeCardNumber);
    on<CardOnNameChangeEvent>(_onChangeCardName);
    on<CardExpiryChangeEvent>(_onChangeExpiryDate);
    on<CardCvvChangeEvent>(_onChangeCvv);
    on<CardZipCodeChangeEvent>(_onChangeZipCode);
    on<OnChangeStateDropDownEvent>(_onChangeStateDropDown);
  }

  void _onChangeStateDropDown(OnChangeStateDropDownEvent event, Emitter emit) {
    emit(OnChangeStateDropDownState(stateCode: event.stateCode));
  }

  Future<void> _getAllStateList() async {
    try {
      var data = await rootBundle.loadString('assets/json/us_state_list.json');
      stateMap.clear();
      stateMap.addAll(jsonDecode(data));
      stateMenuList.clear();
      stateMap.forEach((key, value) {
        stateMenuList.add(DropdownMenuModel(
          value: key, 
          item: value
        ));
      });
    } on CustomException catch (e) {
      debugPrint(e.message);
    }
  }

  void _onChangeCardNumber(CardNumberChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardNumberChangeState(message: 'Please provide card number'));
    } else if(event.text.length < 19) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
    } else {
      emit(CardNumberChangeState());
    }
  }

  void _onChangeCardName(CardOnNameChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardOnNameChangeState(message: 'Please provide card holder name'));
    } else {
      emit(CardOnNameChangeState());
    }
  }

  void _onChangeExpiryDate(CardExpiryChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardExpiryChangeState(message: 'Please provide card expiry date'));
    } else {
      emit(CardExpiryChangeState());
    }
  }

  void _onChangeCvv(CardCvvChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardCvvChangeState(message: 'Please provide card cvv number'));
    } else {
      emit(CardCvvChangeState());
    }
  }

  void _onChangeZipCode(CardZipCodeChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(CardZipCodeChangeState(message: 'Please provide zipcode'));
    } else {
      emit(CardZipCodeChangeState());
    }
  }

  void _onSplitItemEvent(OnSplitItemEvent event, Emitter emit) {
    if(orderList.isNotEmpty) {
      var paymentModel = PaymentModel(
        isPreAuth: false,
        isFirstOrder: false, 
        orderId: orderDetails['orderId'], 
        customerName: customerName,
        customerIdentity: customerIdentity,
        customerId: customerId,
        tableName: orderList.first.tableList.fold("", (p0, p1) => p0.isBlank ? '${p1.tableName}' : '$p0, ${p1.tableName}'),
        orderSequence: 0, 
        orderedItem: List.generate(
          orderList.first.productDetails.length, 
          (index) {
            var item  = orderList.first.productDetails[index];
            return OrderModel(
              itemId: item.productId!,
              title: item.productName!,
              price: item.productPrice!.toDouble(),
              totalPrice: (item.quantity! * item.productPrice!.toDouble()).roundTwo,
              quantity: item.quantity!
            );
          }
        ), 
        selectedTableList: []
      );
      emit(OnSplitItemState(paymentModel: paymentModel));
    }
  }

  void _hideFinixError(PaymentHideFinixErrorEvent event, Emitter emit) {
    emit(PaymentFinixErrorState());
  }

  Future<void> _onAddFinixNewCard(CreatePaymentInstrumentEvent event, Emitter emit) async {
    if(await _addNewCardValidation(event, emit)) {
      try {
        var tempExpiryData = event.expiryMonthYear.replaceAll(' ', '').split('/');
        var paymentInstrumentModel = FinixPaymentInstrumentModel(
          customerIdentity: customerIdentity, 
          cardNumber: event.cardNumber, 
          expiryMonth: int.parse(tempExpiryData[0]), 
          expiryYear: int.parse(tempExpiryData[1]), 
          city: event.city,
          line1: event.addressLine1,
          region: stateMap[event.region]!,
          cvv: event.cvv, 
          cardHolderName: event.cardHolderName,
          postalCode: event.postalCode
        ).toJson;
        emit(PaymentLoadingState());
        var response = await _paymentRepository.createPaymentInstrument(body: paymentInstrumentModel);
        switch (response.statusCode) {
          case HttpStatus.created:
            emit(PaymentFinixErrorState(message: "Card added successfully", isSuccess: true));
            break;
          case HttpStatus.unprocessableEntity:
            emit(PaymentFinixErrorState(message: '${jsonDecode(response.body)['_embedded']['errors'][0]['message']}'));
            break;
          default:
            emit(PaymentFinixErrorState(message: "Unable to add new card"));
        }
      } on CustomException catch (e) {
        emit(PaymentFinixErrorState(message: e.message));
      }
    }
    }

  Future<bool> _addNewCardValidation(CreatePaymentInstrumentEvent event, Emitter emit) async {
    if(event.cardHolderName.isBlank) {
      emit(CardOnNameChangeState(message: 'Please provide card holder name'));
      return false;
    } else if(event.cardNumber.isBlank) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
      return false;
    } else if(event.cardNumber.length < 16) {
      emit(CardNumberChangeState(message: 'Please provide valid card number'));
      return false;
    } else if(event.expiryMonthYear.isBlank) {
      emit(CardExpiryChangeState(message: 'Please provide valid expiry date'));
      return false;
    } else if(event.cvv.isBlank) {
      emit(CardCvvChangeState(message: 'Please provide card security pin'));
      return false;
    } else if(event.postalCode.isBlank) {
      emit(CardZipCodeChangeState(message: 'Please provide postal code'));
      return false;
    } else if(!await _checkConnectivity.hasConnection) {
      emit(PaymentFinixErrorState(message: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  void _onSelectSavedCard(SelectSavedCardEvent event, Emitter emit) {
    selectedPaymentInstruction = event.paymentInstrument;
    emit(SelectSavedCardState(
      index: event.index,
      paymentInstrument: event.paymentInstrument
    ));
  }

  Future<void> _onFetchPaymentInstrument(FetchFinixPaymentInstrumentEvent event, Emitter emit) async {
    try {
      emit(PaymentLoadingState());
      var response = await _paymentRepository.getAllFinixPaymentInstrument();
      paymentInstrumentList.clear();
      for(var item in response) {
        if(item.identity == customerIdentity) {
          paymentInstrumentList.add(item);
        }
      }
      emit(FetchFinixPaymentInstrumentState(paymentInstrumentList: paymentInstrumentList));
    } on CustomException catch (e) {
      emit(PaymentFailedState(message: e.message));
    }
  }

  void _onChangeCardMonth(OnChangeCardMonthEvent event, Emitter emit) {
    emit(OnChangeCardMonthState(event.selectedMonth));
  }

  void _onChangeCardYear(OnChangeCardYearEvent event, Emitter emit) {
    emit(OnChangeCardYearState(event.selectedYear));
  }

  void _onChangeSplitSequence(OnChangeSplitCheckEvent event, Emitter emit) {
    emit(OnChangeSplitCheckState(checkIndex: event.checkIndex));
  }  

  void _onChangePaymentOption(PaymentSelectedOptionEvent event, Emitter emit) async {
    emit(PaymentSelectedOptionState(selectedItem: event.selectedIndex));
    if(paymentOptionSelectedIndex != 1 && event.selectedIndex == 1 && paymentInstrumentList.isEmpty && customerIdentity.isNotEmpty) {
      paymentOptionSelectedIndex = event.selectedIndex;
      Future.delayed(const Duration(milliseconds: 200), () => add(FetchFinixPaymentInstrumentEvent()));
    }
  }

  void _onChangeTabPageIndex(ChangeTabPageIndexEvent event, Emitter emit){
    emit(ChangeTabPageIndexState(tabIndex: event.pageIndex));
  }

  void _onSelectSplitItem(OnSelectSplitEvent event, Emitter emit){
    emit(OnSelectSplitState(selectedIndex: event.selectedIndex));
  }

  Future<void> _onFetchPaymentStatus(PaymentStatusEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(PaymentLoadingState());
        var data = await _paymentRepository.getAllPendingOrders();
        if(data.isNotEmpty) {
          await _getAllStateList();
          orderList.clear();
          originalOrderList.clear();
          var temp = <PaymentOrderModel>[];
          for(var item in data) {
            if(item.orderId == orderDetails['orderId']) {
              customerIdentity = item.customerIdentity ?? '';
              customerId = item.customerId ?? '';
              customerName = item.customerName.toString();
              var orderNumber = item.orderNumber.toString();
              var orderId = item.orderId.toString();
              var tableList = item.tableDetails!;
              ///Check Details Length
              if(item.checkDetails!.isEmpty) {
                List<payment_terminal.SplitItem> tempProductDetails = [];
                double subTotal = 0.0;
                double discount = 0.0;
                double tax = 0.0;
                double tip = 0.0;
                double grandTotal = 0.0;
                for(var subItem in item.orderedProductDetailsByOrderSequence!){
                  tempProductDetails.addAll(subItem.productDetails!);
                  subTotal += subItem.billingDetails!.subTotal!;
                  discount += subItem.billingDetails!.discount!;
                  tax += subItem.billingDetails!.tax!;
                  tip += subItem.billingDetails!.tip!;
                  grandTotal += subItem.billingDetails!.grandTotal!;
                }
                temp.add(PaymentOrderModel(
                  customerName: customerName, 
                  totalGuest: item.totalGuest!,
                  orderNumber: orderNumber, 
                  orderId: orderId, 
                  customerId: customerId, 
                  preAuthDetails: item.preAuthDetails,
                  tableList: tableList,
                  orderDate: item.orderDate,
                  serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                  serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                  orderDetails: item.orderedProductDetailsByOrderSequence!, 
                  checkSequence: 1,
                  productDetails: tempProductDetails,
                  billingDetails: payment_terminal.BillingDetails(
                    subTotal: subTotal,
                    discount: discount,
                    tax: tax,
                    tip: tip,
                    grandTotal: grandTotal,
                    balanceDue: grandTotal,
                    paymentStatus: item.totalBillingDetail!.paymentStatus
                  )
                ));
              } else {
                if(item.checkDetails!.every((element) => element.splitItems == null || element.splitItems!.isEmpty)) {
                  List<payment_terminal.SplitItem> tempProductDetails = [];
                  for(var subItem in item.orderedProductDetailsByOrderSequence!){
                    tempProductDetails.addAll(subItem.productDetails!);
                  }
                  temp.add(PaymentOrderModel(
                    customerName: customerName, 
                    totalGuest: item.totalGuest!,
                    orderNumber: orderNumber, 
                    orderId: orderId, 
                    customerIdentity: customerIdentity,
                    orderDate: item.orderDate,
                    customerId: customerId, 
                    preAuthDetails: item.preAuthDetails,
                    tableList: tableList,
                    serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                    serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                    hasCheckSequence: true,
                    checkId: item.checkDetails!.first.checkId,
                    orderDetails: item.orderedProductDetailsByOrderSequence!, 
                    checkSequence: item.checkDetails!.length,
                    productDetails: tempProductDetails,
                    billingDetails: payment_terminal.BillingDetails(
                      subTotal: item.totalBillingDetail!.subTotal!.toDouble(),
                      discount: item.totalBillingDetail!.discount!.toDouble(),
                      tax: item.totalBillingDetail!.tax!,
                      tip: item.totalBillingDetail!.tip!.toDouble(),
                      grandTotal: item.totalBillingDetail!.grandTotal!.toDouble(),
                      balanceDue: item.totalBillingDetail!.balanceDue!.toDouble(),
                      paymentStatus: item.totalBillingDetail!.paymentStatus,
                      paymentMode: item.totalBillingDetail!.paymentMode
                    )
                  ));
                } else {
                  payment_terminal.BillingDetails? billingDetails;
                  for(var subItem in item.checkDetails!) {
                    billingDetails = payment_terminal.BillingDetails(
                      subTotal: subItem.billingDetails!.subTotal!.toDouble(),
                      discount: subItem.billingDetails!.discount!.toDouble(),
                      tax: subItem.billingDetails!.tax!,
                      tip: subItem.billingDetails!.tip!.toDouble(),
                      grandTotal: subItem.billingDetails!.grandTotal!.toDouble(),
                      balanceDue: subItem.billingDetails!.balanceDue!.toDouble(),
                      paymentStatus: subItem.billingDetails!.paymentStatus!,
                      paymentMode: subItem.billingDetails!.paymentMode
                    );
                    temp.add(PaymentOrderModel(
                      customerName: customerName, 
                      totalGuest: item.totalGuest!,
                      orderNumber: orderNumber, 
                      orderId: orderId, 
                      customerIdentity: customerIdentity,
                      orderDate: item.orderDate,
                      customerId: customerId, 
                      preAuthDetails: item.preAuthDetails,
                      serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                      serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                      tableList: tableList,
                      checkId: subItem.checkId,
                      hasCheckSequence: true,
                      orderDetails: item.orderedProductDetailsByOrderSequence!, 
                      checkSequence: subItem.checkSequence!,
                      productDetails: subItem.splitItems!,
                      billingDetails: billingDetails,
                      
                    ));
                  }
                }
              }
              break;
            }
          }
          temp.sort((a,b) => a.checkSequence.compareTo(b.checkSequence));
          orderList.addAll(temp);
          originalOrderList.addAll(temp);
        }
        emit(PaymentStatusState(
          orderList: orderList, 
          orderId: orderDetails['orderId'],
          customerName: customerName,
          hasSequence: orderList.first.hasCheckSequence ?? false,
          isPerformPayment: event.isPerformPayment,
          stateMenuList: stateMenuList,
          currentPageIndex: orderDetails['pageIndex']
        ));
      } on CustomException catch (e) {
        debugPrint(e.message);
      }
    }
  }

  Future<void> _onPlaceOrderEvent(UpdatePaymentStatusEvent event, Emitter emit) async {
    if(await _paymentValidation(event, emit)) {
      try {
        if(event.hasCheckSequence) {
          var splitItems = List.generate(event.paymentOrderModel.productDetails.length, (index) {
            var data = event.paymentOrderModel.productDetails[index];
            return data.toJson;
          });
          String? cardType;
          String? cardNumber;
          emit(PaymentLoadingState());
          if(event.paymentMode == 'CREDIT CARD') {
            cardType = selectedPaymentInstruction!.brand!;
            cardNumber = selectedPaymentInstruction!.lastFour!;
            var transferModel = FinixTransferModel(
              amount: (event.tipReceive + event.amountReceive) * 100.0, 
              paymentInstrumentId: selectedPaymentInstruction!.id!
            );
            //Call Finix Transfer API
            var finixTransferId = await _paymentRepository.finixTransfer(transferModel: transferModel);
            log(finixTransferId);
          }
          if(event.paymentMode == 'PRE AUTH') {
            // cardType = selectedPaymentInstruction!.brand!;
            // cardNumber = selectedPaymentInstruction!.lastFour!;
            var authorizationId = orderList.first.preAuthDetails!.finixAuthorizationId!;
            var amount = (event.tipReceive + event.amountReceive) * 100.0;
            var finixAuthCaptureId = await _paymentRepository.finixCaptureAuthorization(authorizationId: authorizationId, amount: amount);
            log(finixAuthCaptureId);
          }
          var remainingBalance = (event.paymentOrderModel.billingDetails!.balanceDue! - event.amountReceive).roundTwo;
          var checkSequenceRequest = {
          "checkId": event.paymentOrderModel.checkId,
          "splitItems": splitItems,
            "billingDetails": {
              "subTotal": event.amountReceive,
              "discount": 0.0,
              "tax": 0.0,
              "tip": event.tipReceive,
              "grandTotal": (event.amountReceive + event.tipReceive).roundTwo,
              "balanceDue": remainingBalance,
              "paymentStatus": true,
              "paymentMode": event.paymentMode,
              "cardType": cardType,
              "cardNumber": cardNumber
            }
          };
          var response = await _paymentRepository.updatePaymentByCheckSequence(body: checkSequenceRequest);
          if(response.isNotEmpty){
            emit(PaymentSuccessState(message: "Payment Successful"));
          } else {
            emit(PaymentFailedState(message: "Payment Failed"));
          }
        } else {
          String? cardType;
          String? cardNumber;
          emit(PaymentLoadingState());
          if(event.paymentMode == 'CREDIT CARD') {
            cardType = selectedPaymentInstruction!.brand!;
            cardNumber = selectedPaymentInstruction!.lastFour!;
            var transferModel = FinixTransferModel(
              amount: (event.tipReceive + event.amountReceive) * 100.0, 
              paymentInstrumentId: selectedPaymentInstruction!.id!
            );
            //Call Finix Transfer API
            var finixTransferId = await _paymentRepository.finixTransfer(transferModel: transferModel);
            log(finixTransferId);
          }
          if(event.paymentMode == 'PRE AUTH') {
            // cardType = selectedPaymentInstruction!.brand!;
            // cardNumber = selectedPaymentInstruction!.lastFour!;
            var authorizationId = orderList.first.preAuthDetails!.finixAuthorizationId!;
            var amount = (event.tipReceive + event.amountReceive) * 100.0;
            var finixAuthCaptureId = await _paymentRepository.finixCaptureAuthorization(authorizationId: authorizationId, amount: amount);
            log(finixAuthCaptureId);
          }
          var splitItems = List.generate(
            event.paymentOrderModel.productDetails.length, 
            (index) {
              var data = event.paymentOrderModel.productDetails[index];
              return SplitItem(productId: data.productId!, productName: data.productName!, quantity: data.quantity!, productPrice: data.productPrice!);
            }
          );
          var subTotal = orderList.first.billingDetails!.subTotal!.roundTwo;
          ///calculate tax
          var tax = (subTotal * 10) / 100;
          var remainingBalance = (orderList.first.billingDetails!.balanceDue! - event.amountReceive) <= 0.0 ? 0.0 : (orderList.first.billingDetails!.balanceDue! - event.amountReceive);
          var grandTotal = ((subTotal + tax + event.tipReceive) - orderList.first.billingDetails!.discount!).roundTwo;
          var totalBillingDetails = payment_terminal.BillingDetails(
            subTotal: subTotal, 
            discount: orderList.first.billingDetails!.discount, 
            tax: tax, 
            tip: event.tipReceive, 
            grandTotal: grandTotal, 
            paymentStatus: true, 
            balanceDue: remainingBalance.roundTwo
          );
          var checkDetails = CheckDetails(
            customerName: customerName, 
            customerIdentity: customerIdentity,
            cardNumber: cardNumber, 
            cardType: cardType, 
            checkSequence: 1, 
            splitItems: splitItems, 
            subBillingDetails: SubBillingDetails(
              subTotal: event.amountReceive,
              discount: orderList.first.billingDetails!.discount!,
              tax: tax,
              tip: event.tipReceive,
              grandTotal: (event.amountReceive + event.tipReceive).roundTwo,
              paymentStatus: true,
              paymentMode: event.paymentMode, 
              balanceDue: remainingBalance.roundTwo,
              cardType: cardType,
              cardNumber: cardNumber
            ),
          );
          var paymentUpdateRequestModel = PaymentRequestModel(
            orderId: orderDetails['orderId'], 
            checkDetails: [checkDetails], 
            isPreAuth: false, 
            cardType: null, 
            customerId: customerId, 
            paymentMode: event.paymentMode, 
            paymentStatus: true, 
            cardNumber: null, 
            totalBillingDetails: totalBillingDetails,
          ).toJson;
          var response = await _paymentRepository.updatePaymentStatus(body: paymentUpdateRequestModel);
          if(response.isNotEmpty){
            emit(PaymentSuccessState(message: "Payment Successful"));
          } else {
            emit(PaymentFailedState(message: "Payment Failed"));
          }
        }
      } on CustomException catch (e) {
        emit(PaymentFailedState(message: e.message));
      }
    }
  }

  Future<bool> _paymentValidation(UpdatePaymentStatusEvent event, Emitter emit) async {
    if(event.amountReceive + event.tipReceive <= 0.0) {
      emit(PaymentFailedState(message: "Please provide amount"));
      return false;
    } else if(event.paymentMode.isBlank) {
      emit(PaymentFailedState(message: "Please select payment mode"));
      return false;
    } else if(event.paymentMode == 'CREDIT CARD' && selectedPaymentInstruction == null) {
      emit(PaymentFailedState(message: "Please add new card or select saved card"));
      return false;
    } else if(!await _checkConnectivity.hasConnection) {
      emit(PaymentFailedState(message: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  void _onAmountChange(OnAmountTextChange event, Emitter emit) {
    if(event.text.isBlank){
      emit(AmountTextErrorState(msg: 'Please provide tendered amount', amount: event.text));
    } else {
      emit(AmountTextErrorState(msg: '', amount: event.text));
    }
  }

  void _onTipAmountChange(OnTipTextChange event, Emitter emit) {
    if(event.text.isBlank){
      emit(TipTextErrorState(msg: 'Please provide tendered amount', amount: event.text));
    } else {
      emit(TipTextErrorState(msg: '', amount: event.text));
    }
  }

  ////Split Evenly
  Future<void> _onSplitEvenly(OnSplitEvenlyEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        PaymentOrderModel? paymentOrderModel;
        if(orderList.isNotEmpty){

          for(var item in  orderList){
            if(item.orderId == event.orderId){
              paymentOrderModel = item;
            }
          }

          if(paymentOrderModel != null) {
            int checkSequence = 1;
            var splitItems = <SplitItem>[];
            var subTotal = 0.0;
            var discount = 0.0;
            var tax = 0.0;
            var tip = 0.0;
            var grandTotal = 0.0;
            List<CheckDetails> checkDetails = [];
            ///create check sequence based on split division
            for (var i = 0; i < event.splitDivision; i++) {
              if(splitItems.isEmpty) {
                for(var item in paymentOrderModel.orderDetails) {
                  for(var subItem in item.productDetails!) {
                    splitItems.add(SplitItem(
                      productId: subItem.productId!, 
                      productName: subItem.productName!, 
                      quantity: subItem.quantity!,
                      productPrice: subItem.productPrice!
                    ));
                  }
                  subTotal+=item.billingDetails!.subTotal!;
                  discount+=item.billingDetails!.discount!;
                  tax+=item.billingDetails!.tax!;
                  tip+=item.billingDetails!.tip!;
                  grandTotal+=item.billingDetails!.grandTotal!;
                }
              }
              checkDetails.add(CheckDetails(
                customerName: customerName,
                checkSequence: checkSequence, 
                customerIdentity: customerIdentity,
                isEvenlySplit: true,
                splitItems: splitItems, 
                subBillingDetails: SubBillingDetails(
                  discount: discount,
                  subTotal: subTotal,
                  tip: tip,
                  tax: tax,
                  grandTotal: grandTotal,
                  paymentStatus: false,
                  balanceDue: (grandTotal/event.splitDivision).roundTwo
                )
              ));
              checkSequence+=1;
            }
            ///total billing details calculated
            var totalBillingDetails = payment_terminal.BillingDetails(
              subTotal: paymentOrderModel.billingDetails!.subTotal, 
              discount: paymentOrderModel.billingDetails!.discount, 
              tax: paymentOrderModel.billingDetails!.tax, 
              tip: paymentOrderModel.billingDetails!.tip, 
              grandTotal: paymentOrderModel.billingDetails!.grandTotal, 
              paymentStatus: false, 
              balanceDue: paymentOrderModel.billingDetails!.grandTotal
            );
            ///payment request model
            var paymentRequestModel = PaymentRequestModel(
              orderId: event.orderId,
              customerId: customerId, 
              paymentStatus: false, 
              totalBillingDetails: totalBillingDetails, 
              checkDetails: checkDetails,
              isPreAuth: event.isPreAuth
            ).toJson;
            emit(PaymentLoadingState());
            var response = await _paymentRepository.onSplitEvenly(payload: paymentRequestModel);
            if(response.isNotEmpty){
              add(PaymentStatusEvent());
            } else{
              emit(PaymentFailedState(message: "Unable to place order"));
            }
          }
        }
      } catch (e) {
        debugPrint("Something went wrong");
      }
    } else {
      emit(PaymentFailedState(message: AppStrings.noInternetConnection));
    }
  }


}