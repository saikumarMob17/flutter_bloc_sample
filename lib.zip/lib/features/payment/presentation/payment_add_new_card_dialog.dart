import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import 'bloc/payment_bloc.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/custom_solid_button.dart';

class PaymentAddNewCardDialog extends StatelessWidget {
  
  final PaymentBloc paymentBloc;
  final String customerName;
  final List<DropdownMenuModel> stateList;

  const PaymentAddNewCardDialog({
    required this.paymentBloc,
    required this.customerName,
    required this.stateList,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    final nameTextController = TextEditingController(text: customerName);
    final cardTextController = TextEditingController();
    final expiryController = TextEditingController();
    final cvvTextController = TextEditingController();
    final address1TextController = TextEditingController();
    final cityController = TextEditingController();
    final zipcodeController = TextEditingController();
    var apiError = '';
    bool apiSuccessStatus = false;
    String nameError = '';
    String cardNumberError = '';
    String expiryError = '';
    String cvvError = '';
    String postalCodeError = '';
    String selectedStateCode = 'AL';
    var maskFormatter = MaskTextInputFormatter(
      mask: '#### #### #### ####', 
      filter: { "#": RegExp(r'[0-9]') },
      type: MaskAutoCompletionType.lazy
    );
    return Container(
      width: context.screenWidth * 0.40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Helper.isDark
        ? AppColors.contentColorDark
        : AppColors.white
      ),
      child: BlocProvider<PaymentBloc>.value(
        value: paymentBloc,
        child: Container(
          width: context.screenWidth * 0.50,
          padding: const EdgeInsets.symmetric(
            vertical: AppSize.s16,
            horizontal: AppSize.s16
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppSize.s12),
            color: Helper.isDark 
            ? AppColors.transparent 
            : AppColors.transparent,
          ),
          child: BlocConsumer<PaymentBloc, PaymentState>(
            builder: (context, state) {
              return ListView(
                shrinkWrap: true,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: "Add New Card",
                        textStyle: getMediumStyle(fontSize: 18),
                      ),
                      Transform.translate(
                        offset: const Offset(10, 0),
                        child: IconButton(
                          onPressed: () => context.pop(), 
                          icon: const Icon(Icons.clear)
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s15),
                  CustomTextField(
                    textController: nameTextController,
                    label: "Name",
                    verPadding: AppSize.s10,
                    horPadding: AppSize.s10,
                    isMandatory: true,
                    errorText: nameError,
                    onChange: (value) => paymentBloc.add(CardOnNameChangeEvent(text: value)),
                  ),
                  const SizedBox(height: AppSize.s15),
                  CustomTextField(
                    textController: cardTextController,
                    label: "Card Number",
                    verPadding: AppSize.s10,
                    horPadding: AppSize.s10,
                    maxLength: 19,
                    textInputType: TextInputType.number,
                    inputFormatter: [maskFormatter],
                    isMandatory: true,
                    errorText: cardNumberError,
                    onChange: (value) => paymentBloc.add(CardNumberChangeEvent(text: value)),
                  ),
                  const SizedBox(height: AppSize.s15),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomTextField(
                          textController: expiryController,
                          label: "Expiry Date",
                          verPadding: AppSize.s10,
                          horPadding: AppSize.s10,
                          isMandatory: true,
                          readOnly: true,
                          onTap: () async { 
                            var date = await showMonthYearPicker(context);
                            if(date != null){
                              expiryController.text = '${date.month.toString().padLeft(2,"0")} / ${date.year}';
                              paymentBloc.add(CardExpiryChangeEvent(text: expiryController.text));
                            }
                          },
                          errorText: expiryError,
                        ),
                      ),
                      const SizedBox(width: AppSize.s15),
                      Expanded(
                        child: CustomTextField(
                          textController: cvvTextController,
                          label: "CVV",
                          verPadding: AppSize.s10,
                          horPadding: AppSize.s10,
                          isMandatory: true,
                          textInputType: TextInputType.number,
                          inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                          maxLength: 4,
                          errorText: cvvError,
                          onChange: (value) => paymentBloc.add(CardCvvChangeEvent(text: value)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s15),
                  CustomTextField(
                    textController: address1TextController,
                    label: "Billing Address Line 1",
                    verPadding: AppSize.s10,
                    horPadding: AppSize.s10,
                    errorText: ''
                  ),
                  const SizedBox(height: AppSize.s15),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomTextField(
                          textController: cityController,
                          label: "City",
                          verPadding: AppSize.s10,
                          horPadding: AppSize.s10,
                        ),
                      ),
                      const SizedBox(width: AppSize.s15),
                      Expanded(
                        child: CustomTextField(
                          textController: zipcodeController,
                          label: "Zipcode / Postal Code",
                          verPadding: AppSize.s10,
                          horPadding: AppSize.s10,
                          maxLength: 6,
                          textInputType: TextInputType.number,
                          inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                          isMandatory: true,
                          errorText: postalCodeError,
                          onChange: (value) => paymentBloc.add(CardZipCodeChangeEvent(text: value)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s15),
                  CustomDropdownWidget(
                    items: stateList, 
                    value: selectedStateCode,
                    label: 'State',
                    isExpanded: true,
                    labelStyle: getRegularStyle(
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                    onChange: (value) => paymentBloc.add(OnChangeStateDropDownEvent(stateCode: value!)),
                  ),
                  Visibility(
                    visible: apiError.isNotEmpty,
                    child: Container(
                      margin: const EdgeInsets.only(top: AppSize.s20),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8.0,
                        vertical: 8.0
                      ),
                      decoration: BoxDecoration(
                        color: apiSuccessStatus 
                        ? AppColors.green.withOpacity(0.1) 
                        : AppColors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(5)
                      ),
                      child: Row(
                        children: [
                          Icon(
                            apiSuccessStatus
                            ? Icons.check_circle
                            : Icons.warning_rounded, 
                            color: apiSuccessStatus 
                            ? AppColors.green 
                            : AppColors.red, 
                            size: AppSize.s22
                          ),
                          const SizedBox(width: AppSize.s8),
                          Expanded(
                            child: CustomText(
                              title: apiError,
                              color: apiSuccessStatus 
                              ? AppColors.green 
                              : AppColors.red,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSize.s20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CustomOutlinedButton(
                        onPressed: () => context.pop(),
                        borderColor: AppColors.red,
                        textColor: AppColors.red,
                        text: 'Cancel',
                      ),
                      const SizedBox(width: AppSize.s12),
                      CustomSolidButton(
                        onPressed: () => paymentBloc.add(CreatePaymentInstrumentEvent(
                          cardNumber: maskFormatter.getUnmaskedText(),
                          expiryMonthYear: expiryController.text, 
                          cvv: cvvTextController.text, 
                          cardHolderName: nameTextController.text,
                          addressLine1: address1TextController.text,
                          city: cityController.text,
                          postalCode: zipcodeController.text,
                          region: selectedStateCode
                        )),
                        text: 'Add Card'
                      ),
                    ],
                  ),
                ],
              );
            },
            listener: (context, state) {
              switch (state) {
                case PaymentFinixErrorState _:
                  apiError = state.message;
                  apiSuccessStatus = state.isSuccess;
                  if(!state.isSuccess) {
                    if(state.message.isNotEmpty) {
                      context.pop();
                    }
                    Future.delayed(const Duration(seconds: 4), () => paymentBloc.add(PaymentHideFinixErrorEvent()));
                  } else {
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      context.pop();
                      context.pop();
                      paymentBloc.add(FetchFinixPaymentInstrumentEvent());
                    });
                  }
                  break;
                case CardOnNameChangeState _:
                  nameError = state.message;
                  break;
                case CardNumberChangeState _:
                  cardNumberError = state.message;
                  break;
                case CardExpiryChangeState _:
                  expiryError = state.message;
                  break;
                case CardCvvChangeState _:
                  cvvError = state.message;
                  break;
                case CardZipCodeChangeState _:
                  postalCodeError = state.message;
                  break;
                case OnChangeStateDropDownState _:
                  selectedStateCode = state.stateCode;
                  break;
                default:
              }
            },
          ),
        ),
      )
    );
  }

  Future<DateTime?> showMonthYearPicker(BuildContext context) async {
    var dateTime = DateTime.now();
    return await showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s10)),
          content: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s12),
              color: Helper.isDark 
              ? AppColors.transparent 
              : AppColors.white,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: AppSize.s20,
                    left: AppSize.s20
                  ),
                  child: CustomText(
                    title: 'Card Expiry Date', 
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s16
                    )
                  ),
                ),
                SizedBox(
                  width: context.screenWidth * 0.30,
                  height: context.screenHeight * 0.40,
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.monthYear,
                    minimumDate: DateTime.now(),
                    onDateTimeChanged: (date) {
                      dateTime = date;
                    }
                  ),
                ),
                Transform.translate(
                  offset: const Offset(0,-8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => context.pop(null), 
                        style: ButtonStyle(
                          overlayColor: MaterialStateColor.resolveWith((states) => Colors.red.withOpacity(0.1)),
                          shape: MaterialStateProperty.all(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s8))
                          ),
                        ),
                        child: CustomText(
                          title: AppStrings.cancel.toUpperCase(),
                          textStyle: getMediumStyle(color: AppColors.red)
                        )
                      ),
                      const SizedBox(width: AppSize.s8),
                      TextButton(
                        onPressed: () => context.pop(dateTime), 
                        style: TextButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0))
                        ),
                        child: CustomText(
                          title: 'OK',
                          textStyle: getMediumStyle(color: AppColors.blue),
                        )
                      ),
                      const SizedBox(width: AppSize.s10)
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

}