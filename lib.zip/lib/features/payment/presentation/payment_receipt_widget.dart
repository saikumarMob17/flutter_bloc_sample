import '../../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../../constants/app_colors.dart';
import '../../../../constants/app_size.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../routes/route.dart';
import '../../orders/domain/billing_model.dart';
import '../../payment_terminal/domain/payment_order_model.dart';

class PaymentReceiptWidget extends StatelessWidget {

  final PaymentOrderModel checkDetails;
  final int checkSequence;

  const PaymentReceiptWidget({
    super.key, 
    required this.checkDetails, 
    required this.checkSequence
  });

  @override
  Widget build(BuildContext context) {
    var orderBillingLabel = <OrderBillingModel>[
      OrderBillingModel(title: AppStrings.subTotal, amount: 0.0),
      OrderBillingModel(title: AppStrings.tip, amount: 0.0),
      OrderBillingModel(title: AppStrings.tax, amount: 0.0),
      OrderBillingModel(title: AppStrings.total, amount: 0.0),
    ];
    calculateBillingAmount(orderBillingLabel, orderDetails: checkDetails);
    return Container(
      height: context.screenHeight * 0.74,
      width: context.screenWidth * 0.32,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Helper.isDark
        ? AppColors.contentColorDark
        : AppColors.white
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                vertical: AppSize.s20,
                horizontal: AppSize.s20
              ),
              children: [
                const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: 'Vendom',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '743 Washington Ave',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: 'Miami Beach, FL 33139',
                      fontSize: AppSize.s14,
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s18),
                CustomText(
                  title: 'Server : ${checkDetails.serverId}',
                  fontSize: AppSize.s14,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Check #$checkSequence',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: 'Table ${checkDetails.tableList.fold('', (p0, p1) => p0.isBlank ? p1.tableName! : '$p0 ${p1.tableName}')}',
                      fontSize: AppSize.s14,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Order Id: ${checkDetails.orderNumber}',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: checkDetails.orderDate == null 
                      ? ''
                      : checkDetails.orderDate!.toString().convertDateTimeClockOut,
                      fontSize: AppSize.s14,
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s18),
                Column(
                  children: List.generate(
                    checkDetails.productDetails.length, 
                    (index) {
                      var orderData = checkDetails.productDetails[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: AppSize.s2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: '${orderData.quantity}  ${orderData.productName}',
                              fontSize: AppSize.s14,
                            ),
                            CustomText(
                              title: '\$${(orderData.productPrice! * orderData.quantity!).roundTwo}',
                              fontSize: AppSize.s14,
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
                const SizedBox(height: AppSize.s18),
                Column(
                  children: List.generate(
                    orderBillingLabel.length, 
                    (index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: AppSize.s2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: orderBillingLabel[index].title,
                              fontSize: AppSize.s14,
                            ),
                            CustomText(
                              title: '\$${orderBillingLabel[index].amount}',
                              fontSize: AppSize.s14,
                            ),
                          ],
                        ),
                      ); 
                    }
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s18, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Column(
                  children: List.generate(
                    checkDetails.billingDetails == null || checkDetails.billingDetails!.paymentMode == null || checkDetails.billingDetails!.paymentMode!.isEmpty
                    ? 0
                    : checkDetails.billingDetails!.paymentMode!.length,
                    (index) {
                      var data = checkDetails.billingDetails!.paymentMode![index];
                      return Row(
                        children: [
                          Expanded(flex: 2, child: CustomText(title: data.paymentMode!)),
                          Expanded(child: CustomText(title: '\$${data.amountPaid! + data.tip!}', textAlign: TextAlign.end,)),
                        ],
                      );
                    }
                  ),
                ),
                Row(
                  children: [
                    Expanded(child: CustomText(title: 'Amount Due', textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: '\$${checkDetails.billingDetails!.balanceDue!}', textAlign: TextAlign.end, textStyle: getMediumStyle())),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s18),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                const SizedBox(height: AppSize.s30),
                const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(title: 'Thank you for your Visit!'),
                    CustomText(title: 'Follow us on Instagram : Vendom.Miami')
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s10,
              horizontal: AppSize.s14
            ),
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(10.0),
                bottomRight: Radius.circular(10.0),
              ),
              color: Helper.isDark
              ? AppColors.backgroundColorDark
              : AppColors.backgroundColor
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomOutlinedButton(
                  onPressed: () => context.pop(),
                  text: 'Cancel',
                  textColor: AppColors.red,
                  borderColor: AppColors.red,
                ),
                const SizedBox(width: AppSize.s10),
                CustomSolidButton(
                  onPressed: () => debugPrint('Click here to print receipt'),
                  text: ' Print ',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void calculateBillingAmount(List<OrderBillingModel> orderBillingLabel, {required PaymentOrderModel orderDetails}) {
    var grandTotal = ((orderDetails.billingDetails!.subTotal! + orderDetails.billingDetails!.tax! + orderDetails.billingDetails!.tip!) - orderDetails.billingDetails!.discount!).roundTwo;
    orderBillingLabel[0].amount = orderDetails.billingDetails!.subTotal!;
    orderBillingLabel[1].amount = orderDetails.billingDetails!.tip!;
    orderBillingLabel[2].amount = orderDetails.billingDetails!.tax!;
    orderBillingLabel[3].amount = grandTotal;
  }

}

class DashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    double dashWidth = 9, dashSpace = 5, startX = 0;
    final paint = Paint()
      ..color = Helper.isDark ? AppColors.white : AppColors.black
      ..strokeWidth = 1;
    while (startX < size.width) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}