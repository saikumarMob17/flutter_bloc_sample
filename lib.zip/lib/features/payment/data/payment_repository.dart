import 'dart:convert';
import 'dart:io';
import 'package:cliqtechnologies_retl/services/finix_payment_instrument_response.dart';
import 'package:cliqtechnologies_retl/services/finix_transfer_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import '../../../constants/app_strings.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../payment_terminal/domain/payment_terminal_response.dart';

class PaymentRepository {

  late ApiClient _apiClient;

  PaymentRepository(){
    _apiClient = ApiClient();
  }

  Future<Map> placeOrder({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.placeOrder, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.created:
          if(body['firstOrder']){
            for(var item in body['tables']){
              await updateTableStatus(id: item['tableId'].toString());
            }
          }
          return jsonResponse;
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<void> updateTableStatus({required String id}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: '${EndPoints.updateFloorPlanById}?id=$id', body: null);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          debugPrint(jsonResponse['data']);
          break;
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<Map> updatePaymentStatus({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updatePaymentStatus, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch (response.statusCode) {
        case HttpStatus.ok:
          return jsonResponse;
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<Map> updatePaymentByCheckSequence({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updatePaymentStatusByCheckSequence, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch (response.statusCode) {
        case HttpStatus.ok:
          return jsonResponse;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<Payments>> getAllPendingOrders() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.paymentTerminal);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data =  paymentTerminalResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Map> onSplitEvenly({required Map payload}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updatePaymentStatus, body: payload);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          return jsonResponse;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> finixTransfer({required FinixTransferModel transferModel}) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      var requestModel = transferModel.toJson;
      var response = await _apiClient.postRequest(endPoint: EndPoints.transfers, body: requestModel, customHeader: customHeader);
      switch (response.statusCode) {
        case HttpStatus.created:
          var decodedMessage = jsonDecode(response.body);
          if(decodedMessage['state'] == 'SUCCEEDED') {
            return decodedMessage['id'];
          } else {
            var failureCode = decodedMessage['failure_code'];
            var failureMessage = decodedMessage['failure_message'];
            throw CustomException(message: '$failureCode $failureMessage');
          }
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<PaymentInstrument>> getAllFinixPaymentInstrument() async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      var response = await _apiClient.getRequest(endPoint: EndPoints.paymentInstruments, customHeader: customHeader);
      switch (response.statusCode) {
        case HttpStatus.ok:
          var data = finixPaymentInstrumentResponseFromJson(response.body);
          return data.embedded == null ? [] : data.embedded!.paymentInstruments!;
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Response> createPaymentInstrument({required Map body}) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      return await _apiClient.postRequest(endPoint: EndPoints.paymentInstruments, body: body, customHeader: customHeader);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> finixCaptureAuthorization({required String authorizationId, required double amount}) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      var requestModel = {"capture_amount": amount};
      var response = await _apiClient.putRequest(endPoint: '${EndPoints.authorizations}/$authorizationId', body: requestModel, customHeader: customHeader);
      switch (response.statusCode) {
        case HttpStatus.ok:
          var decodedMessage = jsonDecode(response.body);
          if(decodedMessage['state'] == 'SUCCEEDED') {
            return decodedMessage['id'];
          } else {
            var failureCode = decodedMessage['failure_code'];
            var failureMessage = decodedMessage['failure_message'];
            throw CustomException(message: '$failureCode $failureMessage');
          }
        case HttpStatus.paymentRequired:
        case HttpStatus.unprocessableEntity:
          var errorMap = jsonDecode(response.body)['_embedded']['errors'][0];
          var failureCode = errorMap['failure_code'] ?? '';
          throw CustomException(message: '${errorMap['message']}$failureCode');
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  } 
  
}