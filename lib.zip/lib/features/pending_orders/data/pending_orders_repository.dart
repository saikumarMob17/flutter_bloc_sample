import 'dart:convert';
import 'dart:io';

import 'package:cliqtechnologies_retl/network/api/api_client.dart';
import 'package:cliqtechnologies_retl/network/custom_exception.dart';

import '../../../network/end_points.dart';
import '../../../utils/helper.dart';
import '../domain/pending_orders_response.dart';

class PendingOrdersRepository {

  late ApiClient _apiClient;

  PendingOrdersRepository(){
    _apiClient = ApiClient();
  }

  Future<List<PendingOrders>> getAllPendingOrders() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.getAllPendingOrders);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data =  pendingOrdersResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } catch (e) {
      throw CustomException(message: e.toString().substring(11));
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}