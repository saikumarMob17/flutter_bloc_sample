part of 'pending_orders_bloc.dart';

sealed class PendingOrdersState {}

class PendingOrdersInitialState extends PendingOrdersState {}

class PendingOrdersLoadingState extends PendingOrdersState {}

class PendingOrderFailedState extends PendingOrdersState {
  String message;

  PendingOrderFailedState({this.message = ''});
}

class PendingOrdersFetchDataState extends PendingOrdersState {
  List<PendingOrdersModel> pendingOrdersList;
  bool isMostRecent;

  PendingOrdersFetchDataState({required this.pendingOrdersList, this.isMostRecent = false});
}

class PendingOrdersTabIndexState extends PendingOrdersState {
  int tabIndex;

  PendingOrdersTabIndexState({this.tabIndex = 0});
}

class PendingOrdersShowSelectedOrderState extends PendingOrdersState {
  PendingOrdersModel pendingOrder;
  int index;

  PendingOrdersShowSelectedOrderState({required this.pendingOrder, this.index = -1});
}

class OnSwitchUserPendingState extends PendingOrdersState {
  bool isLogout;
  OnSwitchUserPendingState({this.isLogout = false});
}