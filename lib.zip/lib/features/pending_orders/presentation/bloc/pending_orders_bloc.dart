import '../../data/pending_orders_repository.dart';
import '../../../../network/custom_exception.dart';
import '../../../../routes/route.dart';
import '../../../../utils/check_connectivity.dart';
import '../../domain/pending_orders_model.dart';
part 'pending_orders_event.dart';
part 'pending_orders_state.dart';

class PendingOrdersBloc extends Bloc<PendingOrdersEvent, PendingOrdersState>{
  
  var pendingOrdersList = <PendingOrdersModel>[];
  var originalPendingOrdersList = <PendingOrdersModel>[];
  
  late CheckConnectivity _checkConnectivity;
  late PendingOrdersRepository _pendingOrdersRepository;

  PendingOrdersBloc() : super(PendingOrdersInitialState()){
    _checkConnectivity = CheckConnectivity();
    _pendingOrdersRepository = PendingOrdersRepository();
    on<PendingOrdersFetchEvent>(_onFetchPendingOrders);
    on<PendingOrdersTabIndexEvent>(_onChangeTab);
    on<PendingOrdersShowSelectedOrderEvent>(_onShowSelectedOrder);
    on<PendingOrdersSearchFilterEvent>(_onSearchPendingOrder);
    on<OnSwitchUserPendingEvent>(_onSwitchUser);
    on<PendingOrderMostRecentEvent>(_onFilterMostRecent);
  }

  void _onFilterMostRecent(PendingOrderMostRecentEvent event, Emitter emit) {
    if(originalPendingOrdersList.isNotEmpty) {
      if(event.isMostRecent){
        pendingOrdersList.sort((a,b) => b.orderDate.compareTo(a.orderDate));
      } else {
        pendingOrdersList.sort((a,b) => a.orderDate.compareTo(b.orderDate));
      }
      emit(PendingOrdersFetchDataState(pendingOrdersList: pendingOrdersList, isMostRecent: event.isMostRecent));
    }
  }


  Future<void> _onFetchPendingOrders(PendingOrdersFetchEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(PendingOrdersLoadingState());
        var data = await _pendingOrdersRepository.getAllPendingOrders();
        if(data.isNotEmpty) {
          pendingOrdersList.clear();
          originalPendingOrdersList.clear();
          for(var item in data) {
            var customerName = item.customerName.toString();
            var orderNumber = item.orderNumber.toString();
            var orderId = item.orderId.toString();
            ///order product
            for(var subItem in item.orderedProductDetailsByOrderSequence!){
              var orderSeq = subItem.orderSequence!;
              var orderFinish = subItem.isFinished!;
              var productList = subItem.productDetails!;
              originalPendingOrdersList.add(PendingOrdersModel(
                customerName: customerName, 
                orderNumber: orderNumber, 
                orderId: orderId,
                orderDate: item.orderDate!,
                orderSequence: orderSeq, 
                serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId!,
                serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName!,
                isOrderFinished: orderFinish, 
                productList: productList,
                tableList: item.tableDetails ?? [],
              ));
            }
          }
          originalPendingOrdersList.sort((a,b) => a.orderDate.compareTo(b.orderDate));
          pendingOrdersList.addAll(originalPendingOrdersList);
        }
        emit(PendingOrdersFetchDataState(pendingOrdersList: pendingOrdersList));
      } on CustomException catch (e) {
        emit(PendingOrderFailedState(message: e.message));
      }
    }
  }


  void _onChangeTab(PendingOrdersTabIndexEvent event, Emitter emit){
    emit(PendingOrdersTabIndexState(tabIndex: event.tabIndex));
  }

  void _onShowSelectedOrder(PendingOrdersShowSelectedOrderEvent event, Emitter emit){
    emit(PendingOrdersShowSelectedOrderState(pendingOrder: event.pendingOrder, index: event.index));
  }

  ///Search pending orders
  void _onSearchPendingOrder(PendingOrdersSearchFilterEvent event, Emitter emit) {
    pendingOrdersList.clear();
    if(event.text.isNotEmpty){
      var searchText = event.text.toLowerCase();
      for(var item in originalPendingOrdersList){
        if(item.orderNumber.toLowerCase().contains(searchText) || item.customerName.toLowerCase().contains(searchText) || item.serverName.toLowerCase().contains(searchText)){
          pendingOrdersList.add(item);
        }
      }
    } else {
      pendingOrdersList.addAll(originalPendingOrdersList);
    }
    emit(PendingOrdersFetchDataState(pendingOrdersList: pendingOrdersList));
  }

  Future<void> _onSwitchUser(OnSwitchUserPendingEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(PendingOrdersLoadingState());
        var response = await _pendingOrdersRepository.onClockOutUser();
        emit(OnSwitchUserPendingState(isLogout: response));
      } on CustomException catch (e) {
        emit(PendingOrderFailedState(message: e.message));
      }
    }
  }

}