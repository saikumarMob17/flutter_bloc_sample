part of 'pending_orders_bloc.dart';

sealed class PendingOrdersEvent {}

class PendingOrdersFetchEvent extends PendingOrdersEvent {}

class PendingOrdersTabIndexEvent extends PendingOrdersEvent {
  int tabIndex;

  PendingOrdersTabIndexEvent({this.tabIndex = 0});
}

class PendingOrdersShowSelectedOrderEvent extends PendingOrdersEvent {
  PendingOrdersModel pendingOrder;
  int index;

  PendingOrdersShowSelectedOrderEvent({required this.pendingOrder, this.index = -1});
}

class PendingOrdersSearchFilterEvent extends PendingOrdersEvent {
  String text;

  PendingOrdersSearchFilterEvent({
    required this.text,
  });
}

class OnSwitchUserPendingEvent extends PendingOrdersEvent {}

class PendingOrderMostRecentEvent extends PendingOrdersEvent {
  bool isMostRecent;
  PendingOrderMostRecentEvent({this.isMostRecent = false});
}