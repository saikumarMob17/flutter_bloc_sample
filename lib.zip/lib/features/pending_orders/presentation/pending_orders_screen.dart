import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_strings.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_empty_widget.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../domain/pending_orders_response.dart';
import 'bloc/pending_orders_bloc.dart';
import '../domain/pending_orders_model.dart';

class PendingOrdersScreen extends StatefulWidget {

  const PendingOrdersScreen({super.key});

  @override
  State createState() => _PendingOrdersScreenState();
}

class _PendingOrdersScreenState extends State<PendingOrdersScreen> with Helper {

  var tabTitleList = [
    AppStrings.active,
    AppStrings.completed
  ];

  PendingOrdersModel? selectedPendingOrder;
  var pendingOrdersList = <PendingOrdersModel>[];
  int tabSelectedIndex = 0;
  int selectedOrderIndex = -1;
  var billingDetails = PendingOrderBillingDetails();
  bool isLoading = true;
  int activeCount = 0;
  int completeCount = 0;
  late PendingOrdersBloc _pendingOrdersBloc;
  bool isMostRecent = false;

  @override
  void initState() {
    _pendingOrdersBloc = context.read<PendingOrdersBloc>();
    super.initState();
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<PendingOrdersBloc, PendingOrdersState>(
        builder: (context, state) {
          switch (state) {
            case PendingOrdersFetchDataState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              isMostRecent = state.isMostRecent;
              pendingOrdersList.clear();
              pendingOrdersList.addAll(state.pendingOrdersList);
              activeCount = 0.pendingOrderIndex(pendingOrdersList).length;
              completeCount = pendingOrdersList.length - activeCount;
              break;
            case PendingOrdersTabIndexState _:
              selectedPendingOrder = null;
              selectedOrderIndex = -1;
              tabSelectedIndex = state.tabIndex;
              break;
            case PendingOrdersShowSelectedOrderState _:
              billingDetails = getBillingDetails(state.pendingOrder.productList);
              selectedPendingOrder = state.pendingOrder;
              selectedOrderIndex = state.index;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case PendingOrdersLoadingState _:
              showLoadingDialog(context: context);
              break;
            case PendingOrdersShowSelectedOrderState _:
              getBillingDetails(state.pendingOrder.productList);
              selectedPendingOrder = state.pendingOrder;
              if(MediaQuery.of(context).size.width <= 600 && selectedPendingOrder != null){
                orderDetails(context: context, orderDetails: selectedPendingOrder!);
              }
              break;
            case PendingOrderFailedState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.message);
              break;
            case OnSwitchUserPendingState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => context.pop(),
                        icon: const Icon(Icons.west)
                      ),
                      const SizedBox(width: AppSize.s4),
                      CustomText(
                        title: AppStrings.pendingOrders,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s18
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      CustomImageView(
                        imagePath: AppImages.shoppingCart,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => context.pushReplacement(AppRoutes.tableViewScreen),
                      ),
                      const SizedBox(width: AppSize.s10),
                      CustomImageView(
                        imagePath: AppImages.switchIcon,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => _pendingOrdersBloc.add(OnSwitchUserPendingEvent()),
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: AppSize.s10),
                      child: CustomTextField(
                        hint: AppStrings.searchHere,
                        prefixImagePath: AppImages.searchIcon,
                        prefixImageColor: AppColors.lightGrey,
                        horPadding: AppSize.s12,
                        verPadding: AppSize.s12,
                        onChange: (value) => _pendingOrdersBloc.add(PendingOrdersSearchFilterEvent(text: value)),
                      ),
                    ),
                    Container(
                      height: AppSize.s45,
                      width: context.screenWidth,
                      decoration: BoxDecoration(
                        color: Helper.isDark
                        ? AppColors.contentColorDark
                        : AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10),
                        boxShadow: [BoxShadow(
                          color: AppColors.grey.withOpacity(0.2), 
                          blurRadius: AppSize.s1, 
                          offset: const Offset(0, 2)
                          )
                        ]
                      ),
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s20),
                        children: List.generate(
                          tabTitleList.length, 
                          (index) => GestureDetector(
                            onTap: () => _pendingOrdersBloc.add(PendingOrdersTabIndexEvent(tabIndex: index)),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                              margin: const EdgeInsets.only(right: AppSize.s20),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    width: 3.0, 
                                    color: tabSelectedIndex == index 
                                    ? AppColors.blue 
                                    : AppColors.transparent
                                  ),
                                ),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: CustomText(
                                  title: " ${tabTitleList[index]} (${index == 0 ? activeCount : completeCount}) ",
                                  textStyle: getMediumStyle(
                                    color: tabSelectedIndex == index 
                                    ? AppColors.blue 
                                    : Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    tabSelectedIndex.pendingOrderIndex(pendingOrdersList).isEmpty
                    ? Expanded(
                        child: CustomEmptyWidget(
                          imagePath: AppImages.notFound, 
                          emptyTitle: AppStrings.noOrderFound, 
                          isVisible: !isLoading
                        ),
                      )
                    : Expanded(
                      child: Scrollbar(
                        child: SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          physics: const NeverScrollableScrollPhysics(),
                          child: Scrollbar(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: SizedBox(
                                height: double.maxFinite, 
                                width: context.screenWidth * 2, 
                                child: Column(
                                  children: [
                                    Container(
                                      color: AppColors.transparent,
                                      padding: const EdgeInsets.symmetric(
                                        vertical: AppSize.s15,
                                        horizontal: AppSize.s8
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: CustomText(
                                              title: AppStrings.orderNumber, 
                                              textStyle: getMediumStyle()
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: AppStrings.table, 
                                              textStyle: getMediumStyle()
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: AppStrings.customerName, 
                                              textStyle: getMediumStyle()
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: AppStrings.cost, 
                                              textStyle: getMediumStyle()
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: AppStrings.quantity, 
                                              textAlign: TextAlign.center,
                                              textStyle: getMediumStyle()
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: tabSelectedIndex.pendingOrderIndex(pendingOrdersList).length,
                                        padding: EdgeInsets.zero,
                                        itemBuilder: (_, index){
                                          var subOrder = tabSelectedIndex.pendingOrderIndex(pendingOrdersList);
                                          var data = subOrder[index];
                                          return InkWell(
                                            onTap: () => _pendingOrdersBloc.add(PendingOrdersShowSelectedOrderEvent(pendingOrder: data, index: index)),
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(
                                                vertical: AppSize.s10,
                                                horizontal: AppSize.s8
                                              ),
                                              decoration: BoxDecoration(
                                                color: Helper.isDark 
                                                ? index%2 == 1 ? AppColors.transparent : AppColors.contentColorDark
                                                : index%2 == 1 ? AppColors.transparent : AppColors.white,
                                                border: Border.all(
                                                  width: AppSize.s1, 
                                                  color: selectedOrderIndex == index 
                                                  ? AppColors.blue 
                                                  : AppColors.transparent
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Expanded(
                                                    child: CustomText(
                                                      title: data.orderNumber, 
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12
                                                      )
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: CustomText(
                                                      title: data.tableList.fold("", (p0, p1) => p0.isEmpty ? p1.tableName! : '$p0-${p1.tableName!}'), 
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: CustomText(
                                                      title: data.customerName, 
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: CustomText(
                                                      title: '\$${getBillingDetails(data.productList).totalCost}', 
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: CustomText(
                                                      title: data.productList.length.toString(), 
                                                      textAlign: TextAlign.center,
                                                      textStyle: getMediumStyle(
                                                        fontSize: AppSize.s12
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        }
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(selectedLeftNavigationItem: 0),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.pendingOrders,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s20
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => context.pushReplacement(AppRoutes.tableViewScreen),
                              text: AppStrings.newOrder,
                              textColor: AppColors.blue,
                              preFixWidget: const Icon(
                                AppIcons.addIcon, 
                                size: AppSize.s18, 
                                color: AppColors.blue
                              ),
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomSolidButton(
                              onPressed: () => _pendingOrdersBloc.add(OnSwitchUserPendingEvent()),
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                              text: AppStrings.switchUser
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s20),
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 38,
                            width: context.screenWidth,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                              children: List.generate(
                                tabTitleList.length, 
                                (index) => GestureDetector(
                                  onTap: () => _pendingOrdersBloc.add(PendingOrdersTabIndexEvent(tabIndex: index)),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s1),
                                    margin: const EdgeInsets.only(right: AppSize.s30),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: AppSize.s2, 
                                          color: tabSelectedIndex == index 
                                          ? AppColors.blue 
                                          : AppColors.transparent
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: CustomText(
                                        title: " ${tabTitleList[index]} (${index == 0 ? activeCount : completeCount}) ",
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s16,
                                          color: tabSelectedIndex == index 
                                          ? AppColors.blue 
                                          : Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        CustomOutlinedButton(
                          onPressed: () => _pendingOrdersBloc.add(PendingOrderMostRecentEvent(isMostRecent: !isMostRecent)),
                          text: AppStrings.mostRecent,
                          backgroundColor: isMostRecent 
                          ? AppColors.primaryColor 
                          : null,
                          suffixWidget: Icon(
                            AppIcons.swapVerIcon, 
                            color: isMostRecent 
                            ? AppColors.white 
                            : AppColors.blue
                          ),
                          widgetSpacing: AppSize.s4,
                          textColor: isMostRecent 
                          ? AppColors.white 
                          : AppColors.blue,
                        ),
                        const SizedBox(width: AppSize.s10),
                        SizedBox(
                          width: context.screenWidth * 0.22,
                          child: CustomTextField(
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.grey,
                            horPadding: AppSize.s15,
                            verPadding: 9,
                            hint: AppStrings.searchHere,
                            prefixImageSize: AppSize.s16,
                            onChange: (text) => _pendingOrdersBloc.add(PendingOrdersSearchFilterEvent(text: text),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ////Pending Order View
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: AppSize.s15,
                    right: AppSize.s15,
                    bottom: AppSize.s15
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              height: AppSize.s15, 
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor
                            ),
                            Visibility(
                              visible: tabSelectedIndex.pendingOrderIndex(pendingOrdersList).isNotEmpty,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Helper.isDark 
                                  ? AppColors.headerColorDark 
                                  : AppColors.white,
                                  border: Border(bottom: BorderSide(color: AppColors.grey.withOpacity(0.5)))
                                ),
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s15,
                                  horizontal: AppSize.s14
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.orderNumber, 
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.table, 
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.customerName, 
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.cost, 
                                        textAlign: TextAlign.center,
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.server, 
                                        textAlign: TextAlign.center,
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: AppStrings.quantity, 
                                        textAlign: TextAlign.center,
                                        textStyle: getMediumStyle(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: tabSelectedIndex.pendingOrderIndex(pendingOrdersList).isEmpty 
                              ? CustomEmptyWidget(
                                  emptyTitle: AppStrings.noOrderFound,
                                  imagePath: AppImages.notFound,
                                  isVisible: !isLoading,
                                )
                              : ListView.builder(
                                shrinkWrap: true,
                                itemCount: tabSelectedIndex.pendingOrderIndex(pendingOrdersList).length,
                                padding: EdgeInsets.zero,
                                itemBuilder: (_, index){
                                  var subOrder = tabSelectedIndex.pendingOrderIndex(pendingOrdersList);
                                  var data = subOrder[index];
                                  return InkWell(
                                    onTap: () => _pendingOrdersBloc.add(PendingOrdersShowSelectedOrderEvent(pendingOrder: data, index: index)),
                                    child: Ink(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: AppSize.s12,
                                        horizontal: AppSize.s14
                                      ),
                                      decoration: BoxDecoration(
                                        color: selectedOrderIndex == index
                                        ? Helper.isDark
                                        ? AppColors.grey.withOpacity(0.5)
                                        : AppColors.lightGrey
                                        : Helper.isDark 
                                          ? AppColors.transparent 
                                          : AppColors.white,
                                        border: Border.all(
                                          color: selectedOrderIndex == index
                                          ? AppColors.blue
                                          : Helper.isDark
                                          ? AppColors.lightTextColor
                                          : AppColors.lightGrey,
                                          width: 0.5
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: CustomText(
                                              title: "${data.orderNumber}  #${data.orderSequence}",
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: data.tableList.fold("", (prev, item) => prev.isEmpty ? item.tableName! : '$prev, ${item.tableName!}'), 
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: data.customerName
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: '\$${getBillingDetails(data.productList).totalCost}', 
                                              textAlign: TextAlign.center
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: data.serverName,
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          Expanded(
                                            child: CustomText(
                                              title: data.productList.length.toString(), 
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: AppSize.s15),
                      ///Right Layout View
                      Container(
                        width: context.screenWidth * 0.25, 
                        margin: const EdgeInsets.only(top: AppSize.s15),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(AppSize.s10),
                          color: Helper.isDark 
                          ? AppColors.headerColorDark 
                          : AppColors.white,
                        ),
                        child:  selectedPendingOrder == null 
                        ? const CustomEmptyWidget(
                            emptyTitle: AppStrings.noSelectedOrders,
                            imagePath: AppImages.foodRestaurantOrder,
                            imageColor: AppColors.primaryColor,
                          )
                        : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: AppSize.s12,
                                horizontal: AppSize.s12,
                              ),
                              decoration: BoxDecoration(
                                color: Helper.isDark 
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(AppSize.s10),
                                  topRight: Radius.circular(AppSize.s10)
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: selectedPendingOrder == null
                                        ? ""
                                        : selectedPendingOrder!.customerName, 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s18,
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: AppSize.s8, 
                                          vertical: AppSize.s4
                                        ),
                                        decoration: BoxDecoration(
                                          color: selectedPendingOrder == null
                                          ? AppColors.transparent
                                          : selectedPendingOrder!.isOrderFinished
                                            ? AppColors.green
                                            : AppColors.orange,
                                          borderRadius: BorderRadius.circular(AppSize.s5)
                                        ),
                                        child: CustomText(
                                          title: selectedPendingOrder == null
                                          ? ""
                                          : selectedPendingOrder!.isOrderFinished
                                            ? AppStrings.completed
                                            : AppStrings.active,
                                          color: selectedPendingOrder == null
                                          ? AppColors.black
                                          : AppColors.white
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s12),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          CustomText(
                                            title: selectedPendingOrder == null
                                            ? ""
                                            : selectedPendingOrder!.orderNumber,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14
                                            ),
                                          ),
                                          CustomText(
                                            title: selectedPendingOrder == null
                                            ? ""
                                            : "   |   #${selectedPendingOrder!.orderSequence}",
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14
                                            ),
                                          ),
                                        ],
                                      ),
                                      CustomText(
                                        title: selectedPendingOrder == null
                                        ? ""
                                        : selectedPendingOrder!.orderDate.convertDateTimeClockOut.substring(0, 12).trim(),
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s12
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Expanded(
                              child: ListView.builder(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: selectedPendingOrder == null 
                                ? 0
                                : selectedPendingOrder!.productList.length,
                                itemBuilder: (_, index){
                                  var data = selectedPendingOrder!.productList[index];
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: AppSize.s14, vertical: AppSize.s12),
                                    decoration: BoxDecoration(
                                      color: data.isProductPrepared == null
                                      ? null
                                      : data.isProductPrepared!
                                        ? AppColors.green.withOpacity(0.3)
                                        : AppColors.red.withOpacity(0.3),
                                      border: const Border(
                                        bottom: BorderSide(
                                          width: AppSize.s05, 
                                          color: AppColors.grey
                                        ),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.all(AppSize.s6),
                                          decoration: const BoxDecoration(
                                            color: AppColors.primaryColor,
                                            shape: BoxShape.circle
                                          ),
                                          child: const CustomImageView(
                                            imagePath: AppImages.orangeJuice,
                                            color: AppColors.white,
                                            height: AppSize.s20,
                                            width: AppSize.s20,
                                          ),
                                        ),
                                        const SizedBox(width: AppSize.s8),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                title: data.productName!,
                                                textStyle: getMediumStyle(
                                                  fontSize: AppSize.s14
                                                ),
                                              ),
                                              const SizedBox(height: AppSize.s2),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  CustomText(
                                                    title: '\$${data.productPrice!.toDouble()}',
                                                    textStyle: getRegularStyle(
                                                      fontSize: AppSize.s14,
                                                      color: Helper.isDark
                                                      ? AppColors.white.withOpacity(0.5)
                                                      : AppColors.black.withOpacity(0.5)
                                                    ),
                                                  ),
                                                  CustomText(
                                                    title: 'x ${data.quantity!}',
                                                    textStyle: getRegularStyle(
                                                      fontSize: AppSize.s14,
                                                      color: Helper.isDark
                                                      ? AppColors.white.withOpacity(0.5)
                                                      : AppColors.black.withOpacity(0.5)
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: AppSize.s14,
                                horizontal: AppSize.s14
                              ),
                              decoration: BoxDecoration(
                                color: Helper.isDark 
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: const BorderRadius.only(
                                  bottomLeft: Radius.circular(AppSize.s10),
                                  bottomRight: Radius.circular(AppSize.s10)
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: 'Subtotal',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                      CustomText(
                                        title: selectedPendingOrder == null 
                                        ? ''
                                        : '\$${billingDetails.subTotal}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s5),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.tax,
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14
                                        ),
                                      ),
                                      CustomText(
                                        title: selectedPendingOrder == null 
                                        ? ''
                                        : '\$${billingDetails.tax}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Divider(color: AppColors.grey, thickness: 1.0, height: AppSize.s18),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: AppStrings.total,
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s15
                                        ),
                                      ),
                                      CustomText(
                                        title: selectedPendingOrder == null 
                                        ? ''
                                        : '\$${billingDetails.totalCost}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s15
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void orderDetails({required BuildContext context, required PendingOrdersModel orderDetails}) {
    showModalBottomSheet(
      context: context, 
      isScrollControlled: true,
      builder: (_) {
        return Container(
          height: context.screenHeight * 0.90,
          padding: const EdgeInsets.all(AppSize.s12),
          decoration: BoxDecoration(
            color: Helper.isDark 
            ? AppColors.contentColorDark
            : AppColors.white,
            borderRadius: BorderRadius.circular(AppSize.s18)
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: context.screenWidth * 0.16,
                    height: 5,
                    decoration: BoxDecoration(
                      color: AppColors.grey,
                      borderRadius: BorderRadius.circular(AppSize.s15)
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s12),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: AppSize.s10,
                  horizontal: AppSize.s14,
                ),
                decoration: BoxDecoration(
                  color: Helper.isDark 
                  ? AppColors.backgroundColorDark
                  : AppColors.backgroundColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(AppSize.s10),
                    topRight: Radius.circular(AppSize.s10)
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: orderDetails.customerName, 
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s22
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s8, 
                            vertical: AppSize.s4
                          ),
                          decoration: BoxDecoration(
                            color: selectedPendingOrder == null
                            ? AppColors.transparent
                            : selectedPendingOrder!.isOrderFinished
                              ? AppColors.green
                              : AppColors.orange,
                            borderRadius: BorderRadius.circular(AppSize.s5)
                          ),
                          child: CustomText(
                            title: selectedPendingOrder == null
                            ? ""
                            : selectedPendingOrder!.isOrderFinished
                              ? AppStrings.completed
                              : AppStrings.active,
                            color: selectedPendingOrder == null
                            ? AppColors.black
                            : AppColors.white
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: orderDetails.orderNumber,
                          textStyle: getMediumStyle(),
                        ),
                        CustomText(
                          title: '#${orderDetails.orderSequence}',
                          textStyle: getMediumStyle(),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSize.s6),
              Expanded(
                child: Container(
                  color: Helper.isDark
                  ? AppColors.backgroundColorDark
                  : AppColors.backgroundColor,
                  child: ListView.builder(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    itemCount: orderDetails.productList.length,
                    itemBuilder: (_, index){
                      var data = orderDetails.productList[index];
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s12, vertical: AppSize.s12),
                        decoration: const BoxDecoration(
                          border: Border(
                            bottom: BorderSide(color: AppColors.grey, width: AppSize.s1)
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(AppSize.s8),
                              decoration: const BoxDecoration(
                                color: AppColors.primaryColor,
                                shape: BoxShape.circle
                              ),
                              child: const CustomImageView(
                                imagePath: AppImages.orangeJuice,
                                color: AppColors.white,
                              ),
                            ),
                            const SizedBox(width: AppSize.s12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    title: data.productName!,
                                    textStyle: getMediumStyle(
                                      fontSize: AppSize.s16,
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black,
                                    ),
                                  ),
                                  const SizedBox(height: AppSize.s6),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: '\$ ${data.productPrice!.toDouble()}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s16,
                                          color: AppColors.grey.withOpacity(0.9)
                                        ),
                                      ),
                                      CustomText(
                                        title: 'x ${data.quantity!}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          color: AppColors.grey.withOpacity(0.9)
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s6),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: AppSize.s14,
                  horizontal: AppSize.s16,
                ),
                decoration: BoxDecoration(
                  color: Helper.isDark 
                  ? AppColors.backgroundColorDark
                  : AppColors.backgroundColor,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(AppSize.s10),
                    bottomRight: Radius.circular(AppSize.s10)
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: 'Subtotal',
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                        CustomText(
                          title: selectedPendingOrder == null 
                          ? ''
                          : '\$${billingDetails.subTotal}',
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s5),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: AppStrings.tax,
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                        CustomText(
                          title: selectedPendingOrder == null 
                          ? ''
                          : '\$${billingDetails.tax}',
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s14
                          ),
                        ),
                      ],
                    ),
                    const Divider(color: AppColors.grey, thickness: AppSize.s1, height: AppSize.s18),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: AppStrings.total,
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s15
                          ),
                        ),
                        CustomText(
                          title: selectedPendingOrder == null 
                          ? ''
                          : '\$${billingDetails.totalCost}',
                          textStyle: getRegularStyle(
                            fontSize: AppSize.s15
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    );
  } 

  PendingOrderBillingDetails getBillingDetails(List<CanceledProduct> orderDetails){
    if(orderDetails.isNotEmpty) {
      var subTotal = 0.0;
      for(var item in orderDetails) {
        subTotal+=(item.quantity!.toDouble() * item.productPrice!.toDouble());
      }
      subTotal = subTotal.roundTwo;
      double tax = (subTotal * 10) / 100;
      double grandTotal = (subTotal + tax).roundTwo;
      billingDetails.subTotal = subTotal;
      billingDetails.tax = tax;
      billingDetails.totalCost = grandTotal;
    }
    return billingDetails;
  }
  
}