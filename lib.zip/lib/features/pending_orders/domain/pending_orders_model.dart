import 'pending_orders_response.dart';

class PendingOrdersModel {
  String customerName;
  String orderNumber;
  String orderDate;
  String orderId;
  int orderSequence;
  bool isOrderFinished;
  String serverId;
  String serverName;
  List<CanceledProduct> productList;
  List<TableDetail> tableList;


  PendingOrdersModel({
    required this.customerName,
    required this.orderNumber,
    this.orderDate = '',
    required this.orderId,
    required this.orderSequence,
    this.serverId = '',
    this.serverName = '',
    required this.isOrderFinished,
    required this.productList,
    required this.tableList,
  });
}

class PendingOrderBillingDetails {
  double subTotal;
  double tax;
  double totalCost;

  PendingOrderBillingDetails({
    this.subTotal = 0.0,
    this.tax = 0.0,
    this.totalCost = 0.0
  });
}