// To parse this JSON data, do
//
//     final pendingOrdersResponse = pendingOrdersResponseFromJson(jsonString);

import 'dart:convert';

PendingOrdersResponse pendingOrdersResponseFromJson(String str) => PendingOrdersResponse.fromJson(json.decode(str));

class PendingOrdersResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<PendingOrders>? data;

  PendingOrdersResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory PendingOrdersResponse.fromJson(Map<String, dynamic> json) => PendingOrdersResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<PendingOrders>.from(json["data"]!.map((x) => PendingOrders.fromJson(x))),
  );
}

class PendingOrders {
  final String? customerName;
  final String? customerIdentity;
  final double? totalCost;
  final bool? paymentStatus;
  final int? quantity;
  final List<OrderedProductDetailsByOrderSequence>? orderedProductDetailsByOrderSequence;
  final String? orderNumber;
  final String? orderDate;
  final String? orderId;
  final List<TableDetail>? tableDetails;
  final EmployeeDetails? employeeDetails;

  PendingOrders({
    this.customerName,
    this.customerIdentity,
    this.totalCost,
    this.paymentStatus,
    this.quantity,
    this.orderedProductDetailsByOrderSequence,
    this.orderNumber,
    this.orderDate,
    this.orderId,
    this.tableDetails,
    this.employeeDetails,
  });

  factory PendingOrders.fromJson(Map<String, dynamic> json) => PendingOrders(
    customerName: json["customerName"],
    customerIdentity: json["customerIdentity"],
    totalCost: json["totalCost"]?.toDouble(),
    paymentStatus: json["paymentStatus"],
    quantity: json["quantity"],
    orderedProductDetailsByOrderSequence: json["orderedProductDetailsByOrderSequence"] == null ? [] : List<OrderedProductDetailsByOrderSequence>.from(json["orderedProductDetailsByOrderSequence"]!.map((x) => OrderedProductDetailsByOrderSequence.fromJson(x))),
    orderNumber: json["orderNumber"],
    orderDate: json["orderDate"],
    orderId: json["orderId"],
    tableDetails: json["tableDetails"] == null ? [] : List<TableDetail>.from(json["tableDetails"]!.map((x) => TableDetail.fromJson(x))),
    employeeDetails: json["employeeDetails"] == null ? null : EmployeeDetails.fromJson(json["employeeDetails"]),
  );
}

class EmployeeDetails {
  final String? employeeId;
  final String? employeeName;
  final String? location;
  final String? role;
  final dynamic lastClockedIn;

  EmployeeDetails({
    this.employeeId,
    this.employeeName,
    this.location,
    this.role,
    this.lastClockedIn,
  });

  factory EmployeeDetails.fromJson(Map<String, dynamic> json) => EmployeeDetails(
    employeeId: json["employeeId"],
    employeeName: json["employeeName"],
    location: json["location"],
    role: json["role"],
    lastClockedIn: json["lastClockedIn"],
  );
}

class OrderedProductDetailsByOrderSequence {
  final int? orderSequence;
  final bool? isFinished;
  final List<CanceledProduct>? productDetails;
  final List<CanceledProduct>? canceledProducts;
  final List<CanceledProduct>? newlyaddedProducts;
  final dynamic billingDetails;

  OrderedProductDetailsByOrderSequence({
    this.orderSequence,
    this.isFinished,
    this.productDetails,
    this.canceledProducts,
    this.newlyaddedProducts,
    this.billingDetails,
  });

  factory OrderedProductDetailsByOrderSequence.fromJson(Map<String, dynamic> json) => OrderedProductDetailsByOrderSequence(
    orderSequence: json["orderSequence"],
    isFinished: json["isFinished"],
    productDetails: json["productDetails"] == null ? [] : List<CanceledProduct>.from(json["productDetails"]!.map((x) => CanceledProduct.fromJson(x))),
    canceledProducts: json["canceledProducts"] == null ? [] : List<CanceledProduct>.from(json["canceledProducts"]!.map((x) => CanceledProduct.fromJson(x))),
    newlyaddedProducts: json["newlyaddedProducts"] == null ? [] : List<CanceledProduct>.from(json["newlyaddedProducts"]!.map((x) => CanceledProduct.fromJson(x))),
    billingDetails: json["billingDetails"],
  );
}

class CanceledProduct {
  final String? orderedProductId;
  final int? productId;
  final String? productName;
  final int? quantity;
  final double? productPrice;
  final bool? isProductPrepared;

  CanceledProduct({
    this.orderedProductId,
    this.productId,
    this.productName,
    this.quantity,
    this.productPrice,
    this.isProductPrepared,
  });

  factory CanceledProduct.fromJson(Map<String, dynamic> json) => CanceledProduct(
    orderedProductId: json["orderedProductId"],
    productId: json["productId"],
    productName: json["productName"],
    quantity: json["quantity"],
    productPrice: json["productPrice"]?.toDouble(),
    isProductPrepared: json["isProductPrepared"],
  );
}

class TableDetail {
  final String? tableName;
  final int? tableId;

  TableDetail({
    this.tableName,
    this.tableId,
  });

  factory TableDetail.fromJson(Map<String, dynamic> json) => TableDetail(
    tableName: json["tableName"],
    tableId: json["tableId"],
  );
}
