import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_icon_button.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import 'bloc/service_status_state.dart';
import 'bloc/service_status_bloc.dart';
import '../../../widgets/left_navigation_screen.dart';

class ServiceStatusScreen extends StatefulWidget {
  const ServiceStatusScreen({super.key});

  @override
  State<ServiceStatusScreen> createState() => _ServiceStatusScreenState();
}

class _ServiceStatusScreenState extends State<ServiceStatusScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<ServiceStatusBloc, ServiceStatusState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            // case DashboardChangeTabState:
            //   state = state as DashboardChangeTabState;
            //   selectedItem = state.index;
            //   modeItem.clear();
            //   modeItem.addAll(Helper.dashboardMenuItems[selectedItem]);
            //   break;
            // default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }


  Widget mobileView({required BuildContext bContext}){
    return Container();
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomText(
                              title: AppStrings.serviceStatus,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              text: AppStrings.checkList,
                              textColor: AppColors.primaryColor,
                              preFixWidget: const Icon(
                                AppIcons.checkListIcon, 
                                size: AppSize.s18, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              text: AppStrings.sync,
                              textColor: AppColors.primaryColor,
                              widgetSpacing: AppSize.s8,
                              preFixWidget: const Icon(AppIcons.loopIcon, size: AppSize.s18, color: AppColors.primaryColor)
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                              horPadding: AppSize.s10,
                              verPadding: AppSize.s10,
                              text: AppStrings.switchUser
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomIconButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s14,
                              verPadding: AppSize.s12,
                              widget: const CustomImageView(imagePath: AppImages.notificationColor, blendMode: BlendMode.dstIn),
                            ),
                            const SizedBox(width: AppSize.s8),
                            CustomIconButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s10,
                              verPadding: AppSize.s10,
                              widget: const CustomImageView(imagePath: AppImages.menuHorizontalColor, blendMode: BlendMode.dstIn),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s40),
                    CustomText(
                      title: AppStrings.allSystemOperational,
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark 
                        ? AppColors.white
                        : AppColors.black
                      )
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(AppSize.s20),
                  child: ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    children: [
                      Wrap(
                        alignment: WrapAlignment.center,
                        children: List.generate(
                          16, 
                          (index) {
                            return Container(
                              width: context.screenWidth * 0.22,
                              margin: const EdgeInsets.only(right: AppSize.s22, bottom: AppSize.s22),
                              padding: const EdgeInsets.all(AppSize.s10),
                              decoration: BoxDecoration(
                                color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                borderRadius: BorderRadius.circular(AppSize.s8),
                                //boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.4), blurRadius: 4.0)]
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      CustomText(
                                        title: 'Order Processing/ KDS',
                                        color: Helper.isDark 
                                        ? AppColors.white
                                        : AppColors.black
                                      ),
                                      const SizedBox(width: AppSize.s8),
                                      const CustomImageView(
                                        imagePath: AppImages.questionIcon,
                                        color: AppColors.grey,
                                      ),
                                    ],
                                  ),
                                  Icon(
                                    AppIcons.rightCheckIcon, 
                                    size: AppSize.s18, 
                                    color: Helper.isDark 
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ],
                              ),
                            );
                          }
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(top: AppSize.s20, bottom: AppSize.s40),
                        child: Divider(color: AppColors.grey, thickness: AppSize.s1, height: AppSize.s1),
                      ),
                      CustomText(
                        title: AppStrings.faq,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16,
                          color: Helper.isDark 
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const SizedBox(height: AppSize.s14),
                      Column(
                        children: List.generate(
                          3, 
                          (index) {
                            return Container(
                              decoration: BoxDecoration(
                                color: AppColors.transparent,
                                borderRadius: BorderRadius.circular(AppSize.s8)
                              ),
                              child: Theme(
                                data: Theme.of(context).copyWith(
                                  dividerColor: AppColors.transparent, 
                                  splashColor: Colors.transparent,
                                  highlightColor: Colors.transparent
                                ),
                                child: ExpansionTile(
                                  tilePadding: EdgeInsets.zero,
                                  childrenPadding: EdgeInsets.zero,
                                  title: Container(
                                    padding: const EdgeInsets.all(AppSize.s10),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark 
                                      ? AppColors.contentColorDark
                                      : AppColors.white,
                                      borderRadius: BorderRadius.circular(AppSize.s8)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: "What steps should i take when my devices come out offline mode?",
                                          textStyle: getMediumStyle(
                                            color: Helper.isDark 
                                            ? AppColors.white
                                            : AppColors.black
                                          ),
                                        ),
                                        Icon(
                                          AppIcons.arrowDown, 
                                          color: Helper.isDark 
                                          ? AppColors.white
                                          : AppColors.black
                                        )
                                      ],
                                    ),
                                  ),
                                  trailing: const SizedBox(),
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppSize.s10),
                                      margin: const EdgeInsets.only(right: AppSize.s32),
                                      decoration: BoxDecoration(
                                        color: Helper.isDark 
                                        ? AppColors.contentColorDark
                                        : AppColors.white,
                                        borderRadius: BorderRadius.circular(AppSize.s8)
                                      ),
                                      child: CustomText(
                                        title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s12,
                                          color: Helper.isDark 
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

}