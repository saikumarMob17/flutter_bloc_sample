import 'package:cliqtechnologies_retl/features/service_status/presentation/bloc/service_status_state.dart';
import 'package:cliqtechnologies_retl/features/service_status/presentation/bloc/service_status_event.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ServiceStatusBloc extends Bloc<ServiceStatusEvent, ServiceStatusState>{

  ServiceStatusBloc() : super(ServiceStatusInitialState());
}