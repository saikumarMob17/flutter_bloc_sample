sealed class ServiceStatusState {}

class ServiceStatusInitialState extends ServiceStatusState {}