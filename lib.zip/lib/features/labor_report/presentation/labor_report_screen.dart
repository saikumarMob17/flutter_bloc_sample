import 'package:cliqtechnologies_retl/features/labor_report/presentation/bloc/labor_report_bloc.dart';
import 'package:cliqtechnologies_retl/features/labor_report/presentation/bloc/labor_report_state.dart';
import 'package:cliqtechnologies_retl/widgets/custom_dropdown_widget.dart';
import 'package:cliqtechnologies_retl/widgets/dropdownmenu_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';

class LaborReportScreen extends StatefulWidget {
  const LaborReportScreen({super.key});

  @override
  State<LaborReportScreen> createState() => _LaborReportScreenState();
}

class _LaborReportScreenState extends State<LaborReportScreen> {

  var tabTitleList = [
    'Labor Summary',
    'Time Entries',
    'Break Adherence',
    'Hourly Sales Report',
    'Employee Productivity',
    'Pooled Tips',
    'Swipe Card Log',
    'Time Entries Audit',
  ];

  int tabSelectedIndex = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark ? AppColors.backgroundColorDark : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<LaborReportBloc, LaborReportState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: 'Labor Report',
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to menu screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomText(
                title: 'View', 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16,
                  color: Helper.isDark 
                  ? AppColors.white
                  : AppColors.black
                )
              ),
              const SizedBox(width: AppSize.s10),
              Expanded(
                child: SizedBox(
                  height: AppSize.s50,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    children: [
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'Labor')], 
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      ),
                      const SizedBox(width: AppSize.s8),
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'This Week')], 
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      ),
                      const SizedBox(width: AppSize.s8),
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'All Hours')],
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      )
                    ],
                  )
                ),
              )
            ],
          ),
          const SizedBox(height: AppSize.s2),
          Row(
            children: [
              CustomText(
                title: 'For', 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16,
                  color: Helper.isDark 
                  ? AppColors.white
                  : AppColors.black
                ),
              ),
              const SizedBox(width: AppSize.s10),
              CustomDropdownWidget(
                items: [DropdownMenuModel(value: '0', item: 'All Employees')], 
                verPad: AppSize.s6,
                borderColor: AppColors.primaryColor,
                value: '0',
                onChange: (value) => debugPrint('Click here to change'),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s10),
          SizedBox(
            height: 44,
            width: context.screenWidth,
            child: ListView(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              children: List.generate(
                tabTitleList.length, 
                (index) {
                  var data = tabTitleList[index];
                  return GestureDetector(
                    // onTap: () => bContext.read<OrdersBloc>().add(OrdersChangeDropDownEvent(
                    //   selectedValue: drinkOption[index].value, 
                    //   selectedIndex: index)),
                    // onTap: () => debugPrint('Click here to change tab'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                      margin: const EdgeInsets.only(right: AppSize.s20),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            width: 3.0, 
                            color: tabSelectedIndex == index 
                            ? AppColors.primaryColor 
                            : AppColors.transparent
                          ),
                        ),
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: CustomText(
                          title: data,
                          textStyle: getMediumStyle(
                            color: tabSelectedIndex == index 
                            ? AppColors.primaryColor 
                            : Helper.isDark
                              ? AppColors.white
                              : AppColors.black,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: AppSize.s10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: tabTitleList[tabSelectedIndex],
                textStyle: getMediumStyle(fontSize: AppSize.s16),
              ),
              CustomOutlinedButton(
                onPressed: () => debugPrint('Click here to update'),
                text: "Filter",
                topPadding: AppSize.s8,
                bottomPadding: AppSize.s8,
                preFixWidget: const Icon(AppIcons.updateIcon, size: AppSize.s16),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s10),
          Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(
                  padding: const EdgeInsets.all(AppSize.s4),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s8)
                  ),
                  child: Scrollbar(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Container(
                        width: context.screenWidth * 1.8,
                        color: AppColors.grey.withOpacity(0.2),
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                              color: AppColors.white,
                              child: const Row(
                                children: [
                                  Expanded(
                                    child: CustomText(title: "Job Title"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Regular Hours"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Overtime Hours"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Regular Pay"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Overtime Pay"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Total Pay"),
                                  ),
                                ],
                              ),
                            ),
                            ...List.generate(
                              10, 
                              (index) {
                                return Container(
                                  color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                                  child: const Row(
                                    children: [
                                      Expanded(
                                        child: CustomText(title: "Barback"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "8.17"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "0.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$0.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                    ],
                                  )
                                );
                              }
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s10),
                Container(
                  padding: const EdgeInsets.all(AppSize.s4),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s8)
                  ),
                  child: Scrollbar(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Container(
                        width: context.screenWidth * 2,
                        color: AppColors.grey.withOpacity(0.2),
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                              color: AppColors.white,
                              child: const Row(
                                children: [
                                  Expanded(
                                    child: CustomText(title: "Sales"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Orders"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Guest"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Tips"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Gratuity"),
                                  ),
                                  Expanded(
                                    child: CustomText(title: "Declared Tips"),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: CustomText(title: "Total Pay/Sales", maxLines: 1,),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: CustomText(title: "Total Sales/Employee Hour", maxLines: 1),
                                  ),
                                ],
                              ),
                            ),
                            ...List.generate(
                              1, 
                              (index) {
                                return Container(
                                  color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                                  child: const Row(
                                    children: [
                                      Expanded(
                                        child: CustomText(title: "Barback"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "8.17"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "0.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$0.00"),
                                      ),
                                      Expanded(
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: CustomText(title: "\$65.00"),
                                      ),
                                    ],
                                  )
                                );
                              }
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Tax Rate"),
                              CustomText(title: "Tax Amount"),
                              CustomText(title: "Net Sales")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Discount"),
                              CustomText(title: "Count"),
                              CustomText(title: "Amount")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      3, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Gross Sales"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Services"),
                              CustomText(title: "Orders"),
                              CustomText(title: "Net Sales")
                            ],
                          ),
                        );
                      }
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      5, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Void Amount"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      8, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Expected Closeout Cash"),
                              CustomText(title: "\$22,782.25")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Cash Before Tipouts"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      7, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Net Sales"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomText(
                              title: 'Labor Reports',
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              leftPadding: AppSize.s16,
                              rightPadding: AppSize.s16,
                              topPadding: AppSize.s12,
                              bottomPadding: AppSize.s12,
                              text: 'Publish Changes',
                              textColor: AppColors.primaryColor,
                              preFixWidget: const Icon(
                                AppIcons.syncIcon, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s14,
                              verPadding: AppSize.s12,
                              text: AppStrings.switchUser,
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              widget: const CustomImageView(
                                imagePath: AppImages.menuHorizontalColor, 
                                blendMode: BlendMode.dstIn
                                ),
                              textColor: AppColors.primaryColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: AppSize.s20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                title: 'View', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'Labor')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'This Week')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Hours')],
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomText(
                                title: 'For', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Employees')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              )
                            ],
                          ),
                          
                          Row(
                            children: [
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to update'),
                                text: AppStrings.update,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                preFixWidget: const Icon(AppIcons.updateIcon, size: AppSize.s16),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to play'),
                                text: AppStrings.emailExport,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                widgetSpacing: AppSize.s5,
                                preFixWidget: const CustomImageView(
                                  imagePath: AppImages.emailPushIcon, 
                                  blendMode: BlendMode.dstIn
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              width: context.screenWidth,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                // padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                                children: List.generate(
                                  tabTitleList.length, 
                                  (index) => GestureDetector(
                                    //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                      margin: const EdgeInsets.only(right: AppSize.s30),
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            width: 3.0, 
                                            color: tabSelectedIndex == index 
                                            ? AppColors.primaryColor 
                                            : AppColors.transparent
                                          )
                                        ),
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: CustomText(
                                          title: tabTitleList[index],
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s14,
                                            color: tabSelectedIndex == index 
                                            ? AppColors.primaryColor 
                                            : Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s20),
                      ///Report UI
                      Expanded(
                        child: ListView(
                          children: [
                            CustomText(
                              title: 'Restaurant Summary', 
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s16,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            const SizedBox(height: AppSize.s20),
                            Container(
                              padding: const EdgeInsets.all(AppSize.s10),
                              decoration: BoxDecoration(
                                color: Helper.isDark
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: BorderRadius.circular(AppSize.s10)
                              ),
                              child: Column(
                                children: [
                                  const Row(
                                    children: [
                                      Expanded(
                                        child: CustomText(
                                          title: 'Job Title',
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Regular Hours',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Overtime Hours',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Regular pay',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Overtime Pay',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Total Pay',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s10),
                                  Column(
                                    children: List.generate(
                                      10, (index) {
                                        return Container(
                                          color: Helper.isDark
                                          ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                          : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                          padding: const EdgeInsets.symmetric(vertical: AppSize.s4),
                                          child: const Row(
                                            children: [
                                              Expanded(
                                                child: CustomText(title: 'Barback')
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '8.17',
                                                  textAlign: TextAlign.end,
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '0.00',
                                                  textAlign: TextAlign.end
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$65.20',
                                                  textAlign: TextAlign.end
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$0.00',
                                                  textAlign: TextAlign.end
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$65.20',
                                                  textAlign: TextAlign.end
                                                )
                                              ),
                                            ],
                                          )
                                        );
                                      }
                                    )
                                  )
                                ]
                              ),
                            ),
                            const SizedBox(height: AppSize.s20),
                            Container(
                              padding: const EdgeInsets.all(AppSize.s10),
                              decoration: BoxDecoration(
                                color: Helper.isDark
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: BorderRadius.circular(AppSize.s10)
                              ),
                              child: Column(
                                children: [
                                  const Row(
                                    children: [
                                      Expanded(
                                        child: CustomText(
                                          title: 'Sales',
                                          fontSize: AppSize.s14
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Orders',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Guests',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Tips',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Gratuity',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Declared Tips',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Total Pay/Sales',
                                          textAlign: TextAlign.start,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: 'Total Sales/Employee Hour',
                                          textAlign: TextAlign.end,
                                          fontSize: AppSize.s14,
                                        )
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s10),
                                  Column(
                                    children: List.generate(
                                      1, (index) {
                                        return Container(
                                          color: Helper.isDark
                                          ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                          : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                          padding: const EdgeInsets.symmetric(vertical: AppSize.s4),
                                          child: const Row(
                                            children: [
                                              Expanded(
                                                child: CustomText(title: 'Barback')
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '8.17',
                                                  textAlign: TextAlign.start,
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '0.00',
                                                  textAlign: TextAlign.start
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$65.20',
                                                  textAlign: TextAlign.start
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$0.00',
                                                  textAlign: TextAlign.start
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$65.20',
                                                  textAlign: TextAlign.start
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$0.00',
                                                  textAlign: TextAlign.start
                                                )
                                              ),
                                              Expanded(
                                                child: CustomText(
                                                  title: '\$65.20',
                                                  textAlign: TextAlign.end
                                                )
                                              ),
                                            ],
                                          )
                                        );
                                      }
                                    )
                                  )
                                ]
                              ),
                            ),
                            const SizedBox(height: AppSize.s30),
                            CustomText(
                              title: 'Employee Summary', 
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s16,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            const SizedBox(height: AppSize.s20),
                            Container(
                              padding: const EdgeInsets.all(AppSize.s5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Helper.isDark 
                                  ? AppColors.grey 
                                  : AppColors.black, 
                                  width: AppSize.s1
                                ),
                                borderRadius: BorderRadius.circular(AppSize.s5)
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const CustomText(title: 'Amoddio, Pablo'),
                                      Container(
                                        padding: const EdgeInsets.all(AppSize.s1),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(AppSize.s5),
                                          border: Border.all(
                                            color: Helper.isDark 
                                            ? AppColors.grey 
                                            : AppColors.black, 
                                            width: AppSize.s1
                                          ),
                                        ),
                                        child: const Icon(AppIcons.addIcon, size: AppSize.s16),
                                      )
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s10),
                                  Container(
                                    padding: const EdgeInsets.all(AppSize.s10),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark
                                      ? AppColors.contentColorDark
                                      : AppColors.white,
                                      borderRadius: BorderRadius.circular(AppSize.s10)
                                    ),
                                    child: Column(
                                      children: List.generate(
                                        2, 
                                        (index) {
                                          return Container(
                                            padding: EdgeInsets.symmetric(
                                              vertical: index%2 == 0 ? AppSize.s6 :AppSize.s4,
                                              horizontal: index%2 == 0 ? AppSize.s6 :AppSize.s4,
                                            ),
                                            color: Helper.isDark
                                            ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                            : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                            child: const Row(
                                              children: [
                                                Expanded(
                                                  child: CustomText(title: 'Job Title',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Regular Hours',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Overtime Hours',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Regular pay',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Overtime Pay',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Total Pay',)
                                                )
                                              ],
                                            ),
                                          );
                                        }
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: AppSize.s20),
                                  const Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: SizedBox()
                                      ),
                                      Expanded(
                                        child: CustomText(title: 'Net Sales',)
                                      ),
                                      Expanded(
                                        child: CustomText(title: 'Tips',)
                                      ),
                                      Expanded(
                                        child: CustomText(title: 'Gratuity',)
                                      ),
                                      Expanded(
                                        child: CustomText(title: 'Declared Tips',)
                                      ),
                                    ],
                                  ),
                                  const Divider(),
                                  const Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: SizedBox()
                                      ),
                                      Expanded(
                                        child: CustomText(title: '\$65.20')
                                      ),
                                      Expanded(
                                        child: CustomText(title: '\$0.00')
                                      ),
                                      Expanded(
                                        child: CustomText(title: '\$0.00')
                                      ),
                                      Expanded(
                                        child: CustomText(title: '\$65.20')
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s20),
                                  Container(
                                    padding: const EdgeInsets.all(AppSize.s10),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark
                                      ? AppColors.contentColorDark
                                      : AppColors.white,
                                      borderRadius: BorderRadius.circular(AppSize.s10)
                                    ),
                                    child: Column(
                                      children: List.generate(
                                        2, 
                                        (index) {
                                          return Container(
                                            padding: EdgeInsets.symmetric(
                                              vertical: index%2 == 0 ? AppSize.s6 :AppSize.s4,
                                              horizontal: index%2 == 0 ? AppSize.s6 :AppSize.s4,
                                            ),
                                            color: Helper.isDark
                                            ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                            : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                            child: const Row(
                                              children: [
                                                Expanded(
                                                  child: CustomText(title: 'Job Title',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Regular Hours',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Overtime Hours',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Regular pay',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Overtime Pay',)
                                                ),
                                                Expanded(
                                                  child: CustomText(title: 'Total Pay',)
                                                )
                                              ],
                                            ),
                                          );
                                        }
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

}