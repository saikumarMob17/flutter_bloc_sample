import 'package:cliqtechnologies_retl/features/labor_report/presentation/bloc/labor_report_event.dart';
import 'package:cliqtechnologies_retl/features/labor_report/presentation/bloc/labor_report_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LaborReportBloc extends Bloc<LaborReportEvent, LaborReportState>{

  LaborReportBloc() : super(LaborReportInitialState());
}