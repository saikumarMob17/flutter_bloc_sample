sealed class LaborReportState {}

class LaborReportInitialState extends LaborReportState {}