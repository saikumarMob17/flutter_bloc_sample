import 'dart:convert';

LoginResponse loginResponseFromJson(String str) => LoginResponse.fromJson(json.decode(str));

class LoginResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final Data? data;

  LoginResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );
}

class Data {
  final String? token;
  final String? userId;
  final String? role;
  final String? userName;
  final String? tenantName;
  final String? location;
  final String? userEmail;

  Data({
    this.token,
    this.userId,
    this.role,
    this.userName,
    this.tenantName,
    this.location,
    this.userEmail
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    token: json["token"] ?? '',
    userId: json['userId'] ?? '',
    role: json['role'] ?? '',
    userName: json['userName'] ?? '',
    tenantName: json['tenantName'] ?? '',
    location: json['loction'] ?? '',
    userEmail: json['userEmail'] ?? ''
  );
}
