import 'package:cliqtechnologies_retl/routes/route.dart';

class LoginRequest {

  String email;
  String password;
  String tenantId;
  String securityPin;
  LoginType loginType;

  LoginRequest({
    this.email = '',
    this.password = '',
    this.tenantId = '',
    this.securityPin = '',
    this.loginType = LoginType.pin
  });

  Map<String, dynamic> get toJson => {
    "email": loginType == LoginType.pin ? '' : email,
    "password": loginType == LoginType.pin ? '' : password,
    "securityPin": loginType == LoginType.pin ? securityPin : '',
    "tenantId": Preferences.getString(key: AppStrings.prefTenantId)
  };

}