import 'dart:convert';
import 'dart:io';
import 'package:cliqtechnologies_retl/routes/route.dart';

import '../domain/login_response.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';

class LoginRepository {

  late ApiClient _apiClient;

  LoginRepository(){
    _apiClient = ApiClient();
  }

  Future<LoginResponse> userLogin({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.login, body: body);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          Preferences.setString(key: AppStrings.prefToken, value: jsonResponse['data']['token']);
          if(await userClockedIn(userId: jsonResponse['data']['userId'])){
            return loginResponseFromJson(response.body);
          } else {
            throw CustomException(message: 'User unable to clocked In');
          }
        case HttpStatus.badRequest:
          throw CustomException(message: jsonResponse['message']);
        default:
          throw CustomException(message: 'Something went wrong');
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> userClockedIn({required String userId}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.clockIn}?employeeId=$userId");
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            return true;
          }
          return false;
        default:
          return false;
      }
    } catch (e) {
      return false;
    }
  }
}