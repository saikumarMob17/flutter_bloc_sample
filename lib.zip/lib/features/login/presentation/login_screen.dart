import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../constants/app_colors.dart';
import '../../../../constants/app_images.dart';
import '../../../../constants/app_size.dart';
import '../../../../constants/app_strings.dart';
import '../../../../constants/app_style.dart';
import 'bloc/login_bloc.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_pattern_lock_widget.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../utils/shared_pref.dart';
import '../../../widgets/custom_keypad_widget.dart';

class LoginScreen extends StatefulWidget {

  const LoginScreen({super.key});

  @override
  State createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with Helper{

  late TextEditingController emailTextController;
  late TextEditingController passwordTextController;
  bool isRememberMe = false;
  bool showPassword = true;
  var loginType = LoginType.pin;
  String pinValue = '';
  String errorEmail = '';
  String errorPassword = '';
  String patternPosition = '';
  ScreenType screenType = ScreenType.mobile;
  var currentDateTime = [];
  late LoginBloc _loginBloc;

  @override
  void initState() {
    _loginBloc = context.read<LoginBloc>();
    emailTextController = TextEditingController();
    passwordTextController = TextEditingController();
    if(Preferences.getBool(key: AppStrings.prefRememberMe)) {
      isRememberMe = true;
      emailTextController.text = Preferences.getString(key: AppStrings.prefEmail);
    }
    currentDateTime = Helper.getFormattedDateTime();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      body: BlocConsumer<LoginBloc, LoginState>(
        builder: (bContext, state) {
          return LayoutBuilder(
            builder: (context, constraints) {
              screenType = constraints.maxWidth.screenType;
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: bContext)
              : posView(bContext: bContext);
            }
          );
        },
        listener: (context, state) {
          switch (state) {
            case ChangeLoginTypeState _:
              loginType = state.loginType;
              break;
            case LoginPinEnterState _:
              pinValue = state.pinValue;
              break;
            case LoginRememberMeState _:
              isRememberMe = state.isRememberMe;
              break;
            case LoginShowPasswordState _:
              showPassword = state.passwordVisible;
              break;
            case LoginEmailChangeState _:
              errorEmail = state.msg;
              break;
            case LoginPasswordChangeState _:
              errorPassword = state.msg;
              break;
            case LoginSuccessState _:
              hideLoadingDialog(context: context);
              context.go(AppRoutes.dashboardScreen);
              break;
            case LoginLoadingState _:
              showLoadingDialog(context: context);
              break;
            case LoginFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(
                context: context, 
                title: state.msg, 
                screenType: screenType
              );
            default:
          }
        }
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.only(top: context.statusBarHeight),
      children: [
        Row(
          children: [
            const SizedBox(width: AppSize.s20),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  title: AppStrings.welcome, 
                  textStyle: getBoldStyle()),
                CustomText(
                  title: AppStrings.loginToContinue, 
                  textStyle: getMediumStyle()
                ),
              ],
            ),
            const SizedBox(width: AppSize.s20),
            const Expanded(
              child: CustomImageView(
                imagePath: AppImages.headerCurveImg,
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
        ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: AppSize.s40,
            vertical: loginType == LoginType.pin ? 0 : AppSize.s40
          ),
          children: [
            loginType == LoginType.pin
            ? pinWidget(bContext: bContext)
            : loginWidget(bContext: bContext),
            CustomSolidButton(
              text: AppStrings.login,
              verPadding: AppSize.s20,
              onPressed: () => _loginBloc.add(LoginSubmitEvent(
                loginType: loginType, 
                email: emailTextController.text, 
                password: passwordTextController.text,
                isRememberMe: isRememberMe
              )),
            ),
            const SizedBox(height: AppSize.s8),
            CustomOutlinedButton(
              onPressed: () => _loginBloc.add(ChangeLoginTypeEvent(loginType: loginType == LoginType.pin ? LoginType.userName : LoginType.pin)),
              textColor: Helper.isDark 
              ? AppColors.white 
              : AppColors.lightTextColor,
              text: loginType == LoginType.pin 
              ? AppStrings.loginMsg 
              : AppStrings.userPinInstead
            ),
            const SizedBox(height: AppSize.s25),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppSize.s24),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.topDarkColor 
                        : AppColors.buttonBackgroundColor,
                        shape: BoxShape.circle,
                      ),
                      child: const CustomImageView(
                        imagePath: AppImages.fingerprintIcon,
                        width: AppSize.s24,
                        height: AppSize.s36,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    CustomText(
                      title: AppStrings.loginWithTouch,
                      color: Helper.isDark 
                      ? AppColors.lightGrey 
                      : AppColors.black,
                    ),
                  ],
                ),
                Container(
                  height: AppSize.s70,
                  width: AppSize.s2,
                  margin: const EdgeInsets.symmetric(horizontal: AppSize.s25),
                  color: AppColors.dividerColor,
                ),
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppSize.s24),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.topDarkColor 
                        : AppColors.buttonBackgroundColor,
                        shape: BoxShape.circle,
                      ),
                      child: const CustomImageView(
                        imagePath: AppImages.faceIdIcon,
                        width: AppSize.s24,
                        height: AppSize.s36,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    CustomText(
                      title: AppStrings.loginWithFace,
                      color: Helper.isDark 
                      ? AppColors.lightGrey 
                      : AppColors.black,
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: AppSize.s25),
          ],
        ),
      ],
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        Expanded(
          child: Container(
            color: Helper.isDark ? AppColors.black : AppColors.white,
            alignment: Alignment.center,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: AppImages.logoTextWhite,
                    width: 460,
                    height: 260,
                    fit: BoxFit.contain,
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.primaryColor,
                  ),
                  const CustomImageView(
                    imagePath: AppImages.logoIconTransparent,
                    width: 180,
                    color: AppColors.transparent,
                  ),
                  const SizedBox(height: AppSize.s30),
                  CustomText(
                    title: currentDateTime[0],
                    textStyle: getSemiBoldStyle(
                      fontSize: AppSize.s28 
                    ),
                  ),
                  CustomText(
                    title: currentDateTime[1],
                    textStyle: getBoldStyle(
                      fontSize: AppSize.s38
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.symmetric(
              horizontal: context.screenWidth * 0.12,
            ),
            children: [
              loginTypeWidget(bContext: bContext),
              Visibility(
                visible: loginType != LoginType.pattern,
                child: CustomSolidButton(
                  backgroundColor: AppColors.primaryColor,
                  text: AppStrings.login,
                  verPadding: AppSize.s20,
                  onPressed: () => _loginBloc.add(LoginSubmitEvent(
                    loginType: loginType, 
                    email: emailTextController.text, 
                    password: passwordTextController.text,
                    isRememberMe: isRememberMe
                  )),
                ),
              ),
              const SizedBox(height: AppSize.s10),
              CustomOutlinedButton(
                onPressed: () => _loginBloc.add(ChangeLoginTypeEvent(
                  loginType: loginType == LoginType.pin 
                  ? LoginType.userName 
                  : LoginType.pin
                  )
                ),
                textColor: Helper.isDark 
                ? AppColors.primaryColor 
                : AppColors.lightTextColor,
                text: loginType == LoginType.pin 
                ? AppStrings.loginMsg 
                : AppStrings.userPinInstead,
                topPadding: AppSize.s18,
                bottomPadding: AppSize.s18,
              ),
              const SizedBox(height: AppSize.s25),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () => _loginBloc.add(ChangeLoginTypeEvent(loginType: loginType == LoginType.pin ? LoginType.pattern : LoginType.pin)),
                        child: Container(
                          padding: const EdgeInsets.all(AppSize.s18),
                          decoration: BoxDecoration(
                            color: Helper.isDark ? AppColors.topDarkColor : AppColors.buttonBackgroundColor,
                            shape: BoxShape.circle,
                          ),
                          child: CustomImageView(
                            imagePath: loginType == LoginType.pin ? AppImages.patternIcon : AppImages.pinIcon,
                            width: AppSize.s22,
                            height: AppSize.s34,
                            color: AppColors.primaryColor,
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSize.s10),
                      CustomText(
                        title: loginType == LoginType.pin 
                        ? AppStrings.loginWithPattern 
                        : AppStrings.loginWithPin,
                        textStyle: getRegularStyle(
                          fontSize: AppSize.s14,
                          fontWeight: FontWeight.w400,
                          color: Helper.isDark 
                          ? AppColors.lightGrey 
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                  Container(
                    height: AppSize.s70,
                    width: AppSize.s2,
                    margin: const EdgeInsets.symmetric(horizontal: AppSize.s25),
                    color: AppColors.dividerColor,
                  ),
                  Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(AppSize.s18),
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.topDarkColor 
                          : AppColors.buttonBackgroundColor,
                          shape: BoxShape.circle,
                        ),
                        child: const CustomImageView(
                          imagePath: AppImages.faceIdIcon,
                          width: AppSize.s22,
                          height: AppSize.s34,
                          color: AppColors.primaryColor,
                        ),
                      ),
                      const SizedBox(height: AppSize.s10),
                      CustomText(
                        title: AppStrings.loginWithFace,
                        textStyle: getRegularStyle(
                          fontSize: AppSize.s14,
                          fontWeight: FontWeight.w400,
                          color: Helper.isDark 
                          ? AppColors.lightGrey 
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget loginTypeWidget({required BuildContext bContext}) {
    switch (loginType) {
      case LoginType.pin:
        return pinWidget(bContext: bContext);
      case LoginType.userName:
        return loginWidget(bContext: bContext);
      default:
        return patternWidget(bContext: bContext);
    }
  }

  Widget patternWidget({required BuildContext bContext}){
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(AppSize.s14),
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.primaryColor
          ),
          child: const CustomImageView(
            imagePath: AppImages.patternIcon,
            width: AppSize.s26,
            height: AppSize.s26,
            color: AppColors.white,
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.patternLock, 
            textStyle: getMediumStyle( 
              fontSize: AppSize.s22
            ),
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.patternLockMsg, 
            textStyle: getRegularStyle(
              color: Helper.isDark 
              ? AppColors.lightGrey 
              : AppColors.lightTextGrey, 
              fontSize: AppSize.s14
            ),
          ),
        ),
        const SizedBox(height: AppSize.s22),
        SizedBox(
          height: 280,
          child: CustomPatternLockWidget(
            selectedColor: AppColors.primaryColor,
            notSelectedColor: AppColors.primaryColor,
            relativePadding: 0.3,
            fillPoints: true,
            onInputComplete: (output) => _loginBloc.add(LoginPatternLockEvent(pattern: output.join(''))),
          ),
        ),
        const SizedBox(height: AppSize.s20),       
      ],
    );
  }

  Widget pinWidget({required BuildContext bContext}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(AppSize.s14),
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.primaryColor
          ),
          child: const CustomImageView(
            imagePath: AppImages.pinIcon,
            width: AppSize.s26,
            height: AppSize.s26,
            color: AppColors.white,
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.enterPin, 
            textStyle: getMediumStyle(
              color: Helper.isDark 
              ? AppColors.white 
              : AppColors.black, 
              fontSize: AppSize.s22
            )
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.enterPinMsg, 
            textStyle: getRegularStyle(
              color: Helper.isDark 
              ? AppColors.lightGrey 
              : AppColors.lightTextGrey, 
              fontSize: AppSize.s14
            ),
          ),
        ),
        const SizedBox(height: AppSize.s22),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(
            6, 
            (index) {
              return Container(
                height: AppSize.s18,
                width: AppSize.s18,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: pinValue.length >= index + 1 
                  ? AppColors.primaryColor 
                  : Helper.isDark 
                    ? AppColors.lightTextGrey 
                    : AppColors.white,
                  boxShadow: [BoxShadow(color: AppColors.primaryColor.withOpacity(0.2), blurRadius: 4)]
                ),
              );
            }
          ),
        ),
        const SizedBox(height: AppSize.s10),
        CustomKeypadWidget(
          onTap: (value) => _loginBloc.add(LoginPinEnterEvent(value: value))
        ),
        const SizedBox(height: AppSize.s20),
      ],
    );
  }

  Widget loginWidget({required BuildContext bContext}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(AppSize.s14),
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.primaryColor
          ),
          child: const CustomImageView(
            imagePath: AppImages.loginIcon,
            width: AppSize.s26,
            height: AppSize.s26,
            color: AppColors.white,
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.login, 
            textStyle: getMediumStyle(
              color: Helper.isDark 
              ? AppColors.white 
              : AppColors.black, 
              fontSize: AppSize.s22
            ),
          ),
        ),
        const SizedBox(height: AppSize.s8),
        Align(
          alignment: Alignment.center, 
          child: CustomText(
            title: AppStrings.loginSubtitle, 
            textStyle: getRegularStyle(
              color:  Helper.isDark 
              ? AppColors.lightGrey 
              : AppColors.lightTextGrey,  
              fontSize: AppSize.s14
            ),
          ),
        ),
        ///Email Field
        const SizedBox(height: AppSize.s22),
        CustomTextField(
          textController: emailTextController,
          verPadding: AppSize.s12,
          horPadding: AppSize.s14,
          prefixImagePath: AppImages.personIcon,
          label: AppStrings.username,
          isMandatory: true,
          errorText: errorEmail,
          onChange: (value) => _loginBloc.add(LoginEmailChangeEvent(email: value))
        ),
        ///Password Field
        const SizedBox(height: AppSize.s12),
        CustomTextField(
          textController: passwordTextController,
          verPadding: AppSize.s12,
          horPadding: AppSize.s14,
          obscureText: showPassword,
          label: AppStrings.password,
          isMandatory: true,
          prefixImagePath: AppImages.passwordIcon,
          inputFormatter: [FilteringTextInputFormatter.deny(Helper.restrictSpaceRegExp)],
          suffixImagePath: showPassword ? AppImages.eyeOpenIcon : AppImages.eyeCloseIcon,
          suffixCallBack: () => _loginBloc.add(LoginShowPasswordEvent(passwordVisible: showPassword)),
          errorText: errorPassword,
          onChange: (value) => _loginBloc.add(LoginPasswordChangeEvent(password: value)),
        ),
        const SizedBox(height: AppSize.s12),
        Row(
          children: [
            CustomCheckBox(
              value: isRememberMe,
              onChange: (value) => _loginBloc.add(LoginRememberMeEvent(isRememberMe: value!)),
            ),
            const SizedBox(width: AppSize.s2),
            CustomText(
              title: AppStrings.rememberMe, 
              textStyle: getRegularStyle(
                fontWeight: FontWeight.w400,
                color: Helper.isDark 
                ? AppColors.lightGrey 
                : AppColors.black
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSize.s20),
      ],
    );
  }
}