part of 'login_bloc.dart';

sealed class LoginEvent {}

class ChangeLoginTypeEvent extends LoginEvent {
  LoginType loginType;
  ChangeLoginTypeEvent({required this.loginType});
}

class LoginPinEnterEvent extends LoginEvent {
  int value;
  LoginPinEnterEvent({required this.value});
}

class LoginSubmitEvent extends LoginEvent {
  
  LoginType loginType;
  String email;
  String password;
  bool isRememberMe;

  LoginSubmitEvent({
    required this.loginType,
    this.email = '',
    this.password = '',
    this.isRememberMe = false
  });

}

class LoginRememberMeEvent extends LoginEvent {
  bool isRememberMe;
  LoginRememberMeEvent({required this.isRememberMe});
}

class LoginShowPasswordEvent extends LoginEvent {
  bool passwordVisible;
  LoginShowPasswordEvent({required this.passwordVisible});
}

class LoginEmailChangeEvent extends LoginEvent {
  String email;
  LoginEmailChangeEvent({this.email=''});
}

class LoginPasswordChangeEvent extends LoginEvent {
  String password;
  LoginPasswordChangeEvent({this.password=''});
}

class LoginPatternLockEvent extends LoginEvent {
  String pattern;
  LoginPatternLockEvent({required this.pattern});
}