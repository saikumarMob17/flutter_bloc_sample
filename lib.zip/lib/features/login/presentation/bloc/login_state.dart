part of 'login_bloc.dart';

sealed class LoginState {}

class LoginInitialState extends LoginState {}

class ChangeLoginTypeState extends LoginState {
  LoginType loginType;
  ChangeLoginTypeState({required this.loginType});
}
class LoginPinEnterState extends LoginState {
  String pinValue;
  LoginPinEnterState({required this.pinValue});
}


class LoginSuccessState extends LoginState {
  String msg;
  LoginSuccessState({required this.msg});
}

class LoginFailedState extends LoginState {
  String msg;
  LoginFailedState({this.msg = ''});
}

class LoginLoadingState extends LoginState {
  String msg;
  LoginLoadingState({this.msg=''});
}


class LoginRememberMeState extends LoginState {
  bool isRememberMe;
  LoginRememberMeState({required this.isRememberMe});
}

class LoginShowPasswordState extends LoginState {
  bool passwordVisible;
  LoginShowPasswordState({required this.passwordVisible});
}


class LoginEmailChangeState extends LoginState {
  String msg;
  LoginEmailChangeState({this.msg=''});
}

class LoginPasswordChangeState extends LoginState {
  String msg;
  LoginPasswordChangeState({this.msg=''});
}