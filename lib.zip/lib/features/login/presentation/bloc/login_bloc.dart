import '../../../../constants/app_strings.dart';
import '../../../../features/login/data/login_repository.dart';
import '../../../../features/login/domain/login_request.dart';
import '../../../../network/custom_exception.dart';
import '../../../../utils/app_extension_method.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../../utils/helper.dart';
import '../../../../utils/shared_pref.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {

  LoginType loginType = LoginType.pin;
  String pinValue = AppStrings.emptyString;
  late CheckConnectivity _checkConnectivity;
  late LoginRepository _loginRepository;
  bool isRememberMe = false;
  bool showPassword = false;

  LoginBloc() : super(LoginInitialState()) {
    _loginRepository = LoginRepository();
    _checkConnectivity = CheckConnectivity();
    on<ChangeLoginTypeEvent>(_onChangeLoginType);
    on<LoginPinEnterEvent>(_onChangePinEnter);
    on<LoginSubmitEvent>(_onLoginSubmit);
    on<LoginRememberMeEvent>(_onChangeRememberMe);
    on<LoginShowPasswordEvent>(_onShowPassword);
    on<LoginEmailChangeEvent>(_onChangeEmail);
    on<LoginPasswordChangeEvent>(_onChangePassword);
    on<LoginPatternLockEvent>(_onLoginWithPattern);
  }

  void _onChangeLoginType(ChangeLoginTypeEvent event, Emitter emit){
    loginType = event.loginType;
    emit(ChangeLoginTypeState(loginType: event.loginType));
  }

  Future<void> _onLoginWithPattern(LoginPatternLockEvent event, Emitter emit) async {
    if(await validationPattern(emit: emit, pattern: event.pattern)){
      emit(LoginSuccessState(msg: AppStrings.loginSuccessMsg));
    }
  }

  void _onChangePinEnter(LoginPinEnterEvent event, Emitter emit){
    if(event.value >= 0){
      if(pinValue.length < 6){
        pinValue+='${event.value}';
      }
    } else {
      if(pinValue.isNotEmpty){
        pinValue = pinValue.substring(0, pinValue.length - 1);
      }
    }
    emit(LoginPinEnterState(pinValue: pinValue));
  }

  void _onChangeEmail(LoginEmailChangeEvent event, Emitter emit){
    if(event.email.isEmpty){
      emit(LoginEmailChangeState(msg: AppStrings.emptyEmailMsg));
    } else if(!event.email.isValidEmail){
      emit(LoginEmailChangeState(msg: AppStrings.invalidEmail));
    } else {
      emit(LoginEmailChangeState(msg: AppStrings.emptyString));
    }
  }

  void _onChangePassword(LoginPasswordChangeEvent event, Emitter emit){
    if(event.password.isEmpty){
      emit(LoginPasswordChangeState(msg: AppStrings.emptyPasswordMsg));
    } else {
      emit(LoginPasswordChangeState(msg: AppStrings.emptyString));
    }
  }

  void _onShowPassword(LoginShowPasswordEvent event, Emitter emit){
    showPassword = !event.passwordVisible;
    emit(LoginShowPasswordState(passwordVisible: showPassword));
  }

  void _onChangeRememberMe(LoginRememberMeEvent event, Emitter emit){
    isRememberMe = event.isRememberMe;
    emit(LoginRememberMeState(isRememberMe: isRememberMe));
  }


  Future<void> _onLoginSubmit(LoginSubmitEvent event, Emitter emit) async {
    switch (loginType) {
      case LoginType.pin:
      case LoginType.userName:
        if(await validationLoginFields(loginType, emit: emit, email: event.email, password: event.password)) {
          emit(LoginLoadingState());
          try {
            isRememberMe = event.isRememberMe;
            var bodyData = LoginRequest(
              email: event.email,
              password: event.password,
              securityPin: pinValue,
              loginType: loginType
            ).toJson;
            var loginData = await _loginRepository.userLogin(body: bodyData);
            Preferences.setBool(key: AppStrings.prefRememberMe, value: isRememberMe);
            Preferences.setString(key: AppStrings.prefEmail, value: event.email.isEmpty ? loginData.data!.userEmail! : event.email);
            Preferences.setString(key: AppStrings.prefToken, value: loginData.data!.token!);
            Preferences.setString(key: AppStrings.prefUserId, value: loginData.data!.userId!);
            Preferences.setString(key: AppStrings.prefFullName, value: loginData.data!.userName!);
            Preferences.setString(key: AppStrings.prefUserRole, value: loginData.data!.role!);
            Preferences.setString(key: AppStrings.prefTenantName, value: loginData.data!.tenantName!);
            Preferences.setString(key: AppStrings.prefLocation, value: loginData.data!.location!);
            emit(LoginSuccessState(msg: loginData.message!));
          } on CustomException catch(e) {
            emit(LoginFailedState(msg: e.message));
          }
        }
        break;
      default:
    }
  }

  Future<bool> validationPattern({required Emitter emit, required String pattern}) async {
    if(pattern.isEmpty){
      emit(LoginFailedState(msg: 'Please provide pattern'));
      return false;
    } else if(pattern.length < 6){
      emit(LoginFailedState(msg: 'Please enter valid pin'));
      return false;
    } else if(!await _checkConnectivity.hasConnection){
      emit(LoginFailedState(msg: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  Future<bool> validationLoginFields(LoginType loginType, {required Emitter emit, required String email, required String password}) async {
    switch (loginType) {
      case LoginType.pin:
        if(pinValue.isEmpty){
          emit(LoginFailedState(msg: 'Please enter pin'));
          return false;
        } else if(pinValue.length < 6){
          emit(LoginFailedState(msg: 'Please enter valid pin'));
          return false;
        } else if(!await _checkConnectivity.hasConnection){
          emit(LoginFailedState(msg: AppStrings.noInternetConnection));
          return false;
        } else {
          return true;
        }
      case LoginType.userName:
        if(email.isBlank) {
          emit(LoginEmailChangeState(msg: AppStrings.emptyEmailMsg));
          return false;
        } else if(!email.isValidEmail) {
          emit(LoginEmailChangeState(msg: AppStrings.invalidEmail));
          return false;
        } else if(password.isBlank) {
          emit(LoginPasswordChangeState(msg: AppStrings.emptyPasswordMsg));
          return false;
        } else if(!await _checkConnectivity.hasConnection) {
          emit(LoginFailedState(msg: AppStrings.noInternetConnection));
          return false;
        } else {
          return true;
        }
      default:
        return false;
    }
  }

}