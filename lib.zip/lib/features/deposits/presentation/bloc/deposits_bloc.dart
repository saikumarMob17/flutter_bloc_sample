import 'package:cliqtechnologies_retl/features/deposits/presentation/bloc/deposits_event.dart';
import 'package:cliqtechnologies_retl/features/deposits/presentation/bloc/deposits_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class DepositsBloc extends Bloc<DepositsEvent, DepositsState>{

  DepositsBloc() : super(DepositsInitialState());
}