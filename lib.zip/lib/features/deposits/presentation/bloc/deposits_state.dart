sealed class DepositsState {}

class DepositsInitialState extends DepositsState {}