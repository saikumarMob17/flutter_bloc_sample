import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'bloc/deposits_bloc.dart';
import 'bloc/deposits_state.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/dropdownmenu_model.dart';

class DepositsScreen extends StatefulWidget {
  const DepositsScreen({super.key});

  @override
  State<DepositsScreen> createState() => _DepositsScreenState();
}

class _DepositsScreenState extends State<DepositsScreen> {

  var titleList = [
    'Date',
    'Action',
    'Amount',
    'User'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<DepositsBloc, DepositsState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.cashDeposit,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18, 
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to menu screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s24),
          CustomTextField(
            textController: TextEditingController(),
            hint: AppStrings.searchHere,
            prefixImagePath: AppImages.searchIcon,
            prefixImageColor: AppColors.lightTextGrey,
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
          ),
          const SizedBox(height: AppSize.s20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "${AppStrings.total}:  ", 
                      style: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                    ),
                    TextSpan(
                      text: "\$300", 
                      style: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: AppColors.primaryColor
                      ),
                    ),
                  ]
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSize.s6,
                  vertical: AppSize.s4
                ),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(AppSize.s5)
                ),
                child: const CustomText(
                  title: "+ ${AppStrings.add}",
                  color: AppColors.white,
                  fontSize: AppSize.s16,
                ),
              )
            ],
          ),
          const SizedBox(height: AppSize.s10),
          Expanded(
            child: ListView.builder(
              itemCount: 8,
              shrinkWrap: true,
              itemBuilder: (_, index) {
                return Container(
                  margin: const EdgeInsets.only(bottom: AppSize.s10),
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s10,
                    horizontal: AppSize.s15
                  ),
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      titleList.length, 
                      (subIndex) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s8
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(
                                title: titleList[subIndex], 
                                textStyle: getMediumStyle(
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                )
                              ),
                              subIndex == 1
                              ? Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: AppSize.s6,
                                  vertical: AppSize.s4
                                ),
                                decoration: BoxDecoration(
                                  color: index%2 == 0 ? AppColors.green : AppColors.amber,
                                  borderRadius: BorderRadius.circular(AppSize.s5)
                                ),
                                child: CustomText(
                                  title: index%2 == 0 ? AppStrings.done : AppStrings.pending,
                                  color: AppColors.white,
                                ),
                              )
                              : CustomText(
                                title: '\$300', 
                                textStyle: getMediumStyle(
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                  )
                                )
                            ],
                          ),
                        );
                      }
                    ),
                  ),
                );
              }
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.cashDeposit,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark 
                                ? AppColors.white 
                                : AppColors.black,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: context.screenWidth * 0.15,
                              child: const CustomTextField(
                                prefixImagePath: AppImages.searchIcon,
                                prefixImageColor: AppColors.lightTextGrey,
                                prefixImageSize: AppSize.s16,
                                horPadding: AppSize.s14,
                                verPadding: 9,
                                hint: AppStrings.search,
                              ),
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomOutlinedButton(
                              onPressed: () => showAddDepositDialog(context: context),
                              text: AppStrings.addDeposit,
                              preFixWidget: const Icon(
                                AppIcons.addIcon, 
                                color:AppColors.blue,
                                size: 22,
                              ),
                              textColor: AppColors.blue
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              text: AppStrings.switchUser,
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                            ),
                            // const SizedBox(width: AppSize.s10),
                            // CustomOutlinedButton(
                            //   onPressed: () => debugPrint(''),
                            //   // verPadding: AppSize.s12,
                            //   widget: const CustomImageView(imagePath: AppImages.notificationColor,blendMode: BlendMode.dstIn,),
                            //   textColor: AppColors.primaryColor,
                            // ),
                            // const SizedBox(width: AppSize.s10),
                            // CustomIconButton(
                            //   onPressed: () => debugPrint(''),
                            //   widget: const CustomImageView(
                            //     imagePath: AppImages.menuHorizontalColor, 
                            //     blendMode: BlendMode.dstIn
                            //   ),
                            // ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s30),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s40,
                        vertical: AppSize.s0
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: CustomText(
                              title: AppStrings.date,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            )
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.actions,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            )
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.missing,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: 'Threshold Amount',
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.amount,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.user,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s0),
                  shrinkWrap: true,
                  itemCount: 15,
                  itemBuilder: (_, index){
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s40,
                        vertical: AppSize.s12
                      ),
                      color: Helper.isDark
                      ? index%2 == 0 ? AppColors.contentColorDark : AppColors.transparent
                      : index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: CustomText(
                              title: '10 march 2023',
                              fontSize: AppSize.s14,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: AppSize.s6,
                                  vertical: AppSize.s4
                                ),
                                decoration: BoxDecoration(
                                  color: index == 5
                                  ? AppColors.red
                                  : index%2 == 0 ? AppColors.green : AppColors.amber,
                                  borderRadius: BorderRadius.circular(AppSize.s5)
                                ),
                                child: CustomText(
                                  title: index == 5
                                  ? AppStrings.missing
                                  : index%2 == 0 ? AppStrings.done : AppStrings.pending,
                                  color: AppColors.white,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: index == 5
                              ? '\$50'
                              : '--',
                              fontSize: AppSize.s14,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            )
                          ),
                          Expanded(
                            child: CustomText(
                              title: '\$250',
                              fontSize: AppSize.s14,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            )
                          ),
                          Expanded(
                            child: CustomText(
                              title: index == 5
                              ? '\$200'
                              : '\$250',
                              fontSize: AppSize.s14,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            )
                          ),
                          Expanded(
                            child: CustomText(
                              title: 'Linda P',
                              fontSize: AppSize.s14,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void showAddDepositDialog({required BuildContext context}){
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          content: Container(
            width: context.screenWidth * 0.35,
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s24,
              horizontal: AppSize.s24
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s12),
              color: Helper.isDark 
              ? AppColors.contentColorDark 
              : AppColors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  title: AppStrings.addDeposit,
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s20,
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                CustomTextField(
                  textController: TextEditingController(),
                  hint: AppStrings.amount,
                  label: AppStrings.amount,
                  verPadding: AppSize.s14,
                  horPadding: AppSize.s20,
                ),
                const SizedBox(height: AppSize.s20),
                CustomDropdownWidget(
                  isExpanded: true,
                  label: AppStrings.chooseUser, 
                  labelStyle: getRegularStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                  items: [DropdownMenuModel(value: '-1', item: 'Select User')], 
                  value: '-1'
                ),
                const SizedBox(height: AppSize.s20),
                CustomDropdownWidget(
                  isExpanded: true,
                  label: AppStrings.chooseCashDrawer, 
                  labelStyle: getRegularStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                  items: [DropdownMenuModel(value: '-1', item: 'Select Cash Drawer')], 
                  value: '-1'
                ),
                const SizedBox(height: AppSize.s20),
                CustomTextField(
                  verPadding: AppSize.s14,
                  horPadding: AppSize.s14,
                  suffixImagePath: AppImages.dateIcon,
                  hint: AppStrings.chooseDate,
                  label: AppStrings.chooseDate,
                  readOnly: true,
                  onTap: () => showDatePickerDialog(context),
                  textController: TextEditingController()
                ),
                const SizedBox(height: AppSize.s32),
                SizedBox(
                  width: double.maxFinite,
                  child: CustomSolidButton(
                    onPressed: () => debugPrint('Click here to close dialog'),
                    text: AppStrings.done,
                  ),
                ),
              ],
            ),
          ),
        );
      }
    );
  }

  Future<void> showDatePickerDialog(BuildContext context) async {
    var tempDate = await showDatePicker(
      context: context, 
      firstDate: DateTime.parse('2012-02-27'), 
      lastDate: DateTime.now(),
    );
    if(tempDate != null){
      //dateTextController.text = tempDate.toString().substring(0, 11);
    }
  }
}