import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../constants/app_size.dart';
import 'bloc/customer/customer_bloc.dart';
import '../domain/customer_order_model.dart';
import '../domain/lookup_customer_response.dart';

class CustomerScreen extends StatefulWidget {

  final LookupCustomer customerInfo;
  const CustomerScreen({super.key, required this.customerInfo});

  @override
  State createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {

  var tabList = [
    'All Orders',
    'Pending Orders',
    'Completed Orders',
    // 'Cancelled Orders'
  ];

  int tabIndex = 0;
  double grandTotal = 0.0;
  late LookupCustomer customerInfo;
  var customerOrderList = <CustomerOrderModel>[];

  @override
  void initState() {
    customerInfo = widget.customerInfo;
    
    for(var item in customerInfo.orderHistory!) {
      for(var subItem in item.orderDetailsByOrderSequence!) {
        customerOrderList.add(CustomerOrderModel(
          orderSequence: subItem.orderSequence!,
          orderFinished: subItem.isFinished!,
          orderNumber: item.orderNumber!,
          orderDate: item.orderedDate!,
          billingDetails: item.billingDetails!,
          productDetails: subItem.productDetails!
        ));
      }
    }

    for(var item in customerOrderList) {
      double sequencePrice = 0.0;
      for(var subItem in item.productDetails) {
        var tempPrice = (subItem.quantity! * subItem.productPrice!).roundTwo;
        sequencePrice+=tempPrice;
        grandTotal+=tempPrice;
      }
      double tax = (sequencePrice * 10) / 100;
      item.grandTotal = (sequencePrice + tax).roundTwo;
    }
    grandTotal+=((grandTotal * 10) / 100);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<CustomerBloc, CustomerState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case OnChangeTabState:
              state = state as OnChangeTabState;
              tabIndex = state.tabIndex;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.customer,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to menu screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s10),
          CustomText(
            title: 'Details', 
            textStyle: getMediumStyle(
              color: Helper.isDark
              ? AppColors.white
              : AppColors.black
            ),
          ),
          const SizedBox(height: AppSize.s10),
          Container(
            padding: const EdgeInsets.all(AppSize.s10),
            decoration: BoxDecoration(
              color: Helper.isDark
              ? AppColors.contentColorDark
              : AppColors.white,
              borderRadius: BorderRadius.circular(AppSize.s10)
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const CustomImageView(
                  imagePath: AppImages.userIcon
                ),
                const SizedBox(height: AppSize.s20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: AppSize.s60),
                  child: Divider(color: AppColors.grey, height: AppSize.s1, thickness: AppSize.s1)
                ),
                const SizedBox(height: AppSize.s20),
                CustomText(
                  title: customerInfo.customerDetails!.customerName!, 
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s20,
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  )
                ),
                const SizedBox(height: AppSize.s8),
                CustomText(
                  title: customerInfo.customerDetails!.customerEmail!, 
                  textStyle: getRegularStyle(
                    fontSize: AppSize.s14, 
                    color: AppColors.grey
                  ),
                ),
                const SizedBox(height: AppSize.s5),
                CustomText(
                  title: customerInfo.customerDetails!.customerPhone!, 
                  textStyle: getRegularStyle(
                    fontSize: AppSize.s14, 
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSize.s20),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(AppSize.s20),
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        title: 'Orders', 
                        textStyle: getMediumStyle(
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: AppSize.s10),
                        child: Divider(color: AppColors.grey, height: AppSize.s1, thickness: AppSize.s1)
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  CustomText(title: customerInfo.orderHistory!.length.toString(), textStyle: getRegularStyle(color: AppColors.grey,fontSize: 18)),
                                  CustomText(
                                    title: ' (Total)', 
                                    textStyle: getRegularStyle(
                                      fontSize: 14, 
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s8),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFFFFD4B1),
                                ),
                                child: const CustomImageView(
                                  imagePath: AppImages.arrowUpIcon, 
                                  width: AppSize.s16, 
                                  height: AppSize.s16, 
                                  color: Color(0xFFF97A66)
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSize.s10),
                          CustomText(
                            title: 'Impression increased', 
                            textStyle: getRegularStyle(
                              fontSize: AppSize.s8, 
                              color: const Color(0xFFF97A66)
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: AppSize.s10),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(AppSize.s20),
                  decoration: BoxDecoration(
                    color: Helper.isDark
                    ? AppColors.contentColorDark
                    : AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(title: 'Order Cost', textStyle: getMediumStyle()),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: AppSize.s10),
                        child: Divider(color: AppColors.grey, height: AppSize.s1, thickness: AppSize.s1)
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  CustomText(
                                    title: '\$${grandTotal.toString()}', 
                                    textStyle: getRegularStyle(
                                      color: AppColors.grey,
                                      fontSize: 18
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s8),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFFD8FDE0),
                                ),
                                child: const CustomImageView(imagePath: AppImages.arrowDownIcon, width: AppSize.s16, height: AppSize.s16, color: Color(0xFF4FAA47))
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSize.s10),
                          CustomText(title: 'Impression decreased', textStyle: getRegularStyle(fontSize: AppSize.s8, color: const Color(0xFF4FAA47)))
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s40),
          Container(
            height: 50,
            padding: const EdgeInsets.only(
              left: AppSize.s15,
              right: AppSize.s15,
              top: AppSize.s15,
              bottom: AppSize.s5
            ),
            decoration: BoxDecoration(
              color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
              borderRadius: BorderRadius.circular(AppSize.s10),
              boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
            ),
            child: ListView(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              children: List.generate(
                tabList.length, 
                (index) {
                  var data = tabList[index];
                  return InkWell(
                    onTap: () => context.read<CustomerBloc>().add(OnChangeTabEvent(tabIndex: index)),
                    child: Container(
                      margin: const EdgeInsets.only(right: AppSize.s40),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: tabIndex == index 
                            ? AppColors.primaryColor 
                            : AppColors.transparent
                          ),
                        ),
                      ),
                      child: CustomText(
                        title: data,
                        textStyle: getMediumStyle(
                          color: tabIndex == index 
                          ? AppColors.primaryColor 
                          : AppColors.grey
                        ),
                      ),
                    ),
                  );
                }
              ),
            ),
          ),
          const SizedBox(height: AppSize.s10),
          Scrollbar(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              physics: const NeverScrollableScrollPhysics(),
              child: Scrollbar(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SizedBox(
                    height: 350, 
                    width: context.screenWidth * 2, 
                    child: Column(
                      children: [
                        Container(
                          color: AppColors.transparent,
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s15,
                            horizontal: AppSize.s8
                          ),
                          child: Row(
                            children: [
                              Expanded(child: CustomText(title: 'Order Number', textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black))),
                              Expanded(child: CustomText(title: 'Order Sequence', textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black))),
                              Expanded(child: CustomText(title: 'Order Date', textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black))),
                              Expanded(child: CustomText(title: 'Product Price', textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black))),
                              Expanded(child: CustomText(title: 'Status', textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black))),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: filterOrder(tabIndex).isEmpty,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: AppSize.s20),
                                child: CustomText(
                                  title: AppStrings.noOrderFound,
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: AppColors.primaryColor
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: filterOrder(tabIndex).length,
                            padding: EdgeInsets.zero,
                            itemBuilder: (_, index){
                              var subOrderData = filterOrder(tabIndex);
                              var data = subOrderData[index];
                              return Container(
                                color: Helper.isDark
                                ? index%2 == 0 ? AppColors.transparent : AppColors.contentColorDark
                                : index%2 == 1 ? AppColors.transparent : AppColors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s10,
                                  horizontal: AppSize.s8
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: CustomText(
                                        title: data.orderNumber, 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12,
                                          color: Helper.isDark ? AppColors.white : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: '#${data.orderSequence.toString()}', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12,
                                          color: Helper.isDark ? AppColors.white : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.orderDate.substring(0, 10), 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12,
                                          color: Helper.isDark ? AppColors.white : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: '\$${data.grandTotal}', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12,
                                          color: Helper.isDark ? AppColors.white : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        textAlign: TextAlign.start,
                                        title: tabIndex == 0
                                        ? data.orderFinished ? 'Completed' : 'Pending'
                                          : tabIndex == 1
                                            ? 'Pending'
                                            : tabIndex == 2
                                            ? 'Completed'
                                            : 'Cancelled',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14, 
                                          color: tabIndex == 0
                                          ? data.orderFinished ? AppColors.green : AppColors.amber
                                            : tabIndex == 1
                                              ? AppColors.amber
                                              : tabIndex == 2
                                              ? AppColors.green
                                              : AppColors.red
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }
                          ),
                        ),
                      ],
                    )
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomText(
                          title: AppStrings.customer,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        CustomSolidButton(
                          onPressed: () => debugPrint(''),
                          text: AppStrings.switchUser,
                          prefix: const Icon(
                            Icons.swap_horiz_rounded, 
                            color: AppColors.white
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s20,
                    horizontal: 88
                  ),
                  children: [
                    CustomText(
                      title: AppStrings.details,
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s16,
                        color: Helper.isDark 
                        ? AppColors.white
                        : AppColors.black
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    Row(
                      children: [
                        Container(
                          width: context.screenWidth * 0.17,
                          height: context.screenHeight * 0.40,
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s30,
                            horizontal: AppSize.s45
                          ),
                          decoration: BoxDecoration(
                            color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10),
                            boxShadow: Helper.isDark
                            ? null
                            : [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              const CustomImageView(
                                imagePath: AppImages.userIcon,
                                width: 120,
                                height: 135,
                              ),
                              const SizedBox(height: AppSize.s20),
                              const Divider(color: AppColors.grey, height: AppSize.s1, thickness: AppSize.s1),
                              const Spacer(),
                              FittedBox(
                                child: CustomText(
                                  title: customerInfo.customerDetails!.customerName!, 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s18,
                                  ),
                                  maxLines: 1,
                                ),
                              ),
                              const SizedBox(height: AppSize.s8),
                              FittedBox(
                                child: CustomText(
                                  title: customerInfo.customerDetails!.customerEmail!.isBlank
                                  ? '--'
                                  : customerInfo.customerDetails!.customerEmail!, 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14, 
                                    color: AppColors.grey
                                  ),
                                ),
                              ),
                              const SizedBox(height: AppSize.s5),
                              CustomText(
                                title: customerInfo.customerDetails!.customerPhone!.isBlank
                                ? '--'
                                : customerInfo.customerDetails!.customerPhone!, 
                                textStyle: getRegularStyle(
                                  fontSize: AppSize.s14, 
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: AppSize.s35),
                        Container(
                          width: context.screenWidth * 0.17,
                          height: context.screenHeight * 0.40,
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s20,
                            horizontal: AppSize.s20
                          ),
                          decoration: BoxDecoration(
                            color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10),
                            boxShadow: Helper.isDark 
                            ? null
                            : [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                title: 'Geographics', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s18,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(height: AppSize.s10),
                              Container(height: AppSize.s1, color: AppColors.grey, width: (context.screenWidth * 0.17) * 0.50),
                              const SizedBox(height: AppSize.s20),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                decoration: BoxDecoration(
                                  color: Helper.isDark ? AppColors.backgroundColorDark : AppColors.white,
                                  borderRadius: BorderRadius.circular(AppSize.s10),
                                  boxShadow: Helper.isDark
                                  ? null
                                  : [BoxShadow(color: AppColors.blue.withOpacity(0.2), blurRadius: AppSize.s4)]
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppSize.s6),
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xFFF97A66),
                                      ),
                                      child: const CustomImageView(
                                        imagePath: AppImages.phoneIcon, 
                                        color: AppColors.white,
                                        height: AppSize.s20,
                                        width: AppSize.s20,
                                      )
                                    ),
                                    const SizedBox(width: AppSize.s10),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        CustomText(title: AppStrings.contact, color: Helper.isDark ? AppColors.white : AppColors.black),
                                        const SizedBox(height: AppSize.s5),
                                        CustomText(
                                          title: customerInfo.customerDetails!.customerPhone!.isBlank
                                          ? '--'
                                          : customerInfo.customerDetails!.customerPhone!, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: AppSize.s15),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                decoration: BoxDecoration(
                                  color: Helper.isDark ? AppColors.backgroundColorDark : AppColors.white,
                                  borderRadius: BorderRadius.circular(AppSize.s10),
                                  boxShadow: Helper.isDark
                                  ? null
                                  : [BoxShadow(color: AppColors.blue.withOpacity(0.2), blurRadius: AppSize.s4)]
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppSize.s6),
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.primaryColor,
                                      ),
                                      child: const CustomImageView(
                                        imagePath: AppImages.addressIcon, 
                                        color: AppColors.white,
                                        height: AppSize.s20,
                                        width: AppSize.s20
                                      )
                                    ),
                                    const SizedBox(width: AppSize.s10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          CustomText(title: 'Address', color: Helper.isDark ? AppColors.white : AppColors.black),
                                          const SizedBox(height: AppSize.s5),
                                          CustomText(title: '--', color: Helper.isDark ? AppColors.white : AppColors.black)
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(height: AppSize.s15),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                decoration: BoxDecoration(
                                  color: Helper.isDark ? AppColors.backgroundColorDark : AppColors.white,
                                  borderRadius: BorderRadius.circular(AppSize.s10),
                                  boxShadow: Helper.isDark
                                  ? null
                                  : [BoxShadow(color: AppColors.blue.withOpacity(0.2), blurRadius: AppSize.s4)]
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(AppSize.s6),
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.green,
                                      ),
                                      child: const CustomImageView(
                                        imagePath: AppImages.summaryIcon, 
                                        color: AppColors.white,
                                        height: AppSize.s20,
                                        width: AppSize.s20
                                      )
                                    ),
                                    const SizedBox(width: AppSize.s10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          CustomText(title: 'Last Visit', color: Helper.isDark ? AppColors.white : AppColors.black),
                                          const SizedBox(height: AppSize.s5),
                                          CustomText(
                                            title: customerOrderList.first.orderDate.convertDateTimeClockOut.substring(0,13), 
                                            textOverflow: TextOverflow.ellipsis,
                                            color: Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),                            
                            ],
                          ),
                        ),
                        const SizedBox(width: AppSize.s35),
                        SizedBox(
                          height: context.screenHeight * 0.40,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Container(
                                  width: context.screenWidth * 0.17,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: AppSize.s10,
                                    horizontal: AppSize.s30
                                  ),
                                  decoration: BoxDecoration(
                                    color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                    borderRadius: BorderRadius.circular(AppSize.s10),
                                    boxShadow: Helper.isDark
                                    ? null
                                    : [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      CustomText(
                                        title: 'Orders', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s18,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        )
                                      ),
                                      const SizedBox(height: AppSize.s5),
                                      Container(height: AppSize.s1, color: AppColors.grey, width: (context.screenWidth * 0.17) * 0.50),
                                      const Spacer(),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s10, vertical: AppSize.s15),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark ? AppColors.backgroundColorDark : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s10),
                                          boxShadow: Helper.isDark
                                          ? null
                                          : [BoxShadow(color: AppColors.blue.withOpacity(0.2), blurRadius: AppSize.s4)]
                                        ),
                                        child: Row(
                                          children: [
                                            CustomText(
                                              title: customerInfo.orderHistory!.length.toString(), 
                                              textStyle: getRegularStyle(fontSize: AppSize.s16)
                                            ),
                                            CustomText(
                                              title: ' (Total)', 
                                              textStyle: getRegularStyle(
                                                fontSize: AppSize.s14,
                                                color: Helper.isDark
                                                ? AppColors.white
                                                : AppColors.black
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),                            
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: AppSize.s20),
                              Expanded(
                                child: Container(
                                  width: context.screenWidth * 0.17,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: AppSize.s10,
                                    horizontal: AppSize.s30
                                  ),
                                  decoration: BoxDecoration(
                                    color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                    borderRadius: BorderRadius.circular(AppSize.s10),
                                    boxShadow: [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      CustomText(
                                        title: 'Order Cost', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s18,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s5),
                                      Container(height: AppSize.s1, color: AppColors.grey, width: (context.screenWidth * 0.17) * 0.50),
                                      const Spacer(),
                                      Container(
                                        width: double.maxFinite,
                                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s10, vertical: AppSize.s15),
                                        decoration: BoxDecoration(
                                          color: Helper.isDark ? AppColors.backgroundColorDark : AppColors.white,
                                          borderRadius: BorderRadius.circular(AppSize.s10),
                                          boxShadow: Helper.isDark
                                          ? null
                                          : [BoxShadow(color: AppColors.blue.withOpacity(0.2), blurRadius: AppSize.s4)]
                                        ),
                                        child: CustomText(
                                          title: '\$${grandTotal.roundTwo.toString()}', 
                                          textStyle: getRegularStyle(
                                            fontSize: AppSize.s16
                                          )
                                        ),
                                      ),                           
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s34),
                    Container(
                      height: 50,
                      padding: const EdgeInsets.only(
                        left: AppSize.s40,
                        right: AppSize.s40,
                        top: AppSize.s15,
                        bottom: AppSize.s5
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark ? AppColors.contentColorDark :AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10),
                        boxShadow: Helper.isDark
                        ? null
                        : [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                      ),
                      child: ListView(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        children: List.generate(
                          tabList.length, 
                          (index) {
                            var data = tabList[index];
                            return InkWell(
                              onTap: () => context.read<CustomerBloc>().add(OnChangeTabEvent(tabIndex: index)),
                              child: Container(
                                margin: const EdgeInsets.only(right: AppSize.s40),
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: tabIndex == index 
                                      ? AppColors.blue 
                                      : Helper.isDark ? AppColors.transparent : AppColors.white,
                                    ),
                                  ),
                                ),
                                child: CustomText(
                                  title: data,
                                  textStyle: getMediumStyle(
                                    color: tabIndex == index 
                                    ? AppColors.blue 
                                    : Helper.isDark ? AppColors.lightGrey : AppColors.black
                                  ),
                                ),
                              ),
                            );
                          }
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s14),
                    Container(
                      padding: const EdgeInsets.only(
                        left: AppSize.s40,
                        right: AppSize.s40,
                        top: AppSize.s15,
                        bottom: AppSize.s5
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.contentColorDark 
                        :AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10),
                        boxShadow: Helper.isDark
                        ? null
                        : [BoxShadow(color: AppColors.grey.withOpacity(0.2), blurRadius: AppSize.s4)]
                      ),
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.only(bottom: 15),
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: AppColors.grey, 
                                  width: AppSize.s1
                                ),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: CustomText(
                                    title: 'Order Number',
                                    textStyle: getMediumStyle(),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: 'Order Sequence',
                                    textStyle: getMediumStyle(),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: 'Ordered Date',
                                    textStyle: getMediumStyle(),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: 'Product Price',
                                    textAlign: TextAlign.center,
                                    textStyle: getMediumStyle(),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: 'Order Status',
                                    textAlign: TextAlign.end,
                                    textStyle: getMediumStyle(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Visibility(
                            visible: filterOrder(tabIndex).isEmpty,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s20),
                                  child: CustomText(
                                    title: AppStrings.noOrderFound,
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14,
                                      color: AppColors.primaryColor
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          ListView.separated(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: filterOrder(tabIndex).length,
                            itemBuilder: (_, index) {
                              var subOrderData = filterOrder(tabIndex);
                              var data = subOrderData[index];
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 1,
                                      child: CustomText(
                                        title: data.orderNumber,
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: '#${data.orderSequence}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.orderDate.substring(0, 10).formatDateMMDDYYY,
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: '\$${data.grandTotal}',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        textAlign: TextAlign.end,
                                        title: tabIndex == 0
                                        ? data.orderFinished ? 'Completed' : 'Pending'
                                          : tabIndex == 1
                                            ? 'Pending'
                                            : tabIndex == 2
                                            ? 'Completed'
                                            : 'Cancelled',
                                        textStyle: getRegularStyle(
                                          fontSize: AppSize.s14, 
                                          color: tabIndex == 0
                                          ? data.orderFinished ? AppColors.green : AppColors.orange
                                            : tabIndex == 1
                                              ? AppColors.orange
                                              : tabIndex == 2
                                              ? AppColors.green
                                              : AppColors.red
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }, 
                            separatorBuilder: (_, index) => const Divider(
                              color: AppColors.grey, 
                              height: AppSize.s1, 
                              thickness: AppSize.s1
                            ), 
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<CustomerOrderModel> filterOrder(int tabIndex) {
    switch (tabIndex) {
      case 0:
        return customerOrderList;
      case 1:
        return customerOrderList.where((element) => !element.orderFinished).toList();
      case 2:
        return customerOrderList.where((element) => element.orderFinished).toList();
      case 3:
        return [];
      default:
        return [];
    }
  }
}