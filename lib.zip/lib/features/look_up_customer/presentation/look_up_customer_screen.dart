import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../routes/app_routes.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'bloc/look_up_customer/look_up_customer_bloc.dart';
import '../domain/lookup_customer_response.dart';

class LookUpCustomerScreen extends StatefulWidget {
  
  const LookUpCustomerScreen({super.key});

  @override
  State createState() => _LookUpCustomerScreenState();
}

class _LookUpCustomerScreenState extends State<LookUpCustomerScreen> with Helper {

  List<LookupCustomer> searchCustomerList = [];
  late TextEditingController nameEmail;
  late TextEditingController phone;
  late TextEditingController creditCard;
  String fieldsErrorMessage = '';
  late LookUpCustomerBloc _lookUpCustomerBloc;

  @override
  void initState() {
    _lookUpCustomerBloc = context.read<LookUpCustomerBloc>();
    nameEmail = TextEditingController();
    phone = TextEditingController();
    creditCard = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<LookUpCustomerBloc, LookUpCustomerState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case SuccesState:
              state = state as SuccesState;
              searchCustomerList.clear();
              searchCustomerList.addAll(state.searchCustomerList);
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints) {
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state.runtimeType) {
            case LookupLoadingState:
              showLoadingDialog(context: context);
              break;
            case FailedState:
              hideLoadingDialog(context: context);
              state = state as FailedState;
              if(state.message.isNotEmpty) {
                showSnackBar(context: context, title: state.message);
              }
              break;
            case SuccesState:
              state = state as SuccesState;
              hideLoadingDialog(context: context);
              searchCustomerList.clear();
              searchCustomerList.addAll(state.searchCustomerList);
              if(searchCustomerList.isNotEmpty) {
                showSearchResultDialog(context: context, searchCustomerList: searchCustomerList);
              } else {
                Helper.showConfirmationDialog(
                  context: context,
                  title: 'Not Found',
                  message: 'The Customer you are looking for does not exist.',
                  showActionButton: false
                );
              }
              break;
            case OnSwitchUserLookUpState:
              hideLoadingDialog(context: context);
              state = state as OnSwitchUserLookUpState;
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            case LookupFieldEmptyState:
              state = state as LookupFieldEmptyState;
              fieldsErrorMessage = state.errorMsg;
              if(state.errorMsg.isNotEmpty) {
                hideErrorMessage(context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.lookUpCustomer,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => _lookUpCustomerBloc.add(OnSwitchUserLookupEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s8),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s22,
                    width: AppSize.s22,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s30),
          CustomText(
            title: AppStrings.nameEmail, 
            textStyle: getMediumStyle(
              color: Helper.isDark
              ? AppColors.white
              : AppColors.black
            )
          ),
          const SizedBox(height: AppSize.s6),
          CustomTextField(
            textController: nameEmail,
            hint: AppStrings.enterNameEmail,
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
            child: Align(
              alignment: Alignment.center,
              child: CustomText(
                title: AppStrings.or, 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16, 
                  color: AppColors.grey,
                  fontStyle: FontStyle.italic
                ),
              ),
            ),
          ),
          CustomText(
            title: AppStrings.phoneNumber, 
            textStyle: getMediumStyle(
              color: Helper.isDark
              ? AppColors.white
              : AppColors.black
            )
          ),
          const SizedBox(height: AppSize.s6),
          CustomTextField(
            textController: phone,
            hint: AppStrings.enterPhoneNumber,
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
            child: Align(
              alignment: Alignment.center,
              child: CustomText(
                title: AppStrings.or, 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16, 
                  color: AppColors.grey, 
                  fontStyle: FontStyle.italic
                ),
              ),
            ),
          ),
          CustomText(
            title: AppStrings.creditCardNumber, 
            textStyle: getMediumStyle(
              color: Helper.isDark
              ? AppColors.white
              : AppColors.black
            )
          ),
          const SizedBox(height: AppSize.s6),
          CustomTextField(
            textController: creditCard,
            hint: 'xxxx xxxx xxxx',
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
            child: CustomText(
              title: fieldsErrorMessage,
              textStyle: getRegularStyle(
                color: fieldsErrorMessage.isNotEmpty 
                ?AppColors.red 
                : AppColors.transparent,
                fontSize: AppSize.s14
              ),
            ),
          ),
          CustomSolidButton(
            text: AppStrings.search,
            onPressed: () => _lookUpCustomerBloc.add(SearchCustomerEvent(
              nameEmail: nameEmail.text,
              phone: phone.text,
              creditCard: creditCard.text
            )),
            verPadding: AppSize.s18,
            borderRadius: AppSize.s6,
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.lookUpCustomer,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20, 
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    CustomSolidButton(
                      onPressed: () => _lookUpCustomerBloc.add(OnSwitchUserLookupEvent()),
                      text: AppStrings.switchUser,
                      prefix: const Icon(
                        Icons.swap_horiz_rounded, 
                        color: AppColors.white
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: ListView(
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(AppSize.s20),
                      children: [
                        CustomText(
                          title: AppStrings.phoneNumber,
                          textStyle: getMediumStyle(),
                        ),
                        const SizedBox(height: AppSize.s8),
                        CustomTextField(
                          textController: phone,
                          hint: AppStrings.enterPhoneNumber,
                          horPadding: AppSize.s10,
                          verPadding: AppSize.s10,
                          inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                        ),
                        const SizedBox(height: AppSize.s10),
                        Align(
                          alignment: Alignment.center,
                          child: CustomText(
                            title: AppStrings.or,
                            textStyle: getMediumStyle(
                              color: AppColors.grey,
                              fontStyle: FontStyle.italic
                            ),
                          ),
                        ),
                        const SizedBox(height: AppSize.s10),
                        CustomText(
                          title: AppStrings.nameEmail,
                          textStyle: getMediumStyle(),
                        ),
                        const SizedBox(height: AppSize.s8),
                        CustomTextField(
                          textController: nameEmail,
                          hint: AppStrings.enterNameEmail,
                          horPadding: AppSize.s10,
                          verPadding: AppSize.s10,
                        ),
                        const SizedBox(height: AppSize.s10),
                        Align(
                          alignment: Alignment.center,
                          child: CustomText(
                            title: AppStrings.or,
                            textStyle: getMediumStyle(
                              color: AppColors.grey,
                              fontStyle: FontStyle.italic
                            ),
                          ),
                        ),
                        const SizedBox(height: AppSize.s10),
                        CustomText(
                          title: AppStrings.creditCardNumber,
                          textStyle: getMediumStyle(),
                        ),
                        const SizedBox(height: AppSize.s8),
                        CustomTextField(
                          textController: creditCard,
                          hint: 'xxxx xxxx xxxx',
                          horPadding: AppSize.s10,
                          verPadding: AppSize.s10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
                          child: CustomText(
                            title: fieldsErrorMessage,
                            textStyle: getRegularStyle(
                              color: fieldsErrorMessage.isNotEmpty 
                              ?AppColors.red 
                              : AppColors.transparent,
                              fontSize: AppSize.s14
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: CustomSolidButton(
                            onPressed: () => _lookUpCustomerBloc.add(SearchCustomerEvent(
                              nameEmail: nameEmail.text, 
                              phone: phone.text, 
                              creditCard: creditCard.text)
                            ),
                            text: AppStrings.submit,
                            horPadding: AppSize.s24,
                            verPadding: AppSize.s18,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Expanded(child: SizedBox())
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> hideErrorMessage(BuildContext context) async {
    Future.delayed(const Duration(milliseconds: 2500), () => _lookUpCustomerBloc.add(LookupFieldEmptyEvent()));
  }

  void showSearchResultDialog({required BuildContext context, required List<LookupCustomer> searchCustomerList}){
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          content: Container(
            width: context.screenWidth.screenType == ScreenType.mobile
            ? context.screenWidth * 0.95
            : context.screenWidth * 0.64,
            padding: const EdgeInsets.symmetric(
              vertical: AppSize.s10,
              horizontal: AppSize.s20
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSize.s10),
              color: Helper.isDark 
              ? AppColors.contentColorDark 
              : AppColors.white
            ),
            child: ListView.separated(
              shrinkWrap: true,
              itemBuilder: (_, index){
                var data = searchCustomerList[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s10
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: CustomText(
                          title: data.customerDetails!.customerName!.isBlank
                          ? '--'
                          : data.customerDetails!.customerName!,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          title: data.customerDetails!.customerPhone!.isBlank
                          ? '--'
                          : data.customerDetails!.customerPhone!,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomText(
                          title: data.customerDetails!.customerEmail!.isBlank
                          ? '--'
                          : data.customerDetails!.customerEmail!,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s14,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          context.pop();
                          context.push(AppRoutes.customerScreen, extra: data);
                        },
                        child: const Icon(
                          Icons.open_in_new, 
                          color: AppColors.primaryColor
                        ),
                      ),
                    ],
                  ),
                );
              },
              separatorBuilder: (_, __) => Divider(
                height: AppSize.s1, 
                thickness: AppSize.s1, 
                color: Helper.isDark 
                ? AppColors.lightGrey 
                : AppColors.grey
              ), 
              itemCount: searchCustomerList.length
            ),
          ),
        );
      }
    );
  }
}