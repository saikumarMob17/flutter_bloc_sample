part of 'look_up_customer_bloc.dart';

sealed class LookUpCustomerState {}

class LookUpCustomerInitialState extends LookUpCustomerState {}

class FailedState extends LookUpCustomerState {
  String message;

  FailedState({this.message = ''});
}

class LookupFieldEmptyState extends LookUpCustomerState {
  String errorMsg;

  LookupFieldEmptyState({this.errorMsg = ''});
}

class SuccesState extends LookUpCustomerState {
  List<LookupCustomer> searchCustomerList;

  SuccesState({required this.searchCustomerList});
}

class LookupLoadingState extends LookUpCustomerState {}


class OnSwitchUserLookUpState extends LookUpCustomerState {
  bool isLogout;
  OnSwitchUserLookUpState({this.isLogout = false});
}