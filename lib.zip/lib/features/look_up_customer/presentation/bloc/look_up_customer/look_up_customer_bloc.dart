import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../constants/app_strings.dart';
import '../../../data/lookup_customer_repository.dart';
import '../../../../../utils/check_connectivity.dart';
import '../../../../../network/custom_exception.dart';
import '../../../domain/lookup_customer_response.dart';
part 'look_up_customer_event.dart';
part 'look_up_customer_state.dart';

class LookUpCustomerBloc extends Bloc<LookUpCustomerEvent, LookUpCustomerState> {

  late LookupCustomerRepository _repository;
  late CheckConnectivity _checkConnectivity;
  List<LookupCustomer> searchCustomerList = [];

  LookUpCustomerBloc() : super(LookUpCustomerInitialState()){
    _repository = LookupCustomerRepository();
    _checkConnectivity = CheckConnectivity();
    on<SearchCustomerEvent>(_onSearchCustomer);
    on<OnSwitchUserLookupEvent>(_onSwitchUser);
    on<LookupFieldEmptyEvent>(_onShowEmptyFieldError);
  }

  void _onShowEmptyFieldError(LookupFieldEmptyEvent event, Emitter emit) {
    emit(LookupFieldEmptyState(errorMsg: ''));
  }

  Future<void> _onSearchCustomer(SearchCustomerEvent event, Emitter emit) async {
    if(event.nameEmail.isNotEmpty || event.creditCard.isNotEmpty || event.phone.isNotEmpty){
      if(await _checkConnectivity.hasConnection){
        emit(LookupLoadingState());
        String searchQuery = '';
        if(event.nameEmail.isNotEmpty){
          if(event.nameEmail.contains('@')){
            searchQuery = 'FindCustomerByEmail?customerEmail=${event.nameEmail}';
          } else {
            searchQuery = 'FindCustomerByName?customerName=${event.nameEmail}';
          }
        }
        if(event.phone.isNotEmpty){
          searchQuery = 'FindCustomerByPhoneNum?customerPhone=${event.phone}';
        }
        if(event.creditCard.isNotEmpty){
          searchQuery = 'FindCustomerDetailsByCardNum?cardNum=${event.creditCard}';
        }
        var response = await _repository.getAllLookupCustomer(searchQuery: searchQuery);
        searchCustomerList.clear();
        searchCustomerList.addAll(response);
        emit(SuccesState(searchCustomerList: searchCustomerList));
      } else {
        emit(FailedState(message: AppStrings.noInternetConnection));
      }
    } else {
      emit(LookupFieldEmptyState(errorMsg: 'Please provide Phone Number or Name/Email, or Credit Card to search for customer'));
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserLookupEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(LookupLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserLookUpState(isLogout: response));
      } on CustomException catch (e) {
        emit(FailedState(message: e.message));
      }
    }
  }
}