part of 'look_up_customer_bloc.dart';

sealed class LookUpCustomerEvent {}


class SearchCustomerEvent extends LookUpCustomerEvent {
  String nameEmail;
  String phone;
  String creditCard;

  SearchCustomerEvent({
    this.creditCard = '',
    this.nameEmail = '',
    this.phone = ''
  });
}

class OnSwitchUserLookupEvent extends LookUpCustomerEvent {}

class LookupFieldEmptyEvent extends LookUpCustomerEvent {}