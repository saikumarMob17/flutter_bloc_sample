part of 'customer_bloc.dart';

sealed class CustomerState {}

class CustomerInitialState extends CustomerState {}

class OnChangeTabState extends CustomerState {
  int tabIndex;
  OnChangeTabState({required this.tabIndex});
}