part of 'customer_bloc.dart';

sealed class CustomerEvent {}

class OnChangeTabEvent extends CustomerEvent {
  int tabIndex;
  OnChangeTabEvent({required this.tabIndex});
}