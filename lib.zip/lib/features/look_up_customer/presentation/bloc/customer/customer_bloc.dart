import 'package:flutter_bloc/flutter_bloc.dart';
part 'customer_event.dart';
part 'customer_state.dart';


class CustomerBloc extends Bloc<CustomerEvent, CustomerState>{

  CustomerBloc() : super(CustomerInitialState()) {
    on<OnChangeTabEvent>(_onChangeTabIndex);
  }

  void _onChangeTabIndex(OnChangeTabEvent event, Emitter emit){
    emit(OnChangeTabState(tabIndex: event.tabIndex));
  }

}