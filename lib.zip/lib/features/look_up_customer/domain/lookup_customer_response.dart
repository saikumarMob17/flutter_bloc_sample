import 'dart:convert';

LookupCustomerResponse lookupCustomerResponseFromJson(String str) => LookupCustomerResponse.fromJson(json.decode(str));

class LookupCustomerResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<LookupCustomer>? data;

  LookupCustomerResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory LookupCustomerResponse.fromJson(Map<String, dynamic> json) => LookupCustomerResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null 
    ? [] 
    : List<LookupCustomer>.from(json["data"]!.map((x) => LookupCustomer.fromJson(x))),
  );
}

class LookupCustomer {
  final String? customerId;
  final CustomerDetails? customerDetails;
  final List<OrderHistory>? orderHistory;

  LookupCustomer({
    this.customerId,
    this.customerDetails,
    this.orderHistory,
  });

  factory LookupCustomer.fromJson(Map<String, dynamic> json) => LookupCustomer(
    customerId: json["customerId"],
    customerDetails: json["customerDetails"] == null ? null : CustomerDetails.fromJson(json["customerDetails"]),
    orderHistory: json["orderHistory"] == null ? [] : List<OrderHistory>.from(json["orderHistory"]!.map((x) => OrderHistory.fromJson(x))),
  );
}

class CustomerDetails {
  final String? customerName;
  final String? customerEmail;
  final String? customerPhone;
  final String? creditCardNumber;
  final String? customerIdentity;

  CustomerDetails({
    this.customerName,
    this.customerEmail,
    this.customerPhone,
    this.creditCardNumber,
    this.customerIdentity
  });

  factory CustomerDetails.fromJson(Map<String, dynamic> json) => CustomerDetails(
    customerName: json["customerName"],
    customerEmail: json["customerEmail"],
    customerPhone: json["customerPhone"],
    creditCardNumber: json["creditCardNumber"],
    customerIdentity: json["customerIdentity"],
  );
}

class OrderHistory {
  final String? orderNumber;
  final String? orderedDate;
  final List<OrderDetailsByOrderSequence>? orderDetailsByOrderSequence;
  final BillingDetails? billingDetails;

  OrderHistory({
    this.orderNumber,
    this.orderedDate,
    this.orderDetailsByOrderSequence,
    this.billingDetails,
  });

  factory OrderHistory.fromJson(Map<String, dynamic> json) => OrderHistory(
    orderNumber: json["orderNumber"],
    orderedDate: json["orderedDate"],
    orderDetailsByOrderSequence: json["orderDetailsByOrderSequence"] == null ? [] : List<OrderDetailsByOrderSequence>.from(json["orderDetailsByOrderSequence"]!.map((x) => OrderDetailsByOrderSequence.fromJson(x))),
    billingDetails: json["billingDetails"] == null ? null : BillingDetails.fromJson(json["billingDetails"]),
  );
}

class BillingDetails {
  final double? subTotal;
  final double? discount;
  final double? tax;
  final double? tip;
  final double? grandTotal;
  final bool? paymentStatus;
  final dynamic paymentMode;

  BillingDetails({
    this.subTotal,
    this.discount,
    this.tax,
    this.tip,
    this.grandTotal,
    this.paymentStatus,
    this.paymentMode,
  });

  factory BillingDetails.fromJson(Map<String, dynamic> json) => BillingDetails(
    subTotal: json["subTotal"].toDouble(),
    discount: json["discount"].toDouble(),
    tax: json["tax"].toDouble(),
    tip: json["tip"].toDouble(),
    grandTotal: json["grandTotal"].toDouble(),
    paymentStatus: json["paymentStatus"],
    paymentMode: json["paymentMode"],
  );
}

class OrderDetailsByOrderSequence {
  final int? orderSequence;
  final bool? isFinished;
  final List<ProductDetail>? productDetails;
  final dynamic billingDetails;

  OrderDetailsByOrderSequence({
    this.orderSequence,
    this.isFinished,
    this.productDetails,
    this.billingDetails,
  });

  factory OrderDetailsByOrderSequence.fromJson(Map<String, dynamic> json) => OrderDetailsByOrderSequence(
    orderSequence: json["orderSequence"],
    isFinished: json["isFinished"],
    productDetails: json["productDetails"] == null ? [] : List<ProductDetail>.from(json["productDetails"]!.map((x) => ProductDetail.fromJson(x))),
    billingDetails: json["billingDetails"],
  );
}

class ProductDetail {
  final int? productId;
  final String? productName;
  final int? quantity;
  final double? productPrice;

  ProductDetail({
    this.productId,
    this.productName,
    this.quantity,
    this.productPrice,
  });

  factory ProductDetail.fromJson(Map<String, dynamic> json) => ProductDetail(
    productId: json["productId"],
    productName: json["productName"],
    quantity: json["quantity"],
    productPrice: json["productPrice"].toDouble(),
  );
}
