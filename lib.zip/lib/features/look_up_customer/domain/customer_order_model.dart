import 'lookup_customer_response.dart';

class CustomerOrderModel {
  String orderNumber;
  String orderDate;
  BillingDetails billingDetails;
  // bool paymentStatus;
  // double subTotal;
  // double discount;
  // double tax;
  // double tip;
  double grandTotal;
  bool orderFinished;
  int orderSequence;
  List<ProductDetail> productDetails;

  CustomerOrderModel({
    this.orderNumber = '',
    this.orderDate = '',
    required this.billingDetails,
    this.orderFinished = false,
    this.orderSequence = 0,
    this.grandTotal = 0.0,
    required this.productDetails
  });
}