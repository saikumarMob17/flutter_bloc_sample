import 'dart:convert';
import 'dart:io';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../../utils/helper.dart';
import '../domain/lookup_customer_response.dart';

class LookupCustomerRepository {

  late ApiClient _apiClient;

  LookupCustomerRepository(){
    _apiClient = ApiClient();
  }

  Future<List<LookupCustomer>> getAllLookupCustomer({required String searchQuery}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: '${EndPoints.lookupCustomer}$searchQuery');
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data = lookupCustomerResponseFromJson(response.body);
          return data.data!;
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}