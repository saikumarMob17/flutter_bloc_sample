import 'package:cliqtechnologies_retl/features/menu_reports/presentation/bloc/menu_report_state.dart';
import 'package:cliqtechnologies_retl/routes/route.dart';
import 'package:cliqtechnologies_retl/utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../../../widgets/left_navigation_screen.dart';

class MenuReportScreen extends StatefulWidget {
  const MenuReportScreen({super.key});

  @override
  State<MenuReportScreen> createState() => _MenuReportScreenState();
}

class _MenuReportScreenState extends State<MenuReportScreen> {

  var tabTitleList = [
    'Product Mix',
    'Top Groups',
    'Top Items',
    'Top Modifiers',
    'Item Details',
    'Modifier Details',
    '86 Report',
  ];

  int tabSelectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark ? AppColors.backgroundColorDark : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<MenuReportBloc, MenuReportState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Container();
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomText(
                              title: 'Menu Reports',
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              leftPadding: AppSize.s16,
                              rightPadding: AppSize.s16,
                              topPadding: AppSize.s12,
                              bottomPadding: AppSize.s12,
                              text: 'Publish Changes',
                              textColor: AppColors.primaryColor,
                              preFixWidget: const Icon(
                                AppIcons.syncIcon, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s14,
                              verPadding: AppSize.s12,
                              text: AppStrings.switchUser,
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              widget: const CustomImageView(imagePath: AppImages.menuHorizontalColor, blendMode: BlendMode.dstIn),
                              textColor: AppColors.primaryColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: AppSize.s20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                title: 'View', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'Menu')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'Last 7 Days')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Hours')],
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomText(
                                title: 'For', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Employees')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'More')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomSolidButton(
                                text: 'Select Date Range',
                                verPadding: AppSize.s6,
                                horPadding: AppSize.s10,
                                onPressed: () => debugPrint('Click here to select date range'),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to update'),
                                text: AppStrings.update,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                preFixWidget: const Icon(AppIcons.updateIcon, size: AppSize.s16),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to play'),
                                text: AppStrings.emailExport,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                widgetSpacing: AppSize.s5,
                                preFixWidget: const CustomImageView(
                                  imagePath: AppImages.emailPushIcon, 
                                  blendMode: BlendMode.dstIn
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      //Label Widget
                      Row(
                        children: [
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              width: context.screenWidth,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                children: List.generate(
                                  tabTitleList.length, 
                                  (index) => GestureDetector(
                                    onTap: () => debugPrint('Click here to change the label'),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                      margin: const EdgeInsets.only(right: AppSize.s30),
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            width: 3.0, 
                                            color: tabSelectedIndex == index ? AppColors.primaryColor : AppColors.transparent
                                          )
                                        ),
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: CustomText(
                                          title: tabTitleList[index],
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s14,
                                            color: tabSelectedIndex == index 
                                            ? AppColors.primaryColor 
                                            : Helper.isDark
                                              ? AppColors.white
                                              : AppColors.black
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s18),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                title: 'Day of Week', 
                                textStyle: getMediumStyle(
                                  color: Helper.isDark
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s20),
                              Row(
                                children: List.generate(
                                  2, 
                                  (index) {
                                    return Row(
                                      children: [
                                        const CustomCheckBox(value: false),
                                        CustomText(
                                          title: 'Show items with no sales', 
                                          fontSize: AppSize.s14,
                                          color: Helper.isDark
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                        const SizedBox(width: AppSize.s15)
                                      ],
                                    );
                                  }
                                ),
                              ),
                            ],
                          ),
                          CustomOutlinedButton(
                            onPressed: () => debugPrint('Click here to update'),
                            text: 'Show/Hide Columns',
                            topPadding: AppSize.s8,
                            bottomPadding: AppSize.s8,
                          )
                        ],
                      ),
                      const SizedBox(height: AppSize.s18),
                      ///Menu Report UI
                      Expanded(
                        child: ListView(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(AppSize.s10),
                              decoration: BoxDecoration(
                                color: Helper.isDark
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: BorderRadius.circular(AppSize.s10)
                              ),
                              child: Scrollbar(
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: Scrollbar(
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Container(
                                        width: context.screenWidth * 1.6,
                                        color: Helper.isDark 
                                        ? AppColors.contentColorDark 
                                        : AppColors.white,
                                        child: Column(
                                          children: [
                                            const Row(
                                              children: [
                                                Expanded(child: SizedBox()),
                                                Expanded(child: CustomText(title: 'Avg Price')),
                                                Expanded(child: CustomText(title: 'Item Qty')),
                                                Expanded(child: CustomText(title: 'Gross Amount')),
                                                Expanded(child: CustomText(title: 'Discount Amount')),
                                                Expanded(child: CustomText(title: 'Net Amount')),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      CustomText(title: 'Pct Quantity'),
                                                      Divider(),
                                                      Row(
                                                        children: [
                                                          Expanded(child: CustomText(title: '% Qty (Group)')),
                                                          Expanded(child: CustomText(title: '% Qty (Menu)')),
                                                          Expanded(child: CustomText(title: '% Qty (All)')),
                                                        ],
                                                      )
                                                    ],
                                                  )
                                                ),
                                                SizedBox(width: AppSize.s5),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      CustomText(title: 'Pct Net \$\$'),
                                                      Divider(),
                                                      Row(
                                                        children: [
                                                          Expanded(child: CustomText(title: '% Net Amt(Group)')),
                                                          Expanded(child: CustomText(title: '% Net Amt(Menu)', textAlign: TextAlign.center)),
                                                          Expanded(child: CustomText(title: '% Net Amt(All)', textAlign: TextAlign.end)),
                                                        ],
                                                      )
                                                    ],
                                                  )
                                                ),
                                              ],
                                            ),
                                            const Divider(),
                                            Container(
                                              padding: const EdgeInsets.symmetric(vertical: AppSize.s4),
                                              child: const Row(
                                                children: [
                                                  Expanded(child: CustomText(title: 'ALL MENUS')),
                                                  Expanded(child: CustomText(title: '\$148.33')),
                                                  Expanded(child: CustomText(title: '252')),
                                                  Expanded(child: CustomText(title: '\$38,628.25')),
                                                  Expanded(child: CustomText(title: '\$0.00')),
                                                  Expanded(child: CustomText(title: '0.0%')),
                                                  Expanded(child: CustomText(title: '')),
                                                  Expanded(child: CustomText(title: '')),
                                                ],
                                              )
                                            ),
                                            const Divider(),
                                            Column(
                                              children: List.generate(
                                                50, 
                                                (index) {
                                                  return Container(
                                                    color: Helper.isDark
                                                    ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                    : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s6, horizontal: AppSize.s2),
                                                    child: const Row(
                                                      children: [
                                                        Expanded(child: CustomText(title:  'Dom Perignon Brut')),
                                                        Expanded(child: CustomText(title:  '0')),
                                                        Expanded(child: CustomText(title:  '\$0.00')),
                                                        Expanded(child: CustomText(title:  '\$0.00')),
                                                        Expanded(child: CustomText(title:  '\$0.00')),
                                                        Expanded(child: CustomText(title:  '0.0%')),
                                                        Expanded(
                                                          child: Row(
                                                            children: [
                                                              Expanded(child: CustomText(title:  '\$0.00')),
                                                              Expanded(child: CustomText(title:  '\$0.00')),
                                                              Expanded(child: CustomText(title:  '\$0.00'))
                                                            ],
                                                          ),
                                                        ),
                                                        Expanded(
                                                          child: Row(
                                                            children: [
                                                              Expanded(child: CustomText(title:  '\$0.00')),
                                                              Expanded(child: CustomText(title:  '\$0.00', textAlign: TextAlign.center)),
                                                              Expanded(child: CustomText(title:  '\$0.00', textAlign: TextAlign.end))
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  );
                                                }
                                              )
                                            )
                                          ],
                                        )
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

}