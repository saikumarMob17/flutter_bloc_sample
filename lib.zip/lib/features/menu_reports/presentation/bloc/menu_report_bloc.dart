import 'package:cliqtechnologies_retl/features/menu_reports/presentation/bloc/menu_report_event.dart';
import 'package:cliqtechnologies_retl/features/menu_reports/presentation/bloc/menu_report_state.dart';
import 'package:cliqtechnologies_retl/routes/route.dart';

class MenuReportBloc extends Bloc<MenuReportEvent, MenuReportState>{

  MenuReportBloc() : super(MenuReportInitialState());
}