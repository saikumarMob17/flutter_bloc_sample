sealed class MenuReportState {}

class MenuReportInitialState extends MenuReportState {}