import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_dropdown_widget.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/dropdownmenu_model.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import 'bloc/sales_report_bloc.dart';
import 'bloc/sales_report_state.dart';
import '../../../widgets/custom_checkbox.dart';

class SalesReportScreen extends StatefulWidget {

  const SalesReportScreen({super.key});

  @override
  State createState() => _SalesReportScreenState();

}

class _SalesReportScreenState extends State<SalesReportScreen> {

  var tabTitleList = [
    'Sales Report',
    'Orders',
    'Order Details',
    'Payments',
    'Shifts',
    'Cash Activity Audit',
    'Cash Drawer History'
  ];

  int tabSelectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark ? AppColors.backgroundColorDark : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<SalesReportBloc, SalesReportState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.salesReport,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to menu screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomText(
                title: 'View', 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16,
                  color: Helper.isDark 
                  ? AppColors.white
                  : AppColors.black
                )
              ),
              const SizedBox(width: AppSize.s10),
              Expanded(
                child: SizedBox(
                  height: AppSize.s50,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    children: [
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'Sales')], 
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      ),
                      const SizedBox(width: AppSize.s8),
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'Last 7 Days')], 
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      ),
                      const SizedBox(width: AppSize.s8),
                      CustomDropdownWidget(
                        items: [DropdownMenuModel(value: '0', item: 'All Hours')],
                        verPad: AppSize.s6,
                        borderColor: AppColors.primaryColor,
                        value: '0',
                        onChange: (value) => debugPrint('Click here to change'),
                      )
                    ],
                  )
                ),
              )
            ],
          ),
          const SizedBox(height: AppSize.s2),
          Row(
            children: [
              CustomText(
                title: 'For', 
                textStyle: getMediumStyle(
                  fontSize: AppSize.s16,
                  color: Helper.isDark 
                  ? AppColors.white
                  : AppColors.black
                ),
              ),
              const SizedBox(width: AppSize.s10),
              CustomDropdownWidget(
                items: [DropdownMenuModel(value: '0', item: 'All Employees')], 
                verPad: AppSize.s6,
                borderColor: AppColors.primaryColor,
                value: '0',
                onChange: (value) => debugPrint('Click here to change'),
              ),
              const SizedBox(width: AppSize.s8),
              CustomDropdownWidget(
                items: [DropdownMenuModel(value: '0', item: 'More')], 
                borderColor: AppColors.primaryColor,
                verPad: AppSize.s6,
                value: '0',
                onChange: (value) => debugPrint('Click here to change'),
              )
            ],
          ),
          const SizedBox(height: AppSize.s10),
          SizedBox(
            height: 44,
            width: context.screenWidth,
            child: ListView(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              children: List.generate(
                tabTitleList.length, 
                (index) {
                  var data = tabTitleList[index];
                  return GestureDetector(
                    // onTap: () => bContext.read<OrdersBloc>().add(OrdersChangeDropDownEvent(
                    //   selectedValue: drinkOption[index].value, 
                    //   selectedIndex: index)),
                    // onTap: () => debugPrint('Click here to change tab'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                      margin: const EdgeInsets.only(right: AppSize.s20),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            width: 3.0, 
                            color: tabSelectedIndex == index 
                            ? AppColors.primaryColor 
                            : AppColors.transparent
                          ),
                        ),
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: CustomText(
                          title: data,
                          textStyle: getMediumStyle(
                            color: tabSelectedIndex == index 
                            ? AppColors.primaryColor 
                            : Helper.isDark
                              ? AppColors.white
                              : AppColors.black,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: AppSize.s10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: tabTitleList[tabSelectedIndex],
                textStyle: getMediumStyle(fontSize: AppSize.s16),
              ),
              CustomOutlinedButton(
                onPressed: () => debugPrint('Click here to update'),
                text: "Filter",
                topPadding: AppSize.s8,
                bottomPadding: AppSize.s8,
                preFixWidget: const Icon(AppIcons.updateIcon, size: AppSize.s16),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s10),
          Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      6, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Net Sales"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Tax Rate"),
                              CustomText(title: "Tax Amount"),
                              CustomText(title: "Net Sales")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Discount"),
                              CustomText(title: "Count"),
                              CustomText(title: "Amount")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      3, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Gross Sales"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Services"),
                              CustomText(title: "Orders"),
                              CustomText(title: "Net Sales")
                            ],
                          ),
                        );
                      }
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      5, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Void Amount"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      8, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Expected Closeout Cash"),
                              CustomText(title: "\$22,782.25")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      2, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Cash Before Tipouts"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.all(AppSize.s8),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(AppSize.s10)
                  ),
                  child: Column(
                    children: List.generate(
                      7, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s2),
                          color: index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(title: "Net Sales"),
                              CustomText(title: "\$0.00")
                            ],
                          ),
                        );
                      }
                    )
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }


  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomText(
                              title: AppStrings.salesReport,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22,
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              leftPadding: AppSize.s16,
                              rightPadding: AppSize.s16,
                              topPadding: AppSize.s12,
                              bottomPadding: AppSize.s12,
                              text: AppStrings.publishChanges,
                              textColor: AppColors.primaryColor,
                              preFixWidget: const Icon(
                                AppIcons.syncIcon, 
                                color: AppColors.primaryColor
                              ),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s14,
                              verPadding: AppSize.s12,
                              text: AppStrings.switchUser,
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              widget: const CustomImageView(
                                imagePath: AppImages.menuHorizontalColor,
                                blendMode: BlendMode.dstIn
                              ),
                              textColor: AppColors.primaryColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: AppSize.s20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                title: 'View', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark 
                                  ? AppColors.white
                                  : AppColors.black
                                )
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'Sales')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'Last 7 Days')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Hours')],
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomText(
                                title: 'For', 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s16,
                                  color: Helper.isDark 
                                  ? AppColors.white
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'All Employees')], 
                                verPad: AppSize.s6,
                                borderColor: AppColors.primaryColor,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              ),
                              const SizedBox(width: AppSize.s8),
                              CustomDropdownWidget(
                                items: [DropdownMenuModel(value: '0', item: 'More')], 
                                borderColor: AppColors.primaryColor,
                                verPad: AppSize.s6,
                                value: '0',
                                onChange: (value) => debugPrint('Click here to change'),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to update'),
                                text: AppStrings.update,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                preFixWidget: const Icon(AppIcons.updateIcon, size: AppSize.s16),
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomOutlinedButton(
                                onPressed: () => debugPrint('Click here to play'),
                                text: AppStrings.emailExport,
                                topPadding: AppSize.s8,
                                bottomPadding: AppSize.s8,
                                widgetSpacing: AppSize.s5,
                                preFixWidget: const CustomImageView(
                                  imagePath: AppImages.emailPushIcon, 
                                  blendMode: BlendMode.dstIn
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20, vertical: AppSize.s20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              width: context.screenWidth,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                // padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                                children: List.generate(
                                  tabTitleList.length, 
                                  (index) => GestureDetector(
                                    //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                      margin: const EdgeInsets.only(right: AppSize.s30),
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSide(
                                            width: 3.0, 
                                            color: tabSelectedIndex == index 
                                            ? AppColors.primaryColor 
                                            : AppColors.transparent
                                          ),
                                        ),
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: CustomText(
                                          title: tabTitleList[index],
                                          textStyle: getMediumStyle(
                                            fontSize: AppSize.s14,
                                            color: tabSelectedIndex == index 
                                            ? AppColors.primaryColor 
                                            : Helper.isDark 
                                              ? AppColors.white
                                              : AppColors.black
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: AppSize.s20),
                        child: CustomText(
                          title: AppStrings.salesSummary, 
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16,
                            color: Helper.isDark 
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                title: 'Day of Week',
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                              const SizedBox(width: AppSize.s20),
                              Row(
                                children: List.generate(
                                  7, 
                                  (index) {
                                    return Row(
                                      children: [
                                        const CustomCheckBox(value: false),
                                        CustomText(title: 'Mon', color: Helper.isDark ? AppColors.white : AppColors.black),
                                        const SizedBox(width: AppSize.s15)
                                      ],
                                    );
                                  }
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              CustomText(
                                title: AppStrings.orderAmount, 
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                              const SizedBox(width: AppSize.s15),
                              Row(
                                children: List.generate(
                                  11, 
                                  (index) {
                                    return Row(
                                      children: [
                                        const CustomCheckBox(value: false),
                                        CustomText(
                                          title: '5', 
                                          color: Helper.isDark 
                                          ? AppColors.white
                                          : AppColors.black
                                        ),
                                        const SizedBox(width: AppSize.s15)
                                      ],
                                    );
                                  }
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s10),
                      Row(
                        children: [
                          CustomText(
                            title: AppStrings.timeOfDay, 
                            color: Helper.isDark 
                            ? AppColors.white
                            : AppColors.black
                          ),
                          const SizedBox(width: AppSize.s15),
                          Row(
                            children: List.generate(
                              7, 
                              (index) {
                                return Row(
                                  children: [
                                    const CustomCheckBox(value: false),
                                    CustomText(
                                      title: 'Mon',
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                    const SizedBox(width: AppSize.s15)
                                  ],
                                );
                              }
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSize.s20),
                      ///Report UI
                      Expanded(
                        child: ListView(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: ListView(
                                    shrinkWrap: true,
                                    physics: const NeverScrollableScrollPhysics(),
                                    children: [
                                      Expanded(
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s10),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark 
                                            ? AppColors.contentColorDark 
                                            : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s10)
                                          ),
                                          child: Column(
                                            children: List.generate(
                                              10, 
                                              (index) {
                                                return Container(
                                                  padding: const EdgeInsets.symmetric(
                                                    vertical: AppSize.s5, 
                                                    horizontal: AppSize.s4
                                                  ),
                                                  color: Helper.isDark
                                                  ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                  : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      CustomText(
                                                        title: AppStrings.netSales,
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                      CustomText(
                                                        title: '\$0.00',
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s20),
                                      Expanded(
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s10),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark 
                                            ? AppColors.contentColorDark 
                                            : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s10)
                                          ),
                                          child: Column(
                                            children: List.generate(
                                              2, 
                                              (index) {
                                                return Container(
                                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s4),
                                                  color: Helper.isDark
                                                  ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                  : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      CustomText(
                                                        title: AppStrings.netSales,
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                      CustomText(
                                                        title: '\$0.00',
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s20),
                                      Expanded(
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s10),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark 
                                            ? AppColors.contentColorDark 
                                            : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s10)
                                          ),
                                          child: Column(
                                            children: List.generate(
                                              3, 
                                              (index) {
                                                return Container(
                                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s4),
                                                  color: Helper.isDark
                                                  ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                  : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      CustomText(
                                                        title: AppStrings.netSales,
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                      CustomText(
                                                        title: '\$0.00',
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: AppSize.s20),
                                Expanded(
                                  child: ListView(
                                    shrinkWrap: true,
                                    physics: const NeverScrollableScrollPhysics(),
                                    children: [
                                      Expanded(
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s10),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark 
                                            ? AppColors.contentColorDark 
                                            : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s10)
                                          ),
                                          child: Column(
                                            children: List.generate(
                                              10, 
                                              (index) {
                                                return Container(
                                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s4),
                                                  color: Helper.isDark
                                                  ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                  : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      CustomText(
                                                        title: AppStrings.netSales,
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                      CustomText(
                                                        title: '\$0.00',
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s20),
                                      Expanded(
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s10),
                                          decoration: BoxDecoration(
                                            color: Helper.isDark 
                                            ? AppColors.contentColorDark 
                                            : AppColors.white,
                                            borderRadius: BorderRadius.circular(AppSize.s10)
                                          ),
                                          child: Column(
                                            children: List.generate(
                                              10, 
                                              (index) {
                                                return Container(
                                                  padding: const EdgeInsets.symmetric(vertical: AppSize.s5, horizontal: AppSize.s4),
                                                  color: Helper.isDark
                                                  ? index%2 == 0 ? AppColors.backgroundColorDark : AppColors.transparent
                                                  : index%2 == 0 ? AppColors.backgroundColor : AppColors.transparent,
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      CustomText(
                                                        title: AppStrings.netSales,
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                      CustomText(
                                                        title: '\$0.00',
                                                        color: Helper.isDark
                                                        ? AppColors.white
                                                        : AppColors.black,
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            )
                          ],
                        )
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}