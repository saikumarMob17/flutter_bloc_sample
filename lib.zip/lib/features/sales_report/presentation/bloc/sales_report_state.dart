sealed class SalesReportState {}

class SalesReportInitialState extends SalesReportState {}