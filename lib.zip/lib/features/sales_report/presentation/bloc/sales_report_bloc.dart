import 'package:cliqtechnologies_retl/features/sales_report/presentation/bloc/sales_report_event.dart';
import 'package:cliqtechnologies_retl/features/sales_report/presentation/bloc/sales_report_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SalesReportBloc extends Bloc<SalesReportEvent, SalesReportState>{

  SalesReportBloc() : super(SalesReportInitialState());
}