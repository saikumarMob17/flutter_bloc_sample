import 'dart:io';

import 'package:cliqtechnologies_retl/constants/app_strings.dart';
import 'package:cliqtechnologies_retl/features/employee_shift/domain/employee_shift_details_response.dart';
import 'package:cliqtechnologies_retl/network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../../utils/helper.dart';

class ShiftDetailsRepository {

  late ApiClient _apiClient;

  ShiftDetailsRepository(){
    _apiClient = ApiClient();
  }

  Future<Data?> getEmployeeShiftDetails({required String userId}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.employeeShiftDetails}?id=$userId");
      switch (response.statusCode) {
        case HttpStatus.ok:
          var data = employeeShiftDetailsResponseFromJson(response.body);
          return data.data;
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch(e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}