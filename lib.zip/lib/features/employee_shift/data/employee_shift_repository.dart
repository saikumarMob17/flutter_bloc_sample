import 'dart:io';
import '../../../network/api/api_client.dart';
import '../../../routes/route.dart';
import '../../../network/custom_exception.dart';
import '../domain/employee_shift_response.dart';

class EmployeeShiftRepository {

  late ApiClient _apiClient;

  EmployeeShiftRepository(){
    _apiClient = ApiClient();
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<EmployeeShifts>> getEmployeeShiftDetails({required String date}) async {
    try {
      ///date format: “yyyy-mm-dd”
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.allShiftDetails}?date=$date");
      switch (response.statusCode) {
        case HttpStatus.ok:
          var data = employeeShiftResponseFromJson(response.body);
          var employeeList = <EmployeeShifts>[];
          for(var item in data.data) {
            if(Preferences.getString(key: AppStrings.prefUserRole) == 'Server' || Preferences.getString(key: AppStrings.prefUserRole) == 'Cashier') {
              if(item.employeeId ==  Preferences.getString(key: AppStrings.prefUserId)){
                employeeList.add(item);
              }
            } else {
              employeeList.add(item);
            }
          }
          return employeeList;
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch(e) {
      throw CustomException(message: e.message);
    }
  }
}