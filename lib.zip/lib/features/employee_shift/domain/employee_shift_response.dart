// To parse this JSON data, do
//
//     final employeeShiftResponse = employeeShiftResponseFromJson(jsonString);

import 'dart:convert';

EmployeeShiftResponse employeeShiftResponseFromJson(String str) => EmployeeShiftResponse.fromJson(json.decode(str));


class EmployeeShiftResponse {
    final int? statusCode;
    final String? status;
    final String? message;
    final List<EmployeeShifts> data;

    EmployeeShiftResponse({
        this.statusCode,
        this.status,
        this.message,
        required this.data,
    });

    factory EmployeeShiftResponse.fromJson(Map<String, dynamic> json) => EmployeeShiftResponse(
        statusCode: json["statusCode"],
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? [] : List<EmployeeShifts>.from(json["data"]!.map((x) => EmployeeShifts.fromJson(x))),
    );
}

class EmployeeShifts {
    final DateTime? date;
    final String? employeeId;
    final String? employeeName;
    final double? totalPayments;
    final double? cashInHand;
    final double? tipAmount;

    EmployeeShifts({
        this.date,
        this.employeeId,
        this.employeeName,
        this.totalPayments,
        this.cashInHand,
        this.tipAmount,
    });

    factory EmployeeShifts.fromJson(Map<String, dynamic> json) => EmployeeShifts(
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        employeeId: json["employeeId"],
        employeeName: json["employeeName"] ?? '',
        totalPayments: json["totalPayments"]?.toDouble(),
        cashInHand: json["cashInHand"]?.toDouble(),
        tipAmount: json["tipAmount"]?.toDouble(),
    );
}
