import 'dart:convert';

EmployeeShiftDetailsResponse employeeShiftDetailsResponseFromJson(String str) => EmployeeShiftDetailsResponse.fromJson(json.decode(str));


class EmployeeShiftDetailsResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final Data? data;

  EmployeeShiftDetailsResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory EmployeeShiftDetailsResponse.fromJson(Map<String, dynamic> json) => EmployeeShiftDetailsResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );
}

class Data {
  final String? employeeName;
  final String? location;
  final String? role;
  final List<EmployeeShiftDetails>? data;

  Data({
    this.employeeName,
    this.location,
    this.role,
    this.data
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    employeeName: json["employeeName"],
    location: json["location"],
    role: json["role"],
    data: json["shiftDetailHistoryByOrders"] == null ? [] : List<EmployeeShiftDetails>.from(json["shiftDetailHistoryByOrders"]!.map((x) => EmployeeShiftDetails.fromJson(x))),
  );
}

class EmployeeShiftDetails {
  final DateTime? date;
  final String? orderId;
  final String? orderNumber;
  final double? totalPayments;
  final double? cashInHand;
  final double? tipAmount;

  EmployeeShiftDetails({
    this.date,
    this.orderId,
    this.orderNumber,
    this.totalPayments,
    this.cashInHand,
    this.tipAmount,
  });

  factory EmployeeShiftDetails.fromJson(Map<String, dynamic> json) => EmployeeShiftDetails(
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    orderId: json["orderId"],
    orderNumber: json["orderNumber"],
    totalPayments: json["totalPayments"]?.toDouble(),
    cashInHand: json["cashInHand"]?.toDouble(),
    tipAmount: json["tipAmount"]?.toDouble(),
  );
}
