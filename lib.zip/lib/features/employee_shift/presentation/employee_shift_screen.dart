import 'package:cliqtechnologies_retl/constants/app_icons.dart';
import 'package:cliqtechnologies_retl/utils/shared_pref.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'employee_shift_receipt_widget.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/custom_empty_widget.dart';
import 'bloc/employee_shifts/employee_shift_bloc.dart';
import '../domain/employee_shift_response.dart';

class EmployeeShiftScreen extends StatefulWidget {
  const EmployeeShiftScreen({super.key});

  @override
  State createState() => _EmployeeShiftScreenState();
}

class _EmployeeShiftScreenState extends State<EmployeeShiftScreen> with Helper {

  var titleList = [
    AppStrings.employee,
    AppStrings.totalPayments,
    AppStrings.cashInHand,
    AppStrings.tip
  ];

  List<EmployeeShifts> employeeShiftList = [];
  bool isLoading = true;
  DateTime filterDate = DateTime.now();
  late EmployeeShiftBloc _employeeShiftBloc;

  @override
  void initState() {
    _employeeShiftBloc = context.read<EmployeeShiftBloc>();
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<EmployeeShiftBloc, EmployeeShiftState>(
        builder: (context, state) {
          switch (state) {
            case EmployeeShiftListState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              employeeShiftList.clear();
              employeeShiftList.addAll(state.employeeShiftList);
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints) {
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case EmployeeShiftLoadingState _:
              showLoadingDialog(context: context);
              break;
            case EmployeeShiftFailedState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              if(state.message.isNotEmpty) {
                showSnackBar(context: context, title: state.message);
              }
              break;
            case OnSwitchUserEmployeeShiftState _:
              isLoading = false;
              hideLoadingDialog(context: context);
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(AppIcons.arrowBack)
                  ),
                  CustomText(
                    title: AppStrings.reviewEmployeeShift,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18, 
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => _employeeShiftBloc.add(OnSwitchUserShiftReviewEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s8),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => showMoreOption(context: context),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          employeeShiftList.isEmpty
          ? Expanded(
            child: CustomEmptyWidget(
              imagePath: AppImages.notFound, 
              emptyTitle: AppStrings.noRecordFound, 
              isVisible: !isLoading
            ))
          : Expanded(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: AppSize.s10),
                  child: CustomTextField(
                    hint: AppStrings.searchHere,
                    prefixImagePath: AppImages.searchIcon,
                    prefixImageColor: AppColors.lightGrey,
                    horPadding: AppSize.s12,
                    verPadding: AppSize.s12,
                    onChange: (value) => _employeeShiftBloc.add(EmployeeShiftSearchEmployeeEvent(name: value)),
                  ),
                ),
                const SizedBox(height: AppSize.s10),
                Expanded(
                  child: ListView.builder(
                    itemCount: employeeShiftList.length,
                    shrinkWrap: true,
                    itemBuilder: (_, index) {
                      var data = employeeShiftList[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: AppSize.s10),
                        padding: const EdgeInsets.symmetric(
                          vertical: AppSize.s10,
                          horizontal: AppSize.s15
                        ),
                        decoration: BoxDecoration(
                          color: Helper.isDark
                          ? AppColors.contentColorDark
                          : AppColors.white,
                          borderRadius: BorderRadius.circular(AppSize.s10)
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: AppStrings.employee, 
                                  textStyle: getMediumStyle(
                                    color: AppColors.primaryColor
                                  ),
                                ),
                                Row(
                                  children: [
                                    CustomText(
                                      title: data.employeeName!, 
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark
                                        ? AppColors.white
                                        : AppColors.black
                                      ),
                                    ),
                                    const SizedBox(width: AppSize.s8),
                                    InkWell(
                                      onTap: () => context.push(AppRoutes.shiftDetailsScreen, extra: data.employeeId),
                                      child: const Icon(Icons.open_in_new, color: AppColors.primaryColor, size: AppSize.s20),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(height: AppSize.s10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: AppStrings.totalPayments, 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: '\$${data.totalPayments!.roundTwo}', 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: AppSize.s10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: AppStrings.cashInHand, 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: '\$${data.cashInHand!.roundTwo}', 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: AppSize.s10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: 'CC Tip', 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: '\$${data.tipAmount!.roundTwo}', 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }


  void showMoreOption({required BuildContext context}) {
    final width = context.screenWidth;
    final height = context.screenHeight;
    showMenu(
      context: context, 
      position: RelativeRect.fromLTRB(
        width * 0.50, 
        height * 0.12, 
        width * 0.015, 
        10
      ),
      items: [
        PopupMenuItem<int>(
          value: 3,
          child: const Text('Change Date'),
          onTap: () => showDatePickerDialog(context),
        ),
      ]
    );
  }


  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s18),
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(AppIcons.arrowBack)
                        ),
                        CustomText(
                          title: AppStrings.reviewEmployeeShift,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20,
                            color: Helper.isDark
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: context.screenWidth * 0.15,
                          child: CustomTextField(
                            hint: AppStrings.searchHere,
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.lightTextGrey,
                            verPadding: 9,
                            horPadding: AppSize.s14,
                            prefixImageSize: AppSize.s16,
                            onChange: (value) => _employeeShiftBloc.add(EmployeeShiftSearchEmployeeEvent(name: value)),
                          ),
                        ),
                        const SizedBox(width: AppSize.s8),
                        CustomOutlinedButton(
                          onPressed: () => showDatePickerDialog(context),
                          text: 'Filter to Today',
                          topPadding: AppSize.s18,
                          bottomPadding: AppSize.s18,
                          textColor: AppColors.blue,
                        ),
                        const SizedBox(width: AppSize.s8),
                        CustomSolidButton(
                          onPressed: () => _employeeShiftBloc.add(OnSwitchUserShiftReviewEvent()),
                          text: AppStrings.switchUser,
                          prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                        ),
                        // const SizedBox(width: AppSize.s10),
                        // CustomIconButton(
                        //   onPressed: () => debugPrint(''),
                        //   horPadding: AppSize.s14,
                        //   verPadding: AppSize.s12,
                        //   widget: const CustomImageView(imagePath: AppImages.notificationColor, blendMode: BlendMode.dstIn),
                        // ),
                        // const SizedBox(width: AppSize.s10),
                        // CustomIconButton(
                        //   onPressed: () => debugPrint(''),
                        //   horPadding: AppSize.s10,
                        //   verPadding: AppSize.s10,
                        //   widget: const CustomImageView(imagePath: AppImages.menuHorizontalColor, blendMode: BlendMode.dstIn),
                        // ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(
                  left: AppSize.s40,
                  right: AppSize.s20,
                  top: AppSize.s25,
                  bottom: AppSize.s10
                ),
                color: Helper.isDark
                ? AppColors.backgroundColorDark
                : AppColors.white,
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: CustomText(
                        title: AppStrings.employee,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: AppStrings.totalPayments,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: AppStrings.cashInHand,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: AppStrings.tip,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: AppStrings.print,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: employeeShiftList.isEmpty 
                ? CustomEmptyWidget(
                    imagePath: AppImages.notFound, 
                    emptyTitle: AppStrings.noRecordFound, 
                    isVisible: !isLoading
                  )
                : ListView.builder(
                  shrinkWrap: true,
                  itemCount: employeeShiftList.length,
                  itemBuilder: (_, index){
                    var data = employeeShiftList[index];
                    return Container(
                      padding: const EdgeInsets.only(
                        left: AppSize.s40,
                        right: AppSize.s20,
                        top: AppSize.s12,
                        bottom: AppSize.s12
                      ),
                      color: Helper.isDark
                      ? index%2 == 0 ? AppColors.contentColorDark : AppColors.transparent
                      : index%2 == 0 ? AppColors.backgroundColor : AppColors.white,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: CustomText(
                              title: data.employeeName!,
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: Helper.isDark
                                ? AppColors.lightGrey
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '\$${(data.totalPayments! + data.tipAmount!).roundTwo}',
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: Helper.isDark
                                ? AppColors.lightGrey
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '\$${data.cashInHand!.roundTwo}',
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: Helper.isDark
                                ? AppColors.lightGrey
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: Row(
                              children: [
                                CustomText(
                                  title: '\$${data.tipAmount!.roundTwo}',
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark
                                    ? AppColors.lightGrey
                                    : AppColors.black
                                  ),
                                ),
                                const SizedBox(width: AppSize.s20),
                                InkWell(
                                  onTap: () => context.push(AppRoutes.shiftDetailsScreen, extra: data.employeeId),
                                  child: const Icon(Icons.open_in_new, color: AppColors.blue, size: AppSize.s22,),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: InkWell(
                                onTap: () => showEmployeeShiftDialog(context: context),
                                child: const Icon(Icons.print, color: AppColors.blue, size: AppSize.s22),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> showDatePickerDialog(BuildContext context) async {
    var tempDate = await showDatePicker(
      context: context, 
      initialDate: filterDate,
      firstDate: DateTime.parse('2012-02-27'), 
      lastDate: DateTime.now(),
    );
    if(tempDate != null && context.mounted){
      filterDate = tempDate;
      context.read<EmployeeShiftBloc>().add(EmployeeShiftFilterByDateEvent(date: tempDate));
    }
  }

  showEmployeeShiftDialog({required BuildContext context}) {
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: const EmployeeShiftReceiptWidget(),
        );
      }
    );
  }

}