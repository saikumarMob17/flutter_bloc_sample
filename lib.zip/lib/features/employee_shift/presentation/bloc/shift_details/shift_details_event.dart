part of 'shift_details_bloc.dart';

sealed class ShiftDetailsEvent {}

class FetchShiftDetailsEvent extends ShiftDetailsEvent {}

class ShiftDetailsSwitchUserEvent extends ShiftDetailsEvent {}