part of 'shift_details_bloc.dart';

sealed class ShiftDetailsState {}

class ShiftDetailsInitialState extends ShiftDetailsState {}

class ShiftDetailsLoadingState extends ShiftDetailsState {}

class ShiftDetailsFailedState extends ShiftDetailsState {
  String message;
  ShiftDetailsFailedState({this.message = ''});
}

class FetchShiftDetailsState extends ShiftDetailsState {
  String employeeName;
  String employeeLocation;
  String employeeRole;
  List<EmployeeShiftDetails> employeeShiftDetails = [];

  FetchShiftDetailsState({
    required this.employeeShiftDetails, 
    this.employeeName = '', 
    this.employeeLocation = '', 
    this.employeeRole = ''
  });
}

class OnSwitchUserShiftDetailsState extends ShiftDetailsState {
  bool isLogout;
  OnSwitchUserShiftDetailsState({this.isLogout = false});
}