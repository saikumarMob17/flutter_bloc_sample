import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../constants/app_strings.dart';
import '../../../data/shift_details_repository.dart';
import '../../../../../utils/check_connectivity.dart';
import '../../../../../network/custom_exception.dart';
import '../../../domain/employee_shift_details_response.dart';
part 'shift_details_event.dart';
part 'shift_details_state.dart';

class ShiftDetailsBloc extends Bloc<ShiftDetailsEvent, ShiftDetailsState>{

  late ShiftDetailsRepository _repository;
  late CheckConnectivity _checkConnectivity;
  List<EmployeeShiftDetails> employeeShiftDetails = [];
  late String employeeId;

  ShiftDetailsBloc({required this.employeeId}) : super(ShiftDetailsInitialState()){
    _repository = ShiftDetailsRepository();
    _checkConnectivity = CheckConnectivity();
    on<FetchShiftDetailsEvent>(_fetchShiftDetails);
    on<ShiftDetailsSwitchUserEvent>(_onClockOutUser);
  }

  Future<void> _fetchShiftDetails(FetchShiftDetailsEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(ShiftDetailsLoadingState());
        var data = await _repository.getEmployeeShiftDetails(userId: employeeId);
        String name = '';
        String location = '';
        String role = '';
        if(data != null) {
          name = data.employeeName!;
          location = data.location!;
          role = data.role!;
          employeeShiftDetails.clear();
          employeeShiftDetails.addAll(data.data!);
          employeeShiftDetails.sort((a,b) => b.date!.compareTo(a.date!));
        }
        emit(FetchShiftDetailsState(
          employeeShiftDetails: employeeShiftDetails, 
          employeeLocation: location, 
          employeeName: name, 
          employeeRole: role
        ));
      } on CustomException catch (e) {
        emit(ShiftDetailsFailedState(message: e.message));
      }
    } else {
      emit(ShiftDetailsFailedState(message: AppStrings.noInternetConnection));
    }
  }

  Future<void> _onClockOutUser(ShiftDetailsSwitchUserEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(ShiftDetailsLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserShiftDetailsState(isLogout: response));
      } on CustomException catch (e) {
        emit(ShiftDetailsFailedState(message: e.message));
      }
    }
  }
}