part of 'employee_shift_bloc.dart';

sealed class EmployeeShiftEvent {}

class OnSwitchUserShiftReviewEvent extends EmployeeShiftEvent {}

class EmployeeShiftListEvent extends EmployeeShiftEvent {}

class EmployeeShiftSearchEmployeeEvent extends EmployeeShiftEvent {
  String name;

  EmployeeShiftSearchEmployeeEvent({this.name = ''});
}

class EmployeeShiftFilterByDateEvent extends EmployeeShiftEvent {
  DateTime date;
  EmployeeShiftFilterByDateEvent({required this.date});
}