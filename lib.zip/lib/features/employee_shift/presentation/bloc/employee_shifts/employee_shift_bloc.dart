import '../../../data/employee_shift_repository.dart';
import '../../../../../utils/check_connectivity.dart';
import '../../../../../network/custom_exception.dart';
import '../../../domain/employee_shift_response.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'employee_shift_event.dart';
part 'employee_shift_state.dart';


class EmployeeShiftBloc extends Bloc<EmployeeShiftEvent, EmployeeShiftState> {

  late CheckConnectivity _checkConnectivity;
  late EmployeeShiftRepository _repository;
  List<EmployeeShifts> employeeShiftList = [];
  List<EmployeeShifts> originalEmployeeShiftList = [];
  late DateTime todayDate;
  
  EmployeeShiftBloc() : super(EmployeeShiftInitialState()) {
    todayDate = DateTime.now();
    _checkConnectivity = CheckConnectivity();
    _repository = EmployeeShiftRepository();
    on<OnSwitchUserShiftReviewEvent>(_onSwitchUser);
    on<EmployeeShiftListEvent>(_fetchEmployeeShiftDetails);
    on<EmployeeShiftSearchEmployeeEvent>(_onSearchEmployee);
    on<EmployeeShiftFilterByDateEvent>(_filterEmployeeShift);
  }

  Future<void> _onSwitchUser(OnSwitchUserShiftReviewEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(EmployeeShiftLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserEmployeeShiftState(isLogout: response));
      } on CustomException catch (e) {
        emit(EmployeeShiftFailedState(message: e.message));
      }
    }
  }

  void _filterEmployeeShift(EmployeeShiftFilterByDateEvent event, Emitter emit){
    todayDate = event.date;
    add(EmployeeShiftListEvent());
  }

  Future<void> _fetchEmployeeShiftDetails(EmployeeShiftListEvent event, Emitter emit) async { 
    try {
      var tempDate = todayDate.toString().substring(0, 10);
      emit(EmployeeShiftLoadingState());
      var data = await _repository.getEmployeeShiftDetails(date: tempDate);
      employeeShiftList.clear();
      originalEmployeeShiftList.clear();
      employeeShiftList.addAll(data);
      originalEmployeeShiftList.addAll(data);
      emit(EmployeeShiftListState(employeeShiftList: employeeShiftList));
    } on CustomException catch (e) {
      emit(EmployeeShiftFailedState(message: e.message));
    }
  }

  void _onSearchEmployee(EmployeeShiftSearchEmployeeEvent event, Emitter emit) {
    employeeShiftList.clear();
    if(event.name.isEmpty){
      employeeShiftList.addAll(originalEmployeeShiftList);
    } else {
      for(var item in originalEmployeeShiftList){
        if(item.employeeName!.toLowerCase().contains(event.name.toLowerCase())){
          employeeShiftList.add(item);
        }
      }
    }
    emit(EmployeeShiftListState(employeeShiftList: employeeShiftList));
  }
}