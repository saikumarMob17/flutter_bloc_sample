part of 'employee_shift_bloc.dart';

sealed class EmployeeShiftState {}

class EmployeeShiftInitialState extends EmployeeShiftState {}

class EmployeeShiftLoadingState extends EmployeeShiftState {}

class EmployeeShiftFailedState extends EmployeeShiftState {
  String message;
  EmployeeShiftFailedState({this.message = ''});
}

class OnSwitchUserEmployeeShiftState extends EmployeeShiftState {
  bool isLogout;
  OnSwitchUserEmployeeShiftState({this.isLogout = false});
}

class EmployeeShiftListState extends EmployeeShiftState {
  List<EmployeeShifts> employeeShiftList;
  EmployeeShiftListState({required this.employeeShiftList}); 
}