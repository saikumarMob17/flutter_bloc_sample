import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';

class EmployeeShiftReceiptWidget extends StatelessWidget {


  const EmployeeShiftReceiptWidget({super.key});

  @override
  Widget build(BuildContext context) {
    // var orderBillingLabel = <OrderBillingModel>[
    //   OrderBillingModel(title: AppStrings.subTotal, amount: 0.0),
    //   OrderBillingModel(title: AppStrings.tip, amount: 0.0),
    //   OrderBillingModel(title: AppStrings.tax, amount: 0.0),
    //   OrderBillingModel(title: AppStrings.total, amount: 0.0),
    // ];
    // calculateBillingAmount(orderBillingLabel, orderDetails: checkDetails);
    return Container(
      height: context.screenHeight * 0.80,
      width: context.screenWidth * 0.32,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: AppColors.white
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                vertical: 20.0,
                horizontal: 20.0
              ),
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CustomText(
                      title: 'Shift Review Summary',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: 'Yoselin Cardozo',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: 'Vendom - 743 Washington Ave',
                      fontSize: AppSize.s14,
                    ),
                    const SizedBox(height: AppSize.s10),
                    CustomText(
                      title: '*** EMPLOYEE ACCOUNT ***',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s28, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const CustomText(
                      title: 'Cash in hand (collected cash sales) Paid',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$0.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Owed to Yoselin',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$0.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** TIPS & FEE EARNED ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s18, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const CustomText(
                      title: 'Non-cash tips',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: '\$2,727.24',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const CustomText(
                      title: 'Cash tips',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: '\$0.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total tips',
                      textStyle: getMediumStyle()
                    ),
                    CustomText(
                      title: '\$2,727.24',
                      textStyle: getMediumStyle()
                    )
                  ],
                ),
                //My Guest Report
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** MY GUEST REPORT ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s18, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const CustomText(
                      title: 'Total guest served',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: '2',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const CustomText(
                      title: 'Average spend per guest',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: '\$7,055.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                ///CREDIT TIP AUDIT
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** CREDIT TIP AUDIT ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s18, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: CustomText(
                        title: 'Check',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: 'Last4',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: 'Subtotal',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: 'Tip',
                        textAlign: TextAlign.center,
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: 'Total',
                        textAlign: TextAlign.end,
                        textStyle: getMediumStyle()
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Column(
                  children: List.generate(
                    4, 
                    (index) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: CustomText(
                              title: '75',
                              fontSize: AppSize.s14,
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '8131',
                              fontSize: AppSize.s14,
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '4068.00',
                              fontSize: AppSize.s14,
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '552.96',
                              fontSize: AppSize.s14,
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: '5160.96',
                              fontSize: AppSize.s14,
                              textAlign: TextAlign.end,
                            ),
                          ),
                        ],
                      );
                    }
                  )
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: CustomText(
                        title: 'Total',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: '',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: '\$0.0',
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: '\$0.0',
                        textAlign: TextAlign.center,
                        textStyle: getMediumStyle()
                      ),
                    ),
                    Expanded(
                      child: CustomText(
                        title: '\$0.0',
                        textAlign: TextAlign.end,
                        textStyle: getMediumStyle()
                      ),
                    ),
                  ],
                ),
                ///SALES & TAXES SUMMARY
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** SALES & TAXES SUMMARY ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Category Quantity',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: 'Net Sales',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Column(
                  children: List.generate(
                    4, 
                    (index) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            title: 'Bar Sales (6)',
                            fontSize: AppSize.s14,
                          ),
                          CustomText(
                            title: '\$0.0',
                            fontSize: AppSize.s14,
                          )
                        ],
                      );
                    }
                  )
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total net sales',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Tax',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$4,110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Gross sales',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Non-cash Tips',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total amount',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                ///CASH/CREDIT PER SALES CATEGORY
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** CASH/CREDIT PER SALES CATEGORY ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s18),
                const CustomText(
                  title: '(Mixed-payment checks not included)',
                  fontSize: AppSize.s14,
                ),
                const SizedBox(height: AppSize.s12),
                CustomText(
                  title: 'Cash Sales',
                  textStyle: getMediumStyle(),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                const CustomText(
                  title: 'None',
                  fontSize: AppSize.s14,
                ),
                const SizedBox(height: AppSize.s18),
                CustomText(
                  title: 'Non-Cash Sales',
                  textStyle: getMediumStyle(),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Column(
                  children: List.generate(
                    4, 
                    (index) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            title: 'Bar Sales (6)',
                            fontSize: AppSize.s14,
                          ),
                          CustomText(
                            title: '\$0.0',
                            fontSize: AppSize.s14,
                          )
                        ],
                      );
                    }
                  )
                ),
                ///TOTAL CREDIT PAYMENTS
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** TOTAL CREDIT PAYMENTS ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s28, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Amount',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Tip',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total credit',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                //TOTAL PAYMENTS
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** TOTAL PAYMENTS ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s28, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Amount',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Tip',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total credit',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                //CREDIT CARD BREAKDOWN
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** CREDIT CARD BREAKDOWN ***',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s28, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Mastercard',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Visa',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '\$110.0',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Total',
                      textStyle: getMediumStyle(),
                    ),
                    CustomText(
                      title: '\$14,110.0',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                //END SHIFT REVIEW SUMMARY
                const SizedBox(height: AppSize.s28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: 'End Shift Review Summary',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s28, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Printed',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: '6/5/2024 5:05 AM',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
              ],
            )
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              vertical: 10.0,
              horizontal: 14.0
            ),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10.0),
                bottomRight: Radius.circular(10.0),
              ),
              color: AppColors.backgroundColor,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomOutlinedButton(
                  onPressed: () => context.pop(),
                  text: 'Cancel',
                  textColor: AppColors.red,
                  borderColor: AppColors.red,
                ),
                const SizedBox(width: AppSize.s10),
                CustomSolidButton(
                  onPressed: () => debugPrint('Click here to print receipt'),
                  text: ' Print ',
                ),
              ],
            )
          )
        ],
      ),
    );
  }

  // void calculateBillingAmount(List<OrderBillingModel> orderBillingLabel, {required PaymentOrderModel orderDetails}) {
  //   var grandTotal = ((orderDetails.billingDetails!.subTotal! + orderDetails.billingDetails!.tax! + orderDetails.billingDetails!.tip!) - orderDetails.billingDetails!.discount!).roundTwo;
  //   orderBillingLabel[0].amount = orderDetails.billingDetails!.subTotal!;
  //   orderBillingLabel[1].amount = orderDetails.billingDetails!.tip!;
  //   orderBillingLabel[2].amount = orderDetails.billingDetails!.tax!;
  //   orderBillingLabel[3].amount = grandTotal;
  // }

}

class DashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    double dashWidth = 9, dashSpace = 5, startX = 0;
    final paint = Paint()
      ..color = AppColors.black
      ..strokeWidth = 1;
    while (startX < size.width) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}