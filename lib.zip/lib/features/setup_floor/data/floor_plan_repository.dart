import 'dart:convert';
import 'dart:io';
import '../../../network/custom_exception.dart';
import '../../../utils/helper.dart';
import '../domain/all_floor_plan_response.dart';
import '../domain/floor_plan_response.dart' as floor;
import '../../../network/api/api_client.dart';
import '../../../network/end_points.dart';

class FloorPlanRepository {
  late ApiClient _apiClient;

  FloorPlanRepository(){
    _apiClient = ApiClient();
  }

  Future<Map> saveFloorPlan({required Map<String, dynamic> bodyData}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.addFloorPlan, body: bodyData);
      switch (response.statusCode) {
        case HttpStatus.created:
          return jsonDecode(response.body);
        default:
          return jsonDecode(response.body);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<Map> updateFloorPlan({required Map<String, dynamic> bodyData}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updateFloorPlan, body: bodyData);
      switch (response.statusCode) {
        case HttpStatus.created:
          return jsonDecode(response.body);
        default:
          return jsonDecode(response.body);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<List<Floors>> getAllFloorPlan() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.getAllFloorPlan);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data = allFloorPlanResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<floor.Floor> getFloorPlan({required String floorId}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.getFloorPlan}?id=$floorId");
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data = floor.floorPlanResponseFromJson(response.body);
          return data.data!;
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}