// To parse this JSON data, do
//
//     final floorPlanResponse = floorPlanResponseFromJson(jsonString);

import 'dart:convert';

FloorPlanResponse floorPlanResponseFromJson(String str) => FloorPlanResponse.fromJson(json.decode(str));

class FloorPlanResponse {
  int? statusCode;
  String? status;
  String? message;
  Floor? data;

  FloorPlanResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory FloorPlanResponse.fromJson(Map<String, dynamic> json) => FloorPlanResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Floor.fromJson(json["data"]),
  );
}

class Floor {
  int? floorNumber;
  String? floorImgPath;
  List<FloorPlan>? floorPlan;

  Floor({
    this.floorNumber,
    this.floorImgPath,
    this.floorPlan,
  });

  factory Floor.fromJson(Map<String, dynamic> json) => Floor(
    floorNumber: json["floorNumber"],
    floorImgPath: json["floor_img_path"],
    floorPlan: json["floor_plan"] == null ? [] : List<FloorPlan>.from(json["floor_plan"]!.map((x) => FloorPlan.fromJson(x))),
  );
}

class FloorPlan {
  String? tableName;
  int? tableCount;
  bool? tableIsHorizontal;
  double? tableRadius;
  String? tableShape;
  double? tableDx;
  double? tableDy;
  int? tableIndex;
  int? tableId;
  bool? tableAvailibility;

  FloorPlan({
    this.tableName,
    this.tableCount,
    this.tableIsHorizontal,
    this.tableRadius,
    this.tableShape,
    this.tableDx,
    this.tableDy,
    this.tableIndex,
    this.tableId,
    this.tableAvailibility,
  });

  factory FloorPlan.fromJson(Map<String, dynamic> json) => FloorPlan(
    tableId: json['table_Id'],
    tableName: json["table_name"],
    tableCount: json["table_count"],
    tableIsHorizontal: json["table_is_horizontal"],
    tableRadius: json["table_radius"].toDouble(),
    tableShape: json["table_shape"],
    tableDx: json["table_dx"]?.toDouble(),
    tableDy: json["table_dy"]?.toDouble(),
    tableIndex: json["table_index"],
    tableAvailibility: json["table_availibility"],
  );
}
