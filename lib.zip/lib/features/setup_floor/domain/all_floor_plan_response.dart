import 'dart:convert';

AllFloorPlanResponse allFloorPlanResponseFromJson(String str) => AllFloorPlanResponse.fromJson(json.decode(str));

class AllFloorPlanResponse {
  int? statusCode;
  String? status;
  String? message;
  List<Floors>? data;

  AllFloorPlanResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory AllFloorPlanResponse.fromJson(Map<String, dynamic> json) => AllFloorPlanResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<Floors>.from(json["data"]!.map((x) => Floors.fromJson(x))),
  );
}

class Floors {
  int? floorId;
  int? floorNumber;
  String? floorImgPath;
  List<FloorPlan>? floorPlan;

  Floors({
    this.floorId,
    this.floorNumber,
    this.floorImgPath,
    this.floorPlan,
  });

  factory Floors.fromJson(Map<String, dynamic> json) => Floors(
    floorId: json["floorId"],
    floorNumber: json["floorNumber"],
    floorImgPath: json["floor_img_path"],
    floorPlan: json["floor_plan"] == null ? [] : List<FloorPlan>.from(json["floor_plan"]!.map((x) => FloorPlan.fromJson(x))),
  );
}

class FloorPlan {
  String? tableName;
  int? tableCount;
  int? tableId;
  bool? tableIsHorizontal;
  double? tableRadius;
  String? tableShape;
  double? tableDx;
  double? tableDy;
  int? tableIndex;
  bool? tableAvailability;
  TableOrderDetails? tableOrderDetails;

  FloorPlan({
    this.tableId,
    this.tableName,
    this.tableCount,
    this.tableIsHorizontal,
    this.tableRadius,
    this.tableShape,
    this.tableDx,
    this.tableDy,
    this.tableIndex,
    this.tableAvailability,
    this.tableOrderDetails
  });

  factory FloorPlan.fromJson(Map<String, dynamic> json) => FloorPlan(
    tableId: json['table_Id'],
    tableName: json["table_name"],
    tableCount: json["table_count"],
    tableIsHorizontal: json["table_is_horizontal"],
    tableRadius: json["table_radius"].toDouble(),
    tableShape: json["table_shape"],
    tableDx: json["table_dx"].toDouble(),
    tableDy: json["table_dy"].toDouble(),
    tableIndex: json["table_index"],
    tableAvailability: json['table_availibility'],
    tableOrderDetails: json['orderDetailsOfTable'] == null ? null : TableOrderDetails.fromJson(json['orderDetailsOfTable'])
  );
}

class TableOrderDetails {
  String? customerName;
  String? orderNumber;
  String? orderId;
  bool? isFinished;
  int? guestCount;
  double? balanceDue;
  bool? paymentStatus;
  String? serverName;
  String? serverId;

  TableOrderDetails({
    this.customerName,
    this.orderId,
    this.isFinished,
    this.guestCount,
    this.balanceDue,
    this.orderNumber,
    this.paymentStatus,
    this.serverName,
    this.serverId
  });

  factory TableOrderDetails.fromJson(Map<String, dynamic> json){
    return TableOrderDetails(
      customerName: json['customerName'] ?? '',
      orderId: json['orderId'],
      isFinished: json['isfinished'] ?? false,
      orderNumber: json['orderNumber'],
      guestCount: json['guestCount'],
      balanceDue: json['balanceDue'] == null ? 0.0 : json['balanceDue'].toDouble(),
      paymentStatus: json['paymentStatus'],
      serverName: json['serverName'] ?? '',
      serverId: json['serverId'] ?? '',
    );
  }
}
