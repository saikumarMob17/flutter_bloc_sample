import 'package:cliqtechnologies_retl/features/setup_floor/domain/all_floor_plan_response.dart';
import 'package:cliqtechnologies_retl/utils/helper.dart';
import 'package:flutter/material.dart';

class TableShapeModel {

  String tableName;
  int? tableCount;
  int? tableId;
  int? sittingCapacity;
  bool? horizontal;
  double? radius;
  bool isSelected;
  bool? tableAvailableStatus;
  TableShape tableShape;
  Offset tableCoordinate;
  int index;
  TableOrderDetails? bookedOrderDetails;

  TableShapeModel({
    required this.tableName, 
    required this.tableShape, 
    required this.tableCoordinate,
    this.tableCount = 0, 
    this.horizontal,
    this.sittingCapacity = 0, 
    this.radius = 0, 
    this.index = -1,
    this.tableId = -1,
    this.isSelected = false,
    this.tableAvailableStatus = false,
    this.bookedOrderDetails
  });

}