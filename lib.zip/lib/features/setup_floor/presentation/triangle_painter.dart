import 'package:flutter/material.dart';

class TrianglePainter extends CustomPainter {

  final Color strokeColor;
  final PaintingStyle paintingStyle;
  final double strokeWidth;
  final String? tableName;

  TrianglePainter({
    this.strokeColor = Colors.black, 
    this.strokeWidth = 3, 
    this.paintingStyle = PaintingStyle.fill,
    this.tableName
  });

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = strokeColor
      ..strokeWidth = strokeWidth
      ..style = paintingStyle;

    canvas.drawPath(getTrianglePath(size.width, size.height), paint);

    const textStyle = TextStyle(
      color: Colors.white,
      fontSize: 14,
    );
    TextSpan textSpan = TextSpan(
      text: tableName ?? '',
      style: textStyle,
    );
    final textPainter = TextPainter(
      text: textSpan,
      textDirection: TextDirection.ltr,
    );
    textPainter.layout(
      minWidth: 0,
      maxWidth: size.width,
    );
    final xCenter = (size.width - textPainter.width) / 2;
    final yCenter = (size.height - textPainter.height) / 1.2;
    final offset = Offset(xCenter, yCenter);
    textPainter.paint(canvas, offset);
  }

  Path getTrianglePath(double x, double y) {
    return Path()
      ..moveTo(x / 2, 0)
      ..lineTo(x, y)
      ..lineTo(0, y);
  }

  @override
  bool shouldRepaint(TrianglePainter oldDelegate) {
    return oldDelegate.strokeColor != strokeColor ||
        oldDelegate.paintingStyle != paintingStyle ||
        oldDelegate.strokeWidth != strokeWidth;
  }
}