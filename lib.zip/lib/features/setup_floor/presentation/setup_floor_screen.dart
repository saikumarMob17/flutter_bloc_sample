import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart';
import '../../../routes/app_routes.dart';
import '../domain/table_shape_model.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import 'triangle_painter.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../constants/app_colors.dart';
import '../../../routes/route.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';

class SetupFloorPlanScreen extends StatefulWidget {

  const SetupFloorPlanScreen({super.key});

  @override
  State createState() => _SetupFloorPlanScreenState();
}

class _SetupFloorPlanScreenState extends State<SetupFloorPlanScreen> with Helper {
  
  final GlobalKey _dragTargetKey = GlobalKey();

  double left = 0.0;
  double top = 0.0;
  double right = 0.0;
  double bottom = 0.0;

  List<TableShapeModel> listTable = [];
  List<TableShapeModel> dragedWidget = [];
  
  late TextEditingController labelTextController;
  late TextEditingController radiusTextController;
  late TextEditingController tableCountTextController;
  late ImagePicker _imagePicker;

  int selectedIndex = -1;
  TableShapeModel? selectedTableModel;
  double topMargin = 0.0;
  int totalPerson = 0;
  double verticalScrollOffSet = 0.0;
  double horizontalScrollOffSet = 0.0;
  bool horizontal = true;
  TableShape selectedTableShape = TableShape.square;
  Uint8List? floorPlanImageBytes;

  late ScrollController _verticalScrollController;
  late ScrollController _horizontalScrollController;

  @override
  void initState() {
    _verticalScrollController = ScrollController();
    _horizontalScrollController = ScrollController();
    _verticalScrollController.addListener(verticalControllerListener);
    _horizontalScrollController.addListener(horizontalControllerListener);
    _imagePicker = ImagePicker();
    labelTextController = TextEditingController();
    radiusTextController = TextEditingController();
    tableCountTextController = TextEditingController();
    listTable.add(TableShapeModel(tableName: AppStrings.emptyString, radius:  AppSize.s65, tableShape: TableShape.circle, tableCoordinate: Offset.zero));
    listTable.add(TableShapeModel(tableName: AppStrings.emptyString, tableCount: 1, horizontal: true, tableShape: TableShape.square, tableCoordinate: Offset.zero));
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) => _getDragTargetCoordinate());
    super.initState();
  }

  void verticalControllerListener() => verticalScrollOffSet = _verticalScrollController.offset;

  void horizontalControllerListener() => horizontalScrollOffSet = _horizontalScrollController.offset;

  void _getDragTargetCoordinate() {
    topMargin = (kToolbarHeight + context.statusBarHeight);
    RenderBox box = _dragTargetKey.currentContext!.findRenderObject() as RenderBox;
    Offset position = box.localToGlobal(Offset.zero); //this is global position
    left = position.dx;
    top =  (position.dy - topMargin);
    right = (position.dx + box.size.width) - AppSize.s65;
    bottom = ((position.dy + box.size.height) - topMargin) - AppSize.s65;
    _horizontalScrollController.animateTo(220, duration: const Duration(milliseconds: 400), curve: Curves.linear);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        titleSpacing: 0,
        title: CustomText(
          title: AppStrings.setUpFloorPlan,
          textStyle: getMediumStyle(
            fontSize: AppSize.s20,
            color: Helper.isDark 
            ? AppColors.white 
            : AppColors.black
          ),
        ),
        actions: [
          CustomOutlinedButton(
            text: " ${AppStrings.save} ",
            onPressed: () => context.read<FloorBloc>().add(FloorPlanUpdateEvent()),
          ),
          const SizedBox(width: AppSize.s10),
          CustomOutlinedButton(
            text: " ${AppStrings.clear} ",
            onPressed: () => context.read<FloorBloc>().add(FloorPlanClearEvent()),
            borderColor: AppColors.red,
            textColor: AppColors.red,
          ),
          const SizedBox(width: AppSize.s10),
          CustomSolidButton(
            onPressed: () => context.read<FloorBloc>().add(OnSwitchUserFloorEvent()),
            prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
            verPadding: AppSize.s15,
            text: AppStrings.switchUser
          ),
          const SizedBox(width: AppSize.s20)
        ],
      ),
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.lightGrey,
      //New UI
      body: BlocConsumer<FloorBloc, FloorState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case FloorPlanFetchState:
              state = state as FloorPlanFetchState;
              try {
                floorPlanImageBytes ??= base64Decode(state.imagePath);
              } catch(_){}
              dragedWidget.clear();
              dragedWidget.addAll(state.draggedWidgets);
              _hideAndClearDetailFields();
              break;
            case FloorPlanSelectWidgetState:
              state = state as FloorPlanSelectWidgetState;
              _onTapDraggedWidget(index: state.index);
              break;
            case FloorPlanUpdateDraggedState:
              state = state as FloorPlanUpdateDraggedState;
              _updateDraggedWidget();
              _hideAndClearDetailFields();
              break;
            case ChangeTableDirectionState:
              state = state as ChangeTableDirectionState;
              horizontal = !horizontal;
              break;
            case FloorPlanChooseImageState:
              state = state as FloorPlanChooseImageState;
              try {
                floorPlanImageBytes = base64Decode(state.imagePath);
              } catch(_){}
              break;
            default:
          }
          return Stack(
            children: [
              Scrollbar(
                child: SingleChildScrollView(
                  controller: _verticalScrollController,
                  scrollDirection: Axis.vertical,
                  child: Scrollbar(
                    child: SingleChildScrollView(
                      controller: _horizontalScrollController,
                      scrollDirection: Axis.horizontal,
                      child: SizedBox(
                        width: Helper.screenWidth, 
                        height: Helper.screenHeight,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: DragTarget<TableShapeModel>(
                            builder: (context, candidateItems, rejectedItems) {
                              return Stack(
                                children: [
                                  Container(
                                    key: _dragTargetKey, 
                                    height: Helper.floorHeight, 
                                    width: Helper.floorWidth,
                                    margin: const EdgeInsets.only(top: AppSize.s10),
                                    decoration: BoxDecoration(
                                      color: Helper.isDark 
                                      ? AppColors.contentColorDark 
                                      : AppColors.white,
                                    ),
                                    child: CustomImageView(imgBytes: floorPlanImageBytes)
                                  ),
                                  ...List.generate(
                                    dragedWidget.length, 
                                    (index) {
                                      var data = dragedWidget[index];
                                      return Positioned(
                                        top: data.tableCoordinate.dy - top,
                                        left: data.tableCoordinate.dx - left,
                                        child: InkWell(
                                          onTap: () => context.read<FloorBloc>().add(FloorPlanSelectWidgetEvent(tableModel: data, index: index)),
                                          child: _buildMenuItem(
                                            widget: _getTableShape(
                                              data, 
                                              selectedColor: selectedIndex == index 
                                              ? AppColors.primaryColor 
                                              : AppColors.grey.withOpacity(0.9)
                                            ), 
                                            data: data
                                          ),
                                        ),
                                      );
                                    }
                                  ),
                                ],
                              );
                            },
                            onAcceptWithDetails: (details) => _onAcceptDragWithDetails(details, context),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: AppSize.s10,
                right: AppSize.s10,
                child: Container(
                  clipBehavior: Clip.hardEdge,
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSize.s16,
                    vertical: AppSize.s10
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppSize.s10),
                    color: AppColors.grey.withOpacity(0.3),
                  ),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 1.5,
                      sigmaY: 1.5
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomText(
                          title: AppStrings.tableShape, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          )
                        ),
                        const SizedBox(height: AppSize.s15),
                        ...List.generate(
                          listTable.length, 
                          (index) { 
                            var data = listTable[index];
                            return _buildMenuItem(widget: _getTableShape(data), data: data);
                          }
                        ),
                        Container(
                          margin: const EdgeInsets.only(top: AppSize.s20, bottom: AppSize.s18),
                          height: AppSize.s1,  
                          width: AppSize.s45,
                          decoration: BoxDecoration(
                            color: AppColors.black,
                            borderRadius: BorderRadius.circular(AppSize.s10)
                          ),
                        ),
                        FloatingActionButton(
                          heroTag: AppStrings.image,
                          onPressed: () => chooseFloorImage(context: context),
                          foregroundColor: AppColors.white, 
                          child: const Icon(Icons.image),
                        ),
                        const SizedBox(height: AppSize.s4),
                        CustomText(
                          title: AppStrings.image, 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Visibility(
                visible: !selectedIndex.isNegative,
                child: Positioned(
                  top: AppSize.s10,
                  left: AppSize.s10,
                  child: Container(
                    width: 84,
                    padding: const EdgeInsets.all(AppSize.s8),
                    clipBehavior: Clip.hardEdge,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppSize.s10),
                      color: AppColors.grey.withOpacity(0.3),
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: 1.5,
                        sigmaY: 1.5
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CustomText(
                            title: AppStrings.details, 
                            textStyle: getMediumStyle(
                              fontWeight: FontWeight.w500
                            ),
                          ),
                          const SizedBox(height: AppSize.s10),
                          CustomTextField(
                            hint: AppStrings.label,
                            label: AppStrings.label,
                            textController: labelTextController,
                            isMandatory: true,
                            maxLength: 3,
                            verPadding: AppSize.s5,
                            horPadding: AppSize.s5,
                            textAlign: TextAlign.center,
                          ),
                          Visibility(
                            visible: selectedTableShape != TableShape.circle,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: AppSize.s10),
                                CustomTextField(
                                  hint: AppStrings.table,
                                  label: AppStrings.table,
                                  textController: tableCountTextController,
                                  isMandatory: true,
                                  verPadding: AppSize.s5,
                                  horPadding: AppSize.s5,
                                  textInputType: TextInputType.number,
                                  inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: AppSize.s10),
                                CustomTextField(
                                  hint: AppStrings.person,
                                  label: AppStrings.person,
                                  textController: TextEditingController(text: totalPerson.toString()),
                                  verPadding: AppSize.s5,
                                  horPadding: AppSize.s5,
                                  isEnable: false,
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: AppSize.s10),
                                CustomText(
                                  title: AppStrings.direction,
                                  textStyle: getRegularStyle(
                                    fontWeight: FontWeight.w500
                                  ),
                                ),
                                const SizedBox(height: AppSize.s2),
                                Row(
                                  children: [
                                    CustomCheckBox(
                                      value: horizontal,
                                      onChange: (value) => context.read<FloorBloc>().add(FloorPlanChangeTableDirectionEvent()),
                                    ),
                                    CustomText(
                                      title: 'LTR',
                                      textStyle: getRegularStyle(
                                        fontWeight: FontWeight.w500
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppSize.s4),
                                Row(
                                  children: [
                                    CustomCheckBox(
                                      value: !horizontal,
                                      onChange: (value) => context.read<FloorBloc>().add(FloorPlanChangeTableDirectionEvent()),
                                    ),
                                    CustomText(
                                      title: 'TTB',
                                      textStyle: getRegularStyle(
                                        fontWeight: FontWeight.w500
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Visibility(
                            visible: selectedTableShape == TableShape.circle,
                            child: Column(
                              children: [
                                const SizedBox(height: AppSize.s10),
                                CustomTextField(
                                  hint: AppStrings.radius,
                                  label: AppStrings.radius,
                                  textController: radiusTextController,
                                  inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                                  isMandatory: true,
                                  verPadding: AppSize.s5,
                                  horPadding: AppSize.s5,
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: AppSize.s16),
                          CustomOutlinedButton(
                            onPressed: () => context.read<FloorBloc>().add(FloorPlanUpdateDraggedEvent(
                              selectedTableIndex: selectedIndex,
                              tableLable: labelTextController.text,
                              tableCount: tableCountTextController.text,
                              radius: radiusTextController.text
                            )),
                            text: 'Set',
                            topPadding: AppSize.s10,
                            bottomPadding: AppSize.s10
                          ),
                          const SizedBox(height: AppSize.s2),
                          CustomOutlinedButton(
                            onPressed: () => context.read<FloorBloc>().add(FloorPlanDeleteDraggedWidgetEvent(selectedIndex: selectedIndex)),
                            text: 'Cut',
                            borderColor: AppColors.red,
                            textColor: AppColors.red,
                            topPadding: AppSize.s10,
                            bottomPadding: AppSize.s10
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case FloorPlanSuccessState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.msg, color: AppColors.green);
              break;
            case FloorPlanFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.msg);
              break;
            case FloorPlanLoadingState _:
              showLoadingDialog(context: context);
              break;
            case FloorPlanFetchState _:
              hideLoadingDialog(context: context);
              break;
            case OnSwitchUserFloorState _:
              hideLoadingDialog(context: context);
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Future<void> chooseFloorImage({required BuildContext context}) async {
    try {
      final XFile? image = await _imagePicker.pickImage(source: ImageSource.gallery);
      if(image != null && mounted) {
        var base64 = base64Encode(await image.readAsBytes());
        if(context.mounted) {
          context.read<FloorBloc>().add(FloorPlanChooseImageEvent(imagePath: base64));
        }
      }
    } catch (e) {
      debugPrint('error while choosing image');
    }
  }

  void _onAcceptDragWithDetails(DragTargetDetails<TableShapeModel> details, BuildContext context) {
    double dx = details.offset.dx;
    double dy = details.offset.dy;
    dy-=topMargin;
    dx+=horizontalScrollOffSet;
    if((left <= dx && dx <= right) && (top <= dy && dy <= bottom)) {
      context.read<FloorBloc>().add(FloorPlanAcceptDraggedWidgetEvent(
        details: details, 
        topMargin: topMargin, 
        verticalScrollOffSet: verticalScrollOffSet, 
        horizontalScrollOffSet: horizontalScrollOffSet
      ));
    }
  }

  void _onTapDraggedWidget({required int index}) {
    var temp = dragedWidget[index];
    selectedTableModel = temp;
    if(labelTextController.text.isEmpty || selectedIndex != index) {
      labelTextController.text = temp.tableName;
    }
    selectedTableShape = dragedWidget[index].tableShape;
    switch (dragedWidget[index].tableShape) {
      case TableShape.circle:
        if(radiusTextController.text.isEmpty || selectedIndex != index) {
          radiusTextController.text = temp.radius.toString();
        }
        break;
      case TableShape.square:
      case TableShape.rectangle:
        totalPerson = temp.tableCount!.squareSittingCalculation;
        horizontal = temp.horizontal ?? true;
        if(tableCountTextController.text.isEmpty || selectedIndex != index) {
          tableCountTextController.text = temp.tableCount == null ? '1' : temp.tableCount.toString();
        }
        break;
      default:
    }
    selectedIndex = index;
  }

  void _updateDraggedWidget() {
    if(!selectedIndex.isNegative) {
      switch (dragedWidget[selectedIndex].tableShape) {
        case TableShape.circle:
          dragedWidget[selectedIndex].radius = double.parse(radiusTextController.text);
          break;
        case TableShape.square:
        case TableShape.rectangle:
          dragedWidget[selectedIndex]
          ..tableCount = int.parse(tableCountTextController.text)
          ..horizontal = horizontal;
          break;
        default:
      }
      dragedWidget[selectedIndex].tableName = labelTextController.text;
    }
  }

  void _hideAndClearDetailFields() {
    labelTextController.clear();
    radiusTextController.clear();
    tableCountTextController.clear();
    selectedIndex = -1;
    selectedTableModel = null;
  }

  Widget _buildMenuItem({
    required Widget widget, 
    required TableShapeModel data
  }){
    return Draggable<TableShapeModel>(
      feedback: widget,
      data: data,
      child: widget
    );
  }

  Widget _getTableShape(TableShapeModel tableShapeModel, {Color? selectedColor}) {
    switch (tableShapeModel.tableShape) {
      case TableShape.circle:
        ///V2      
        return Container(
          height: tableShapeModel.radius,
          width: tableShapeModel.radius,
          margin: const EdgeInsets.only(bottom: AppSize.s20),
          decoration: BoxDecoration(
            color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
            shape: BoxShape.circle,
            border: Border.all(
              color: selectedColor ?? AppColors.grey.withOpacity(0.4), 
              width: 1.5
            ),
          ),
          child: Stack(
            children: [
              Align(
                alignment: Alignment.center,
                child: Text(
                  tableShapeModel.tableName,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
              ),
              Positioned(
                top: (tableShapeModel.radius!/6.5),  
                left: (tableShapeModel.radius!/6.5),
                child: IgnorePointer(
                  child: CircleAvatar(
                    radius: 4.5, 
                    backgroundColor: TableAvailableStatus.available.tableAvailableStatusColor
                  ),
                ),
              ),
            ],
          ),
        );
      case TableShape.square:
      case TableShape.rectangle:
        ///V3
        int tempTableCount = tableShapeModel.tableCount == null ? 1 : tableShapeModel.tableCount!;
        bool isHorizontal = tableShapeModel.horizontal == null ? true : tableShapeModel.horizontal!;
        return SizedBox(
          width: isHorizontal ? tempTableCount * AppSize.s65 : AppSize.s65,
          height: !isHorizontal ? tempTableCount * AppSize.s65 : AppSize.s65,
          child: Stack(
            children: [
              isHorizontal
              ? Row(
                children: List.generate(
                  tempTableCount, 
                  (_) => Transform.rotate(
                    angle: math.pi / 4,
                    child: Container(
                      width: AppSize.s65, 
                      height: AppSize.s65, 
                      decoration: BoxDecoration(
                        color: AppColors.grey.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(AppSize.s14)
                      ),
                    ),
                  ),
                ),
              )
              : Column(
                children: List.generate(
                  tempTableCount, 
                  (_) => Transform.rotate(
                    angle: math.pi / 4,
                    child: Container(
                      width: AppSize.s65, 
                      height: AppSize.s65, 
                      decoration: BoxDecoration(
                        color: AppColors.grey.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(AppSize.s14)
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(AppSize.s5),
                decoration: BoxDecoration(
                  color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                  borderRadius: BorderRadius.circular(AppSize.s8),
                  border: Border.all(
                    color: selectedColor ?? AppColors.grey.withOpacity(0.4),
                    width: 1.5
                  ),
                ),
                child: isHorizontal
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tempTableCount, 
                    (_) => const SizedBox(
                      width: 52, 
                      height: 52,
                    ),
                  ),
                )
                : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tempTableCount, 
                    (_) => const SizedBox(
                      width: 52, 
                      height: 52,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: IgnorePointer(
                  child: Text(
                    tableShapeModel.tableName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: getMediumStyle( 
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 11,
                left: 11,
                child: IgnorePointer(
                  child: CircleAvatar(
                    radius: 4.5, 
                    backgroundColor: TableAvailableStatus.available.tableAvailableStatusColor
                  ),
                ),
              ),
            ],
          ),
        );
      default:
        return SizedBox(
          child: CustomPaint(
            painter: TrianglePainter(
              strokeColor: selectedColor ?? AppColors.primaryColor,
              tableName: tableShapeModel.tableName
            ),
            child: SizedBox(
              height: tableShapeModel.radius, 
              width: tableShapeModel.radius
            ),
          ),
        );
    }
  }
}
