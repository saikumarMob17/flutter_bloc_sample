part of 'floor_bloc.dart';

sealed class FloorState {}

class InitialFloorState extends FloorState {}

class FloorPlanFetchState extends FloorState {
  List<TableShapeModel> draggedWidgets;
  String imagePath;
  FloorPlanFetchState({required this.draggedWidgets, this.imagePath = ''});
}

class ChangeTableDirectionState extends FloorState {
  ChangeTableDirectionState();
}

class FloorPlanSelectWidgetState extends FloorState {
  int index;
  FloorPlanSelectWidgetState({required this.index});
}

class FloorPlanUpdateDraggedState extends FloorState {}


class FloorPlanChooseImageState extends FloorState {
  String imagePath;
  FloorPlanChooseImageState({required this.imagePath});
}

class FloorPlanSuccessState extends FloorState {
  String msg;
  FloorPlanSuccessState({this.msg = ''});
}
class FloorPlanFailedState extends FloorState {
  String msg;
  FloorPlanFailedState({this.msg = ''});
}

class FloorPlanLoadingState extends FloorState {}

class OnSwitchUserFloorState extends FloorState {
  bool isLogout;

  OnSwitchUserFloorState({this.isLogout = false});
}