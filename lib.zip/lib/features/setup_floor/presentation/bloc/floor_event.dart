part of 'floor_bloc.dart';

sealed class FloorEvent {}

class FloorPlanFetchEvent extends FloorEvent {}

class FloorPlanChangeTableDirectionEvent extends FloorEvent {}

class FloorPlanSelectWidgetEvent extends FloorEvent {
  TableShapeModel tableModel; 
  int index;

  FloorPlanSelectWidgetEvent({required this.tableModel, required this.index});
}

class FloorPlanUpdateDraggedEvent extends FloorEvent {
  int selectedTableIndex;
  String radius;
  String tableLable;
  String tableCount;

  FloorPlanUpdateDraggedEvent({
    required this.selectedTableIndex,
    this.radius = '',
    this.tableLable = '',
    this.tableCount = ''
  });
}

class FloorPlanDeleteDraggedWidgetEvent extends FloorEvent {
  int selectedIndex;
  FloorPlanDeleteDraggedWidgetEvent({required this.selectedIndex});
}

class FloorPlanClearEvent extends FloorEvent {}

class FloorPlanSavedEvent extends FloorEvent {}

class FloorPlanUpdateEvent extends FloorEvent {
  FloorPlanUpdateEvent();
}

class FloorPlanAcceptDraggedWidgetEvent extends FloorEvent {
  DragTargetDetails<TableShapeModel> details;
  double topMargin;
  double verticalScrollOffSet;
  double horizontalScrollOffSet;
  FloorPlanAcceptDraggedWidgetEvent({
    required this.details, 
    required this.topMargin, 
    this.verticalScrollOffSet = 0.0, 
    this.horizontalScrollOffSet = 0.0
  });
}

class FloorPlanChooseImageEvent extends FloorEvent {
  ///Base64 Image
  String imagePath;
  FloorPlanChooseImageEvent({required this.imagePath});
}

class OnSwitchUserFloorEvent extends FloorEvent {}