import 'dart:io';
import '../../../../routes/route.dart';
import '../../../../network/custom_exception.dart';
import '../../data/floor_plan_repository.dart';
import '../../domain/table_shape_model.dart';
import '../../../../utils/app_extension_method.dart';
import '../../../../utils/check_connectivity.dart';
part 'floor_event.dart';
part 'floor_state.dart';

class FloorBloc extends Bloc<FloorEvent, FloorState> {

  List<TableShapeModel> dragedWidget = [];
  TableShapeModel? selectedTableModel;
  TableShape selectedTableShape = TableShape.square;
  String floorImg = "";
  late CheckConnectivity _checkConnectivity;
  late FloorPlanRepository _floorPlanRepository;

  FloorBloc() : super(InitialFloorState()){
    _checkConnectivity = CheckConnectivity();
    _floorPlanRepository = FloorPlanRepository();
    on<FloorPlanFetchEvent>(_onFetchFloorPlan);
    on<FloorPlanChangeTableDirectionEvent>(_onChangeTableDirection);
    on<FloorPlanSelectWidgetEvent>(_onSelectWigdet);
    on<FloorPlanUpdateDraggedEvent>(_onUpdateDraggedWidget);
    on<FloorPlanDeleteDraggedWidgetEvent>(_onDeleteDraggedWidget);
    on<FloorPlanClearEvent>(_onClearFloorPlan);
    on<FloorPlanAcceptDraggedWidgetEvent>(_onAcceptDraggedWidget);
    on<FloorPlanSavedEvent>(_onSaveFloorPlan);
    on<FloorPlanUpdateEvent>(_onUpdateFloorPlan);
    on<FloorPlanChooseImageEvent>(_onChooseFloorImage);
    on<OnSwitchUserFloorEvent>(_onSwitchUser);
  }

  Future<void> _onFetchFloorPlan(FloorPlanFetchEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(FloorPlanLoadingState());
        var floorPlan = await _floorPlanRepository.getAllFloorPlan();
        floorImg = floorPlan.first.floorImgPath!;
        Preferences.setString(key: AppStrings.prefFloorId, value: floorPlan.first.floorId.toString());
        for(var item in floorPlan.first.floorPlan!){
          dragedWidget.add(TableShapeModel(
            tableName: item.tableName!, 
            radius:  item.tableRadius!, 
            tableCount: item.tableCount,
            tableId: item.tableId,
            horizontal: item.tableIsHorizontal,
            tableShape: item.tableShape!.getTableShape, 
            tableCoordinate: Offset(item.tableDx!, item.tableDy!),
            tableAvailableStatus: item.tableAvailability,
            index: item.tableIndex!
          ));
        }
        dragedWidget.sort((a,b) => a.index.compareTo(b.index));
        emit(FloorPlanFetchState(draggedWidgets: dragedWidget, imagePath: floorImg));
      } catch (e) {
        emit(FloorPlanFailedState(msg: AppStrings.someThingWentWrong));
      }
    } else {
      emit(FloorPlanFailedState(msg: AppStrings.noInternetConnection));
    } 
  }

  void _onChangeTableDirection(FloorPlanChangeTableDirectionEvent event, Emitter emit) {
    emit(ChangeTableDirectionState());
  }

  void _onSelectWigdet(FloorPlanSelectWidgetEvent event, Emitter emit){
    emit(FloorPlanSelectWidgetState(index: event.index));
  }

  void _onUpdateDraggedWidget(FloorPlanUpdateDraggedEvent event, Emitter emit){
    ///Adding Validation method
    if(tableAddUpdateValidation(event, emit)) {
      emit(FloorPlanUpdateDraggedState());
    }
  }

  bool tableAddUpdateValidation(FloorPlanUpdateDraggedEvent event, Emitter emit) {
    if(!event.selectedTableIndex.isNegative) {
      try {
        TableShape tableShape = dragedWidget[event.selectedTableIndex].tableShape;
        if(tableShape == TableShape.circle) {
          if(event.tableLable.isBlank) {
            emit(FloorPlanFailedState(msg: "Please provide table name"));
            return false;
          } else if(event.radius.isBlank) {
            emit(FloorPlanFailedState(msg: "Please provide table radius"));
            return false;
          } else if (double.parse(event.radius) < 65.0) {
            emit(FloorPlanFailedState(msg: "Table radius should be atleast 65"));
            debugPrint('Table radius should be atleast 65');
            return false;
          } else {  
            return true;
          }
        }

        ///Check if table is rectangular or square
        if(tableShape == TableShape.square || tableShape == TableShape.rectangle) {
          if(event.tableLable.isBlank) {
            emit(FloorPlanFailedState(msg: "Please provide table name"));
            return false;
          } else if(event.tableCount.isBlank) {
            emit(FloorPlanFailedState(msg: "Please provide table count"));
            return false;
          } else if (int.parse(event.tableCount) < 1) {
            emit(FloorPlanFailedState(msg: "Table count cannot be less than 1"));
            return false;
          } else {  
            return true;
          }
        }
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  void _onDeleteDraggedWidget(FloorPlanDeleteDraggedWidgetEvent event, Emitter emit){
    dragedWidget.removeAt(event.selectedIndex);
    for (var i = 0; i < dragedWidget.length; i++) {
      dragedWidget[i].index = i;
    }
    emit(FloorPlanFetchState(draggedWidgets: dragedWidget));
  }

  void _onClearFloorPlan(FloorPlanClearEvent event, Emitter emit){
    dragedWidget.clear();
    emit(FloorPlanFetchState(draggedWidgets: dragedWidget));
  }

  void _onAcceptDraggedWidget(FloorPlanAcceptDraggedWidgetEvent event, Emitter emit) {
    DragTargetDetails<TableShapeModel> details = event.details;
    double dx = details.offset.dx;
    double dy = details.offset.dy;
    double verticalScrollOffSet = event.verticalScrollOffSet;
    double horizontalScrollOffSet = event.horizontalScrollOffSet;
    dy-=event.topMargin;
    dx+=horizontalScrollOffSet;
    dy+=verticalScrollOffSet;
    debugPrint('Dx => $dx Dy $dy');
    TableShapeModel tableShapeModel = details.data;
    if(details.data.index < 0) {
      var dragWidgetIndex = dragedWidget.length;
      switch (tableShapeModel.tableShape) {
        case TableShape.circle:
          dragedWidget.add(TableShapeModel(
            tableName: 'T${dragedWidget.length + 1}', 
            radius: tableShapeModel.radius,
            tableShape: tableShapeModel.tableShape, 
            tableCoordinate: Offset(dx, dy),
            index: dragWidgetIndex,
            tableAvailableStatus: true
          ));
          break;
        case TableShape.square:
        case TableShape.rectangle:
          dragedWidget.add(TableShapeModel(
            tableName: 'T${dragedWidget.length + 1}',
            tableCount: tableShapeModel.tableCount,
            horizontal: tableShapeModel.horizontal, 
            tableShape: tableShapeModel.tableShape, 
            tableCoordinate: Offset(dx, dy),
            index: dragWidgetIndex,
            tableAvailableStatus: true
          ));
          break;
        default:
      }
    } else {
      dragedWidget[details.data.index].tableCoordinate = Offset(dx, dy);
    }
    emit(FloorPlanFetchState(draggedWidgets: dragedWidget));
  }

  Future<void> _onSaveFloorPlan(FloorPlanSavedEvent event, Emitter emit) async {
    if(await addFloorPlanValidation(emit)){
      ///Add New Floor Plan
      var floorPlanRequest = <String, dynamic>{};
      floorPlanRequest['floorNumber'] = 3;
      floorPlanRequest['floor_img_path'] = floorImg;
      var tablePosition = [];
      for(var item in dragedWidget) {
        var tempTablePosition = {};
        tempTablePosition['table_name'] = item.tableName;
        tempTablePosition['table_count'] = item.tableCount;
        tempTablePosition['table_is_horizontal'] = item.horizontal ?? false;
        tempTablePosition['table_radius'] = item.radius;
        tempTablePosition['table_shape'] = item.tableShape.name;
        tempTablePosition['table_dx'] = item.tableCoordinate.dx;
        tempTablePosition['table_dy'] = item.tableCoordinate.dy;
        tempTablePosition['table_index'] = item.index;
        // tempTablePosition['table_availability'] = 'available';
        tablePosition.add(tempTablePosition);
      }
      floorPlanRequest['floor_plan'] = tablePosition;
      try {
        emit(FloorPlanLoadingState());
        var response = await _floorPlanRepository.saveFloorPlan(bodyData: floorPlanRequest);
        if(response.isNotEmpty && response['statusCode'] == HttpStatus.created){
          emit(FloorPlanSuccessState(msg: response['status']));
        } else {
          emit(FloorPlanFailedState(msg: response['status']));
        }
      } catch (e) {
        emit(FloorPlanFailedState(msg: "Something went wrong"));
      }
    }
  }

  Future<void> _onUpdateFloorPlan(FloorPlanUpdateEvent event, Emitter emit) async {
    if(await addFloorPlanValidation(emit)){
      ///Update Floor Plan request
      var floorPlanRequest = <String, dynamic>{};
      floorPlanRequest['floor_Id'] = "12";
      // floorPlanRequest['floor_Id'] = event.floorId;
      floorPlanRequest['floor_img_path'] = floorImg;
      var tablePosition = [];
      for(var item in dragedWidget) {
        var tempTablePosition = {};
        tempTablePosition['table_name'] = item.tableName;
        tempTablePosition['table_count'] = item.tableCount;
        tempTablePosition['table_is_horizontal'] = item.horizontal ?? false;
        tempTablePosition['table_radius'] = item.radius;
        tempTablePosition['table_shape'] = item.tableShape.name;
        tempTablePosition['table_dx'] = item.tableCoordinate.dx;
        tempTablePosition['table_dy'] = item.tableCoordinate.dy;
        tempTablePosition['table_index'] = item.index;
        tempTablePosition['table_availibility'] = item.tableAvailableStatus;
        tablePosition.add(tempTablePosition);
      }
      floorPlanRequest['floor_plan'] = tablePosition;
      try {
        emit(FloorPlanLoadingState());
        var response = await _floorPlanRepository.updateFloorPlan(bodyData: floorPlanRequest);
        if(response.isNotEmpty && response['statusCode'] == HttpStatus.ok){
          emit(FloorPlanSuccessState(msg: response['data']));
        } else {
          emit(FloorPlanFailedState(msg: response['status']));
        }
      } catch (e) {
        emit(FloorPlanFailedState(msg: "Something went wrong"));
      }
    }
  }

  Future<bool> addFloorPlanValidation(Emitter emit) async {
    if(dragedWidget.isEmpty){
      emit(FloorPlanFailedState(msg: "Please setup floor"));
      return false;
    } else if(dragedWidget.any((element) => element.tableName.isEmpty)){
      emit(FloorPlanFailedState(msg: "Table title should not be empty"));
      return false;
    } else if(!await _checkConnectivity.hasConnection){
      emit(FloorPlanFailedState(msg: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  void _onChooseFloorImage(FloorPlanChooseImageEvent event, Emitter emit){
    floorImg = event.imagePath;
    emit(FloorPlanChooseImageState(imagePath: event.imagePath));
  }

  Future<void> _onSwitchUser(OnSwitchUserFloorEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(FloorPlanLoadingState());
        var response = await _floorPlanRepository.onClockOutUser();
        emit(OnSwitchUserFloorState(isLogout: response));
      } on CustomException catch (e) {
        emit(FloorPlanFailedState(msg: e.message));
      }
    }
  }

}