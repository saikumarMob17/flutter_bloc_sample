sealed class CashDrawerState {}

class CashDrawerInitialState extends CashDrawerState {}