import 'package:cliqtechnologies_retl/features/cash_drawer/presentation/bloc/cash_drawer_event.dart';
import 'package:cliqtechnologies_retl/features/cash_drawer/presentation/bloc/cash_drawer_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CashDrawerBloc extends Bloc<CashDrawerEvent, CashDrawerState>{

  CashDrawerBloc() : super(CashDrawerInitialState());
  
}