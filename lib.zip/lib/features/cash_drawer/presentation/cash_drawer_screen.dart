import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'bloc/cash_drawer_bloc.dart';
import 'bloc/cash_drawer_state.dart';

class CashDrawerScreen extends StatefulWidget {
  const CashDrawerScreen({super.key});

  @override
  State<CashDrawerScreen> createState() => _CashDrawerScreenState();
}

class _CashDrawerScreenState extends State<CashDrawerScreen> with SingleTickerProviderStateMixin {

  var tabTitleList = [
    AppStrings.active,
    AppStrings.open,
    AppStrings.closed
  ];
  
  int tabSelectedIndex = 0;
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<CashDrawerBloc, CashDrawerState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  const SizedBox(width: AppSize.s4),
                  CustomText(
                    title: AppStrings.cashDrawer,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to menu screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s24),
          CustomTextField(
            textController: TextEditingController(),
            hint: AppStrings.searchHere,
            prefixImagePath: AppImages.searchIcon,
            prefixImageColor: AppColors.lightGrey,
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
          ),
          TabBar(
            isScrollable: true,
            controller: _tabController,
            tabAlignment: TabAlignment.start,
            indicatorColor: AppColors.blue,
            indicatorWeight: AppSize.s05,
            dividerColor: AppColors.grey,
            dividerHeight: AppSize.s05,
            tabs: List.generate(
              tabTitleList.length, 
              (index) {
                var data = tabTitleList[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
                  child: CustomText(
                    title: data, 
                    textStyle: getMediumStyle(
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                );
              }
            )
          ),
          const SizedBox(height: AppSize.s20),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: List.generate(
                3, 
                (index) {
                  return GridView.count(
                    shrinkWrap: true,
                    crossAxisCount: 2,
                    crossAxisSpacing: AppSize.s15,
                    mainAxisSpacing: AppSize.s15,
                    children: List.generate(
                      3, 
                      (index) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s20,
                            vertical: AppSize.s30
                          ),
                          decoration: BoxDecoration(
                            color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                            borderRadius: BorderRadius.circular(AppSize.s10)
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const CustomImageView(
                                imagePath: AppImages.lockOpenIcon,
                                color: AppColors.primaryColor,
                              ),
                              const SizedBox(height: AppSize.s18),
                              CustomText(
                                title: 'RP Bar POS 2',
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s18,
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                ),
                              ),
                              const SizedBox(height: AppSize.s8),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  CustomText(
                                    title: 'Balance:  ',
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                  CustomText(
                                    title: '\$ 2.29',
                                    textStyle: getMediumStyle(color: AppColors.primaryColor),
                                  )
                                ],
                              )
                            ],
                          ),
                        );
                      }
                    )
                  );
                }
              )
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                padding: const EdgeInsets.all(AppSize.s20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: 'Cash Tenders',
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s22, 
                                color: Helper.isDark 
                                ? AppColors.white 
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              leftPadding: AppSize.s16,
                              rightPadding: AppSize.s16,
                              topPadding: AppSize.s16,
                              bottomPadding: AppSize.s14,
                              text: AppStrings.cashDrawerReport,
                              textColor: AppColors.primaryColor,
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomSolidButton(
                              onPressed: () => debugPrint(''),
                              horPadding: AppSize.s14,
                              verPadding: AppSize.s12,
                              text: AppStrings.switchUser,
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                            ),
                            const SizedBox(width: AppSize.s15),
                            CustomOutlinedButton(
                              onPressed: () => debugPrint(''),
                              // verPadding: AppSize.s12,
                              widget: const CustomImageView(imagePath: AppImages.menuHorizontalColor, blendMode: BlendMode.dstIn),
                              textColor: AppColors.primaryColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s20),
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 44,
                            width: context.screenWidth,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                              children: List.generate(
                                tabTitleList.length, 
                                (index) => GestureDetector(
                                  //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                    margin: const EdgeInsets.only(right: AppSize.s30),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: 3.0, 
                                          color: tabSelectedIndex == index 
                                          ? AppColors.primaryColor 
                                          : AppColors.transparent
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: CustomText(
                                        title: tabTitleList[index],
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s14,
                                          color: tabSelectedIndex == index 
                                          ? AppColors.primaryColor 
                                          : Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: context.screenWidth * 0.18,
                          child: CustomTextField(
                            textController: TextEditingController(),
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.lightTextColor,
                            horPadding: AppSize.s20,
                            verPadding: AppSize.s10,
                            hint: AppStrings.search
                          ),
                        ),
                      ],
                    ),  
                  ],
                ),
              ),
              const SizedBox(height: AppSize.s20),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20),
                  shrinkWrap: true,
                  children: [
                    Wrap(
                      children: List.generate(
                        5, 
                        (index) {
                          return Container(
                            margin: const EdgeInsets.only(right: AppSize.s40, bottom: AppSize.s40),
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s20,
                              vertical: AppSize.s30
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomImageView(
                                  imagePath: AppImages.lockOpenIcon,
                                  color: AppColors.primaryColor,
                                ),
                                const SizedBox(height: AppSize.s18),
                                CustomText(
                                  title: 'RP Bar POS ${index+1}',
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s18,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                const SizedBox(height: AppSize.s8),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CustomText(
                                      title: 'Balance:  ',
                                      textStyle: getMediumStyle(
                                        color: Helper.isDark 
                                        ? AppColors.white 
                                        : AppColors.black
                                      ),
                                    ),
                                    CustomText(
                                      title: '\$ 2.29',
                                      textStyle: getMediumStyle(color: AppColors.primaryColor),
                                    )
                                  ],
                                )
                              ],
                            ),
                          );
                        }
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

}