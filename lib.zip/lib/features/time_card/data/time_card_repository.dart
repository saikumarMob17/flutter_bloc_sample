import 'dart:convert';
import 'dart:io';
import '../../../constants/app_strings.dart';
import '../domain/time_card_response.dart';
import '../../../network/end_points.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../utils/helper.dart';

class TimeCardRepository {

  late ApiClient _apiClient;

  TimeCardRepository(){
    _apiClient = ApiClient();
  }

  Future<List<TimeCard>> fetchTimeCardDetails() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.timeCardDetails);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = timeCardResponseFromJson(response.body);
            return data.data ?? [];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
  
  Future<List<TimeCard>> fetchTimeCardUserDetails({required String employeeId}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.timeCardDetailsById}?empID=$employeeId");
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = timeCardResponseFromJson(response.body);
            return data.data ?? [];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}