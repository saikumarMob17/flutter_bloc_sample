import 'package:flutter/material.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_strings.dart';
import '../../../utils/helper.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_text.dart';

class TimeCardItemWidget extends StatelessWidget {

  final bool isHeader;
  final Color? backgroundColor;
  final String clockInName;
  final String clockInDateTime;
  final String clockOutName;
  final Function()? onTapClickIn;
  final Function()? onTapClickOut;

  const TimeCardItemWidget({
    super.key,
    required this.isHeader,
    this.backgroundColor,
    this.clockInDateTime = AppStrings.dateTime,
    this.clockInName = AppStrings.name,
    this.clockOutName = AppStrings.name,
    this.onTapClickIn,
    this.onTapClickOut
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 2,
          child: InkWell(
            onTap: backgroundColor == null
            ? null
            : onTapClickIn,
            child: Container(
              padding: const EdgeInsets.symmetric(
                vertical: AppSize.s15,
                horizontal: AppSize.s30
              ),
              decoration: BoxDecoration(
                color: backgroundColor ?? const Color(0xFFE3ECFF),
                borderRadius: isHeader 
                ? const BorderRadius.only(
                  topLeft: Radius.circular(AppSize.s6),
                  topRight: Radius.circular(AppSize.s6)
                )
                : null
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: CustomText(
                      title: clockInName, 
                      textStyle: backgroundColor == null 
                      ? getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black) 
                      : getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black)
                    ),
                  ),
                  Expanded(
                    child: CustomText(
                      title: clockInDateTime, 
                      textStyle: backgroundColor == null 
                      ? getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black) 
                      : getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black)
                    ),
                  ),
                  Expanded(
                    child: backgroundColor == null 
                    ? CustomText(
                        title: AppStrings.status, 
                        textAlign: TextAlign.end, 
                        textStyle: getMediumStyle(
                          color: Helper.isDark 
                          ? AppColors.white 
                          : AppColors.black
                        ),
                      )
                    : Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s5,
                            vertical: AppSize.s2
                          ),
                          alignment: Alignment.centerRight,
                          decoration: BoxDecoration(
                            color: AppColors.primaryColor,
                            borderRadius: BorderRadius.circular(3)
                          ),
                          child: const CustomText(
                            title: AppStrings.inString, 
                            color: AppColors.white
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: AppSize.s30),
        Expanded(
          child: InkWell(
            onTap: backgroundColor == null
            ? null
            : onTapClickOut,
            child: Container(
              padding: const EdgeInsets.symmetric(
                vertical: AppSize.s15,
                horizontal: AppSize.s30
              ),
              decoration: BoxDecoration(
                color: backgroundColor ?? const Color(0xFFE3ECFF),
                borderRadius: isHeader 
                ? const BorderRadius.only(
                  topLeft: Radius.circular(AppSize.s6),
                  topRight: Radius.circular(AppSize.s6)
                )
                : null
              ),
              child: Row(
                children: [
                  Expanded(
                    child: CustomText(
                      title: clockOutName, 
                      textStyle: backgroundColor == null 
                      ? getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black) 
                      : getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black)
                    )
                  ),
                  Expanded(
                    child: backgroundColor == null 
                    ? CustomText(
                        title: AppStrings.status, 
                        textAlign: TextAlign.end, 
                        textStyle: getMediumStyle(color: Helper.isDark ? AppColors.white : AppColors.black)
                      )
                    : Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: AppSize.s5,
                            vertical: AppSize.s2
                          ),
                          alignment: Alignment.centerRight,
                          decoration: BoxDecoration(
                            color: AppColors.green,
                            borderRadius: BorderRadius.circular(3)
                          ),
                          child: const CustomText(
                            title: AppStrings.out, 
                            color: AppColors.white
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
} 