import 'dart:convert';

TimeCardResponse timeCardResponseFromJson(String str) => TimeCardResponse.fromJson(json.decode(str));

class TimeCardResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<TimeCard>? data;

  TimeCardResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory TimeCardResponse.fromJson(Map<String, dynamic> json) => TimeCardResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<TimeCard>.from(json["data"]!.map((x) => TimeCard.fromJson(x))),
  );
}

class TimeCard {
  final String? employeeName;
  final String? location;
  final String? role;
  final String? date;
  final String? clockIn;
  final String? clockOut;
  final String? totalHours;
  final String? employeeId;

  TimeCard({
    this.employeeName,
    this.location,
    this.role,
    this.date,
    this.clockIn,
    this.clockOut,
    this.totalHours,
    this.employeeId,
  });

  factory TimeCard.fromJson(Map<String, dynamic> json) => TimeCard(
    employeeName: json["employeeName"],
    location: json["location"],
    role: json["role"],
    date: json["date"],
    clockIn: json["clockIn"],
    clockOut: json["clockOut"],
    totalHours: json["totalHours"],
    employeeId: json["employeeId"],
  );
}
