import 'package:flutter/material.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_text.dart';

class ClockInOutWidget extends StatelessWidget {

  final bool isHeader;
  final bool isClickIn;
  final Color? backgroundColor;
  final String employeeName;
  final String dateTime;
  final Function()? onTap;

  const ClockInOutWidget({
    super.key,
    required this.isHeader,
    this.backgroundColor,
    this.isClickIn = false, 
    this.employeeName = '', 
    this.dateTime = '', 
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s15,
          horizontal: AppSize.s20
        ),
        decoration: BoxDecoration(
          color: backgroundColor ?? const Color(0xFFE3ECFF),
          borderRadius: isHeader 
          ? const BorderRadius.only(
            topLeft: Radius.circular(AppSize.s6),
            topRight: Radius.circular(AppSize.s6)
          )
          : null
        ),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: CustomText(
                title: employeeName, 
                textStyle: getMediumStyle(
                  color: Helper.isDark 
                  ? AppColors.white 
                  : AppColors.black
                ),
              ),
            ),
            Visibility(
              visible: isClickIn,
              child: Expanded(
                child: CustomText(
                  title: dateTime, 
                  textStyle: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
              ),
            ),
            Expanded(
              child: isHeader 
              ? CustomText(
                  title: AppStrings.status, 
                  textAlign: TextAlign.end, 
                  textStyle: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                )
              : Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSize.s5,
                      vertical: AppSize.s2
                    ),
                    alignment: Alignment.centerRight,
                    decoration: BoxDecoration(
                      color: isClickIn 
                      ?AppColors.primaryColor 
                      : AppColors.green,
                      borderRadius: BorderRadius.circular(3)
                    ),
                    child: CustomText(
                      title: isClickIn 
                      ? AppStrings.inString 
                      : AppStrings.out, 
                      color: AppColors.white
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}