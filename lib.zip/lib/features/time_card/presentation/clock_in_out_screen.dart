import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../domain/time_card_response.dart';
import 'bloc/clock_in_out/clock_in_out_bloc.dart';
import '../../../widgets/custom_outlined_button.dart';

class ClockInOutScreen extends StatefulWidget {
  final String employeeId;
  const ClockInOutScreen({super.key, required this.employeeId});

  @override
  State createState() => _ClockInOutScreenState();
}

class _ClockInOutScreenState extends State<ClockInOutScreen> with Helper {

  var clockInOutTag = [
    AppStrings.date,
    AppStrings.job,
    AppStrings.inString,
    AppStrings.out,
    AppStrings.hours,
  ];

  var currentDateTime = [];

  var timeCardDetailsList = <TimeCard>[];
  String employeeName = '';
  String employeeLocation = '';
  String employeeRole = '';

  @override
  void initState() {
    currentDateTime = Helper.getFormattedDateTime();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<ClockInOutBloc, ClockInOutState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case FetchUserDetailsState:
              state = state as FetchUserDetailsState;
              timeCardDetailsList.clear();
              timeCardDetailsList.addAll(state.timeCardList);
              if(timeCardDetailsList.isNotEmpty) {
                employeeName = timeCardDetailsList.first.employeeName ?? '';
                employeeLocation = timeCardDetailsList.first.location ?? '';
                employeeRole = timeCardDetailsList.first.role ?? '';
              }
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state.runtimeType) {
            case ClockInOutLoadingState:
              showLoadingDialog(context: context);
              break;
            case ClockInOutFailedState:
              state = state as ClockInOutFailedState;
              hideLoadingDialog(context: context);
              if(state.message.isNotEmpty){
                showSnackBar(context: context, title: state.message);
              }
              break;
            case FetchUserDetailsState:
              hideLoadingDialog(context: context);
              break;
            case OnSwitchUserClockInOutState:
              hideLoadingDialog(context: context);
              state = state as OnSwitchUserClockInOutState;
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.clockInOut,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18, 
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => context.read<ClockInOutBloc>().add(OnSwitchUserClockInOutEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s10),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s10),
          Container(
            padding: const EdgeInsets.all(AppSize.s10),
            decoration: BoxDecoration(
              color: Helper.isDark 
              ? AppColors.contentColorDark 
              : AppColors.white,
              borderRadius: BorderRadius.circular(AppSize.s10)
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const CustomImageView(
                  imagePath: AppImages.userIcon
                ),
                const SizedBox(height: AppSize.s20),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: AppSize.s60),
                  child: Divider(
                    color: AppColors.grey, 
                    height: AppSize.s1, 
                    thickness: AppSize.s1
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                CustomText(
                  title: employeeName, 
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s20,
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
                const SizedBox(height: AppSize.s8),
                CustomText(
                  title: employeeLocation, 
                  textStyle: getRegularStyle(
                    fontSize: AppSize.s14, 
                    color: AppColors.grey
                  ),
                ),
                const SizedBox(height: AppSize.s5),
                CustomText(
                  title: currentDateTime[0] +"  "+ currentDateTime[1], 
                  textStyle: getRegularStyle(
                    fontSize: AppSize.s14, 
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
                const SizedBox(height: AppSize.s15),
                Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: AppSize.s8,
                    horizontal: AppSize.s20,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor,
                    borderRadius: BorderRadius.circular(AppSize.s6)
                  ),
                  child: CustomText(
                    title: employeeRole,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s16,
                      color: AppColors.white
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSize.s30),
          Scrollbar(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              physics: const NeverScrollableScrollPhysics(),
              child: Scrollbar(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SizedBox(
                    height: 350, 
                    width: context.screenWidth * 2, 
                    child: Column(
                      children: [
                        Container(
                          color: Helper.isDark 
                          ? AppColors.contentColorDark 
                          : AppColors.white,
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSize.s15,
                            horizontal: AppSize.s8
                          ),
                          child: Row(
                            children: List.generate(
                              clockInOutTag.length, 
                              (index) => Expanded(
                                child: CustomText(
                                  title: clockInOutTag[index], 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: timeCardDetailsList.length,
                            padding: EdgeInsets.zero,
                            itemBuilder: (_, index){
                              var data = timeCardDetailsList[index];
                              return Container(
                                color: Helper.isDark 
                                ? index%2 == 0 ? AppColors.transparent : AppColors.contentColorDark
                                : index%2 == 0 ? AppColors.transparent : AppColors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s10,
                                  horizontal: AppSize.s8
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: CustomText(
                                        title: data.date!.substring(0,10).split('-').reversed.join('/'), 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.role ?? '', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.clockIn == null
                                        ? '--'
                                        : "${data.date!.substring(0,11)}${data.clockIn}".convertTimeClockOut,
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.clockOut == null
                                        ? '--'
                                        : "${data.date!.substring(0,11)}${data.clockOut}".convertTimeClockOut,
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: CustomText(
                                        title: data.totalHours ?? '--', 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s12, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(selectedLeftNavigationItem: 0),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark 
                ? AppColors.black
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.clockInOut,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20,
                            color: Helper.isDark 
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        CustomSolidButton(
                          onPressed: () => context.read<ClockInOutBloc>().add(OnSwitchUserClockInOutEvent()),
                          text: AppStrings.switchUser,
                          prefix: const Icon(
                            Icons.swap_horiz_rounded, 
                            color: AppColors.white
                          ),
                        ),
                        // const SizedBox(width: AppSize.s10),
                        // CustomIconButton(
                        //   onPressed: () => debugPrint(''),
                        //   horPadding: AppSize.s10,
                        //   verPadding: AppSize.s10,
                        //   widget: const CustomImageView(
                        //     imagePath: AppImages.menuHorizontalColor, 
                        //     blendMode: BlendMode.dstIn
                        //   ),
                        // ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 80,
                    vertical: AppSize.s26
                  ),
                  children: [
                    const SizedBox(height: AppSize.s30),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s40,
                        vertical: AppSize.s30
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.contentColorDark 
                        : AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10)
                      ),
                      child: Row(
                        children: [
                          const CustomImageView(
                            imagePath: AppImages.userIcon,
                          ),
                          const SizedBox(width: AppSize.s50),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  title: employeeName, 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s20,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                const SizedBox(height: AppSize.s5),
                                CustomText(
                                  title: employeeLocation, 
                                  textStyle: getMediumStyle(
                                    fontSize: AppSize.s14, 
                                    color: AppColors.grey
                                  ),
                                ),
                                const SizedBox(height: AppSize.s5),
                                CustomText(
                                  title: currentDateTime[0]+"  "+currentDateTime[1], 
                                  textStyle: getRegularStyle(
                                    fontSize: AppSize.s14,
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 600),
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s10,
                              horizontal: AppSize.s20,
                            ),
                            decoration: BoxDecoration(
                              color: employeeRole.isEmpty 
                              ? AppColors.transparent
                              : AppColors.primaryColor,
                              borderRadius: BorderRadius.circular(AppSize.s6)
                            ),
                            child: CustomText(
                              title: employeeRole,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s20,
                                color: AppColors.white
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppSize.s34),
                    Align(
                      alignment: Alignment.centerRight,
                      child: CustomOutlinedButton(
                        onPressed: () => debugPrint('Click here for more info'),
                        text: AppStrings.moreInfo,
                        textColor: AppColors.blue,
                      ),
                    ),
                    const SizedBox(height: AppSize.s34),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s40,
                        vertical: AppSize.s15
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.contentColorDark 
                        : AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10)
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: CustomText(
                              title: AppStrings.date,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14, 
                                color: AppColors.blue
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.job,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14, 
                                color: AppColors.blue
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.inString,
                              textAlign: TextAlign.center,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14, 
                                color: AppColors.blue
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.out,
                              textAlign: TextAlign.center,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14, 
                                color: AppColors.blue
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomText(
                              title: AppStrings.hours,
                              textAlign: TextAlign.end,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14, 
                                color: AppColors.blue
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppSize.s10),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSize.s40,
                        vertical: AppSize.s15
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.contentColorDark 
                        : AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10)
                      ),
                      child: ListView.builder(
                        itemCount: timeCardDetailsList.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (_, index){
                          var data = timeCardDetailsList[index];
                          return Container(
                            padding: const EdgeInsets.only(bottom: AppSize.s15, top: AppSize.s15),
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: AppColors.grey, 
                                  width: AppSize.s05
                                ),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: CustomText(
                                    title: data.date!.substring(0,10).split('-').reversed.join('/'),
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: data.role ?? '',
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: data.clockIn == null
                                    ? '--'
                                    : data.date!.convertTimeClockOut,
                                    textAlign: TextAlign.center,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: data.clockOut == null
                                    ? '--'
                                    : "${data.date!.substring(0,11)}${data.clockOut}${data.date!.substring(19)}".convertTimeClockOut,
                                    textAlign: TextAlign.center,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: data.totalHours == null
                                    ? '--'
                                    : data.totalHours!,
                                    textAlign: TextAlign.end,
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}