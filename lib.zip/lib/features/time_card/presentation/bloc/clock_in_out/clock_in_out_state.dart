part of 'clock_in_out_bloc.dart';

sealed class ClockInOutState {}

class ClockInOutInitialState extends ClockInOutState {}

class ClockInOutLoadingState extends ClockInOutState {}

class ClockInOutFailedState extends ClockInOutState {
  String message;

  ClockInOutFailedState({this.message = ''});
}

class FetchUserDetailsState extends ClockInOutState {
  List<TimeCard> timeCardList;

  FetchUserDetailsState({required this.timeCardList});
}

class OnSwitchUserClockInOutState extends ClockInOutState {
  bool isLogout;
  OnSwitchUserClockInOutState({this.isLogout = false});
}