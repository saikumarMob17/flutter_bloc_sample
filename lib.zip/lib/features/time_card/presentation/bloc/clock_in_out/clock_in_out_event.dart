part of 'clock_in_out_bloc.dart';

sealed class ClockInOutEvent {}

class FetchUserDetailsEvent extends ClockInOutEvent {
  String employeeId;

  FetchUserDetailsEvent({required this.employeeId});
}

class OnSwitchUserClockInOutEvent extends ClockInOutEvent {}