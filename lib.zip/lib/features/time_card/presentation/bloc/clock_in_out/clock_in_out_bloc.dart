import '../../../../../constants/app_strings.dart';
import '../../../data/time_card_repository.dart';
import '../../../domain/time_card_response.dart';
import '../../../../../network/custom_exception.dart';
import '../../../../../utils/check_connectivity.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
part 'clock_in_out_event.dart';
part 'clock_in_out_state.dart';

class ClockInOutBloc extends Bloc<ClockInOutEvent, ClockInOutState>{

  late CheckConnectivity _checkConnectivity;
  late TimeCardRepository _repository;
  var timeCardUserDetailsList = <TimeCard>[];

  ClockInOutBloc() : super(ClockInOutInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = TimeCardRepository();
    on<FetchUserDetailsEvent>(_onFetchUserDetails);
    on<OnSwitchUserClockInOutEvent>(_onSwitchUser);
  }

  Future<void> _onFetchUserDetails(FetchUserDetailsEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(ClockInOutLoadingState());
        var data = await _repository.fetchTimeCardUserDetails(employeeId: event.employeeId);
        timeCardUserDetailsList.clear();
        timeCardUserDetailsList.addAll(data);
        emit(FetchUserDetailsState(timeCardList: timeCardUserDetailsList));
      } on CustomException catch(e) {
        emit(ClockInOutFailedState(message: e.message));
      }
    } else {
      emit(ClockInOutFailedState(message: AppStrings.noInternetConnection));
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserClockInOutEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(ClockInOutLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserClockInOutState(isLogout: response));
      } on CustomException catch (e) {
        emit(ClockInOutFailedState(message: e.message));
      }
    }
  }
}