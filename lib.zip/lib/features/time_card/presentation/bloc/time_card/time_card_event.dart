part of 'time_card_bloc.dart';

sealed class TimeCardEvent {}

class FetchTimeCardDetailsEvent extends TimeCardEvent {}

class OnSwitchUserTimeCardEvent extends TimeCardEvent {}

class OnSearchEmployeeEvent extends TimeCardEvent {
  String name;

  OnSearchEmployeeEvent({this.name = ''});
}