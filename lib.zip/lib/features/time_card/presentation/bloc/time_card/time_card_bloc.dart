import '../../../domain/time_card_response.dart';
import '../../../data/time_card_repository.dart';
import '../../../../../utils/check_connectivity.dart';
import '../../../../../network/custom_exception.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'time_card_event.dart';
part 'time_card_state.dart';

class TimeCardBloc extends Bloc<TimeCardEvent, TimeCardState>{
  
  late TimeCardRepository _repository;
  late CheckConnectivity _checkConnectivity;
  List<TimeCard> timeCardList = [];
  List<TimeCard> originalTimeCardList = [];

  TimeCardBloc() : super(TimeCardInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = TimeCardRepository();
    on<FetchTimeCardDetailsEvent>(_onFetchTimeCardDetails);
    on<OnSwitchUserTimeCardEvent>(_onSwitchUser);
    on<OnSearchEmployeeEvent>(_onSearchEmployee);
  }

  Future<void> _onFetchTimeCardDetails(FetchTimeCardDetailsEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(TimeCardLoadingState());
        var data = await _repository.fetchTimeCardDetails();
        timeCardList.clear();
        originalTimeCardList.clear();
        timeCardList.addAll(data);
        originalTimeCardList.addAll(data);
        emit(FetchTimeCardDetailsState(timeCardList: timeCardList));
      } on CustomException catch (e) {
        emit(TimeCardFailedState(message: e.message));
      }
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserTimeCardEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(TimeCardLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserTimeCardState(isLogout: response));
      } on CustomException catch (e) {
        emit(TimeCardFailedState(message: e.message));
      }
    }
  }

  void _onSearchEmployee(OnSearchEmployeeEvent event, Emitter<TimeCardState> emit) {
    timeCardList.clear();
    if(event.name.isEmpty){
      timeCardList.addAll(originalTimeCardList);
    } else {
      for(var item in originalTimeCardList){
        if(item.employeeName!.toLowerCase().contains(event.name.toLowerCase())){
          timeCardList.add(item);
        }
      }
    }
    emit(FetchTimeCardDetailsState(timeCardList: timeCardList));
  }
}