part of 'time_card_bloc.dart';
sealed class TimeCardState {}

class TimeCardInitialState extends TimeCardState {}

class TimeCardLoadingState extends TimeCardState {}

class TimeCardFailedState extends TimeCardState {
  String message;
  TimeCardFailedState({this.message = ''});
}

class OnSwitchUserTimeCardState extends TimeCardState {
  bool isLogout;
  OnSwitchUserTimeCardState({this.isLogout = false});
}

class FetchTimeCardDetailsState extends TimeCardState {
  List<TimeCard> timeCardList;

  FetchTimeCardDetailsState({required this.timeCardList});
}