import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'bloc/time_card/time_card_bloc.dart';
import '../domain/time_card_response.dart';
import '../../../routes/app_routes.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../widgets/custom_empty_widget.dart';
import '../domain/clock_in_out_widget.dart';


class TimeCardScreen extends StatefulWidget {
  const TimeCardScreen({super.key});

  @override
  State createState() => _TimeCardScreenState();
}

class _TimeCardScreenState extends State<TimeCardScreen> with SingleTickerProviderStateMixin, Helper {

  late TabController _tabController;
  var timeCardDetailsList = <TimeCard>[];
  var clockInTimeCard = <TimeCard>[];
  var clockOutTimeCard = <TimeCard>[];

  @override
  void initState() {
    _tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark
      ? AppColors.backgroundColorDark
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     var dateTime = DateTime.now();
      //     print(dateTime.toString());
      //     print(DateTime.parse("2024-07-05T12:00:35.8768041Z").toLocal());
      //     print(dateTime.toUtc().toLocal());
      //   },
      //   child: const Icon(Icons.conveyor_belt)
      // ),
      body: BlocConsumer<TimeCardBloc, TimeCardState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case FetchTimeCardDetailsState:
              state = state as FetchTimeCardDetailsState;
              timeCardDetailsList.clear();
              timeCardDetailsList.addAll(state.timeCardList);
              clockInTimeCard.clear();
              clockOutTimeCard.clear();
              clockInTimeCard = timeCardDetailsList.where((element) => element.clockOut == null).toList();
              clockOutTimeCard = timeCardDetailsList.where((element) => element.clockOut != null).toList();
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state.runtimeType) {
            case FetchTimeCardDetailsState:
              hideLoadingDialog(context: context);
              break;
            case TimeCardLoadingState:
              showLoadingDialog(context: context);
              break;
            case TimeCardFailedState:
              hideLoadingDialog(context: context);
              state = state as TimeCardFailedState;
              if(state.message.isNotEmpty) {
                showSnackBar(context: context, title: state.message);
              }
              break;
            case OnSwitchUserTimeCardState:
              hideLoadingDialog(context: context);
              state = state as OnSwitchUserTimeCardState;
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  const SizedBox(width: AppSize.s4),
                  CustomText(
                    title: AppStrings.timeCard,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => context.read<TimeCardBloc>().add(OnSwitchUserTimeCardEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s8),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s24),
          CustomTextField(
            hint: AppStrings.searchHere,
            prefixImagePath: AppImages.searchIcon,
            prefixImageColor: AppColors.lightGrey,
            horPadding: AppSize.s12,
            verPadding: AppSize.s12,
            onChange: (value) => context.read<TimeCardBloc>().add(OnSearchEmployeeEvent(name: value)),
          ),
          TabBar(
            isScrollable: true,
            controller: _tabController,
            tabAlignment: TabAlignment.start,
            indicatorColor: AppColors.blue,
            indicatorWeight: AppSize.s05,
            dividerColor: AppColors.grey,
            dividerHeight: AppSize.s05,
            tabs: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
                child: CustomText(
                  title: AppStrings.clockIn, 
                  textStyle: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppSize.s15),
                child: CustomText(
                  title: AppStrings.clockOut, 
                  textStyle: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
              ),
            ]
          ),
          const SizedBox(height: AppSize.s20),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppSize.s15),
                      decoration: BoxDecoration(
                        color: Helper.isDark
                        ? AppColors.contentColorDark
                        : const Color(0xFFE3ECFF),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(AppSize.s6),
                          topRight: Radius.circular(AppSize.s6),
                        ),
                        border: Border.all(width: AppSize.s1, color: Helper.isDark
                        ? AppColors.contentColorDark
                        : const Color(0xFFE3ECFF))
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            flex: 2,
                            child: CustomText(
                              title: AppStrings.name,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: CustomText(
                              title: AppStrings.dateTime,
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                CustomText(
                                  title: AppStrings.status,
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: clockInTimeCard.length,
                        itemBuilder: (_, index) {
                          var data = clockInTimeCard[index];
                          return Container(
                            color: Helper.isDark
                            ? index%2 == 0 
                              ? AppColors.black 
                              : AppColors.transparent
                            : index%2 == 0 
                              ? AppColors.white 
                              : AppColors.transparent,
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s15,
                              vertical: AppSize.s10
                            ),
                            child: InkWell(
                              onTap: () {
                                if(data.employeeId != null){
                                  context.push(AppRoutes.clockInOutScreen, extra: data.employeeId);
                                }
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: CustomText(
                                      title: data.employeeName ?? '',
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black,
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: CustomText(
                                      title: data.date == null
                                      ? ''
                                      : data.date!.convertDateTimeClockOut,
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black,
                                    ),
                                  ),
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: AppSize.s5,
                                            vertical: AppSize.s2
                                          ),
                                          alignment: Alignment.centerRight,
                                          decoration: BoxDecoration(
                                            color: AppColors.primaryColor,
                                            borderRadius: BorderRadius.circular(3)
                                          ),
                                          child: const CustomText(
                                            title: AppStrings.inString, 
                                            color: AppColors.white
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(AppSize.s15),
                      decoration: BoxDecoration(
                        color: Helper.isDark
                        ? AppColors.contentColorDark
                        : const Color(0xFFE3ECFF),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(AppSize.s6),
                          topRight: Radius.circular(AppSize.s6),
                        ),
                        border: Border.all(width: AppSize.s1, color: Helper.isDark
                        ? AppColors.contentColorDark
                        : const Color(0xFFE3ECFF))
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: CustomText(
                              title: AppStrings.name, 
                              textStyle: getMediumStyle(
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                CustomText(
                                  title: AppStrings.status, 
                                  textStyle: getMediumStyle(
                                    color: Helper.isDark
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: clockOutTimeCard.length,
                        itemBuilder: (_, index) {
                          var data = clockOutTimeCard[index];
                          return Container(
                            color: Helper.isDark
                            ? index%2 == 0 ? AppColors.black : AppColors.transparent
                            : index%2 == 0 ? AppColors.white : AppColors.transparent,
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s15,
                              vertical: AppSize.s10
                            ),
                            child: InkWell(
                              onTap: () {
                                if(data.employeeId != null){
                                  context.push(AppRoutes.clockInOutScreen, extra: data.employeeId);
                                }
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Expanded(
                                    child: CustomText(
                                      title: data.employeeName ?? '',
                                      color: Helper.isDark
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: AppSize.s5,
                                            vertical: AppSize.s2
                                          ),
                                          alignment: Alignment.centerRight,
                                          decoration: BoxDecoration(
                                            color: AppColors.green,
                                            borderRadius: BorderRadius.circular(3)
                                          ),
                                          child: const CustomText(title: AppStrings.out, color: AppColors.white)
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s18),
                color: Helper.isDark 
                ?AppColors.black
                :AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.timeCard,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20,
                            color: Helper.isDark
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: context.screenWidth * 0.15,
                          child: CustomTextField(
                            hint: AppStrings.searchHere,
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.lightTextGrey,
                            verPadding: 9,
                            horPadding: AppSize.s14,
                            prefixImageSize: AppSize.s16,
                            onChange: (value) => context.read<TimeCardBloc>().add(OnSearchEmployeeEvent(name: value)),
                          ),
                        ),
                        const SizedBox(width: AppSize.s8),
                        CustomSolidButton(
                          onPressed: () => context.read<TimeCardBloc>().add(OnSwitchUserTimeCardEvent()),
                          text: AppStrings.switchUser,
                          prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                        ),
                        // const SizedBox(width: AppSize.s10),
                        // CustomIconButton(
                        //   onPressed: () => debugPrint(''),
                        //   horPadding: AppSize.s10,
                        //   verPadding: AppSize.s10,
                        //   widget: const CustomImageView(
                        //     imagePath: AppImages.menuHorizontalColor, 
                        //     blendMode: BlendMode.dstIn
                        //   ),
                        // ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(
                  left: AppSize.s40,
                  right: AppSize.s20,
                  top: AppSize.s20,
                  bottom: AppSize.s10
                ),
                color: Helper.isDark
                ?AppColors.black
                : AppColors.white,
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: CustomText(
                        title: AppStrings.clockIn,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16,
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSize.s20),
                    Expanded(
                      child: CustomText(
                        title: AppStrings.clockOut,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s16,
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: clockInTimeCard.isEmpty && clockOutTimeCard.isEmpty
                  ? CustomEmptyWidget(
                      imagePath: AppImages.notFound, 
                      emptyTitle: AppStrings.noRecordFound,
                      isVisible: !isLoadingVisible,
                    )
                  : Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Column(
                          children: [
                            ClockInOutWidget(
                              isHeader: true,
                              isClickIn: true,
                              employeeName: AppStrings.name,
                              dateTime: AppStrings.dateTime,
                              backgroundColor: Helper.isDark
                              ? AppColors.contentColorDark 
                              : null,
                            ),
                            Expanded(
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: clockInTimeCard.length,
                                padding: EdgeInsets.zero,
                                itemBuilder: (_, index){
                                  var data = clockInTimeCard[index];
                                  return ClockInOutWidget(
                                    isHeader: false, 
                                    isClickIn: true,
                                    backgroundColor: Helper.isDark
                                    ? index%2 == 1 ? AppColors.contentColorDark : AppColors.transparent
                                    : index%2 == 1 ? AppColors.backgroundColor : AppColors.white, 
                                    employeeName: data.employeeName ?? '', 
                                    dateTime: data.date == null
                                    ? ''
                                    : data.date!.convertDateTimeClockOut,
                                    onTap: () {
                                      if(data.employeeId != null){
                                        context.push(AppRoutes.clockInOutScreen, extra: data.employeeId);
                                      }
                                    },
                                  );
                                }
                              )
                            )
                          ],
                        )
                      ),
                      const SizedBox(width: AppSize.s15),
                      Expanded(
                        flex: 1,
                        child: Column(
                          children: [
                            ClockInOutWidget(
                              isHeader: true,
                              isClickIn: false,
                              employeeName: AppStrings.name,
                              backgroundColor: Helper.isDark
                              ? AppColors.contentColorDark 
                              : null,
                            ),
                            Expanded(
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: clockOutTimeCard.length,
                                padding: EdgeInsets.zero,
                                itemBuilder: (_, index){
                                  var data = clockOutTimeCard[index];
                                  return ClockInOutWidget(
                                    isHeader: false, 
                                    isClickIn: false,
                                    backgroundColor: Helper.isDark
                                    ? index%2 == 1 ? AppColors.contentColorDark : AppColors.transparent
                                    : index%2 == 1 ? AppColors.backgroundColor : AppColors.white, 
                                    employeeName: data.employeeName ?? '',
                                    onTap: () {
                                      if(data.employeeId != null){
                                        context.push(AppRoutes.clockInOutScreen, extra: data.employeeId);
                                      }
                                    },
                                  );
                                }
                              )
                            )
                          ],
                        )
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}