part of 'table_view_bloc.dart';

sealed class TableViewEvent {}

class TableViewSelectTableEvent extends TableViewEvent {
  int selectedIndex;
  TableViewSelectTableEvent({this.selectedIndex = 0});
}

class TableViewRemoveTableEvent extends TableViewEvent {
  int removeIndex;
  TableViewRemoveTableEvent({this.removeIndex = 0});
}

class TableViewChangeCustomerNameEvent extends TableViewEvent {
  String name;
  TableViewChangeCustomerNameEvent({required this.name});
}

class TableViewSelectGuestEvent extends TableViewEvent {
  int totalGuest;
  int index;
  TableViewSelectGuestEvent({this.index = -1, this.totalGuest = 0});
}

class TableViewNewOrderEvent extends TableViewEvent {
  String tableName;
  String customerName;
  String customerIdentity;
  int totalPerson;

  TableViewNewOrderEvent({
    required this.tableName, 
    required this.customerName, 
    required this.totalPerson,
    required this.customerIdentity
  });
}

class TableViewGetFloorPlanEvent extends TableViewEvent {}

class TableViewFreeTableEvent extends TableViewEvent {
  List<int> tableId;
  TableViewFreeTableEvent({required this.tableId});
}

class TableViewEmployeeListEvent extends TableViewEvent {}

class TableViewOnChangeEmployeeEvent extends TableViewEvent {
  String employeeId;

  TableViewOnChangeEmployeeEvent({this.employeeId = ''});
}

class TableViewEmailChangeEvent extends TableViewEvent {
  String email;
  TableViewEmailChangeEvent({this.email = ''});
}


class TableViewPasswordChangeEvent extends TableViewEvent {
  String password;
  TableViewPasswordChangeEvent({this.password = ''});
}

class TableViewPinEnterEvent extends TableViewEvent {
  int value;
  TableViewPinEnterEvent({required this.value});
}

class TableViewChangeAuthorizationEvent extends TableViewEvent {
  LoginType loginType;

  TableViewChangeAuthorizationEvent({this.loginType = LoginType.userName});
}

class TableViewAuthorizeEvent extends TableViewEvent {
  
  LoginType loginType;
  String firstText;
  String secondText;

  TableViewAuthorizeEvent({
    required this.loginType,
    this.firstText = '',
    this.secondText = '',
  });
}

class TableViewSelectServerEvent extends TableViewEvent {
  String selectedIndex;

  TableViewSelectServerEvent({this.selectedIndex = ''});
}

class TableViewOnChangeServerEvent extends TableViewEvent {
  String serverId;
  String orderId;
  TableViewOnChangeServerEvent({required this.serverId, required this.orderId});
}

class TableViewOnCloseAuthDialogEvent extends TableViewEvent {}

class TableViewFetchFinixIntitiesEvent extends TableViewEvent {}

class TableViewOnSelectFinixUserEvent extends TableViewEvent {
  FinixIdentityModel? finixUser;

  TableViewOnSelectFinixUserEvent({this.finixUser});
}

class TableViewFinixEmailChangeEvent extends TableViewEvent {
  String text;

  TableViewFinixEmailChangeEvent({this.text = ''});
}

class TableViewFinixFirstNameChangeEvent extends TableViewEvent {
  String text;

  TableViewFinixFirstNameChangeEvent({this.text = ''});
}

class TableViewFinixLastNameChangeEvent extends TableViewEvent {
  String text;

  TableViewFinixLastNameChangeEvent({this.text = ''});
}

class TableViewFinixCreateCustomerEvent extends TableViewEvent {
  String firstName;
  String lastName;
  String email;
  String phone;

  TableViewFinixCreateCustomerEvent({
    this.firstName = '',
    this.lastName = '',
    this.email = '',
    this.phone = '',
  });
}

class TableViewHideFinixErrorEvent extends TableViewEvent {}

class TableViewEnableAuthorizeCardEvent extends TableViewEvent {
  bool isEnable;

  TableViewEnableAuthorizeCardEvent({this.isEnable = false});
}


class OnSwitchUserTableEvent extends TableViewEvent {}