import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/all_employees_response.dart';
import '../../data/table_view_repository.dart';
import '../../../../network/end_points.dart';
import '../../../../services/finix_create_identity_model.dart';
import '../../../../services/finix_identity_model.dart';
import '../../../../utils/app_extension_method.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../../constants/app_strings.dart';
import '../../../../utils/helper.dart';
import '../../../setup_floor/domain/all_floor_plan_response.dart';
import '../../../setup_floor/domain/table_shape_model.dart';
import '../../../../network/custom_exception.dart';
import '../../../../utils/shared_pref.dart';
import '../../domain/authorization_request.dart';
part 'table_view_event.dart';
part 'table_view_state.dart';

class TableViewBloc extends Bloc<TableViewEvent, TableViewState>{

  List<TableShapeModel> tableList = [];
  List<TableShapeModel> selectedTableList = [];
  List<Employees> employeesList = [];
  List<int> enteredPin = [];
  List<FinixIdentityModel> finixIdentityModel = [];
  late CheckConnectivity _checkConnectivity;
  late TableViewRepository _tableViewRepository;

  TableViewBloc() : super(TableViewInitialState()) {
    _checkConnectivity = CheckConnectivity();
    _tableViewRepository = TableViewRepository();
    on<TableViewSelectTableEvent>(_onSelectTable);
    on<TableViewRemoveTableEvent>(_onRemoveSelectedTable);
    on<TableViewSelectGuestEvent>(_onSelectGuest);
    on<TableViewChangeCustomerNameEvent>(_onCustomerNameChange);
    on<TableViewNewOrderEvent>(_onPlaceOrder);
    on<TableViewGetFloorPlanEvent>(_onFetchFloorPlan);
    on<TableViewFreeTableEvent>(_onFreeTable);
    on<TableViewOnChangeServerEvent>(_onChangeServer);
    on<TableViewChangeAuthorizationEvent>(_onChangeAuthorizationType);
    on<TableViewEmailChangeEvent>(_onAuthorizationEmailChange);
    on<TableViewPasswordChangeEvent>(_onAuthorizationPasswordChange);
    on<TableViewAuthorizeEvent>(_onAuthorizeUser);
    on<TableViewPinEnterEvent>(_onChangePinEnter);
    on<TableViewEmployeeListEvent>(_employeeList);
    on<TableViewSelectServerEvent>(_onSelectServer);
    on<TableViewOnCloseAuthDialogEvent>(_onCloseAuthDialog);
    on<TableViewFetchFinixIntitiesEvent>(_fetchAllFinixIdentities);
    on<TableViewOnSelectFinixUserEvent>(_onSelectFinixUser);
    on<TableViewFinixEmailChangeEvent>(_onChangeFinixEmail);
    on<TableViewFinixFirstNameChangeEvent>(_onChangeFinixFirstName);
    on<TableViewFinixLastNameChangeEvent>(_onChangeFinixLastName);
    on<TableViewFinixCreateCustomerEvent>(_createNewFinixCustomer);
    on<TableViewHideFinixErrorEvent>(_onHideFinixError);
    on<TableViewOnChangeEmployeeEvent>(_onChangeNewOrderServer);
    on<TableViewEnableAuthorizeCardEvent>(_onEnableAuthorizeCard);
    on<OnSwitchUserTableEvent>(_onSwitchUser);
  }

  Future<void> _onSwitchUser(OnSwitchUserTableEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(TableViewLoadingState());
        var response = await _tableViewRepository.onClockOutUser();
        emit(OnSwitchUserTableState(isLogout: response));
      } on CustomException catch (e) {
        emit(TableViewFailedState(msg: e.message));
      }
    }
  }

  void _onEnableAuthorizeCard(TableViewEnableAuthorizeCardEvent event, Emitter emit) {
    emit(TableViewEnableAuthorizeCardState(isEnable: event.isEnable));
  }

  void _onChangeNewOrderServer(TableViewOnChangeEmployeeEvent event, Emitter emit) {
    emit(TableViewOnChangeEmployeeState(employeeId: event.employeeId));
  }
 
  void _onHideFinixError(TableViewHideFinixErrorEvent event, Emitter emit) {
    emit(TableViewHideFinixErrorState());
  }

  void _onChangeFinixFirstName(TableViewFinixFirstNameChangeEvent event, Emitter emit) {
    if(event.text.isEmpty) {
      emit(TableViewFinixFirstNameChangeState(text: "Please provide first name"));
    } else {
      emit(TableViewFinixFirstNameChangeState(text: ""));
    }
  }

  void _onChangeFinixLastName(TableViewFinixLastNameChangeEvent event, Emitter emit) {
    if(event.text.isEmpty) {
      emit(TableViewFinixLastNameChangeState(text: "Please provide last name"));
    } else {
      emit(TableViewFinixLastNameChangeState(text: ""));
    }
  }

  void _onChangeFinixEmail(TableViewFinixEmailChangeEvent event, Emitter emit) {
    if(event.text.isBlank) {
      emit(TableViewFinixEmailChangeState(text: "Please provide email"));
    } else if(!event.text.isValidEmail){
      emit(TableViewFinixEmailChangeState(text: "Please provide valid email"));
    } else {
      emit(TableViewFinixEmailChangeState(text: ""));
    }
  }
  
  void _onSelectFinixUser(TableViewOnSelectFinixUserEvent event, Emitter emit) {
    if(event.finixUser == null) {
      emit(TableViewOnSelectFinixUserState(finixUser: event.finixUser, nameError: AppStrings.provideCustomerName));
    } else {
      emit(TableViewOnSelectFinixUserState(finixUser: event.finixUser, nameError: AppStrings.emptyString));
    }
  }

  void _onCloseAuthDialog(TableViewOnCloseAuthDialogEvent event, Emitter emit) {
    enteredPin.clear();
  }

  void _onSelectServer(TableViewSelectServerEvent event, Emitter emit){
    emit(TableViewSelectServerState(selectedServerId: event.selectedIndex));
  }

  void _onChangePinEnter(TableViewPinEnterEvent event, Emitter emit) {
    if(event.value.isNegative) {
      if(enteredPin.isNotEmpty) {
        enteredPin.removeLast();
      }
    } else {
      if(enteredPin.length < 6) {
        enteredPin.add(event.value);
      }
    }
    emit(TableViewPinEnterState(pin: enteredPin));
  }

  void _onChangeAuthorizationType(TableViewChangeAuthorizationEvent event, Emitter emit) {
    emit(TableViewChangeAuthorizationState(loginType: event.loginType));
  }

  void _onAuthorizationEmailChange(TableViewEmailChangeEvent event, Emitter emit) {
    if(event.email.isEmpty) {
      emit(TableViewEmailChangeState(message: AppStrings.emptyEmailMsg));
    } else if(!event.email.isValidEmail) {
      emit(TableViewEmailChangeState(message: AppStrings.invalidEmail));
    } else {
      emit(TableViewEmailChangeState(message: AppStrings.emptyString));
    }
  }

  void _onAuthorizationPasswordChange(TableViewPasswordChangeEvent event, Emitter emit) {
    if(event.password.isEmpty) {
      emit(TableViewPasswordChangeState(message: AppStrings.emptyPasswordMsg));
    } else if(event.password.length < 8) {
      emit(TableViewPasswordChangeState(message: AppStrings.invalidPassword));
    } else {
      emit(TableViewPasswordChangeState(message: AppStrings.emptyString));
    }
  }

  Future<void> _onAuthorizeUser(TableViewAuthorizeEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      if(await validationLoginFields(event.loginType, emit: emit, email: event.firstText, password: event.secondText)) {
        try {
          var body = AuthorizationRequest(
            userEmailId: event.firstText,
            password: event.secondText,
            pin: event.loginType == LoginType.pin ? enteredPin.fold('', (p1, p2) => p1.isEmpty ? p2.toString() : '${p1.toString()}${p2.toString()}') : '',
            loginType: event.loginType
          ).toJson;
          emit(TableViewDialogLoadingState());
          var response = await _tableViewRepository.authorizeManagerProfile(body: body);
          emit(TableViewSuccessState(msg: response));
        } on CustomException catch (e) {
          emit(TableViewFailedState(msg: e.message));
        }
      }
    }
  }

  Future<bool> validationLoginFields(LoginType loginType, {required Emitter emit, required String email, required String password}) async {
    switch (loginType) {
      case LoginType.pin:
        if(enteredPin.isEmpty){
          emit(TableViewFailedState(msg: 'Please enter pin'));
          return false;
        } else if(enteredPin.length < 6){
          emit(TableViewFailedState(msg: 'Weak Pin'));
          return false;
        } else if(!await _checkConnectivity.hasConnection){
          emit(TableViewFailedState(msg: AppStrings.noInternetConnection));
          return false;
        } else {
          return true;
        }
      case LoginType.userName:
        if(email.isBlank) {
          emit(TableViewEmailChangeState(message: AppStrings.emptyEmailMsg));
          return false;
        } else if(!email.isValidEmail) {
          emit(TableViewEmailChangeState(message: AppStrings.invalidEmail));
          return false;
        } else if(password.isBlank) {
          emit(TableViewPasswordChangeState(message: AppStrings.emptyPasswordMsg));
          return false;
        } else if(password.length < 8) {
          emit(TableViewPasswordChangeState(message: AppStrings.invalidPassword));
          return false;
        } else {
          return true;
        }
      default:
        return false;
    }
  }


  bool userNameValidation(Emitter emit, {String email = '', String password = ''}) {
    if(email.isBlank){
      emit(TableViewEmailChangeState(message: AppStrings.emptyEmailMsg));
      return false;
    } else if(!email.isValidEmail){
      emit(TableViewEmailChangeState(message: AppStrings.invalidEmail));
      return false;
    } else if(password.isBlank){
      emit(TableViewPasswordChangeState(message: AppStrings.emptyPasswordMsg));
      return false;
    } else if(password.length < 8){
      emit(TableViewPasswordChangeState(message: AppStrings.invalidPassword));
      return false;
    } else {
      return true;
    }
  }


  Future<void> _onChangeServer(TableViewOnChangeServerEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(TableViewLoadingState());
        var response = await _tableViewRepository.transferCheck(endPoint: '${EndPoints.assignOrder}?ordId=${event.orderId}&eployeeIdWhomToAssign=${event.serverId}');
        emit(TableViewSuccessState(msg: response));
        add(TableViewGetFloorPlanEvent());
      } on CustomException catch (e) {
        emit(TableViewFailedState(msg: e.message));
      }
    } else {
      emit(TableViewFailedState(msg: AppStrings.noInternetConnection));
    }
  }

  void _onSelectGuest(TableViewSelectGuestEvent event, Emitter emit) {
    emit(TableViewSelectGuestState(index: event.index, totalGuest: event.totalGuest));
  }

  void _onCustomerNameChange(TableViewChangeCustomerNameEvent event, Emitter emit) {
    if(event.name.isBlank){
      emit(TableViewErrorCustomerNameState(nameError: AppStrings.provideCustomerName));
    } else {
      emit(TableViewErrorCustomerNameState(nameError: AppStrings.emptyString));
    }
  }

  Future<void> _onPlaceOrder(TableViewNewOrderEvent event, Emitter emit) async {
    if(await validation(event, emit)){
      emit(TableViewNewOrderState());
    }
  }

  Future<bool> validation(TableViewNewOrderEvent event, Emitter emit) async {
    if(event.tableName.isBlank){
      emit(TableViewErrorTableNameState(nameError: AppStrings.selectTable));
      return false;
    } else if(event.customerName.isBlank || event.customerIdentity.isBlank){
      emit(TableViewErrorCustomerNameState(nameError: 'Please select customer'));
      return false;
    } else if(event.totalPerson == 0){
      emit(TableViewErrorGuestState(nameError: AppStrings.selectGuest));
      return false;
    } else if(!await _checkConnectivity.hasConnection){
      emit(TableViewErrorState(error: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

  Future<void> _onFetchFloorPlan(TableViewGetFloorPlanEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        ////Get Floor Plan By ID
        tableList.clear();
        var floorImg = "";
        emit(TableViewLoadingState());
        var floorPlan = await _tableViewRepository.getAllFloorPlan();
        floorImg = floorPlan.first.floorImgPath!;
        for(var item in floorPlan.first.floorPlan!) {
          tableList.add(TableShapeModel(
            tableName: item.tableName!, 
            radius:  item.tableRadius, 
            tableId: item.tableId,
            tableCount: item.tableCount,
            horizontal: item.tableIsHorizontal,
            tableShape: item.tableShape!.getTableShape, 
            tableAvailableStatus: item.tableAvailability!,
            tableCoordinate: Offset(item.tableDx!, item.tableDy!),
            index: item.tableIndex!,
            bookedOrderDetails: item.tableOrderDetails == null || item.tableOrderDetails!.orderId == null ? null : item.tableOrderDetails
          ));
        }
        emit(TableViewGetFloorPlanState(tableList: tableList, imagePath: floorImg));
      } catch (e) {
        emit(TableViewFailedState(msg: AppStrings.someThingWentWrong));
      }
      add(TableViewEmployeeListEvent());
      add(TableViewFetchFinixIntitiesEvent());
    } else {
      emit(TableViewFailedState(msg: AppStrings.noInternetConnection));
    } 
  }

  void _onSelectTable(TableViewSelectTableEvent event, Emitter emit){
    if(tableList.isNotEmpty) {
      if(tableList[event.selectedIndex].tableAvailableStatus!) {
        if(selectedTableList.isNotEmpty) {
          selectedTableList.removeWhere((element) => element.tableName == tableList[event.selectedIndex].tableName);
        } 
        selectedTableList.add(tableList[event.selectedIndex]);
        emit(TableViewGetSelectedTableState(selectedTable: selectedTableList));
      } else {
        if(tableList[event.selectedIndex].bookedOrderDetails == null) {
          var savedStayData = Preferences.getListString(key: AppStrings.prefStayOrder);
          if(savedStayData.any((item) => jsonDecode(item)['tableList'].any((subItem) => subItem['table_name'] == tableList[event.selectedIndex].tableName))) {
            String savedData = "";
            for(var item in savedStayData) {
              if(jsonDecode(item)['tableList'].any((subItem) => subItem['table_name'] == tableList[event.selectedIndex].tableName)){
                savedData = item;
                break;
              }
            }
            if(savedData.isNotEmpty) {
              var storedData = jsonDecode(savedData);
              emit(ShowSavedTableDataState(orderData: storedData));
            }
          }
        } else {
          String orderId = tableList[event.selectedIndex].bookedOrderDetails!.orderId!;
          List<int> tableId = [];
          String tableName = '';
          for(var item in tableList){
            if(item.bookedOrderDetails != null && item.bookedOrderDetails!.orderId! == orderId){
              tableName = tableName.isEmpty ? item.tableName : '$tableName,${item.tableName}';
              tableId.add(item.tableId!);
            }
          }
          var bookedOrderInformation = tableList[event.selectedIndex].bookedOrderDetails!;
          emit(ShowBookedTableState(
            bookedTableStatus: bookedOrderInformation, 
            tableName: tableName,
            tableId: tableId
          ));
        }
      }
    }
  }

  void _onRemoveSelectedTable(TableViewRemoveTableEvent event, Emitter emit){
    if(selectedTableList.isNotEmpty){
      selectedTableList.removeAt(event.removeIndex);
      emit(TableViewGetSelectedTableState(selectedTable: selectedTableList));
    }
  }

  Future<void> _onFreeTable(TableViewFreeTableEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        ///free all table
        emit(TableViewLoadingState());
        bool isTaskCompleted = true;
        for(var item in event.tableId) {
          try {
            var response = await _tableViewRepository.updateTableStatus(id: item.toString());
            if(!response) {
              isTaskCompleted = false;
              break;
            }
          } on CustomException catch (_) {
            isTaskCompleted = false;
            break;
          }
        }
        if(isTaskCompleted) {
          emit(TableViewSuccessState(msg: 'Table availibility updated successfully'));
          add(TableViewGetFloorPlanEvent());
        } else {
          emit(TableViewFailedState(msg: 'Unable to release table'));
        }
      } on CustomException catch(e) {
        emit(TableViewFailedState(msg: e.message));
      }
    } else {
      emit(TableViewFailedState(msg: AppStrings.noInternetConnection));
    } 
  }

  Future<void> _employeeList(TableViewEmployeeListEvent event, Emitter emit) async {
    try {
      var data = await _tableViewRepository.getAllEmployees();
      employeesList.clear();
      for(var item in data) {
        if(item.roles == 'Server') {
          employeesList.add(item);
        }
      }
      emit(TableViewEmployeeListState(employeeList: employeesList));
    } on CustomException catch(e) {
      emit(TableViewFailedState(msg: e.message));
    } 
  }

  Future<void> _fetchAllFinixIdentities(TableViewFetchFinixIntitiesEvent event, Emitter emit) async {
    try {
      var data = await _tableViewRepository.getAllFinixIdentity();
      finixIdentityModel.clear();
      finixIdentityModel.add(FinixIdentityModel(
        appId: "", 
        identityId: "", 
        email: "", 
        phone: "", 
        name: "+ Add New Customer",
      ));
      finixIdentityModel.addAll(data);
      emit(TableViewFetchFinixIntitiesState(finixIdentityList: finixIdentityModel));
    } on CustomException catch (e) {
      emit(TableViewFailedState(msg: e.message));
    }
  }

  Future<void> _createNewFinixCustomer(TableViewFinixCreateCustomerEvent event, Emitter emit) async {
    if(await _finixCustomerFieldValidation(event, emit)) {
      var identityModel = FinixCreateIdentityModel(
        firstName: event.firstName, 
        lastName: event.lastName,
        email: event.email,
        phone: event.phone
      ).toJson;
      emit(TableViewLoadingState());
      var response = await _tableViewRepository.createFinixIdentity(body: identityModel);
      try {
        switch (response.statusCode) {
          case HttpStatus.created:
            emit(TableViewFinixErrorState(message: "Customer created successfully", isSuccess: true));
            break;
          default:
            emit(TableViewFinixErrorState(message: "Unable to create customer"));
        }
      } on CustomException catch (e) {
        emit(TableViewFinixErrorState(message: e.message));
      }
    }
  }

  Future<bool> _finixCustomerFieldValidation(TableViewFinixCreateCustomerEvent event, Emitter emit) async {
    if(event.firstName.isBlank) {
      emit(TableViewFinixFirstNameChangeState(text: "Please provide first name"));
      return false;
    } else if(event.lastName.isBlank) {
      emit(TableViewFinixLastNameChangeState(text: 'Please provide last name'));
      return false;
    } else if(event.email.isBlank) {
      emit(TableViewFinixEmailChangeState(text: 'Please provide email'));
      return false;
    } else if(!event.email.isValidEmail) {
      emit(TableViewFinixEmailChangeState(text: 'Please provide valid email'));
      return false;
    } else if(finixIdentityModel.any((element) => element.email == event.email)) {
      emit(TableViewFinixEmailChangeState(text: 'User already exist with same email'));
      return false;
    } else if(!await _checkConnectivity.hasConnection) {
      emit(TableViewFailedState(msg: AppStrings.noInternetConnection));
      return false;
    } else {
      return true;
    }
  }

}