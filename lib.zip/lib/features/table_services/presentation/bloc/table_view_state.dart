part of 'table_view_bloc.dart';

sealed class TableViewState {}

class TableViewInitialState extends TableViewState {}

class TableViewSelectTableState extends TableViewState {
  int selectIndex;
  TableViewSelectTableState({this.selectIndex = -1});
}

class TableViewNewOrderState extends TableViewState {}


class TableViewSelectGuestState extends TableViewState {
  int totalGuest;
  int index;
  TableViewSelectGuestState({this.index = -1, this.totalGuest = 0});
}

class TableViewErrorCustomerNameState extends TableViewState {
  String nameError;
  TableViewErrorCustomerNameState({required this.nameError});
}

class TableViewErrorTableNameState extends TableViewState {
  String nameError;
  TableViewErrorTableNameState({required this.nameError});
}

class TableViewErrorGuestState extends TableViewState {
  String nameError;
  TableViewErrorGuestState({required this.nameError});
}

class TableViewErrorState extends TableViewState {
  String error;
  TableViewErrorState({this.error = ''});
}

class TableViewGetFloorPlanState extends TableViewState {
  List<TableShapeModel> tableList;
  String imagePath;
  TableViewGetFloorPlanState({required this.tableList, required this.imagePath});
}

class TableViewGetSelectedTableState extends TableViewState {
  List<TableShapeModel> selectedTable;

  TableViewGetSelectedTableState({required this.selectedTable});
}

class TableViewLoadingState extends TableViewState {}

class TableViewFailedState extends TableViewState {
  String msg;
  TableViewFailedState({this.msg = ''});
}

class TableViewSuccessState extends TableViewState {
  String msg;
  TableViewSuccessState({this.msg = ''});
}


class ShowSavedTableDataState extends TableViewState {
  Map orderData;

  ShowSavedTableDataState({
    required this.orderData
  });
}

class ShowBookedTableState extends TableViewState {
  String tableName;
  List<int> tableId;
  TableOrderDetails? bookedTableStatus;

  ShowBookedTableState({this.bookedTableStatus, this.tableName = '', required this.tableId });
}

class TableViewEmployeeListState extends TableViewState {
  List<Employees> employeeList;

  TableViewEmployeeListState({required this.employeeList});
}

class TableViewOnChangeEmployeeState extends TableViewState {
  String employeeId;

  TableViewOnChangeEmployeeState({this.employeeId = ''});
}

class TableViewChangeAuthorizationState extends TableViewState {
  LoginType loginType;

  TableViewChangeAuthorizationState({this.loginType = LoginType.userName});
}

class TableViewEmailChangeState extends TableViewState {
  String message;
  TableViewEmailChangeState({this.message = ''});
}

class TableViewPasswordChangeState extends TableViewState {
  String message;
  TableViewPasswordChangeState({this.message = ''});
}

class TableViewPinEnterState extends TableViewState {
  List<int> pin;

  TableViewPinEnterState({required this.pin});
}

class TableViewDialogLoadingState extends TableViewState {}

class TableViewSelectServerState extends TableViewState {
  String selectedServerId;

  TableViewSelectServerState({this.selectedServerId = ''});
}

class TableViewFetchFinixIntitiesState extends TableViewState {
  List<FinixIdentityModel> finixIdentityList;

  TableViewFetchFinixIntitiesState({required this.finixIdentityList});
}

class TableViewOnSelectFinixUserState extends TableViewState {
  FinixIdentityModel? finixUser;
  String nameError;
  TableViewOnSelectFinixUserState({this.finixUser, this.nameError = ''});
}

class TableViewFinixEmailChangeState extends TableViewState {
  String text;

  TableViewFinixEmailChangeState({this.text = ''});
}

class TableViewFinixFirstNameChangeState extends TableViewState {
  String text;

  TableViewFinixFirstNameChangeState({this.text = ''});
}

class TableViewFinixLastNameChangeState extends TableViewState {
  String text;

  TableViewFinixLastNameChangeState({this.text = ''});
}

class TableViewFinixErrorState extends TableViewState {
  String message;
  bool isSuccess;

  TableViewFinixErrorState({this.message = '', this.isSuccess = false});
}

class TableViewHideFinixErrorState extends TableViewState {}

class TableViewEnableAuthorizeCardState extends TableViewState {
  bool isEnable;

  TableViewEnableAuthorizeCardState({this.isEnable = false});
}

class OnSwitchUserTableState extends TableViewState {
  bool isLogout;
  OnSwitchUserTableState({this.isLogout = false});
}