import 'package:flutter/services.dart';
import '../../../constants/app_style.dart';
import '../../../routes/route.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';

class AddNewUserDialog extends StatelessWidget {

  final TableViewBloc tableViewBloc;

  const AddNewUserDialog({
    super.key,
    required this.tableViewBloc
  });

  @override
  Widget build(BuildContext context) {
    var firstNameTextController = TextEditingController();
    var lastNameTextController = TextEditingController();
    var emailTextController = TextEditingController();
    var phoneTextController = TextEditingController();
    var errorEmail = '';
    var errorFirstName = '';
    var errorLastName = '';
    var apiError = '';
    bool apiSuccessStatus = false;
    return BlocProvider<TableViewBloc>.value(
      value: tableViewBloc,
      child: Container(
        width: context.screenWidth * 0.50,
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s16,
          horizontal: AppSize.s16
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSize.s12),
          color: Helper.isDark 
          ? AppColors.transparent 
          : AppColors.transparent,
        ),
        child: BlocConsumer<TableViewBloc, TableViewState>(
          builder: (context, state) {
            return ListView(
              shrinkWrap: true,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: "Add New Customer",
                      textStyle: getMediumStyle(fontSize: 18),
                    ),
                    Transform.translate(
                      offset: const Offset(10, 0),
                      child: IconButton(
                        onPressed: () => context.pop(), 
                        icon: const Icon(Icons.clear)
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomTextField(
                        textController: firstNameTextController,
                        label: "First Name",
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s10,
                        isMandatory: true,
                        errorText: errorFirstName,
                        onChange: (value) => tableViewBloc.add(TableViewFinixFirstNameChangeEvent(text: value)),
                      ),
                    ),
                    const SizedBox(width: AppSize.s15),
                    Expanded(
                      child: CustomTextField(
                        textController: lastNameTextController,
                        label: "Last Name",
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s10,
                        isMandatory: true,
                        errorText: errorLastName,
                        onChange: (value) => tableViewBloc.add(TableViewFinixLastNameChangeEvent(text: value)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s15),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomTextField(
                        textController: emailTextController,
                        label: "Email",
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s10,
                        isMandatory: true,
                        errorText: errorEmail,
                        onChange: (value) => tableViewBloc.add(TableViewFinixEmailChangeEvent(text: value)),
                      ),
                    ),
                    const SizedBox(width: AppSize.s15),
                    Expanded(
                      child: CustomTextField(
                        textController: phoneTextController,
                        label: "Phone (Optional)",
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s10,
                        textInputType: TextInputType.number,
                        inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                      ),
                    ),
                  ],
                ),
                Visibility(
                  visible: apiError.isNotEmpty,
                  child: Container(
                    margin: const EdgeInsets.only(top: AppSize.s20),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8.0,
                      vertical: 8.0
                    ),
                    decoration: BoxDecoration(
                      color: apiSuccessStatus 
                      ? AppColors.green.withOpacity(0.1) 
                      : AppColors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(5)
                    ),
                    child: Row(
                      children: [
                        Icon(
                          apiSuccessStatus
                          ? Icons.check_circle
                          : Icons.warning_rounded, 
                          color: apiSuccessStatus 
                          ? AppColors.green 
                          : AppColors.red, 
                          size: AppSize.s22
                        ),
                        const SizedBox(width: AppSize.s8),
                        Expanded(
                          child: CustomText(
                            title: apiError,
                            color: apiSuccessStatus 
                            ? AppColors.green 
                            : AppColors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSize.s20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomOutlinedButton(
                      onPressed: () => context.pop(),
                      borderColor: AppColors.red,
                      textColor: AppColors.red,
                      text: 'Cancel',
                    ),
                    const SizedBox(width: AppSize.s12),
                    CustomSolidButton(
                      onPressed: () => tableViewBloc.add(TableViewFinixCreateCustomerEvent(
                        email: emailTextController.text,
                        firstName: firstNameTextController.text,
                        lastName: lastNameTextController.text,
                        phone: phoneTextController.text
                      )),
                      text: 'Add Customer'
                    ),
                  ],
                ),
              ],
            );
          },
          listener: (context, state){
            switch (state) {
              case TableViewFinixEmailChangeState _:
                errorEmail = state.text;
                break;
              case TableViewFinixFirstNameChangeState _:
                errorFirstName = state.text;
                break;
              case TableViewFinixLastNameChangeState _:
                errorLastName = state.text;
                break;
              case TableViewFinixErrorState _:
                apiError = state.message;
                apiSuccessStatus = state.isSuccess;
                if(!state.isSuccess) {
                  Future.delayed(const Duration(seconds: 2), () => tableViewBloc.add(TableViewHideFinixErrorEvent()));
                } else {
                  Future.delayed(const Duration(milliseconds: 800), () {
                    context.pop();
                    context.pop();
                  });
                }
                break;
              case TableViewHideFinixErrorState _:
                apiError = '';
                break;
              default:
            }
          },
        ),
      ),
    );
  }
}