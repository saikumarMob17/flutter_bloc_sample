import '../../../constants/app_images.dart';
import '../../../widgets/custom_empty_widget.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_style.dart';
import '../../../routes/route.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_text.dart';
import '../../../constants/app_size.dart';
import '../../setup_floor/domain/all_floor_plan_response.dart';
import '../domain/employee_drop_down_item.dart';

class ServerChangeDialog extends StatelessWidget {
  
  final TableOrderDetails tableBookingDetails;
  final String tableName;
  final List<EmployeeDropdownItem> serverList;
  final TableViewBloc tableViewBloc;
  
  const ServerChangeDialog({
    super.key,
    this.tableName = '',
    required this.tableViewBloc,
    required this.tableBookingDetails,
    required this.serverList
  });

  @override
  Widget build(BuildContext context) {
    bool isFirstEnable = false;
    String selectedServerId = '';
    selectedServerId = tableBookingDetails.serverId!;
    serverList.sort((a, b) => a.isClockedIn ? -1 : 1);
    return AlertDialog(
      insetPadding: EdgeInsets.zero,
      contentPadding: EdgeInsets.zero,
      content: Container(
        height: context.screenHeight * 0.70,
        width: context.screenWidth * 0.70,
        decoration: BoxDecoration(
          color: Helper.isDark
          ? AppColors.topDarkColor
          : AppColors.white,
          borderRadius: BorderRadius.circular(AppSize.s10)
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: AppSize.s18,
          vertical: AppSize.s6
        ),
        child: BlocProvider<TableViewBloc>.value(
          value: tableViewBloc,
          child: BlocConsumer<TableViewBloc, TableViewState>(
            builder: (_, state) {
              return Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: 'Change Server',
                        textStyle: getMediumStyle(),
                      ),
                      Transform.translate(
                        offset: const Offset(5,0),
                        child: IconButton(
                          onPressed: () => context.pop(), 
                          icon: const Icon(Icons.close)
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s10),
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            children: [
                              Container(
                                width: double.maxFinite,
                                padding: const EdgeInsets.all(AppSize.s12),
                                decoration: BoxDecoration(
                                  color: Helper.isDark 
                                    ? AppColors.headerColorDark 
                                    : AppColors.backgroundColor,
                                  borderRadius: BorderRadius.circular(AppSize.s10),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: 'Table : $tableName',
                                          textStyle: getRegularStyle(
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        CustomText(
                                          title: tableBookingDetails.serverName!,
                                          textStyle: getMediumStyle(),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: AppSize.s20),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: tableBookingDetails.customerName!, 
                                          textStyle: getMediumStyle(),
                                        ),
                                        CustomText(
                                          title: tableBookingDetails.orderNumber!, 
                                          textStyle: getMediumStyle(),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: AppSize.s15),
                              SizedBox(
                                width: double.maxFinite,
                                child: CustomSolidButton(
                                  onPressed: selectedServerId.isBlank
                                  ? null
                                  : () {
                                    context.pop();
                                    tableViewBloc.add(TableViewOnChangeServerEvent(
                                      serverId: selectedServerId, 
                                      orderId: tableBookingDetails.orderId!
                                    ));
                                  },
                                  text: 'Change Server',
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: AppSize.s15),
                        Expanded(
                          child: serverList.isNotEmpty
                          ? ListView.separated(
                            itemCount: serverList.length + 1,
                            shrinkWrap: true,
                            itemBuilder: (_, index) {
                              if(index == 0) {
                                isFirstEnable = true;
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: Text(serverList[index].isClockedIn ? 'Clocked In' : 'Clocked Out'));
                              } else {
                                var data =  serverList[index - 1];
                                return Material(
                                  child: InkWell(
                                    onTap: () => tableViewBloc.add(TableViewSelectServerEvent(selectedIndex: data.id)),
                                    borderRadius: BorderRadius.circular(AppSize.s6),
                                    child: Ink(
                                      padding: const EdgeInsets.all(AppSize.s12),
                                      decoration: BoxDecoration(
                                        color: Helper.isDark 
                                          ? AppColors.headerColorDark 
                                          : AppColors.backgroundColor,
                                        borderRadius: BorderRadius.circular(AppSize.s6),
                                        border: Border.all(
                                          color: selectedServerId == data.id
                                          ? AppColors.primaryColor
                                          : Helper.isDark 
                                            ? AppColors.headerColorDark 
                                            : AppColors.backgroundColor,
                                          width: 1.5
                                        )
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Column(
                                              children: [
                                                CustomText(
                                                  title: data.value,
                                                  textStyle: getMediumStyle(),
                                                ),
                                                CustomText(
                                                  title: data.isClockedIn 
                                                  ? 'Clocked In' 
                                                  : 'Clocked Out',
                                                  color: data.isClockedIn
                                                  ? AppColors.green
                                                  : AppColors.red,
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 30,
                                            child: VerticalDivider(
                                              width: 30.0, 
                                              thickness: 1.0
                                            ),
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                CustomText(
                                                  title: data.orderCount > 0
                                                  ? '${data.orderCount.toString()} table assigned'
                                                  : 'No table assigned'
                                                ),
                                                Row(
                                                  children: [
                                                    const Icon(
                                                      AppIcons.chairIcon, 
                                                      size: AppSize.s20
                                                    ),
                                                    CustomText(title: data.orderCount.toString())
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              }
                            },
                            separatorBuilder: (_, index) {
                              if(isFirstEnable &&  (index > 0 && index < serverList.length)) {
                                if(serverList[index - 1].isClockedIn != serverList[index].isClockedIn) {
                                  isFirstEnable = false;
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 12, bottom: 12),
                                    child: Text(serverList[index].isClockedIn ? 'Clocked In' : 'Clocked Out')
                                  );
                                }
                              }
                              return SizedBox(height: index == 0 ? 0 : 8);
                            }
                          )
                          : const CustomEmptyWidget(
                              imagePath: AppImages.addressIcon, 
                              emptyTitle: 'No Server Found'
                            )
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
            listener: (_, state){
              switch(state.runtimeType) {
                case TableViewSelectServerState:
                state = state as TableViewSelectServerState;
                selectedServerId = state.selectedServerId;
                break;
              }
            },
          ),
        ),
      ),
    );
  }
}