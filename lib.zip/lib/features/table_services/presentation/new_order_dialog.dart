import 'package:cliqtechnologies_retl/widgets/custom_switch_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../routes/app_routes.dart';
import '../../../services/finix_identity_model.dart';
import '../../../utils/helper.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_employee_dropdown_widget.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../utils/app_extension_method.dart';
import 'bloc/table_view_bloc.dart';
import '../../setup_floor/domain/table_shape_model.dart';
import '../domain/employee_drop_down_item.dart';

class NewOrderDialog extends StatefulWidget {
  final String orderNumber;
  final String selectedTable;
  final Map? storeData;
  final List<TableShapeModel>? selectedTableList;
  final List<EmployeeDropdownItem> serverList;
  final List<FinixIdentityModel> finixUser;
  final Function()? onCreateNewUser;
  final Function()? onAuthorizeCard;

  const NewOrderDialog({
    super.key, 
    required this.selectedTable,
    required this.finixUser,
    required this.serverList,
    this.selectedTableList,
    this.storeData,
    this.onCreateNewUser,
    this.orderNumber = '',
    this.onAuthorizeCard
  });

  @override
  State<NewOrderDialog> createState() => _NewOrderDialogState();
}

class _NewOrderDialogState extends State<NewOrderDialog> {

  int selectedIndex = -1;
  int totalPerson = 0;
  String errorName = '';
  String errorGuest = '';
  late TextEditingController customerNameController;
  late TextEditingController tableTextController;
  late TextEditingController totalPersonController;
  String selectedEmployee = '';
  FinixIdentityModel? selectedFinixUser;
  bool isAuthorizationEnable = false;

  @override
  void initState() {
    tableTextController = TextEditingController(text: widget.selectedTable);
    customerNameController = TextEditingController();
    totalPersonController = TextEditingController();
    selectedEmployee = widget.serverList.first.id;
    if(widget.storeData != null){
      var data = widget.storeData as Map;
      tableTextController.text = data['tableName'];
      totalPerson = data['guestCount'];
      selectedIndex = totalPerson > 4 ? 5 : totalPerson - 1;
      if(totalPerson > 4) {
        totalPersonController.text = totalPerson.toString();
      }
      customerNameController.text = data['customerName'];
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<TableViewBloc>(
      create: (_) => TableViewBloc(),
      child: AlertDialog(
        backgroundColor: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12)
        ),
        contentPadding: EdgeInsets.zero,
        insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
        content: BlocConsumer<TableViewBloc, TableViewState>(
          listener: (context, state) {
            switch (state) {
              case TableViewNewOrderState _:
                context.pop();
                var orderData = {};
                var tableList = <Map>[];
                if(widget.selectedTableList != null) {
                  for(var item in widget.selectedTableList!) {
                    tableList.add({
                      "table_name": item.tableName,
                      "table_id": item.tableId
                    });
                  }
                  orderData = {
                    'from': AppRoutes.tableViewScreen,
                    'stay': false,
                    'selected_table': widget.selectedTable,
                    'customer_name': selectedFinixUser == null ? '' : selectedFinixUser!.name,
                    "customer_email": selectedFinixUser == null ? '' : selectedFinixUser!.email,
                    "customer_phone": selectedFinixUser == null ? '' : selectedFinixUser!.phone,
                    "customer_identity": selectedFinixUser == null ? '' : selectedFinixUser!.identityId,
                    'selected_server_id': selectedEmployee,
                    'total_guest': totalPerson,
                    'table_list': tableList
                  };
                } else if(widget.storeData != null) {
                  var data = widget.storeData as Map;
                  for(var item in data['tableList']) {
                    tableList.add({
                      "table_name": item['table_name'],
                      "table_id": item['table_id']
                    });
                  }
                  orderData = {
                    'from': AppRoutes.tableViewScreen,
                    'stay': true,
                    'selected_table': data['tableName'],
                    'customer_name': selectedFinixUser == null ? '' : selectedFinixUser!.name,
                    "customer_email": selectedFinixUser == null ? '' : selectedFinixUser!.email,
                    "customer_phone": selectedFinixUser == null ? '' : selectedFinixUser!.phone,
                    "customer_identity": selectedFinixUser == null ? '' : selectedFinixUser!.identityId,
                    'selected_server_id': selectedEmployee,
                    'total_guest': totalPerson,
                    'table_list': tableList,
                    'order_sequence': data['orderSequence'],
                    'order_details': data['selectedProduct']
                  };
                }
                context.push(
                  AppRoutes.ordersScreen, 
                  extra: orderData
                );
                break;
              case TableViewOnChangeEmployeeState _:
                selectedEmployee = state.employeeId;
                break;
              case TableViewOnSelectFinixUserState _:
                selectedFinixUser = state.finixUser;
                errorName = state.nameError;
                if(selectedFinixUser != null) {
                  if(selectedFinixUser!.name == '+ Add New Customer') {
                    widget.onCreateNewUser!();
                  }
                }
                break;
              case TableViewEnableAuthorizeCardState _:
                isAuthorizationEnable = state.isEnable;
                if(state.isEnable) {
                  widget.onAuthorizeCard!();
                }
                break;
              default:
            }
          },
          builder: (context, state) {
            switch (state.runtimeType) {
              case TableViewSelectGuestState:
                state = state as TableViewSelectGuestState;
                errorGuest = AppStrings.emptyString;
                selectedIndex = state.index;
                totalPerson = state.totalGuest;
                if(selectedIndex < 5) {
                  totalPersonController.clear();
                }
                break;
              case TableViewErrorCustomerNameState:
                state = state as TableViewErrorCustomerNameState;
                errorName = state.nameError;
              case TableViewErrorGuestState:
                state = state as TableViewErrorGuestState;
                errorGuest = state.nameError;
              default:
            }
            return Container(
              width: context.screenWidth * 0.38,
              padding: const EdgeInsets.symmetric(
                vertical: AppSize.s18,
                horizontal: AppSize.s18
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppSize.s12),
                color: Helper.isDark 
                ? AppColors.contentColorDark 
                : AppColors.white,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      title: AppStrings.newOrder,
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s20, 
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                    ),
                    const SizedBox(height: AppSize.s4),
                    CustomText(
                      title: 'There are just a few steps left to complete your purchase.',
                      textStyle: getRegularStyle(
                        fontSize: AppSize.s14,
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                    ),
                    const SizedBox(height: AppSize.s18),
                    CustomTextField(
                      textController: tableTextController,
                      label: AppStrings.table,
                      isMandatory: true,
                      readOnly: true,
                      verPadding: AppSize.s12,
                      horPadding: AppSize.s12,
                    ),
                    const SizedBox(height: AppSize.s18),
                    const Padding(
                      padding: EdgeInsets.only(bottom: AppSize.s8),
                      child: CustomText(
                        title: AppStrings.customerName, 
                        isMandatory: true
                      ),
                    ),
                    DropdownMenu<FinixIdentityModel>(
                      initialSelection: selectedFinixUser,
                      requestFocusOnTap: true,
                      expandedInsets: EdgeInsets.zero,
                      menuHeight: 200,
                      menuStyle: MenuStyle(
                        padding: MaterialStateProperty.all(const EdgeInsets.symmetric(vertical: 0))
                      ),
                      errorText: errorName.isBlank ? null : errorName,
                      inputDecorationTheme: const InputDecorationTheme(
                        contentPadding: EdgeInsets.symmetric(horizontal: 15),
                        isDense: false,
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: AppSize.s05, color: AppColors.grey),
                          borderRadius: BorderRadius.all(Radius.circular(AppSize.s5))
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: AppSize.s1, color: AppColors.blue),
                          borderRadius: BorderRadius.all(Radius.circular(AppSize.s5))
                        ),
                        border: OutlineInputBorder(
                          borderSide: BorderSide(width: AppSize.s1, color: AppColors.blue),
                          borderRadius: BorderRadius.all(Radius.circular(AppSize.s5))
                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: AppSize.s1, color: Color.fromARGB(255, 210, 69, 59)),
                          borderRadius: BorderRadius.all(Radius.circular(AppSize.s5))
                        ),
                      ),
                      hintText: AppStrings.customerName,
                      onSelected: (finixUser) => context.read<TableViewBloc>().add(TableViewOnSelectFinixUserEvent(finixUser: finixUser)),
                      dropdownMenuEntries: List.generate(widget.finixUser.length, (index) => DropdownMenuEntry<FinixIdentityModel>(
                        style: MenuItemButton.styleFrom(
                          textStyle: getRegularStyle(fontSize: AppSize.s14),
                          foregroundColor: widget.finixUser[index].name == '+ Add New Customer' 
                          ? AppColors.primaryColor 
                          : null
                        ),
                        value: widget.finixUser[index],
                        label: widget.finixUser[index].name == '+ Add New Customer'
                        ? widget.finixUser[index].name
                        : '${widget.finixUser[index].name} (${widget.finixUser[index].email})',
                      ),
                    )),
                    const SizedBox(height: AppSize.s18),
                    CustomEmployeeDropdownWidget(
                      items: widget.serverList, 
                      value: selectedEmployee,
                      label: 'Server',
                      isMandatory: true,
                      isExpanded: true,
                      labelStyle: getRegularStyle(
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                      onChange: (value) => context.read<TableViewBloc>().add(TableViewOnChangeEmployeeEvent(employeeId: value!)),
                    ),
                    const SizedBox(height: AppSize.s18),
                    const CustomText(
                      title: AppStrings.guest, 
                      isMandatory: true,
                    ),
                    const SizedBox(height: AppSize.s4),
                    SizedBox(
                      height: AppSize.s40,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            Row(
                              children: List.generate(
                                4, 
                                (index) => InkWell(
                                  onTap: () => context.read<TableViewBloc>().add(TableViewSelectGuestEvent(index: index, totalGuest: index+1)),
                                  child: Container(
                                    height: double.maxFinite,
                                    padding: const EdgeInsets.symmetric(horizontal: AppSize.s15),
                                    margin: const EdgeInsets.only(right: AppSize.s15),
                                    decoration: BoxDecoration(
                                      color: index == selectedIndex 
                                      ?AppColors.primaryColor
                                      : Helper.isDark 
                                        ? AppColors.headerColorDark 
                                        : AppColors.white,
                                      border: Border.all(
                                        color: Helper.isDark 
                                        ? AppColors.topDarkColor 
                                        : const Color(0xFFC9DAE8),
                                        width: AppSize.s1
                                      ),
                                      borderRadius: BorderRadius.circular(AppSize.s5)
                                    ),
                                    child: Center(
                                      child: CustomText(
                                        title: '${index+1}',
                                        textAlign: TextAlign.center,
                                        textStyle: getMediumStyle(
                                          color: index == selectedIndex 
                                          ?AppColors.white
                                          : Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black,
                                          fontSize: AppSize.s16
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () => context.read<TableViewBloc>().add(TableViewSelectGuestEvent(index: 5, totalGuest: 0)),
                              child: SizedBox(
                                width: 80,
                                height: double.maxFinite,
                                child: CustomTextField(
                                  textController: totalPersonController,
                                  horPadding: AppSize.s12,
                                  verPadding: AppSize.s6,
                                  textSize: AppSize.s16,
                                  hint: 'Others',
                                  isEnable: selectedIndex == 5 ? true : false,
                                  textInputType: TextInputType.number,
                                  inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                                  borderColor: selectedIndex == 5 ? AppColors.blue : const Color(0xFFC9DAE8),
                                  fontWeight: FontWeight.w500,
                                  onChange: (value) => context.read<TableViewBloc>().add(TableViewSelectGuestEvent(index: 5, totalGuest: value.isEmpty ? 0 : int.parse(value))),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s20),
                    Visibility(
                      visible: false,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(AppSize.s5),
                          color: AppColors.white
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(title: 'Pre-Authorize Card', textStyle: getMediumStyle()),
                                CustomSwitchWidget(
                                  value: isAuthorizationEnable,
                                  onChange: (value) => context.read<TableViewBloc>().add(TableViewEnableAuthorizeCardEvent(isEnable: value)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Visibility(
                      visible: errorGuest.isNotEmpty,
                      child: Padding(
                        padding: const EdgeInsets.only(top: AppSize.s0, left: AppSize.s6),
                        child: CustomText(title: errorGuest,color: AppColors.red)
                      ),
                    ),
                    const SizedBox(height: AppSize.s0),
                    Row(
                      children: [
                        Expanded(
                          child: CustomOutlinedButton(
                            text: AppStrings.cancel,
                            onPressed: () => context.pop(),
                            topPadding: AppSize.s18,
                            bottomPadding: AppSize.s18,
                            borderColor: AppColors.red,
                            textColor: AppColors.red,
                          ),
                        ),
                        const SizedBox(width: AppSize.s12),
                        Expanded(
                          child: CustomSolidButton(
                            text: AppStrings.bookOrder,
                            onPressed: () => context.read<TableViewBloc>().add(TableViewNewOrderEvent(
                              tableName: tableTextController.text, 
                              customerName: selectedFinixUser == null ? '' : selectedFinixUser!.name,
                              customerIdentity: selectedFinixUser == null ? '' : selectedFinixUser!.identityId,
                              totalPerson: totalPerson
                            )),
                            horPadding: AppSize.s18,
                            verPadding: AppSize.s18,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }
        ),
      )
    );
  }
}