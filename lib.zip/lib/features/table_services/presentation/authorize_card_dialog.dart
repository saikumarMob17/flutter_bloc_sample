import 'package:cliqtechnologies_retl/utils/app_extension_method.dart';
import 'package:cliqtechnologies_retl/widgets/custom_solid_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_text.dart';

class AuthorizeCardDialog extends StatelessWidget {

  const AuthorizeCardDialog({super.key});

  @override
  Widget build(BuildContext context) {
    final amountTextController = TextEditingController();
    return AlertDialog(
      surfaceTintColor: Helper.isDark 
      ? AppColors.contentColorDark 
      : AppColors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppSize.s12)
      ),
      contentPadding: EdgeInsets.zero,
      insetPadding: EdgeInsets.symmetric(
        horizontal: context.screenWidth < 600.0 
        ? AppSize.s14 
        : AppSize.s0
      ),
      content: Container(
        width: context.screenWidth * 0.38,
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s18,
          horizontal: AppSize.s18
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSize.s12),
          color: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
        ),
        child: ListView(
          shrinkWrap: true,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.credit_card),
                    const SizedBox(width: AppSize.s5),
                    CustomText(
                      title: "Pre-Authorize Card",
                      textStyle: getMediumStyle(fontSize: 18),
                    ),
                  ],
                ),
                Transform.translate(
                  offset: const Offset(10, 0),
                  child: IconButton(
                    onPressed: () => context.pop(), 
                    icon: const Icon(Icons.clear)
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSize.s10),
            Row(
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                    3, 
                    (index) {
                      return Row(
                        children: [
                          Material(
                            child: InkWell(
                              onTap: () => debugPrint('Click here to select amount for pre authorization'),
                              borderRadius: BorderRadius.circular(AppSize.s8),
                              child: Ink(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: AppSize.s15,
                                  vertical: AppSize.s15
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.backgroundColor,
                                  borderRadius: BorderRadius.circular(AppSize.s8)
                                ),
                                child: CustomText(
                                  title: '\$${500 * (index + 1)}',
                                  textStyle: getSemiBoldStyle(
                                    fontSize: AppSize.s18
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: AppSize.s10),
                        ],
                      );
                    }
                  )
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppSize.s15,
                      vertical: AppSize.s15
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.backgroundColor,
                      borderRadius: BorderRadius.circular(AppSize.s8)
                    ),
                    child: TextField(
                      // controller: amountTextController,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      keyboardType: TextInputType.number,
                      style: getSemiBoldStyle(
                        fontSize: AppSize.s18,
                        color: AppColors.black
                      ),
                      decoration: InputDecoration.collapsed(
                        hintText: 'Custom Amount',
                        hintStyle: getSemiBoldStyle(
                          fontSize: AppSize.s18,
                          color: AppColors.grey
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Container(
              margin: const EdgeInsets.symmetric(vertical: AppSize.s15),
              padding: const EdgeInsets.symmetric(
                horizontal: AppSize.s15,
                vertical: AppSize.s15
              ),
              decoration: BoxDecoration(
                color: AppColors.orange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppSize.s8)
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_rounded, color: AppColors.orange, size: AppSize.s22),
                  const SizedBox(width: AppSize.s5),
                  Expanded(
                    child: CustomText(
                      title: 'The preauthorize amount will be detected after finish the order.',
                      textStyle: getRegularStyle(
                        color: AppColors.orange,
                        fontSize: AppSize.s14
                      ),
                    ),
                  ),
                ],
              ),
            ),
            CustomSolidButton(
              onPressed: () => print('Click here to authorize card'),
              centerAlignment: true,
              text: 'Authorize Card',
              prefix: const Icon(Icons.credit_card, color: AppColors.white,),
            )
          ],
        )
      )
    );
  }
}

/**
 * Pre-authorized ****1234
 * 
 * Payment has been pre-authorize successfully.
 * $100 pre auth added to the card ending with 3869
 */