import 'dart:math' as math;
import 'dart:typed_data';
import '../../../constants/app_icons.dart';
import 'authorize_card_dialog.dart';
import 'authenticate_user_dialog_widget.dart';
import 'booked_table_details_dialog.dart';
import 'server_change_dialog.dart';
import '../../../routes/app_routes.dart';
import '../../../routes/route.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../services/finix_identity_model.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'new_order_dialog.dart';
import '../../setup_floor/domain/all_floor_plan_response.dart';
import '../../setup_floor/domain/table_shape_model.dart';
import '../../setup_floor/presentation/triangle_painter.dart';
import '../domain/employee_drop_down_item.dart';
import 'add_new_user_dialog.dart';


class TableViewScreen extends StatefulWidget {

  const TableViewScreen({super.key});

  @override
  State createState() => _TableViewScreenState();

}

class _TableViewScreenState extends State<TableViewScreen> with Helper {

  var tabTitleList = [
    AppStrings.extra,
    AppStrings.mainFloor,
    AppStrings.bar
  ];

  // var tableList = <TableViewModel>[];
  int tabSelectedIndex = 0;
  String currentDateTime = '';
  int tableAvailableCount = 0;
  int tableUnAvailableCount = 0;
  int tableAvailableSoonCount = 0;

  List<TableShapeModel> dragedWidget = [];
  List<TableShapeModel> selectedTableList = [];
  List<EmployeeDropdownItem> serverList = [];
  List<FinixIdentityModel> finixUser = [];
  int selectedIndex = -1;
  Uint8List? floorPlanImage;
  late ScrollController _verticalScrollController;
  late ScrollController _horizontalScrollController;
  late TableViewBloc _tableViewBloc;
  

  @override
  void initState() {
    _tableViewBloc = context.read<TableViewBloc>();
    _verticalScrollController = ScrollController();
    _horizontalScrollController = ScrollController();
    currentDateTime = Helper.getDayFormattedDate();
    WidgetsBinding.instance.addPostFrameCallback((_) { 
      _horizontalScrollController.animateTo(240, duration: const Duration(milliseconds: 400), curve: Curves.linear);
      _verticalScrollController.animateTo(10, duration: const Duration(milliseconds: 400), curve: Curves.linear);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark ? AppColors.black : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      resizeToAvoidBottomInset: false,
      body: BlocConsumer<TableViewBloc, TableViewState>(
        builder: (context, state) {
          switch (state) {
            case TableViewGetFloorPlanState _:
              floorPlanImage = base64Decode(state.imagePath);
              dragedWidget.clear();
              dragedWidget.addAll(state.tableList);
              break;
            case TableViewGetSelectedTableState _:
              selectedTableList.clear();
              selectedTableList.addAll(state.selectedTable);
              break;
            case TableViewEmployeeListState _:
              serverList.clear();
              for(var item in state.employeeList) {
                var user = item.user!;
                serverList.add(EmployeeDropdownItem(
                  id: user.id!, 
                  value: '${user.firstName} ${user.lastName}',
                  isClockedIn: item.isClockedIn!,
                  orderCount: item.orderCount!
                ));
              }
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints) {
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case TableViewGetFloorPlanState _:
              hideLoadingDialog(context: context);
              break;
            case TableViewLoadingState _:
              showLoadingDialog(context: context);
              break;
            case TableViewFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.msg);
              break;
            case ShowSavedTableDataState _:
              var savedData = state.orderData;
              showNewOrderDialog(
                bContext: context, 
                selectedTable: '', 
                storedData: savedData
              );
              break;
            case ShowBookedTableState _:
              if(state.bookedTableStatus != null) {
                showBookedOrderTabled(
                  blocInstance: context.read<TableViewBloc>(), 
                  tableBookingDetails: state.bookedTableStatus!,
                  tableName: state.tableName,
                  tableId: state.tableId
                );
              }
              break;
            case TableViewSuccessState _:
              hideLoadingDialog(context: context);
              break;
            case TableViewFetchFinixIntitiesState _:
              finixUser.clear();
              finixUser.addAll(state.finixIdentityList);
              break;
            case OnSwitchUserTableState _:
              hideLoadingDialog(context: context);
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => context.pop(),
                        icon: const Icon(Icons.west)
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            title: AppStrings.tableView,
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s18,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                          CustomText(title: currentDateTime)
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s10),
              SizedBox(
                height: 44,
                width: context.screenWidth,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: List.generate(
                    tabTitleList.length, 
                    (index) => GestureDetector(
                      //onTap: () => context.read<DashboardBloc>().add(DashboardChangeTabIndexEvent(index: index)),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                        margin: const EdgeInsets.only(right: AppSize.s20),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              width: 3.0, 
                              color: tabSelectedIndex == index 
                              ? AppColors.primaryColor 
                              : AppColors.transparent
                            ),
                          ),
                        ),
                        child: Align(
                          alignment: Alignment.center,
                          child: CustomText(
                            title: tabTitleList[index],
                            textStyle: getMediumStyle(
                              color: tabSelectedIndex == index 
                              ? AppColors.primaryColor 
                              : Helper.isDark
                                ? AppColors.white
                                : AppColors.black,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s10),
              ///New Table View
              Expanded(
                child: Scrollbar(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Scrollbar(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Container(
                          width: Helper.screenWidth,
                          height: Helper.screenHeight,
                          color: AppColors.grey.withOpacity(0.2),
                          child: Stack(
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Stack(
                                  children: [
                                    Container(
                                      height: Helper.floorHeight,
                                      width: Helper.floorWidth,
                                      margin: const EdgeInsets.only(top: AppSize.s10),
                                      decoration: BoxDecoration(
                                        color: Helper.isDark 
                                        ? AppColors.contentColorDark 
                                        : AppColors.white,
                                      ),
                                      child: CustomImageView(imgBytes: floorPlanImage)
                                    ),
                                    ...List.generate(
                                      dragedWidget.length, 
                                      (index) {
                                        var data = dragedWidget[index];
                                        return Positioned(
                                          top: data.tableCoordinate.dy,
                                          left: data.tableCoordinate.dx - 240,
                                          child: InkWell(
                                            onTap: () => _tableViewBloc.add(TableViewSelectTableEvent(selectedIndex: index)),
                                            child: _getTableShape(
                                              data, 
                                              selectedColor: selectedIndex == index 
                                              ? AppColors.red 
                                              : AppColors.primaryColor
                                            ),
                                          ),
                                        );
                                      }
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Visibility(
            visible: selectedTableList.isNotEmpty,
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: context.screenHeight * 0.08,
                padding: const EdgeInsets.symmetric(
                  vertical: AppSize.s8,
                  horizontal: AppSize.s8
                ),
                margin: const EdgeInsets.symmetric(
                  vertical: AppSize.s8,
                  horizontal: AppSize.s8
                ),
                decoration: BoxDecoration(
                  color: Helper.isDark 
                  ? AppColors.contentColorDark 
                  : AppColors.white,
                  boxShadow: const [BoxShadow(color: AppColors.grey, blurRadius: 2.0)],
                  borderRadius: BorderRadius.circular(AppSize.s10)
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(width: AppSize.s5),
                    Expanded(
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemCount: selectedTableList.length,
                        itemBuilder: (_, index){
                          var data = selectedTableList[index];
                          return SizedBox(
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(right: AppSize.s18),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: AppSize.s14,
                                    vertical: AppSize.s6
                                  ),
                                  decoration: BoxDecoration(
                                    color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                    border: Border.all(color: AppColors.lightTextGrey),
                                    borderRadius: BorderRadius.circular(AppSize.s6)
                                  ),
                                  child: CustomText(
                                    title: data.tableName,
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s16, 
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: 8,
                                  top: 2,
                                  child: InkWell(
                                    onTap: () => _tableViewBloc.add(TableViewRemoveTableEvent(removeIndex: index)),
                                    child: Container(
                                      padding: const EdgeInsets.all(AppSize.s4),
                                      decoration: const BoxDecoration(
                                        color: AppColors.red,
                                        shape: BoxShape.circle
                                      ),
                                      child: const Icon(
                                        Icons.clear, 
                                        color: AppColors.white, 
                                        size: AppSize.s14
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      ),
                    ),
                    const SizedBox(width: AppSize.s10),
                    CustomSolidButton(
                     onPressed: () {
                        var selectedTable = selectedTableList.fold("", (p0, item) => p0.isBlank ? p0+item.tableName : '$p0-${item.tableName}');
                        showNewOrderDialog(
                          bContext: context, 
                          selectedTable: selectedTable, 
                          selectedTableList: selectedTableList
                        );
                      },
                      horPadding: AppSize.s16,
                      verPadding: AppSize.s16,
                      borderRadius: AppSize.s6,
                      text: AppStrings.continueString
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSize.s20),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSize.s20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          IconButton(
                            onPressed: () => context.pop(),
                            icon: const Icon(AppIcons.arrowBack)
                          ),
                          const SizedBox(width: AppSize.s10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                title: AppStrings.tableView,
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s20, 
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                ),
                              ),
                              Row(
                                children: [
                                  const Icon(AppIcons.calendarIcon, size: AppSize.s18, color: AppColors.grey),
                                  const SizedBox(width: AppSize.s10),
                                  CustomText(title: currentDateTime),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      CustomSolidButton(
                        onPressed: () => _tableViewBloc.add(OnSwitchUserTableEvent()),
                        prefix: const Icon(
                          AppIcons.swapHorIcon, 
                          color: AppColors.white
                        ),
                        text: AppStrings.switchUser
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSize.s25),
                ///New Table View
                Expanded(
                  child: Stack(
                    children: [
                      Scrollbar(
                        child: SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          controller: _verticalScrollController,
                          child: Scrollbar(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              controller: _horizontalScrollController,
                              child: Container(
                                width: Helper.screenWidth, 
                                height: Helper.screenHeight,
                                color: Helper.isDark 
                                ? AppColors.backgroundColorDark 
                                : AppColors.lightGrey,
                                child: Stack(
                                  children: [
                                    Align(
                                      alignment: Alignment.topCenter,
                                      child: Stack(
                                        children: [
                                          Container(
                                            height: Helper.floorHeight,
                                            width: Helper.floorWidth,
                                            margin: const EdgeInsets.only(top: AppSize.s10),
                                            decoration: BoxDecoration(
                                              color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                                            ),
                                            child: CustomImageView(imgBytes: floorPlanImage)
                                          ),
                                          ...List.generate(
                                            dragedWidget.length, 
                                            (index) {
                                              var data = dragedWidget[index];
                                              return Positioned(
                                                top: data.tableCoordinate.dy,
                                                left: data.tableCoordinate.dx - 240,
                                                child: InkWell(
                                                  onTap: () => _tableViewBloc.add(TableViewSelectTableEvent(selectedIndex: index)),
                                                  child: _getTableShape(
                                                    data, 
                                                    selectedColor: !data.isSelected
                                                    ? AppColors.grey.withOpacity(0.4)
                                                    : AppColors.red
                                                  ),
                                                ),
                                              );
                                            }
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: selectedTableList.isNotEmpty,
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            height: context.screenHeight * 0.10,
                            margin: const EdgeInsets.all(AppSize.s20),
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s12,
                              horizontal: AppSize.s18
                            ),
                            decoration: BoxDecoration(
                              color: Helper.isDark 
                              ? AppColors.contentColorDark : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10),
                              border: Border.all(color: AppColors.lightTextGrey, width: AppSize.s05)
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(AppSize.s15),
                                  decoration: BoxDecoration(
                                    color: AppColors.grey.withOpacity(0.2),
                                    shape: BoxShape.circle
                                  ),
                                  child: const CustomImageView(
                                    imagePath: AppImages.tableTopView,
                                    color: AppColors.grey,
                                    height: AppSize.s25,
                                    width: AppSize.s25,
                                  ),
                                ),
                                const SizedBox(width: AppSize.s18),
                                Expanded(
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    shrinkWrap: true,
                                    padding: EdgeInsets.zero,
                                    itemCount: selectedTableList.length,
                                    itemBuilder: (_, index){
                                      var data = selectedTableList[index];
                                      return Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Container(
                                            margin: const EdgeInsets.only(right: AppSize.s30),
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: AppSize.s14,
                                              vertical: AppSize.s6
                                            ),
                                            decoration: BoxDecoration(
                                              color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                                              border: Border.all(color: AppColors.lightTextGrey),
                                              borderRadius: BorderRadius.circular(AppSize.s6)
                                            ),
                                            child: CustomText(
                                              title: data.tableName,
                                              textStyle: getMediumStyle(
                                                fontSize: AppSize.s16
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 20,
                                            top: 0,
                                            child: InkWell(
                                              onTap: () => _tableViewBloc.add(TableViewRemoveTableEvent(removeIndex: index)),
                                              child: Container(
                                                padding: const EdgeInsets.all(AppSize.s2),
                                                decoration: BoxDecoration(
                                                  color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                                                  shape: BoxShape.circle,
                                                  border: Border.all(color: AppColors.red, width: 1.5)
                                                ),
                                                child: const Icon(
                                                  AppIcons.closeIcon, 
                                                  color: AppColors.red, 
                                                  size: AppSize.s14
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      );
                                    }
                                  ),
                                ),
                                const SizedBox(width: AppSize.s10),
                                CustomSolidButton(
                                  onPressed: () {
                                    var selectedTable = selectedTableList.fold("", (p0, item) => p0.isBlank ? p0+item.tableName : '$p0-${item.tableName}');
                                    showNewOrderDialog(
                                      bContext: context, 
                                      selectedTable: selectedTable, 
                                      selectedTableList: selectedTableList
                                    );
                                  },
                                  horPadding: AppSize.s16,
                                  verPadding: AppSize.s18,
                                  borderRadius: AppSize.s6,
                                  text: AppStrings.continueString,
                                  space: AppSize.s8,
                                  prefix: const CustomImageView(
                                    imagePath: AppImages.purchaseOrder,
                                    color: AppColors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void showNewOrderDialog({
    required BuildContext bContext, 
    required String selectedTable,
    List<TableShapeModel>? selectedTableList,
    Map? storedData
  }){
    showDialog(
      context: context, 
      builder: (_) {
        return NewOrderDialog(
          selectedTable: selectedTable,
          selectedTableList: selectedTableList,
          storeData: storedData,
          serverList: serverList,
          finixUser: finixUser,
          onCreateNewUser: () {
            context.pop();
            showCreateNewUserDialog();
          },
          onAuthorizeCard: showAuthorizeCardDialog,
        );
      }
    );
  }

  void showCreateNewUserDialog() {
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (_) {
        return AlertDialog(
          surfaceTintColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: AddNewUserDialog(
            tableViewBloc: _tableViewBloc,
          ),
        );
      }
    );
  }

  void showBookedOrderTabled({
    required TableViewBloc blocInstance,
    String tableName = '',
    required List<int> tableId,
    required TableOrderDetails tableBookingDetails
  }) {
    showDialog(
      context: context, 
      builder: (_) {
        return BookedTableDetailsDialog(
          tableName: tableName,
          tableViewBloc: blocInstance, 
          tableBookingDetails: tableBookingDetails,
          onFreeTable: () {
            context.pop();
            blocInstance.add(TableViewFreeTableEvent(tableId: tableId));
          },
          onPay: () => context.pushReplacement(AppRoutes.paymentTerminalScreen),
          onChangeServer: () {
            context.pop();
            if(Preferences.getString(key: AppStrings.prefUserRole) == 'Manager' || Preferences.getString(key: AppStrings.prefUserRole) == 'Admin') {
              showServerChangeDialog(tableBookingDetails: tableBookingDetails, tableName: tableName);
            } else {
              authorizeUserDialog(tableBookingDetails: tableBookingDetails, tableName: tableName);
            }
          },
        );
      }
    );
  }

  void showServerChangeDialog({
    required TableOrderDetails tableBookingDetails,
    String tableName = ''
  }) {
    showDialog(
      context: context, 
      builder: (_) {
        return ServerChangeDialog(
          tableBookingDetails: tableBookingDetails,
          tableName: tableName,
          serverList: serverList,
          tableViewBloc: _tableViewBloc,
        );
      }
    );
  }

  void showAuthorizeCardDialog() {
    showDialog(
      context: context, 
      builder: (_) => const AuthorizeCardDialog()
    );
  }

  Future<void> authorizeUserDialog({required TableOrderDetails tableBookingDetails, required String tableName}) async {
    var closeFlag = await showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          surfaceTintColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: AuthenticateUserDialog(
            tableViewBloc: _tableViewBloc,
          ),
        );
      }
    ) ?? false;
    _tableViewBloc.add(TableViewOnCloseAuthDialogEvent());
    if(closeFlag) {
      showServerChangeDialog(tableBookingDetails: tableBookingDetails, tableName: tableName);
    } 
  }

  Widget _getTableShape(TableShapeModel tableShapeModel, {Color? selectedColor}) {
    double tableBalanceDue = getTableBalanceDueStatus(tableShapeModel.bookedOrderDetails);
    switch (tableShapeModel.tableShape) {
      case TableShape.circle:
        ///V2
        return Container(
          height: tableShapeModel.radius,
          width: tableShapeModel.radius,
          margin: const EdgeInsets.only(bottom: AppSize.s20),
          decoration: BoxDecoration(
            color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
            shape: BoxShape.circle,
            border: Border.all(
              color: tableShapeModel.tableAvailableStatus!
              ?AppColors.primaryColor
              : tableBalanceDue > 0.0 || tableShapeModel.bookedOrderDetails == null
                ? AppColors.red
                : AppColors.green,
              width: 1.5
            ),
          ),
          child: Stack(
            children: [
              Align(
                alignment: Alignment.center,
                child: Text(
                  tableShapeModel.tableName,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: getMediumStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
              ),
              Positioned(
                top: (tableShapeModel.radius!/6.5),  
                left: (tableShapeModel.radius!/6.5),
                child: IgnorePointer(
                  child: CircleAvatar(
                    radius: 4.5, 
                    backgroundColor: tableShapeModel.tableAvailableStatus!
                    ?AppColors.primaryColor
                    : tableBalanceDue > 0.0 || tableShapeModel.bookedOrderDetails == null
                      ? AppColors.red
                      : AppColors.green,
                  ),
                ),
              ),
              Visibility(
                visible: tableShapeModel.bookedOrderDetails == null || tableShapeModel.tableAvailableStatus!
                ? false
                : true,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    tableShapeModel.bookedOrderDetails == null
                    ? ''
                    : '\$',
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: getMediumStyle(
                      color: tableBalanceDue > 0.0
                      ? AppColors.red
                      : AppColors.green,
                      fontWeight: FontWeight.bold
                    ),
                  )
                ),
              )
            ],
          ),
        );
      case TableShape.square:
      case TableShape.rectangle:
        int tempTableCount = tableShapeModel.tableCount == null ? 1 : tableShapeModel.tableCount!;
        bool isHorizontal = tableShapeModel.horizontal == null ? true : tableShapeModel.horizontal!;
        return SizedBox(
          width: isHorizontal ? tempTableCount * AppSize.s65 : AppSize.s65,
          height: !isHorizontal ? tempTableCount * AppSize.s65 : AppSize.s65,
          child: Stack(
            children: [
              isHorizontal
              ? Row(
                children: List.generate(
                  tempTableCount, 
                  (_) => Transform.rotate(
                    angle: math.pi / 4,
                    child: Container(
                      width: AppSize.s65, 
                      height: AppSize.s65, 
                      decoration: BoxDecoration(
                        color: AppColors.grey.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(AppSize.s14)
                      ),
                    ),
                  ),
                ),
              )
              : Column(
                children: List.generate(
                  tempTableCount, 
                  (_) => Transform.rotate(
                    angle: math.pi / 4,
                    child: Container(
                      width: AppSize.s65, 
                      height: AppSize.s65, 
                      decoration: BoxDecoration(
                        color: AppColors.grey.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(AppSize.s14)
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(AppSize.s5),
                decoration: BoxDecoration(
                  color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                  borderRadius: BorderRadius.circular(AppSize.s8),
                  border: Border.all(
                    color: tableShapeModel.tableAvailableStatus!
                    ? AppColors.primaryColor
                    : tableBalanceDue > 0.0 || tableShapeModel.bookedOrderDetails == null 
                      ? AppColors.red
                      : AppColors.green,
                    width: 1.5
                  ),
                ),
                child: isHorizontal
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tempTableCount, 
                    (_) => const SizedBox(
                      width: 52, 
                      height: 52,
                    ),
                  ),
                )
                : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    tempTableCount, 
                    (_) => const SizedBox(
                      width: 52, 
                      height: 52,
                    ),
                  ),
                )
              ),
              Align(
                alignment: Alignment.center,
                child: IgnorePointer(
                  child: Text(
                    tableShapeModel.tableName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: getMediumStyle( 
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 11,
                left: 11,
                child: IgnorePointer(
                  child: CircleAvatar(
                    radius: 4.5, 
                    backgroundColor: tableShapeModel.tableAvailableStatus!
                    ?AppColors.primaryColor
                    : tableBalanceDue > 0.0 || tableShapeModel.bookedOrderDetails == null 
                      ? AppColors.red
                      : AppColors.green,
                  ),
                ),
              ),
              ///
              Visibility(
                visible: tableShapeModel.bookedOrderDetails == null || tableShapeModel.tableAvailableStatus!
                ? false
                : true,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: AppSize.s4),
                    child: Text(
                      tableShapeModel.bookedOrderDetails == null
                      ? ''
                      : '\$',
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: getMediumStyle(
                        color: tableBalanceDue > 0.0
                        ? AppColors.red
                        : AppColors.green,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      default:
        return SizedBox(
          child: CustomPaint(
            painter: TrianglePainter(
              strokeColor: selectedColor ?? AppColors.primaryColor,
              tableName: tableShapeModel.tableName
            ),
            child: SizedBox(
              height: tableShapeModel.radius, 
              width: tableShapeModel.radius
            ),
          ),
        );
    }
  }

  double getTableBalanceDueStatus(TableOrderDetails? bookedOrderDetails){
    if(bookedOrderDetails == null){
      return 0.0;
    } else{
      if(bookedOrderDetails.balanceDue == null) return 0.0;
      return bookedOrderDetails.balanceDue!;
    } 
  }

}