import 'package:cliqtechnologies_retl/constants/app_images.dart';
import 'package:cliqtechnologies_retl/widgets/custom_image_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import 'bloc/table_view_bloc.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_text.dart';
import '../../../constants/app_colors.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../setup_floor/domain/all_floor_plan_response.dart';

class BookedTableDetailsDialog extends StatelessWidget {
  
  final TableViewBloc tableViewBloc;
  final TableOrderDetails tableBookingDetails;
  final String tableName;
  final Function()? onFreeTable;
  final Function()? onPay;
  final Function()? onChangeServer;
  
  const BookedTableDetailsDialog({
    super.key,
    required this.tableName,
    required this.tableViewBloc,
    required this.tableBookingDetails,
    this.onFreeTable,
    this.onPay,
    this.onChangeServer
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider<TableViewBloc>.value(
      value: tableViewBloc,
      child: AlertDialog(
        backgroundColor: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12)
        ),
        contentPadding: EdgeInsets.zero,
        insetPadding: EdgeInsets.zero,
        content: BlocBuilder<TableViewBloc, TableViewState>(
          builder: (context, state) {
            return Container(
              width: context.screenWidth <= 600 
              ? context.screenWidth * 0.95
              : context.screenWidth * 0.30,
              padding: const EdgeInsets.symmetric(
                vertical: AppSize.s18,
                horizontal: AppSize.s18
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppSize.s12),
                color: Helper.isDark 
                ? AppColors.contentColorDark 
                : AppColors.white,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CustomText(
                    title: AppStrings.bookedTableDetails,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18, 
                      color: Helper.isDark 
                      ? AppColors.white 
                      : AppColors.black
                    ),
                  ),
                  const SizedBox(height: AppSize.s20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: AppSize.s8,
                      horizontal: AppSize.s10
                    ),
                    decoration: BoxDecoration(
                      color: Helper.isDark 
                      ? AppColors.headerColorDark 
                      : AppColors.backgroundColor,
                      borderRadius: BorderRadius.circular(AppSize.s6)
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          AppIcons.accountCircleIcon, 
                          size: AppSize.s20
                        ),
                        const SizedBox(width: AppSize.s8),
                        CustomText(
                          title: tableBookingDetails.customerName!,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16,
                            color: Helper.isDark
                            ? AppColors.white
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSize.s6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: AppSize.s8,
                      horizontal: AppSize.s10
                    ),
                    decoration: BoxDecoration(
                      color: Helper.isDark 
                      ? AppColors.headerColorDark 
                      : AppColors.backgroundColor,
                      borderRadius: BorderRadius.circular(AppSize.s6)
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              AppIcons.chairIcon, 
                              size: AppSize.s20
                            ),
                            const SizedBox(width: AppSize.s8),
                            CustomText(
                              title: tableName,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s16,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            const Icon(
                              AppIcons.groupIcon, 
                              size: AppSize.s20
                            ),
                            const SizedBox(width: AppSize.s8),
                            CustomText(
                              title: 'Guest  ${tableBookingDetails.guestCount}',
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s16,
                                color: Helper.isDark
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSize.s6),
                  InkWell(
                    onTap: onChangeServer,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: AppSize.s8,
                        horizontal: AppSize.s10
                      ),
                      decoration: BoxDecoration(
                        color: Helper.isDark 
                        ? AppColors.headerColorDark 
                        : AppColors.backgroundColor,
                        borderRadius: BorderRadius.circular(AppSize.s6)
                      ),
                      child: Row(
                        children: [
                          CustomImageView(
                            imagePath: AppImages.server,
                            height: AppSize.s20,
                            width: AppSize.s20,
                            color: Helper.isDark
                            ? AppColors.white
                            : AppColors.black,
                          ),
                          const SizedBox(width: AppSize.s8),
                          CustomText(
                            title: '${tableBookingDetails.serverName}',
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s16,
                              color: Helper.isDark
                              ? AppColors.white
                              : AppColors.black
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSize.s20),
                  tableBookingDetails.balanceDue! > 0.0
                  ? Column(
                    children: [
                      Container(
                        width: double.maxFinite,
                        padding: const EdgeInsets.symmetric(
                          vertical: AppSize.s12,
                          horizontal: AppSize.s12
                        ),
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.headerColorDark 
                          : AppColors.backgroundColor,
                          borderRadius: BorderRadius.circular(AppSize.s6)
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              title: tableBookingDetails.orderNumber ?? '', 
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14,
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            const SizedBox(height: AppSize.s8),
                            CustomText(
                              title: '${AppStrings.balanceDue} : \$${tableBookingDetails.balanceDue}', 
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: AppColors.red
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: AppSize.s18),
                      Row(
                        children: [
                          Expanded(
                            child: CustomSolidButton(
                              onPressed: onPay,
                              text: AppStrings.pay,
                              verPadding: AppSize.s16,
                              textSize: AppSize.s16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                  /// For No Balance
                  : Column(
                    children: [
                      Container(
                        width: double.maxFinite,
                        padding: const EdgeInsets.symmetric(
                          vertical: AppSize.s10,
                          horizontal: AppSize.s12
                        ),
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.headerColorDark 
                          : AppColors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(AppSize.s10)
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              title: '${AppStrings.balanceDue} : \$0.0', 
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: AppColors.green
                              ),
                            ),
                            const SizedBox(height: AppSize.s6),
                            CustomText(
                              title: AppStrings.noBalanceDueMessage, 
                              textStyle: getRegularStyle(
                                color: AppColors.green
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: AppSize.s14),
                      SizedBox(
                        width: double.maxFinite,
                        child: CustomSolidButton(
                          onPressed: onFreeTable,
                          backgroundColor: AppColors.green,
                          verPadding: AppSize.s16,
                          text: AppStrings.freeTable,
                          textSize: AppSize.s16,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }
        ),
      ),
    );
  }
}