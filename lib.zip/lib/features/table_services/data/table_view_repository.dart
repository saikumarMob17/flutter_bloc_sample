import 'dart:convert';
import 'dart:io';
import 'package:cliqtechnologies_retl/utils/app_extension_method.dart';
import 'package:http/http.dart';

import '../../../constants/app_strings.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../network/end_points.dart';
import '../../../services/finix_identity_model.dart';
import '../../../services/finix_identity_response.dart';
import '../../../utils/helper.dart';
import '../../setup_floor/domain/all_floor_plan_response.dart';
import '../../setup_floor/domain/floor_plan_response.dart' as floor;
import '../domain/all_employees_response.dart';

class TableViewRepository {
  late ApiClient _apiClient;

  TableViewRepository(){
    _apiClient = ApiClient();
  }

  Future<List<Floors>> getAllFloorPlan() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.getAllFloorPlan);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data = allFloorPlanResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }


  Future<floor.Floor> getFloorPlan({required String floorId}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: "${EndPoints.getFloorPlan}?id=$floorId");
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data = floor.floorPlanResponseFromJson(response.body);
          return data.data!;
        default:
          throw Exception(jsonResponse['message']);
      }
    } catch (e) {
      throw Exception(e.toString().substring(11));
    }
  }

  Future<bool> updateTableStatus({required String id}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: '${EndPoints.updateFloorPlanById}?id=$id', body: null);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            return true;
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }


  Future<List<Employees>> getAllEmployees() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.allEmployees);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = allEmployeesResponseFromJson(response.body);
            return data.data ?? [];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> authorizeManagerProfile({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.authorizeManager, body: body);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok) {
            return jsonDecode(response.body)['message'];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> transferCheck({required String endPoint}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: endPoint, body: null);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok) {
            return jsonDecode(response.body)['message'];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }


  Future<List<FinixIdentityModel>> getAllFinixIdentity() async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      var response = await _apiClient.getRequest(endPoint: EndPoints.identities, customHeader: customHeader);
      switch (response.statusCode) {
        case HttpStatus.ok:
          var identityModel = <FinixIdentityModel>[];
          var data = finixIntityResponseFromJson(response.body);
          if(data.embedded != null) {
            for(var item in data.embedded!.identities!) {
              if(item.entity!= null && (!item.entity!.firstName!.isBlank && !item.entity!.lastName!.isBlank)) {
                identityModel.add(FinixIdentityModel(
                  appId: item.application!, 
                  identityId: item.id!, 
                  email: item.entity!.email!, 
                  phone: item.entity!.phone!, 
                  name: '${item.entity!.firstName!} ${item.entity!.lastName!}',
                  personalAddress: item.entity!.personalAddress,
                  businessAddress: item.entity!.businessAddress
                ));
              }
            }
          }
          return identityModel;
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<Response> createFinixIdentity({required Map body}) async {
    try {
      String basicAuth = 'Basic ${base64.encode(utf8.encode('US8N1hwX2LXxQL5KUFyuCUkt:1dbfa9fb-c594-4295-94a5-fdaf0a5cf103'))}';
      var customHeader = {
        'Content-Type': 'application/json',
        'Finix-Version': '2022-02-01',
        'Authorization': basicAuth
      };
      return await _apiClient.postRequest(endPoint: EndPoints.identities, body: body, customHeader: customHeader);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}