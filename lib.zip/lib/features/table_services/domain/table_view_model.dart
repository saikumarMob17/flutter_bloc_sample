import 'package:cliqtechnologies_retl/utils/helper.dart';

class TableViewModel {

  String tableLabel;
  int tableSize;
  bool isSelected;
  TableAvailableStatus availabilityStatus;

  TableViewModel({
    required this.tableLabel,
    required this.tableSize,
    required this.isSelected,
    required this.availabilityStatus
  });
}