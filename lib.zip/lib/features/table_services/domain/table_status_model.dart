import '../../../utils/helper.dart';

class TableStatusModel {

  int tableCount;
  String tableStatusLabel;
  TableAvailableStatus tableAvailableStatus;

  TableStatusModel({
    required this.tableCount,
    required this.tableStatusLabel,
    required this.tableAvailableStatus
  });
}