class EmployeeDropdownItem {

  String id;
  String value;
  bool isClockedIn;
  int orderCount;

  EmployeeDropdownItem({
    required this.value,
    required this.id,
    this.isClockedIn = false,
    this.orderCount = 0
  });
}