// To parse this JSON data, do
//
//     final allEmployeesResponse = allEmployeesResponseFromJson(jsonString);

import 'dart:convert';

AllEmployeesResponse allEmployeesResponseFromJson(String str) => AllEmployeesResponse.fromJson(json.decode(str));

class AllEmployeesResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<Employees>? data;

  AllEmployeesResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory AllEmployeesResponse.fromJson(Map<String, dynamic> json) => AllEmployeesResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<Employees>.from(json["data"]!.map((x) => Employees.fromJson(x))),
  );
}

class Employees {
  final User? user;
  final String? roles;
  final bool? isClockedIn;
  final int? orderCount;

  Employees({
    this.user,
    this.roles,
    this.isClockedIn,
    this.orderCount
  });

  factory Employees.fromJson(Map<String, dynamic> json) => Employees(
    user: json["user"] == null ? null : User.fromJson(json["user"]),
    roles: json["roles"],
    isClockedIn: json['isClockedIn'] ?? false,
    orderCount: json['orderCount'] ?? 0
  );
}


class User {
  final String? firstName;
  final String? lastName;
  final dynamic token;
  final String? address;
  final bool? status;
  final String? tenantId;
  final bool? isDeleted;
  final String? id;
  final String? userName;
  final String? normalizedUserName;
  final String? email;
  final String? normalizedEmail;
  final bool? emailConfirmed;
  final String? passwordHash;
  final String? securityStamp;
  final String? concurrencyStamp;
  final String? phoneNumber;
  final bool? phoneNumberConfirmed;
  final bool? twoFactorEnabled;
  final dynamic lockoutEnd;
  final bool? lockoutEnabled;
  final int? accessFailedCount;

  User({
    this.firstName,
    this.lastName,
    this.token,
    this.address,
    this.status,
    this.tenantId,
    this.isDeleted,
    this.id,
    this.userName,
    this.normalizedUserName,
    this.email,
    this.normalizedEmail,
    this.emailConfirmed,
    this.passwordHash,
    this.securityStamp,
    this.concurrencyStamp,
    this.phoneNumber,
    this.phoneNumberConfirmed,
    this.twoFactorEnabled,
    this.lockoutEnd,
    this.lockoutEnabled,
    this.accessFailedCount,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    firstName: json["firstName"],
    lastName: json["lastName"],
    token: json["token"],
    address: json["address"],
    status: json["status"],
    tenantId: json["tenantId"],
    isDeleted: json["isDeleted"],
    id: json["id"],
    userName: json["userName"],
    normalizedUserName: json["normalizedUserName"],
    email: json["email"],
    normalizedEmail: json["normalizedEmail"],
    emailConfirmed: json["emailConfirmed"],
    passwordHash: json["passwordHash"],
    securityStamp: json["securityStamp"],
    concurrencyStamp: json["concurrencyStamp"],
    phoneNumber: json["phoneNumber"],
    phoneNumberConfirmed: json["phoneNumberConfirmed"],
    twoFactorEnabled: json["twoFactorEnabled"],
    lockoutEnd: json["lockoutEnd"],
    lockoutEnabled: json["lockoutEnabled"],
    accessFailedCount: json["accessFailedCount"],
  );
}