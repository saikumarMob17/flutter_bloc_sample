import '../../../routes/route.dart';

class AuthorizationRequest {
  String userEmailId;
  String password;
  String pin;
  LoginType loginType;

  AuthorizationRequest({
    this.userEmailId = '',
    this.password = '',
    this.pin = '',
    this.loginType = LoginType.pin
  });

  Map get toJson => {
    "userEmailID": loginType == LoginType.pin ? '' : userEmailId,
    "password": loginType == LoginType.pin ? '' : password,
    "userSecurityPin": loginType == LoginType.pin ? pin : ''
  };
}