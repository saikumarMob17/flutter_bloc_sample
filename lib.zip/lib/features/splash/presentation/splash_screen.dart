import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_strings.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/shared_pref.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../constants/app_colors.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with RouteAware {

  @override
  void didChangeDependencies() {
    startTimer(context: context);
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: Center(
        child: CustomImageView(
          imagePath: AppImages.logoTextBgColor, 
          height: 400, 
          width: 400, 
          fit: BoxFit.contain
        ),
      ),
    );
  }

  void startTimer({required BuildContext context}){
    Preferences.setString(key: AppStrings.prefTenantId, value: '46e51556-4d1c-4c6f-b98f-ba6102b5c883');
    Timer(const Duration(seconds: 2), () {
      if(Preferences.getString(key: AppStrings.prefToken).isNotEmpty) {
        Preferences.setBool(key: AppStrings.prefBiometricAuthentication, value: true);
        context.go(AppRoutes.dashboardScreen);
      } else {
        context.go(AppRoutes.loginScreen);
      }
    });
  }

}