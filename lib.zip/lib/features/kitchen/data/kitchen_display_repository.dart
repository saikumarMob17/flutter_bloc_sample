import 'dart:convert';
import 'dart:io';

import 'package:cliqtechnologies_retl/constants/app_strings.dart';
import 'package:cliqtechnologies_retl/network/api/api_client.dart';
import 'package:cliqtechnologies_retl/network/end_points.dart';

import '../../../network/custom_exception.dart';
import '../../../utils/helper.dart';
import '../domain/kitchen_display_response.dart';
import '../domain/kitchen_finish_response.dart';

class KitchenDisplayRepository {

  late ApiClient _apiClient;

  KitchenDisplayRepository(){
    _apiClient = ApiClient();
  }

  Future<List<KitchenData>> kitchenDisplayData() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.kitchenDisplay);
      switch (response.statusCode) {
        case HttpStatus.ok:
          var data = kitchenDisplayResponseFromJson(response.body);
          return data.data!;
        default:
          return [];
      }
    } on CustomException catch (e) {
      throw(e.message);
    }
  }

  Future<KitchenFinishResponse> finishKitchenOrder({required String orderNumber, required int orderSequence}) async {
    try {
      var endPoint = '${EndPoints.finishKitchenOrder}?orderNum=$orderNumber&orderSeq=$orderSequence';
      var response = await _apiClient.postRequest(endPoint: endPoint, body: null);
      switch (response.statusCode) {
        case HttpStatus.ok:
          return kitchenFinishResponseFromJson(response.body);
        default:
          throw('Unable to call api');
      }
    } catch (e) {
      throw('Something went wrong');
    }
  }

  Future<String> updateKitchenOrderStatus({required List<Map<String, dynamic>> productIds}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.updateKitchenOrderStatus, body: productIds);
      switch (response.statusCode) {
        case HttpStatus.created:
          return jsonDecode(response.body)['status'];
        case HttpStatus.badGateway:
          throw CustomException(message: jsonDecode(response.body)['status']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  } 

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }
}