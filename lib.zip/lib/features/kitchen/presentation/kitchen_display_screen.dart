import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_icons.dart';
import '../domain/kitchen_receipt_widget.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import 'bloc/kitchen_display_bloc.dart';
import 'kitchen_item_mobile_view.dart';
import '../../../widgets/custom_empty_widget.dart';
import 'kitchen_order_status_dialog.dart';
import '../domain/kitchen_display_model.dart';

class KitchenDisplayScreen extends StatefulWidget {

  const KitchenDisplayScreen({super.key});

  @override
  State createState() => _KitchenDisplayScreenState();
}

class _KitchenDisplayScreenState extends State<KitchenDisplayScreen> with Helper {

  List<KitchenDisplayModel> kitchenDataList = [];
  bool isLoading = false;
  double _layoutHeight = 0.0;
  bool isMostRecent = false;
  late KitchenDisplayBloc _kitchenDisplayBloc;
  late ScrollController _scrollController;

  @override
  void initState() {
    _scrollController = ScrollController();
    _kitchenDisplayBloc = context.read<KitchenDisplayBloc>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<KitchenDisplayBloc, KitchenDisplayState>(
        builder: (context, state) {
          switch (state) {
            case KitchenDisplaySuccessState _:
              kitchenDataList.clear();
              kitchenDataList.addAll(state.kitchenDisplayData);
              isMostRecent = state.isMostRecent;
              isLoading = false;
              break;
            case KitchenDisplayLoadingState _:
              isLoading = true;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case KitchenDisplayLoadingState _:
              showLoadingDialog(context: context);
              break;
            case KitchenDisplayFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.message);
              break;
            case KitchenDisplaySuccess _:
            case KitchenDisplaySuccessState _:
              hideLoadingDialog(context: context);
              break;
            case OnSwitchUserKitchenState _:
              hideLoadingDialog(context: context);
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s12,
        vertical: AppSize.s12
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.kitchenDisplay,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => _kitchenDisplayBloc.add(OnSwitchUserKitchenEvent()),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                  const SizedBox(width: AppSize.s10),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s22,
                    width: AppSize.s22,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black,
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s20),
          Expanded(
            child: kitchenDataList.isEmpty
            ? CustomEmptyWidget(
                emptyTitle: AppStrings.noOrderFound,
                imagePath: AppImages.notFound,
                isVisible: !isLoading,
              )
            : KitchenItemMobileView(
              kitchenData: kitchenDataList,
              onTap: (index) {
                // _kitchenDisplayBloc.add(
                //   FinishOrderEvent(
                //     orderNumber: kitchenDataList[index].orderNumber, 
                //     orderSequence: kitchenDataList[index].orderSequenceDetails.orderSequence!
                //   ),
                // );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(selectedLeftNavigationItem: 0),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.kitchenDisplay,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s20,
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: context.screenWidth * 0.20,
                          child: CustomTextField(
                            prefixImagePath: AppImages.searchIcon,
                            prefixImageColor: AppColors.lightTextGrey,
                            prefixImageSize: AppSize.s16,
                            horPadding: AppSize.s14,
                            verPadding: 9,
                            hint: AppStrings.search,
                            onChange: (value) => _kitchenDisplayBloc.add(OnSearchKitchenItemEvent(text: value)),
                          ),
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomOutlinedButton(
                          onPressed: () => _kitchenDisplayBloc.add(KitchenDisplayMostRecentEvent(isMostRecent: !isMostRecent)),
                          text: AppStrings.mostRecent,
                          backgroundColor: isMostRecent 
                          ? AppColors.primaryColor 
                          : null,
                          suffixWidget: Icon(
                            AppIcons.swapVerIcon, 
                            color: isMostRecent 
                            ? AppColors.white 
                            : AppColors.blue
                          ),
                          widgetSpacing: AppSize.s4,
                          textColor: isMostRecent 
                          ? AppColors.white 
                          : AppColors.blue,
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomSolidButton(
                          onPressed: () => _kitchenDisplayBloc.add(OnSwitchUserKitchenEvent()),
                          text: AppStrings.switchUser,
                          prefix: const Icon(
                            Icons.swap_horiz_rounded, 
                            color: AppColors.white
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: kitchenDataList.isEmpty
                ? CustomEmptyWidget(
                    isVisible: !isLoading,
                    imagePath: AppImages.notFound, 
                    emptyTitle: AppStrings.noOrderFound
                  )
                  ///New UI
                : Align(
                  alignment: Alignment.centerLeft,
                  child: LayoutBuilder(
                    builder: (_, size) {
                      _layoutHeight = size.maxHeight;
                      return Scrollbar(
                        // thumbVisibility: true,
                        trackVisibility: true,
                        thickness: AppSize.s8,
                        radius: const Radius.circular(AppSize.s5),
                        controller: _scrollController,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: true,
                          primary: false,
                          controller: _scrollController,
                          padding: const EdgeInsets.all(15.0),
                          children: [
                            Wrap(
                              direction: Axis.vertical,
                              spacing: 5.0,
                              runSpacing: 5.0,
                              children: List.generate(
                                kitchenDataList.length, 
                                (index) {
                                  var data = kitchenDataList[index];
                                  if(_layoutHeight < (data.orderSequenceDetails.productDetails!.length + 3) * 45){
                                    return GestureDetector(
                                      onTap: () => showKitchenOrderStatusDialog(kitchenDisplayData: data, parentIndex: index),
                                      child: Container(
                                        width: context.screenWidth * 0.22,
                                        margin: const EdgeInsets.only(right: AppSize.s6, bottom: AppSize.s6),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(AppSize.s5),
                                          boxShadow: Helper.isDark
                                          ? null
                                          : const [BoxShadow(color: AppColors.grey, blurRadius: AppSize.s1)]
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.all(AppSize.s10),
                                              decoration: const BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(AppSize.s5),
                                                  topRight: Radius.circular(AppSize.s5)
                                                )
                                              ),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  CustomText(
                                                    title: data.tableName,
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                  CustomText(
                                                    title: data.createdDate.toString().substring(11,16),
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                  CustomText(
                                                    title: data.serverName,
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                padding: const EdgeInsets.all(AppSize.s10),
                                                decoration: BoxDecoration(
                                                  color: Helper.isDark 
                                                  ? AppColors.headerColorDark
                                                  : AppColors.white,
                                                  borderRadius: const BorderRadius.only(
                                                    bottomLeft: Radius.circular(AppSize.s5),
                                                    bottomRight: Radius.circular(AppSize.s5)
                                                  )
                                                ),
                                                child: Column(
                                                  mainAxisSize: MainAxisSize.min,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      children: [
                                                        Expanded(
                                                          child: CustomText(
                                                            title: 'Tab : ${data.customerName}',
                                                            textStyle: getMediumStyle(
                                                              fontSize: AppSize.s16,
                                                              color: Helper.isDark 
                                                              ? AppColors.white
                                                              : AppColors.black
                                                            ),
                                                          ),
                                                        ),
                                                        Expanded(
                                                          child: CustomText(
                                                            title: '#${data.orderSequenceDetails.orderSequence}',
                                                            maxLines: 1,
                                                            textAlign: TextAlign.end,
                                                            color: Helper.isDark 
                                                            ? AppColors.white
                                                            : AppColors.black
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Divider(
                                                      color: Helper.isDark 
                                                      ? AppColors.white
                                                      : AppColors.black, 
                                                      height: AppSize.s5, 
                                                      thickness: AppSize.s1
                                                    ),
                                                    Expanded(
                                                      child: ListView(
                                                        shrinkWrap: true,
                                                        children: List.generate(
                                                          data.orderSequenceDetails.productDetails!.length, 
                                                          (subIndex) {
                                                            var productData = data.orderSequenceDetails.productDetails![subIndex];
                                                            return Container(
                                                              padding: const EdgeInsets.only(top: AppSize.s10, bottom: AppSize.s10),
                                                              margin: const EdgeInsets.only(left: 15),
                                                              decoration: BoxDecoration(
                                                                border: Border(
                                                                  bottom: BorderSide(
                                                                    width: 0.5, 
                                                                    color: subIndex < data.orderSequenceDetails.productDetails!.length - 1
                                                                    ? AppColors.grey 
                                                                    : AppColors.transparent
                                                                  ),
                                                                ),
                                                              ),
                                                              child: Row(
                                                                children: [
                                                                  SizedBox(
                                                                    width: 30,
                                                                    child: CustomText(
                                                                      title: '${productData.quantity!}',
                                                                      textStyle: getRegularStyle(
                                                                        fontSize: AppSize.s14,
                                                                        color: Helper.isDark 
                                                                        ? AppColors.white
                                                                        : AppColors.black
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Expanded(
                                                                    child: CustomText(
                                                                      title: productData.productName!,
                                                                      maxLines: 1,
                                                                      textOverflow: TextOverflow.ellipsis,
                                                                      fontSize: 14,
                                                                      color: Helper.isDark 
                                                                      ? AppColors.white
                                                                      : AppColors.black
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            );
                                                          }
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  } else {
                                    return GestureDetector(
                                      onTap: () => showKitchenOrderStatusDialog(kitchenDisplayData: data, parentIndex: index),
                                      child: Container(
                                        width: context.screenWidth * 0.22,
                                        margin: const EdgeInsets.only(right: AppSize.s6, bottom: AppSize.s6),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(AppSize.s5),
                                          boxShadow: Helper.isDark
                                          ? null
                                          : const [BoxShadow(color: AppColors.grey, blurRadius: AppSize.s1)]
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.all(AppSize.s10),
                                              decoration: const BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(AppSize.s5),
                                                  topRight: Radius.circular(AppSize.s5)
                                                )
                                              ),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  CustomText(
                                                    title: data.tableName,
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                  CustomText(
                                                    title: data.createdDate.toString().substring(11,16),
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                  CustomText(
                                                    title: data.serverName,
                                                    textStyle: getRegularStyle(color: AppColors.white),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              padding: const EdgeInsets.all(AppSize.s10),
                                              decoration: BoxDecoration(
                                                color: Helper.isDark 
                                                ? AppColors.headerColorDark
                                                : AppColors.white,
                                                borderRadius: const BorderRadius.only(
                                                  bottomLeft: Radius.circular(AppSize.s5),
                                                  bottomRight: Radius.circular(AppSize.s5)
                                                )
                                              ),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Expanded(
                                                        child: CustomText(
                                                          title: 'Tab : ${data.customerName}',
                                                          textStyle: getMediumStyle(
                                                            fontSize: AppSize.s16,
                                                            color: Helper.isDark 
                                                            ? AppColors.white
                                                            : AppColors.black
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        child: CustomText(
                                                          title: '#${data.orderSequenceDetails.orderSequence}',
                                                          maxLines: 1,
                                                          textAlign: TextAlign.end,
                                                          color: Helper.isDark 
                                                          ? AppColors.white
                                                          : AppColors.black
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Divider(
                                                    color: Helper.isDark 
                                                    ? AppColors.white
                                                    : AppColors.black, 
                                                    height: AppSize.s5, 
                                                    thickness: AppSize.s1
                                                  ),
                                                  ListView(
                                                    shrinkWrap: true,
                                                    physics: const NeverScrollableScrollPhysics(),
                                                    children: List.generate(
                                                      data.orderSequenceDetails.productDetails!.length, 
                                                      (subIndex) {
                                                        var productData = data.orderSequenceDetails.productDetails![subIndex];
                                                        return Container(
                                                          padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                                                          margin: const EdgeInsets.only(left: 15),
                                                          decoration: BoxDecoration(
                                                            border: Border(
                                                              bottom: BorderSide(
                                                                width: 0.4, 
                                                                color: subIndex < data.orderSequenceDetails.productDetails!.length - 1
                                                                ? AppColors.grey 
                                                                : AppColors.transparent
                                                              ),
                                                            ),
                                                          ),
                                                          child: Row(
                                                            children: [
                                                              SizedBox(
                                                                width: 30,
                                                                child: CustomText(
                                                                  title: '${productData.quantity!}',
                                                                  textStyle: getRegularStyle(
                                                                    fontSize: AppSize.s14,
                                                                    color: Helper.isDark 
                                                                    ? AppColors.white
                                                                    : AppColors.black
                                                                  ),
                                                                ),
                                                              ),
                                                              Expanded(
                                                                child: CustomText(
                                                                  title: productData.productName!,
                                                                  maxLines: 1,
                                                                  textOverflow: TextOverflow.ellipsis,
                                                                  fontSize: 14,
                                                                  color: Helper.isDark 
                                                                  ? AppColors.white
                                                                  : AppColors.black
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      }
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }
                                }
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
                ///Old UI
                // : ListView(
                //   // scrollDirection: Axis.horizontal,
                //   padding: const EdgeInsets.symmetric(
                //     horizontal: AppSize.s30,
                //     vertical: AppSize.s20
                //   ),
                //   children: [
                //     Wrap(
                //       children: List.generate(
                //         kitchenDataList.length, 
                //         (index) {
                //           var data = kitchenDataList[index];
                //           return Container(
                //             width: context.screenWidth * 0.20,
                //             margin: const EdgeInsets.only(right: AppSize.s12, bottom: AppSize.s12),
                //             decoration: BoxDecoration(
                //               borderRadius: BorderRadius.circular(AppSize.s10),
                //               boxShadow: Helper.isDark
                //               ? null
                //               : const [BoxShadow(color: AppColors.grey, blurRadius: AppSize.s1)]
                //             ),
                //             child: Column(
                //               children: [
                //                 Container(
                //                   padding: const EdgeInsets.all(AppSize.s10),
                //                   decoration: const BoxDecoration(
                //                     color: AppColors.primaryColor,
                //                     borderRadius: BorderRadius.only(
                //                       topLeft: Radius.circular(AppSize.s10),
                //                       topRight: Radius.circular(AppSize.s10)
                //                     )
                //                   ),
                //                   child: Row(
                //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //                     children: [
                //                       CustomText(
                //                         title: data.tableName,
                //                         textStyle: getRegularStyle(color: AppColors.white),
                //                       ),
                //                       CustomText(
                //                         title: data.createdDate.toString().substring(11,16),
                //                         textStyle: getRegularStyle(color: AppColors.white),
                //                       ),
                //                       CustomText(
                //                         title: data.serverName,
                //                         textStyle: getRegularStyle(color: AppColors.white),
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //                 Container(
                //                   padding: const EdgeInsets.all(AppSize.s10),
                //                   decoration: BoxDecoration(
                //                     color: Helper.isDark 
                //                     ? AppColors.headerColorDark
                //                     : AppColors.white,
                //                     borderRadius: const BorderRadius.only(
                //                       bottomLeft: Radius.circular(AppSize.s10),
                //                       bottomRight: Radius.circular(AppSize.s10)
                //                     )
                //                   ),
                //                   child: Column(
                //                     children: [
                //                       Row(
                //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //                         children: [
                //                           Expanded(
                //                             child: CustomText(
                //                               title: 'Tab: ${data.customerName}',
                //                               textStyle: getMediumStyle(
                //                                 fontSize: AppSize.s16,
                //                                 color: Helper.isDark 
                //                                 ? AppColors.white
                //                                 : AppColors.black
                //                               ),
                //                             ),
                //                           ),
                //                           Expanded(
                //                             child: CustomText(
                //                               title: '#${data.orderSequenceDetails.orderSequence}',
                //                               maxLines: 1,
                //                               textAlign: TextAlign.end,
                //                               color: Helper.isDark 
                //                               ? AppColors.white
                //                               : AppColors.black
                //                             ),
                //                           ),
                //                         ],
                //                       ),
                //                       Divider(
                //                         color: Helper.isDark 
                //                         ? AppColors.white
                //                         : AppColors.black, 
                //                         height: AppSize.s5, 
                //                         thickness: AppSize.s1
                //                       ),
                //                       ListView(
                //                         shrinkWrap: true,
                //                         physics: const NeverScrollableScrollPhysics(),
                //                         children: List.generate(
                //                           data.orderSequenceDetails.productDetails!.length, 
                //                           (subIndex) {
                //                             var productData = data.orderSequenceDetails.productDetails![subIndex];
                //                             return Padding(
                //                               padding: const EdgeInsets.only(top: AppSize.s8),
                //                               child: Row(
                //                                 children: [
                //                                   CustomText(
                //                                     title: '${subIndex+1}',
                //                                     textStyle: getMediumStyle(
                //                                       fontSize: AppSize.s12,
                //                                       color: Helper.isDark 
                //                                       ? AppColors.white
                //                                       : AppColors.black
                //                                     ),
                //                                   ),
                //                                   const SizedBox(width: AppSize.s20),
                //                                   Expanded(
                //                                     child: Container(
                //                                       padding: const EdgeInsets.symmetric(
                //                                         vertical: AppSize.s8
                //                                       ),
                //                                       decoration: BoxDecoration(
                //                                         border: Border(
                //                                           bottom: BorderSide(
                //                                             color: Helper.isDark 
                //                                             ? AppColors.white
                //                                             : AppColors.black
                //                                           ),
                //                                         ),
                //                                       ),
                //                                       child: Row(
                //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //                                         children: [
                //                                           CustomText(
                //                                             title: productData.productName!,
                //                                             color: Helper.isDark 
                //                                             ? AppColors.white
                //                                             : AppColors.black
                //                                           ),
                //                                           CustomText(
                //                                             title: 'X ${productData.quantity!}',
                //                                             color: Helper.isDark 
                //                                             ? AppColors.white
                //                                             : AppColors.grey
                //                                           ),
                //                                         ],
                //                                       ),
                //                                     ),
                //                                   ),
                //                                 ],
                //                               ),
                //                             );
                //                           }
                //                         ),
                //                       ),
                //                       const SizedBox(height: AppSize.s14),
                //                       Row(
                //                         children: [
                //                           Expanded(
                //                             child: CustomOutlinedButton(
                //                               onPressed: () => showReceiptDialog(context: bContext, kitchenData: data),
                //                               topPadding: 8,
                //                               bottomPadding: 8,
                //                               text: 'Print',
                //                             ),
                //                           ),
                //                           const SizedBox(width: AppSize.s8),
                //                           Expanded(
                //                             child: CustomSolidButton(
                //                               onPressed: () => _kitchenDisplayBloc.add(
                //                                 FinishOrderEvent(
                //                                   orderNumber: data.orderNumber, 
                //                                   orderSequence: data.orderSequenceDetails.orderSequence!
                //                                 ),
                //                               ),
                //                               text: AppStrings.finish,
                //                               textColor: AppColors.white,
                //                               verPadding: AppSize.s10,
                //                               horPadding: AppSize.s16
                //                             ),
                //                           ),
                //                         ],
                //                       ),
                //                     ],
                //                   ),
                //                 ),
                //               ],
                //             ),
                //           );
                //         }
                //       ),
                //     ),
                //   ]
                // ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> showKitchenOrderStatusDialog({
    required KitchenDisplayModel kitchenDisplayData,
    required int parentIndex
  }) async {
    var status = await showDialog(
      context: context, 
      builder: (_) => KitchenOrderStatusDialog(
        kitchenDisplayBloc: _kitchenDisplayBloc,
        kitchenDisplayData: kitchenDisplayData,
        parentIndex: parentIndex,
        onPrintReceipt: () {
          context.pop();
          showReceiptDialog(context: context, kitchenData: kitchenDisplayData);
        },
      )
    ) ?? false;
    if(status) {
      _kitchenDisplayBloc.add(KitchenDisplayDataEvent());
    }
  }

  void showReceiptDialog({required BuildContext context, required KitchenDisplayModel kitchenData}){
    showDialog(
      context: context, 
      builder: (_){
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: KitchenReceiptWidget(
            kitchenData: kitchenData,
          ),
        );
      }
    );
  }

}