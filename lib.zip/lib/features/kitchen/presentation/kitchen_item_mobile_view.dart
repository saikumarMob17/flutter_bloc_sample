import 'package:flutter/material.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../constants/app_strings.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_text.dart';
import '../domain/kitchen_display_model.dart';

class KitchenItemMobileView extends StatelessWidget {

  final List<KitchenDisplayModel> kitchenData;
  final Function(int) onTap;

  const KitchenItemMobileView({
    super.key,
    required this.kitchenData,
    required this.onTap
  });

  @override
  Widget build(BuildContext context) {
    int itemIndex = 0;
    return ListView(
      shrinkWrap: true,
      children: [
        Column(
          children: List.generate(
            kitchenData.length.orderItemCount,
            (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: AppSize.s8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(
                    2, 
                    (subIndex) {
                      itemIndex+=1;
                      return itemIndex <= kitchenData.length
                      ? Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(
                            right: subIndex == 0 ? AppSize.s5 : 0, 
                            left: subIndex == 1 ? AppSize.s5 : 0
                          ),
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                decoration: const BoxDecoration(
                                  color: AppColors.primaryColor,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(AppSize.s10),
                                    topRight: Radius.circular(AppSize.s10)
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomText(
                                      title: kitchenData[itemIndex-1].tableName,
                                      textStyle: getRegularStyle(color: AppColors.white),
                                    ),
                                    CustomText(
                                      title: kitchenData[itemIndex-1].createdDate.toString().substring(11,16),
                                      textStyle: getRegularStyle(color: AppColors.white),
                                    ),
                                    CustomText(
                                      title: kitchenData[itemIndex-1].customerName,
                                      textStyle: getRegularStyle(color: AppColors.white),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(AppSize.s10),
                                decoration: BoxDecoration(
                                  color: Helper.isDark 
                                  ? AppColors.headerColorDark
                                  : AppColors.white,
                                  boxShadow: const [BoxShadow(color: AppColors.grey, blurRadius: AppSize.s2)],
                                  borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(AppSize.s10),
                                    bottomRight: Radius.circular(AppSize.s10)
                                  ),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: CustomText(
                                            title: 'Tab: ${kitchenData[itemIndex-1].customerName}',
                                            maxLines: 1,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white
                                              : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: CustomText(
                                            title: "#${kitchenData[itemIndex-1].orderSequenceDetails.orderSequence.toString()}",
                                            maxLines: 1,
                                            textAlign: TextAlign.end,
                                            color: Helper.isDark 
                                            ? AppColors.white
                                            : AppColors.black
                                          ),
                                        ),
                                      ],
                                    ),
                                    Divider(
                                      color: Helper.isDark 
                                      ? AppColors.grey
                                      : AppColors.black, 
                                      height: AppSize.s8, 
                                      thickness: AppSize.s05
                                    ),
                                    ListView(
                                      shrinkWrap: true,
                                      physics: const NeverScrollableScrollPhysics(),
                                      children: List.generate(
                                        kitchenData[itemIndex-1].orderSequenceDetails.productDetails!.length, 
                                        (subIndex) {
                                          var subData = kitchenData[itemIndex-1].orderSequenceDetails.productDetails![subIndex];
                                          return Container(
                                            margin: const EdgeInsets.only(top: AppSize.s5),
                                            padding: const EdgeInsets.symmetric(
                                              vertical: AppSize.s10
                                            ),
                                            decoration: BoxDecoration(
                                              border: Border(
                                                bottom: BorderSide(
                                                  width: AppSize.s05,
                                                  color: Helper.isDark 
                                                  ? AppColors.grey
                                                  : AppColors.black
                                                ),
                                              ),
                                            ),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: CustomText(
                                                    title: '●  ${subData.productName!}',
                                                    color: Helper.isDark 
                                                    ? AppColors.white
                                                    : AppColors.black
                                                  ),
                                                ),
                                                CustomText(
                                                  title: 'x ${subData.quantity}',
                                                )
                                              ],
                                            ),
                                          );
                                        }
                                      ),
                                    ),
                                    const SizedBox(height: AppSize.s14),
                                    CustomSolidButton(
                                      onPressed: () => onTap(index*2 + subIndex),
                                      text: AppStrings.finish,
                                      textColor: AppColors.white,
                                      horPadding: AppSize.s15,
                                      borderRadius: AppSize.s6,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                      : const Expanded(child: SizedBox());
                    }
                  ),
                ),
              );
            }
          ),
        ),
      ]
    );
  }
}