import 'dart:developer';
import '../../../../routes/route.dart';
import '../../data/kitchen_display_repository.dart';
import '../../../../network/custom_exception.dart';
import '../../../../utils/check_connectivity.dart';
import '../../domain/kitchen_display_model.dart';
part 'kitchen_display_event.dart';
part 'kitchen_display_state.dart';

class KitchenDisplayBloc extends Bloc<KitchenDisplayEvent, KitchenDisplayState>{
  
  late CheckConnectivity _checkConnectivity;
  late KitchenDisplayRepository _repository;
  List<KitchenDisplayModel> kitchenDisplayData = [];
  List<KitchenDisplayModel> originalKitchenDisplayData = [];

  KitchenDisplayBloc() : super(KitchenDisplayInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = KitchenDisplayRepository();
    on<KitchenDisplayDataEvent>(_getKitchenData);
    on<FinishOrderEvent>(_onFinishKitchenOrder);
    on<OnSwitchUserKitchenEvent>(_onSwitchUser);
    on<KitchenDisplayMostRecentEvent>(_onFilterMostRecentOrders);
    on<CheckAllOrderKitchenEvent>(_onCheckAllKitchenOrder);
    on<OnSelectKitchenItemEvent>(_onSelectKitchenItem);
    on<OnSearchKitchenItemEvent>(_onSearchKitchenItem);
    on<KitchenDisplayHideDialogErrorEvent>(_onHideKitchenErrorMessage);
  }

  void _onHideKitchenErrorMessage(KitchenDisplayHideDialogErrorEvent event, Emitter emit) {
    emit(KitchenDisplayHideDialogErrorState());
  }

  void _onSearchKitchenItem(OnSearchKitchenItemEvent event, Emitter emit) {
    kitchenDisplayData.clear();
    if(event.text.isEmpty) {
      kitchenDisplayData.addAll(originalKitchenDisplayData);
    } else {
      var searchText = event.text.toLowerCase();
      for (var item in originalKitchenDisplayData) {
        if(item.customerName.toLowerCase().contains(searchText) || item.serverName.toLowerCase().contains(searchText) || item.tableName.contains(searchText)) {
          kitchenDisplayData.add(item);
        }
      }
    }
    emit(KitchenDisplaySuccessState(kitchenDisplayData: kitchenDisplayData));
  }

  void _onSelectKitchenItem(OnSelectKitchenItemEvent event, Emitter emit) {
    emit(OnSelectKitchenItemState(selectedKitchenItem: event.selectedKitchenItem));
  }

  void _onCheckAllKitchenOrder(CheckAllOrderKitchenEvent event, Emitter emit) {
    if(kitchenDisplayData.isNotEmpty) {
      var productList = kitchenDisplayData[event.parentIndex];
      if(event.itemIndex.isNegative) {
        for (var i = 0; i < productList.orderSequenceDetails.productDetails!.length; i++) {
          productList.orderSequenceDetails.productDetails![i].isProductPrepared = event.isCheckAll ? true : null;
        }
      } else {
        productList.orderSequenceDetails.productDetails![event.itemIndex].isProductPrepared = event.isPrepared;
      }
      emit(KitchenDisplaySuccess(message: AppStrings.success));
    }
  }

  Future<void> _getKitchenData(KitchenDisplayDataEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(KitchenDisplayLoadingState());
        var data = await _repository.kitchenDisplayData();
        kitchenDisplayData.clear();
        originalKitchenDisplayData.clear();
        if(data.isNotEmpty){
          for(var item in data){
            for(var subItem in item.orderDetailsByOrderSequences!) {
              var kitchenData = KitchenDisplayModel(
                orderNumber: item.orderNumber!,
                createdDate: item.createdOrderTime.toString(),
                customerName: item.customerName!,
                tableName: item.tableDetails!.fold("", (previousValue, element) => previousValue.isEmpty ? previousValue+element.tableName! : '$previousValue, ${element.tableName!}'),
                orderSequenceDetails: subItem,
                serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId!,
                serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName!
              );
              originalKitchenDisplayData.add(kitchenData);
            }
          }
          ///Sort Based on Recent Prepare Item
          originalKitchenDisplayData.sort((a,b) => a.createdDate.compareTo(b.createdDate));
          kitchenDisplayData.addAll(originalKitchenDisplayData);
        }
        emit(KitchenDisplaySuccessState(kitchenDisplayData: kitchenDisplayData));
      } catch (e) {
        emit(KitchenDisplayFailedState(message: AppStrings.someThingWentWrong)); 
      }
    } else { 
      emit(KitchenDisplayFailedState(message: AppStrings.noInternetConnection));
    }
  }

  Future<void> _onFinishKitchenOrder(FinishOrderEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      if(kitchenDisplayData.isNotEmpty) {
        if(kitchenDisplayData[event.parentIndex].orderSequenceDetails.productDetails!.every((element) => element.isProductPrepared != null)) {
          try {
            emit(KitchenDisplayLoadingState());
            var kitchenItemPreparedId = List<Map<String, dynamic>>.generate(kitchenDisplayData[event.parentIndex].orderSequenceDetails.productDetails!.length, 
            (index) {
              var data = kitchenDisplayData[event.parentIndex].orderSequenceDetails.productDetails![index];
              return {
                "productId": data.orderedProductId!,
                "productStatus": data.isProductPrepared
              };
            });
            var statusMessage = await _repository.updateKitchenOrderStatus(productIds: kitchenItemPreparedId);
            log('Kitchen Order Status => $statusMessage');
            emit(KitchenDisplayHideDialogErrorState(isSuccess: true));
          } on CustomException catch (e) {
            emit(KitchenDisplayHideDialogErrorState(message: e.message));
          }
        } else {
          emit(KitchenDisplayHideDialogErrorState(message: 'Please update status of all item before finish from kitchen'));
        }
      }
    } else {
      emit(KitchenDisplayHideDialogErrorState(message: AppStrings.noInternetConnection));
    }
  }

  Future<void> _onSwitchUser(OnSwitchUserKitchenEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(KitchenDisplayLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserKitchenState(isLogout: response));
      } on CustomException catch (e) {
        emit(KitchenDisplayFailedState(message: e.message));
      }
    }
  }

  void _onFilterMostRecentOrders(KitchenDisplayMostRecentEvent event, Emitter emit){
    if(kitchenDisplayData.isNotEmpty) {
      if(event.isMostRecent){
        kitchenDisplayData.sort((a,b) => b.createdDate.compareTo(a.createdDate));
      } else {
        kitchenDisplayData.sort((a,b) => a.createdDate.compareTo(b.createdDate));
      }
      log('Kitchen Display ::: Filter Most Recent Kitchen Order');
      emit(KitchenDisplaySuccessState(kitchenDisplayData: kitchenDisplayData, isMostRecent: event.isMostRecent));
    }
  }

}