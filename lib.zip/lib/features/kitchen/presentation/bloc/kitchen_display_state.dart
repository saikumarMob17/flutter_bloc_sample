part of 'kitchen_display_bloc.dart';

sealed class KitchenDisplayState {}

class KitchenDisplayInitialState extends KitchenDisplayState {}

class KitchenDisplaySuccessState extends KitchenDisplayState {
  List<KitchenDisplayModel> kitchenDisplayData;
  bool isMostRecent;

  KitchenDisplaySuccessState({required this.kitchenDisplayData, this.isMostRecent = false});
}

class KitchenDisplayLoadingState extends KitchenDisplayState {}

class KitchenDisplayFailedState extends KitchenDisplayState {
  String message;
  KitchenDisplayFailedState({this.message = ''});
}

class KitchenDisplaySuccess extends KitchenDisplayState {
  String message;

  KitchenDisplaySuccess ({this.message = ''});
}

class OnSwitchUserKitchenState extends KitchenDisplayState {
  bool isLogout;
  OnSwitchUserKitchenState({this.isLogout = false});
}

class OnSelectKitchenItemState extends KitchenDisplayState {
  int selectedKitchenItem;

  OnSelectKitchenItemState({this.selectedKitchenItem = -1});
}

class KitchenDisplayHideDialogErrorState extends KitchenDisplayState {
  String message;
  bool isSuccess;

  KitchenDisplayHideDialogErrorState({this.message = '', this.isSuccess = false});
}