part of 'kitchen_display_bloc.dart';

sealed class KitchenDisplayEvent {}

class KitchenDisplayDataEvent extends KitchenDisplayEvent {}

class FinishOrderEvent extends KitchenDisplayEvent {
  int parentIndex;
  FinishOrderEvent({required this.parentIndex});
}

class KitchenDisplayMostRecentEvent extends KitchenDisplayEvent {
  bool isMostRecent;

  KitchenDisplayMostRecentEvent({this.isMostRecent = false});
}

class OnSwitchUserKitchenEvent extends KitchenDisplayEvent {}

class CheckAllOrderKitchenEvent extends KitchenDisplayEvent {
  int parentIndex;
  int itemIndex;
  // KitchenOrderItemStatus kitchenOrderItemStatus;
  bool isPrepared;
  bool isCheckAll;
  CheckAllOrderKitchenEvent({
    this.parentIndex = -1, 
    this.itemIndex = -1, 
    // this.kitchenOrderItemStatus = KitchenOrderItemStatus.process,
    this.isPrepared = false,
    this.isCheckAll = true
  });
}

class OnSelectKitchenItemEvent extends KitchenDisplayEvent {
  int selectedKitchenItem;

  OnSelectKitchenItemEvent({this.selectedKitchenItem = -1});
}

class OnSearchKitchenItemEvent extends KitchenDisplayEvent {
  String text;

  OnSearchKitchenItemEvent({this.text = ''});
}

class KitchenDisplayHideDialogErrorEvent extends KitchenDisplayEvent {}