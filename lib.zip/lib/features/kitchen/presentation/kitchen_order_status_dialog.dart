import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_size.dart';
import 'bloc/kitchen_display_bloc.dart';
import '../../../utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../domain/kitchen_display_model.dart';

class KitchenOrderStatusDialog extends StatelessWidget {

  final KitchenDisplayBloc kitchenDisplayBloc;
  final KitchenDisplayModel kitchenDisplayData;
  final int parentIndex;
  final Function()? onPrintReceipt;

  const KitchenOrderStatusDialog({
    super.key, 
    required this.kitchenDisplayBloc,
    required this.kitchenDisplayData,
    required this.parentIndex,
    this.onPrintReceipt
  });
  
  @override
  Widget build(BuildContext context) {
    int selectedKitchenItem = -1;
    bool isCheckAll = true;
    String errorMessage = '';
    if(kitchenDisplayData.orderSequenceDetails.productDetails!.every((element) => element.isProductPrepared == null || !element.isProductPrepared!)){
      isCheckAll = true;
    } else {
      isCheckAll = false;
    }
    return AlertDialog(
      insetPadding: EdgeInsets.zero,
      contentPadding: EdgeInsets.zero,
      content: Container(
        height: context.screenHeight * 0.60,
        width: context.screenWidth * 0.40,
        decoration: BoxDecoration(
          color: Helper.isDark 
          ?AppColors.contentColorDark
          : AppColors.white,
          borderRadius: BorderRadius.circular(AppSize.s10)
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: AppSize.s18,
          vertical: AppSize.s6
        ),
        child: BlocProvider<KitchenDisplayBloc>.value(
          value: kitchenDisplayBloc,
          child: BlocConsumer<KitchenDisplayBloc, KitchenDisplayState>(
            builder: (_, state) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: 'Tab : ${kitchenDisplayData.customerName}',
                        textStyle: getMediumStyle(
                          fontSize: 18
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(5,0),
                        child: IconButton(
                          onPressed: () => context.pop(false), 
                          icon: const Icon(Icons.close)
                        ),
                      ),
                    ],
                  ),
                  CustomText(
                    title: 'Server : ${kitchenDisplayData.serverName}',
                    textStyle: getMediumStyle(),
                  ),
                  CustomText(
                    title: '${kitchenDisplayData.tableName} | #${kitchenDisplayData.orderSequenceDetails.orderSequence}',
                    textStyle: getMediumStyle(),
                  ),
                  const SizedBox(height: AppSize.s10),
                  const Divider(),
                  Expanded(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: kitchenDisplayData.orderSequenceDetails.productDetails!.length,
                      itemBuilder: (_, index) {
                        var data = kitchenDisplayData.orderSequenceDetails.productDetails![index];
                        return Material(
                          color: Helper.isDark 
                          ?AppColors.contentColorDark
                          :AppColors.white,
                          child: InkWell(
                            onTap: () => kitchenDisplayBloc.add(OnSelectKitchenItemEvent(selectedKitchenItem: index)),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(AppSize.s12),
                                  child: Icon(
                                    data.isProductPrepared == null
                                    ? Icons.abc
                                    : data.isProductPrepared!
                                    ? Icons.check_circle
                                    : Icons.cancel,
                                    color: data.isProductPrepared == null
                                    ? AppColors.transparent 
                                    : data.isProductPrepared!
                                     ? AppColors.green
                                     : AppColors.red,
                                    size: AppSize.s22,
                                  ),
                                ),
                                const SizedBox(width: AppSize.s5),
                                SizedBox(
                                  width: AppSize.s35,
                                  child: CustomText(
                                    title: '${data.quantity!}',
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s16,
                                      color: Helper.isDark 
                                      ? AppColors.white
                                      : AppColors.black
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: data.productName!,
                                    maxLines: 1,
                                    textOverflow: TextOverflow.ellipsis,
                                    fontSize: AppSize.s16,
                                    color: Helper.isDark 
                                    ? AppColors.white
                                    : AppColors.black
                                  ),
                                ),
                                Visibility(
                                  visible: selectedKitchenItem == index,
                                  child: Row(
                                    children: [
                                      InkWell(
                                        customBorder: const StadiumBorder(),
                                        onTap: () => kitchenDisplayBloc.add(CheckAllOrderKitchenEvent(
                                          itemIndex: index, 
                                          parentIndex: parentIndex,
                                          isPrepared: true
                                        )),
                                        child: Container(
                                          padding: const EdgeInsets.all(5.0),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: AppColors.green.withOpacity(0.1)
                                          ),
                                          child: const Icon(Icons.check, color: AppColors.green),
                                        ),
                                      ),
                                      const SizedBox(width: AppSize.s10),
                                      InkWell(
                                        customBorder: const StadiumBorder(),
                                        onTap: () => kitchenDisplayBloc.add(CheckAllOrderKitchenEvent(
                                          parentIndex: parentIndex, 
                                          itemIndex: index,
                                          isPrepared: false
                                        )),
                                        child: Container(
                                          padding: const EdgeInsets.all(AppSize.s5),
                                          margin: const EdgeInsets.only(right: 5),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: AppColors.red.withOpacity(0.1)
                                          ),
                                          child: const Icon(Icons.clear, color: AppColors.red),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Visibility(
                    visible: errorMessage.isNotEmpty,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: AppSize.s5),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8.0,
                        vertical: 8.0
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(5)
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.warning_rounded, 
                            color:AppColors.orange, 
                            size: AppSize.s22
                          ),
                          const SizedBox(width: AppSize.s8),
                          Expanded(
                            child: CustomText(
                              title: errorMessage,
                              color:AppColors.orange,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                       CustomOutlinedButton(
                        onPressed: onPrintReceipt,
                        text: AppStrings.print,
                        textColor: AppColors.blue,
                        widgetSpacing: 8,
                        preFixWidget: const Icon(Icons.print, color: AppColors.blue, size: AppSize.s20),
                      ),
                      const SizedBox(width: AppSize.s10),
                      CustomOutlinedButton(
                        onPressed: () => kitchenDisplayBloc.add(CheckAllOrderKitchenEvent(parentIndex: parentIndex, isCheckAll: isCheckAll)),
                        text: isCheckAll == false
                        ? 'UnCheck All'
                        : 'Check All',
                        textColor: AppColors.blue,
                      ),
                      const SizedBox(width: AppSize.s10),
                      CustomSolidButton(
                        onPressed: () => kitchenDisplayBloc.add(FinishOrderEvent(parentIndex: parentIndex)),
                        prefix: const Icon(Icons.check, color: AppColors.white),
                        verPadding: AppSize.s15,
                        text: AppStrings.done
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s8)
                ],
              );
            },
            listener: (_, state){
              switch (state) {
                case KitchenDisplaySuccess _:
                  selectedKitchenItem = -1;
                  if(kitchenDisplayData.orderSequenceDetails.productDetails!.every((element) => element.isProductPrepared == null || !element.isProductPrepared!)){
                    isCheckAll = true;
                  } else {
                    isCheckAll = false;
                  }
                  break;
                case OnSelectKitchenItemState _:
                  selectedKitchenItem = state.selectedKitchenItem;
                  break;
                case KitchenDisplayHideDialogErrorState _:
                  errorMessage = state.message;
                  if(!state.isSuccess && errorMessage.isNotEmpty) {
                    Future.delayed(const Duration(seconds: 2), () => kitchenDisplayBloc.add(KitchenDisplayHideDialogErrorEvent()));
                  }
                  if(state.isSuccess){
                    Future.delayed(const Duration(milliseconds: 800), () {
                      context.pop();
                      context.pop(true);
                    });
                  }
                default:
              }
            },
          ),
        ),
      ),
    );
  }
}