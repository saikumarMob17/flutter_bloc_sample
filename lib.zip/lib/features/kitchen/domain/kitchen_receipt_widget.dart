import '../../../constants/app_colors.dart';
import '../../../routes/route.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import 'kitchen_display_model.dart';

class KitchenReceiptWidget extends StatelessWidget {
  final  KitchenDisplayModel kitchenData;
  const KitchenReceiptWidget({super.key, required this.kitchenData});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: context.screenHeight * 0.70,
      width: context.screenWidth * 0.30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: AppColors.white
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                vertical: 18.0,
                horizontal: 18.0
              ),
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: kitchenData.customerName,
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      title: '*** BOTTLE PREP STATION ***',
                      textStyle: getRegularStyle(fontSize: AppSize.s14),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s15),
                Padding(
                  padding: const EdgeInsets.only(bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomText(
                      title: 'Server : ${kitchenData.serverName}',
                      textStyle: getMediumStyle(),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s10),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(title: 'Table : ${kitchenData.tableName}', textStyle: getMediumStyle()),
                    CustomText(title: 'Tab : ${kitchenData.customerName}', textStyle: getMediumStyle())
                  ],
                ),
                const SizedBox(height: AppSize.s6),
                Column(
                  children: List.generate(
                    kitchenData.orderSequenceDetails.productDetails!.length, 
                    (index) {
                      var productData =  kitchenData.orderSequenceDetails.productDetails![index];
                      return Padding(
                        padding: const EdgeInsets.only(top: AppSize.s10, left: AppSize.s8),
                        child: Row(
                          children: [
                            CustomText(
                              title: '${productData.quantity!}',
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s14,
                                color: Helper.isDark 
                                ? AppColors.white
                                : AppColors.black
                              ),
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomText(
                              title: productData.productName!,
                              fontSize: AppSize.s14,
                              color: Helper.isDark 
                              ? AppColors.white
                              : AppColors.black
                            )
                          ],
                        ),
                      );
                    }
                  )
                )
              ],
            )
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              vertical: 10.0,
              horizontal: 14.0
            ),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10.0),
                bottomRight: Radius.circular(10.0),
              ),
              color: AppColors.backgroundColor,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomOutlinedButton(
                  onPressed: () => context.pop(),
                  text: 'Cancel',
                  textColor: AppColors.red,
                  borderColor: AppColors.red,
                ),
                const SizedBox(width: AppSize.s10),
                CustomSolidButton(
                  onPressed: () => debugPrint('Click here to print receipt'),
                  text: ' Print ',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class DashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    double dashWidth = 9, dashSpace = 5, startX = 0;
    final paint = Paint()
      ..color = AppColors.black
      ..strokeWidth = 1;
    while (startX < size.width) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}