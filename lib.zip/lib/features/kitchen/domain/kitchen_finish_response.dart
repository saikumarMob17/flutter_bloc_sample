import 'dart:convert';

KitchenFinishResponse kitchenFinishResponseFromJson(String str) => KitchenFinishResponse.fromJson(jsonDecode(str));

class KitchenFinishResponse {
  int? statusCode;
  String? status;
  String? message;
  String? data;

  KitchenFinishResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data
  });

  factory KitchenFinishResponse.fromJson(Map<String, dynamic> json){
    return KitchenFinishResponse(
      statusCode: json['statusCode'],
      status: json['status'],
      message: json['message'],
      data: json['data'],
    );
  }
}