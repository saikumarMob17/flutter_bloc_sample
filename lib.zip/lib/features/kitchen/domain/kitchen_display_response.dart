// To parse this JSON data, do
//
//     final kitchenDisplayResponse = kitchenDisplayResponseFromJson(jsonString);

import 'dart:convert';

KitchenDisplayResponse kitchenDisplayResponseFromJson(String str) => KitchenDisplayResponse.fromJson(json.decode(str));

class KitchenDisplayResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<KitchenData>? data;

  KitchenDisplayResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory KitchenDisplayResponse.fromJson(Map<String, dynamic> json) => KitchenDisplayResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<KitchenData>.from(json["data"]!.map((x) => KitchenData.fromJson(x))),
  );
}

class KitchenData {
  final String? orderNumber;
  final DateTime? createdOrderTime;
  final String? customerName;
  final List<TableDetail>? tableDetails;
  final List<OrderDetailsByOrderSequence>? orderDetailsByOrderSequences;
  final EmployeeDetails? employeeDetails;

  KitchenData({
    this.orderNumber,
    this.createdOrderTime,
    this.customerName,
    this.tableDetails,
    this.orderDetailsByOrderSequences,
    this.employeeDetails,
  });

  factory KitchenData.fromJson(Map<String, dynamic> json) => KitchenData(
    orderNumber: json["orderNumber"],
    createdOrderTime: json["createdOrderTime"] == null ? null : DateTime.parse(json["createdOrderTime"]),
    customerName: json["customerName"],
    tableDetails: json["tableDetails"] == null ? [] : List<TableDetail>.from(json["tableDetails"]!.map((x) => TableDetail.fromJson(x))),
    orderDetailsByOrderSequences: json["orderDetailsByOrderSequences"] == null ? [] : List<OrderDetailsByOrderSequence>.from(json["orderDetailsByOrderSequences"]!.map((x) => OrderDetailsByOrderSequence.fromJson(x))),
    employeeDetails: json["employeeDetails"] == null ? null : EmployeeDetails.fromJson(json["employeeDetails"]),
  );
}

class EmployeeDetails {
  final String? employeeId;
  final String? employeeName;
  final String? location;
  final String? role;
  final String? lastClockedIn;

  EmployeeDetails({
    this.employeeId,
    this.employeeName,
    this.location,
    this.role,
    this.lastClockedIn,
  });

  factory EmployeeDetails.fromJson(Map<String, dynamic> json) => EmployeeDetails(
    employeeId: json["employeeId"],
    employeeName: json["employeeName"],
    location: json["location"],
    role: json["role"],
    lastClockedIn: json["lastClockedIn"],
  );
}

class OrderDetailsByOrderSequence {
  final int? orderSequence;
  final bool? isFinished;
  final List<ProductDetail>? productDetails;
  final dynamic canceledProducts;
  final dynamic newlyaddedProducts;
  final dynamic billingDetails;

  OrderDetailsByOrderSequence({
    this.orderSequence,
    this.isFinished,
    this.productDetails,
    this.canceledProducts,
    this.newlyaddedProducts,
    this.billingDetails,
  });

  factory OrderDetailsByOrderSequence.fromJson(Map<String, dynamic> json) => OrderDetailsByOrderSequence(
    orderSequence: json["orderSequence"],
    isFinished: json["isFinished"],
    productDetails: json["productDetails"] == null ? [] : List<ProductDetail>.from(json["productDetails"]!.map((x) => ProductDetail.fromJson(x))),
    canceledProducts: json["canceledProducts"],
    newlyaddedProducts: json["newlyaddedProducts"],
    billingDetails: json["billingDetails"],
  );
}

class ProductDetail {
  final String? orderedProductId;
  final int? productId;
  final String? productName;
  final int? quantity;
  final double? productPrice;
  bool? isProductPrepared;

  ProductDetail({
    this.orderedProductId,
    this.productId,
    this.productName,
    this.quantity,
    this.productPrice,
    this.isProductPrepared,
  });

  factory ProductDetail.fromJson(Map<String, dynamic> json) => ProductDetail(
    orderedProductId: json["orderedProductId"] ?? '',
    productId: json["productId"],
    productName: json["productName"],
    quantity: json["quantity"],
    productPrice: json["productPrice"].toDouble(),
    isProductPrepared: json["isProductPrepared"],
  );
}

class TableDetail {
    final String? tableName;
    final int? tableId;

    TableDetail({
        this.tableName,
        this.tableId,
    });

    factory TableDetail.fromJson(Map<String, dynamic> json) => TableDetail(
        tableName: json["tableName"],
        tableId: json["tableId"],
    );
}

