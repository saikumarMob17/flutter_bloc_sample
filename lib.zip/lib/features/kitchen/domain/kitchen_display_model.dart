import 'package:cliqtechnologies_retl/features/kitchen/domain/kitchen_display_response.dart';

class KitchenDisplayModel {
  String orderNumber;
  String createdDate;
  String customerName;
  String tableName;
  String serverId;
  String serverName;
  OrderDetailsByOrderSequence orderSequenceDetails;

  KitchenDisplayModel({
    this.orderNumber = '',
    this.createdDate = '',
    this.customerName = '',
    this.tableName = '',
    this.serverId = '',
    this.serverName = '',
    required this.orderSequenceDetails
  });

}