import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_icon_button.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../constants/app_icons.dart';
import 'bloc/printer_bloc.dart';
import 'bloc/printer_state.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/left_navigation_screen.dart';

class PrinterSetupScreen extends StatefulWidget {

  const PrinterSetupScreen({super.key});

  @override
  State createState() => _PrinterSetupScreenState();
}

class _PrinterSetupScreenState extends State<PrinterSetupScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<PrinterBloc, PrinterState>(
        builder: (context, state) {
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) { },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.printerSetup,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuDeep,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.menuVertical,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to more options'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          Expanded(
            child: Column(
              // shrinkWrap: true,
              children: [
                CustomText(
                  title: AppStrings.printerSetup, 
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s18, 
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ), 
                  textAlign: TextAlign.center
                ),
                const SizedBox(height: AppSize.s10),
                const CustomText(
                  title: AppStrings.selectPrinterMsg,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSize.s15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomSolidButton(
                      onPressed: () => debugPrint(''),
                      horPadding: AppSize.s14,
                      verPadding: AppSize.s14,
                      centerAlignment: true,
                      text: '+ ${AppStrings.addOrReplace}',
                    ),
                    const SizedBox(width: AppSize.s10),
                    CustomSolidButton(
                      onPressed: () => debugPrint(''),
                      horPadding: AppSize.s14,
                      verPadding: AppSize.s14,
                      centerAlignment: true,
                      text: AppStrings.checkStatus,
                      prefix: const Icon(
                        AppIcons.loopIcon, 
                        color: AppColors.white, 
                        size: AppSize.s18
                      ),
                    ),
                  ]
                ),
                const SizedBox(height: AppSize.s30),
                Row(
                  children: [
                    CustomText(
                      title: AppStrings.troubleshoot, 
                      textStyle: getMediumStyle(
                        fontSize: AppSize.s18,
                        color: Helper.isDark 
                        ? AppColors.white 
                        : AppColors.black
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s5),
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: 15,
                    itemBuilder: (_, index){
                      return Container(
                        padding: const EdgeInsets.all(AppSize.s10),
                        margin: const EdgeInsets.only(bottom: AppSize.s10),
                        decoration: BoxDecoration(
                          color: Helper.isDark 
                          ? AppColors.contentColorDark 
                          : AppColors.white,
                          borderRadius: BorderRadius.circular(AppSize.s10),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.print_rounded, 
                              color: Helper.isDark 
                              ? AppColors.white 
                              : AppColors.black,
                              size: AppSize.s28
                            ),
                            const SizedBox(width: AppSize.s10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    title: 'RP Bar POS 3',
                                    textStyle: getMediumStyle(
                                      color: Helper.isDark ? AppColors.white : AppColors.black
                                    ),
                                  ),
                                  const SizedBox(height: AppSize.s5),
                                  const CustomText(
                                    title: 'Cliq TP200/TP200W',
                                    color: AppColors.grey
                                  ),
                                  const SizedBox(height: AppSize.s5,),
                                  CustomText(
                                    title: '${index+1} Cash Drawer',
                                    color: AppColors.grey
                                  ),
                                ],
                              ),
                            ),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  CustomText(
                                    title: 'Connected',
                                    color: AppColors.grey,
                                  ),
                                  SizedBox(height: AppSize.s5),
                                  CustomText(
                                    title: 'Serial #5256412',
                                    color: AppColors.grey
                                  ),
                                  SizedBox(height: AppSize.s5),
                                  CustomText(
                                    title: 'IP Address 192.164.256.157',
                                    color: AppColors.grey
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(AppSize.s20),
                color: Helper.isDark
                ? AppColors.black
                : AppColors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => context.pop(),
                          icon: const Icon(Icons.west)
                        ),
                        CustomText(
                          title: AppStrings.printerSetup,
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s22, 
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        CustomSolidButton(
                          onPressed: () => debugPrint(''),
                          horPadding: AppSize.s14,
                          verPadding: AppSize.s10,
                          text: AppStrings.switchUser,
                          prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                        ),
                        const SizedBox(width: AppSize.s10),
                        CustomIconButton(
                          onPressed: () => debugPrint(''),
                          horPadding: AppSize.s10,
                          verPadding: AppSize.s10,
                          widget: const CustomImageView(
                            imagePath: AppImages.menuHorizontalColor, 
                            blendMode: BlendMode.dstIn
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(AppSize.s20),
                  child: Column(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CustomText(
                            title: AppStrings.printerSetup, 
                            textStyle: getMediumStyle(
                              fontSize: AppSize.s24, 
                              color: Helper.isDark 
                              ? AppColors.white 
                              : AppColors.black
                            ), 
                            textAlign: TextAlign.center
                          ),
                          const SizedBox(height: AppSize.s10),
                          const CustomText(
                            title: AppStrings.selectPrinterMsg,
                            textAlign: TextAlign.center,
                            fontSize: AppSize.s16,
                          ),
                          const SizedBox(height: AppSize.s15),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomSolidButton(
                                onPressed: () => debugPrint(''),
                                horPadding: AppSize.s14,
                                verPadding: AppSize.s14,
                                centerAlignment: true,
                                text: '+ ${AppStrings.addOrReplace}',
                              ),
                              const SizedBox(width: AppSize.s10),
                              CustomSolidButton(
                                onPressed: () => debugPrint(''),
                                horPadding: AppSize.s14,
                                verPadding: AppSize.s14,
                                centerAlignment: true,
                                text: AppStrings.checkStatus,
                                prefix: const Icon(
                                  AppIcons.loopIcon, 
                                  color: AppColors.white, 
                                  size: AppSize.s18
                                ),
                              ),
                            ]
                          ),
                          const SizedBox(height: AppSize.s30),
                          Row(
                            children: [
                              CustomText(
                                title: AppStrings.troubleshoot, 
                                textStyle: getMediumStyle(
                                  fontSize: AppSize.s18,
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSize.s10)
                        ],
                      ),
                      Expanded(
                        child: GridView.builder(
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 25.0,
                            crossAxisSpacing: 15.0,
                            childAspectRatio: 7.0
                          ),
                          shrinkWrap: true,
                          itemCount: 17,
                          itemBuilder: (_, index) => Container(
                            padding: const EdgeInsets.all(AppSize.s15),
                            decoration: BoxDecoration(
                              color: Helper.isDark ? AppColors.contentColorDark : AppColors.white,
                              borderRadius: BorderRadius.circular(AppSize.s10)
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.print_rounded, 
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black,
                                  size: AppSize.s50
                                ),
                                const SizedBox(width: AppSize.s10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomText(
                                        title: 'RP Bar POS ${index+1}',
                                        textStyle: getMediumStyle(
                                          color: Helper.isDark ? AppColors.white : AppColors.black
                                        ),
                                      ),
                                      const SizedBox(height: AppSize.s5),
                                      const CustomText(
                                        title: 'Cliq TP200/TP200W',
                                        color: AppColors.grey
                                      ),
                                      const SizedBox(height: AppSize.s5,),
                                      CustomText(
                                        title: '${index+1} Cash Drawer',
                                        color: AppColors.grey
                                      ),
                                    ],
                                  ),
                                ),
                                const Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomText(
                                        title: 'Connected',
                                        color: AppColors.grey,
                                      ),
                                      SizedBox(height: AppSize.s5),
                                      CustomText(
                                        title: 'Serial #5256412',
                                        color: AppColors.grey
                                      ),
                                      SizedBox(height: AppSize.s5),
                                      CustomText(
                                        title: 'IP Address 192.164.256.157',
                                        color: AppColors.grey
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}