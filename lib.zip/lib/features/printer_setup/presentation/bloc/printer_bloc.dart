import 'package:cliqtechnologies_retl/features/printer_setup/presentation/bloc/printer_event.dart';
import 'package:cliqtechnologies_retl/features/printer_setup/presentation/bloc/printer_state.dart';
import 'package:cliqtechnologies_retl/routes/route.dart';

class PrinterBloc extends Bloc<PrinterEvent, PrinterState>{

  PrinterBloc() : super(PrinterInitialState());
}