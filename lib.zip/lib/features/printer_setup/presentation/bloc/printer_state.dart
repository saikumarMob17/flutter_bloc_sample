sealed class PrinterState {}

class PrinterInitialState extends PrinterState {}