import 'dart:convert';
import 'dart:io';
import '../../../constants/app_strings.dart';
import '../domain/check_search_response.dart';
import '../../../network/api/api_client.dart';
import '../../../network/custom_exception.dart';
import '../../../utils/helper.dart';

class CheckSearchRepository {

  late ApiClient _apiClient;

  CheckSearchRepository(){
    _apiClient = ApiClient();
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<CheckSearchResult>> onCheckSearch({required String endPoint}) async {
    try {
      var response = await _apiClient.getRequest(endPoint: endPoint);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = checkSearchResponseFromJson(response.body);
            return data.data ?? [];
          } else {
            throw CustomException(message: jsonDecode(response.body)['message']);
          }
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}