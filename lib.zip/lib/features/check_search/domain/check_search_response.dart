// To parse this JSON data, do
//
//     final checkSearchResponse = checkSearchResponseFromJson(jsonString);

import 'dart:convert';

CheckSearchResponse checkSearchResponseFromJson(String str) => CheckSearchResponse.fromJson(json.decode(str));

class CheckSearchResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<CheckSearchResult>? data;

  CheckSearchResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory CheckSearchResponse.fromJson(Map<String, dynamic> json) => CheckSearchResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<CheckSearchResult>.from(json["data"]!.map((x) => CheckSearchResult.fromJson(x))),
  );
}

class CheckSearchResult {
  final String? orderNumber;
  final String? orderId;
  final int? totalGuest;
  final int? checkCount;
  final String? tableName;
  final TotalBilling? totalBilling;
  final List<CheckTerminalDetail>? checkTerminalDetails;

  CheckSearchResult({
    this.orderNumber,
    this.orderId,
    this.totalGuest,
    this.checkCount,
    this.tableName,
    this.totalBilling,
    this.checkTerminalDetails,
  });

  factory CheckSearchResult.fromJson(Map<String, dynamic> json) => CheckSearchResult(
    orderNumber: json["orderNumber"],
    orderId: json["orderId"],
    totalGuest: json["totalGuest"],
    checkCount: json["checkCount"],
    tableName: json["tableName"],
    totalBilling: json["totalBilling"] == null ? null : TotalBilling.fromJson(json["totalBilling"]),
    checkTerminalDetails: json["checkTerminalDetails"] == null ? [] : List<CheckTerminalDetail>.from(json["checkTerminalDetails"]!.map((x) => CheckTerminalDetail.fromJson(x))),
  );
}

class CheckTerminalDetail {
  final String? checkId;
  final String? billId;
  final DateTime? timeOpened;
  final String? customerName;
  final double? subTotal;
  final double? discount;
  final double? tax;
  final double? tip;
  final double? grandTotal;
  final double? balanceDue;
  final bool? paymentStatus;
  final List<PaymentMode>? paymentMode;

  CheckTerminalDetail({
    this.checkId,
    this.billId,
    this.timeOpened,
    this.customerName,
    this.subTotal,
    this.discount,
    this.tax,
    this.tip,
    this.grandTotal,
    this.balanceDue,
    this.paymentStatus,
    this.paymentMode,
  });

  factory CheckTerminalDetail.fromJson(Map<String, dynamic> json) => CheckTerminalDetail(
    checkId: json["checkId"],
    billId: json["billId"],
    timeOpened: json["timeOpened"] == null ? null : DateTime.parse(json["timeOpened"]),
    customerName: json["customerName"],
    subTotal: json["subTotal"]?.toDouble(),
    discount: json["discount"]?.toDouble(),
    tax: json["tax"]?.toDouble(),
    tip: json["tip"]?.toDouble(),
    grandTotal: json["grandTotal"]?.toDouble(),
    balanceDue: json["balanceDue"]?.toDouble(),
    paymentStatus: json["paymentStatus"],
    paymentMode: json["paymentMode"] == null ? [] : List<PaymentMode>.from(json["paymentMode"]!.map((x) => PaymentMode.fromJson(x))),
  );
}

class PaymentMode {
  final String? paymentMode;
  final double? ammountPaid;
  final double? tip;
  final String? cardType;
  final String? cardNumber;

  PaymentMode({
    this.paymentMode,
    this.ammountPaid,
    this.tip,
    this.cardType,
    this.cardNumber
  });

  factory PaymentMode.fromJson(Map<String, dynamic> json) => PaymentMode(
    paymentMode: json["paymentMode"],
    ammountPaid: json["ammountPaid"]?.toDouble(),
    tip: json["tip"]?.toDouble(),
    cardType: json['cardType'],
    cardNumber: json['cardNumber']
  );
}

class TotalBilling {
  final double? subTotal;
  final double? discount;
  final double? tax;
  final double? tip;
  final double? grandTotal;
  final bool? paymentStatus;
  final double? balanceDue;

  TotalBilling({
    this.subTotal,
    this.discount,
    this.tax,
    this.tip,
    this.grandTotal,
    this.paymentStatus,
    this.balanceDue,
  });

  factory TotalBilling.fromJson(Map<String, dynamic> json) => TotalBilling(
    subTotal: json["subTotal"]?.toDouble(),
    discount: json["discount"]?.toDouble(),
    tax: json["tax"]?.toDouble(),
    tip: json["tip"]?.toDouble(),
    grandTotal: json["grandTotal"]?.toDouble(),
    paymentStatus: json["paymentStatus"],
    balanceDue: json["balanceDue"]?.toDouble(),
  );
}
