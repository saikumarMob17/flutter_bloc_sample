import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../domain/check_search_response.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../constants/app_icons.dart';
import '../../../widgets/custom_text.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';

class CheckSearchWidget extends StatelessWidget {

  final Function(CheckSearchResult)? onViewDetails;
  final List<CheckSearchResult> checkSearchModel;

  const CheckSearchWidget({
    super.key, 
    required this.checkSearchModel,
    this.onViewDetails,
  });

  @override
  Widget build(BuildContext context) {
    final screenType = context.screenWidth.screenType;
    return Container(
      width: screenType == ScreenType.mobile 
      ? context.screenWidth
      : context.screenWidth * 0.80,
      height: screenType == ScreenType.mobile
      ? context.screenHeight * 0.94
      : context.screenHeight * 0.80,
      padding: const EdgeInsets.symmetric(
        vertical: AppSize.s16,
        horizontal: AppSize.s16
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppSize.s12),
        color: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: 'Check Search Result',
                textStyle: getMediumStyle(
                  fontSize: AppSize.s18, 
                  color: Helper.isDark 
                  ? AppColors.white 
                  : AppColors.black
                ),
              ),
              IconButton(
                onPressed: () => context.pop(), 
                icon: const Icon(AppIcons.closeIcon),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: List.generate(
                  getCheckList(checkSearchModel).length,
                  (index) {
                    var rowData = getCheckList(checkSearchModel)[index];
                    var balanceDue = rowData.totalBilling!.balanceDue!;
                    return Container(
                      margin: const EdgeInsets.only(bottom: AppSize.s10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(AppSize.s4),
                        border: Border.all(width: AppSize.s05, color: AppColors.grey)
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s10, 
                              vertical: AppSize.s10
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  title: "${rowData.orderNumber!} (${balanceDue <= 0.0 ? AppStrings.closed : AppStrings.open})",
                                  textStyle: getMediumStyle(
                                    fontWeight: FontWeight.w500, 
                                    fontSize: AppSize.s12,
                                    color: balanceDue <= 0.0 
                                    ? AppColors.green 
                                    : AppColors.red
                                  ),
                                ),
                                CustomText(
                                  title: rowData.checkTerminalDetails!.first.timeOpened!.toString().convertDateTimeClockOut,
                                  textStyle: getMediumStyle(
                                    fontWeight: FontWeight.w500, 
                                    fontSize: AppSize.s12,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                                CustomText(
                                  title: "Total Amount  :  \$${rowData.totalBilling!.grandTotal!.toStringAsFixed(2)}",
                                  textStyle: getMediumStyle(
                                    fontWeight: FontWeight.w500, 
                                    fontSize: AppSize.s12,
                                    color: Helper.isDark 
                                    ? AppColors.white 
                                    : AppColors.black
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s10, 
                              vertical: AppSize.s10
                            ),
                            color: AppColors.grey.withOpacity(0.4),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: CustomText(
                                    title: AppStrings.paymentType, 
                                    textStyle: getMediumStyle(
                                      fontWeight: FontWeight.w500, 
                                      fontSize: AppSize.s12
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: CustomText(
                                    title: AppStrings.paidAmount, 
                                    textStyle: getMediumStyle(
                                      fontWeight: FontWeight.w500, 
                                      fontSize: AppSize.s12
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: CustomText(
                                    title: AppStrings.paymentAmount, 
                                    textStyle: getMediumStyle(
                                      fontWeight: FontWeight.w500, 
                                      fontSize: AppSize.s12
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: CustomText(
                                    title: AppStrings.tip, 
                                    textStyle: getMediumStyle(
                                      fontWeight: FontWeight.w500, 
                                      fontSize: AppSize.s12
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: List.generate(
                              findPaymentModeList(rowData.checkTerminalDetails).length, 
                              (subIndex) {
                                var subData = findPaymentModeList(rowData.checkTerminalDetails)[subIndex];
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: AppSize.s10, 
                                    vertical: AppSize.s10
                                  ),
                                  decoration: const BoxDecoration(
                                    border: Border(bottom: BorderSide(color: AppColors.grey, width: AppSize.s05))
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        flex: 2,
                                        child: CustomText(title: subData.paymentMode ?? ''),
                                      ),
                                      //Info
                                      Expanded(
                                        flex: 2,
                                        child: CustomText(
                                          title: subData.cardType != null && subData.cardNumber != null
                                          ? "${subData.cardType} ${subData.cardNumber}"
                                          : "\$${(subData.ammountPaid! + subData.tip!).roundTwo}"
                                        ),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: CustomText(
                                          title: "\$${subData.ammountPaid!.roundTwo}"
                                        ),
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          title: "\$${subData.tip!.roundTwo}"
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppSize.s8, 
                              vertical: AppSize.s4
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                CustomOutlinedButton(
                                  onPressed: () => onViewDetails!(rowData),
                                  topPadding: AppSize.s4,
                                  bottomPadding: AppSize.s4,
                                  text: AppStrings.view
                                ),
                                Visibility(
                                  visible: balanceDue <= 0 ? false : true,
                                  child: Row(
                                    children: [
                                      const SizedBox(width: AppSize.s8),
                                      CustomSolidButton(
                                        onPressed: () {
                                          context.pop();
                                          context.pushReplacement(AppRoutes.paymentTerminalScreen);
                                        },
                                        verPadding: AppSize.s5,
                                        horPadding: AppSize.s20,
                                        text: AppStrings.pay
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<PaymentMode> findPaymentModeList(List<CheckTerminalDetail>? checkList) {
    if(checkList == null) {
      return [];
    } else {
      List<PaymentMode> paymentModeList = [];
      for(var item in checkList) {
        paymentModeList.addAll(item.paymentMode ?? []);
      }
      return paymentModeList;
    }
  }

  List<CheckSearchResult> getCheckList(List<CheckSearchResult> checks) {
    List<CheckSearchResult> result = [];
    if(checks.isNotEmpty) {
      for(var item in checks) {
        if(item.checkTerminalDetails == null || item.checkTerminalDetails!.isEmpty) {
          continue;
        } else {
          result.add(item);
        }
      }
    }
    return result;
  }

}