import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../domain/check_search_response.dart';
import 'check_search_details_widget.dart';
import 'check_search_widget.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import 'bloc/check_search_bloc.dart';
import '../../../routes/app_routes.dart';
import '../../../constants/app_colors.dart';
import '../../../utils/helper.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_text_field.dart';


class CheckSearchScreen extends StatefulWidget {

  const CheckSearchScreen({super.key});

  @override
  State createState() => _CheckSearchScreenState();
  
}

class _CheckSearchScreenState extends State<CheckSearchScreen> with Helper {

  bool isCheckNumberSelected = false;
  bool isIdSelected = false;
  bool isConsumerInfoSelected = false;
  bool isCreditCardSelected = false;
  bool isAdvanceSearchSelected = false;
  late TextEditingController dateTextController;
  late TextEditingController firstTextController;
  late TextEditingController secondTextController;
  var checkSearchList = <CheckSearchResult>[];
  late DateTime initialDate;

  var advanceCheckTagList = <String>[
    'Find by Order Number',
    'Find by Customer Name',
    'Find by Credit Card',
    'Advance Search',
  ];
  var tabLabel = <String>[
    'Order Number',
    'Customer Name',
    'Credit Card',
    'Advance Search',
  ];
  int selectedTagIndex = 0;
  String firstError = '';
  String secondError = '';
  late CheckSearchBloc _checkSearchBloc;

  @override
  void initState() {
    _checkSearchBloc = context.read<CheckSearchBloc>();
    initialDate = DateTime.now();
    dateTextController = TextEditingController();
    firstTextController = TextEditingController();
    secondTextController = TextEditingController();
    dateTextController.text = initialDate.toString().substring(0, 11).formatDateMMDDYYY;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<CheckSearchBloc, CheckSearchState>(
        builder: (context, state) {
          switch (state) {
            case CheckSearchOptionState _:
              switch (state.index) {
                case 0:
                  isCheckNumberSelected = state.isOpen;
                  break;
                case 1:
                  isIdSelected = state.isOpen;
                  break;
                case 2:
                  isConsumerInfoSelected = state.isOpen;
                  break;
                case 3:
                  isCreditCardSelected = state.isOpen;
                  break;
                case 4:
                  isAdvanceSearchSelected = state.isOpen;
                  break;
              }
              break;
            case OnSelectCheckTagState _:
              if(selectedTagIndex != state.selectedIndex){
                selectedTagIndex = state.selectedIndex;
                firstTextController.clear();
                secondTextController.clear();
                firstError = '';
                secondError = '';
                initialDate = DateTime.now();
                dateTextController.text = initialDate.toString().substring(0, 11).formatDateMMDDYYY;
              }
              break;
            case CheckSearchInvalidFieldState _:
              firstError = state.firstError;
              secondError = state.secondError;
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints){
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state) {
            case OnSearchCheckState _:
              hideLoadingDialog(context: context);
              checkSearchList.clear();
              checkSearchList.addAll(state.checkSearchList);
              if(checkSearchList.isNotEmpty){
                showCheckSearchDialog(checkSearchList: checkSearchList);
              } else {
                showSnackBar(context: context, title: "No check found", color: AppColors.blue);
              }
              break;
            case CheckSearchLoadingState _:
              showLoadingDialog(context: context);
              break;
            case CheckSearchFailedState _:
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.errorMsg);
              break;
            case OnSwitchUserCheckSearchState _:
              hideLoadingDialog(context: context);
              if(state.isLogout){
                AppRoutes.onClickLogout(context: context);
              }
              break;
            default:
          }
        },
      ),
    );
  }

  void showCheckSearchDialog({required List<CheckSearchResult> checkSearchList}){
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: CheckSearchWidget(
            checkSearchModel: checkSearchList,
            onViewDetails: (data) {
              context.pop();
              showCheckSearchDetails(checkSearchResult: data);
            },
          ),
        );
      }
    );
  }

  void showCheckSearchDetails({required CheckSearchResult checkSearchResult}) {
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s12)),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(
            horizontal: context.screenWidth < 600.0 
            ? AppSize.s14 
            : AppSize.s0
          ),
          content: CheckSearchDetailsWidget(checkSearchResult: checkSearchResult),
        );
      }
    );
  }

  Widget mobileView({required BuildContext bContext}){
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => context.pop(),
                    icon: const Icon(Icons.west)
                  ),
                  CustomText(
                    title: AppStrings.advancedCheckScreen,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18,
                      color: Helper.isDark
                      ? AppColors.white
                      : AppColors.black
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  const SizedBox(width: AppSize.s5),
                  CustomImageView(
                    imagePath: AppImages.switchIcon,
                    height: AppSize.s24,
                    width: AppSize.s24,
                    onTap: () => debugPrint('go to cart screen'),
                    color: Helper.isDark
                    ? AppColors.white
                    : AppColors.black
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          Expanded(
            child: ListView(
              shrinkWrap: true,
              children: [
                Wrap(
                  runSpacing: 12.0,
                  children: List.generate(
                    advanceCheckTagList.length, 
                    (index) {
                      return Padding(
                        padding: const EdgeInsets.only(right: AppSize.s10),
                        child: InkWell(
                          onTap: () => _checkSearchBloc.add(OnSelectCheckTagEvent(selectedIndex: index)),
                          borderRadius: BorderRadius.circular(AppSize.s25),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: AppSize.s8,
                              horizontal: AppSize.s12
                            ),
                            decoration: BoxDecoration(
                              color: selectedTagIndex == index 
                              ? AppColors.primaryColor
                              :AppColors.transparent,
                              border: Border.all(width: 0.5, color: AppColors.grey),
                              borderRadius: BorderRadius.circular(AppSize.s25)
                            ),
                            child: Row(
                              children: [
                                Visibility(
                                  visible: index == selectedTagIndex,
                                  child: const Row(
                                    children: [
                                      Icon(Icons.check, size: 18, color: AppColors.white),
                                      SizedBox(width: AppSize.s6),
                                    ],
                                  ),
                                ),
                                Text(
                                  advanceCheckTagList[index], 
                                  style: TextStyle(
                                    color: selectedTagIndex == index 
                                    ?AppColors.white
                                    : Helper.isDark ? AppColors.white : AppColors.black,
                                    fontWeight: FontWeight.w500
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }
                  )
                ),
                const SizedBox(height: AppSize.s30),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: context.screenWidth * 0.60,
                      child: CustomTextField(
                        verPadding: AppSize.s12,
                        horPadding: AppSize.s12,
                        hint: selectedTagIndex == advanceCheckTagList.length - 1
                        ? 'Enter Amount'
                        : tabLabel[selectedTagIndex],
                        label: selectedTagIndex == advanceCheckTagList.length - 1
                        ? 'Start Amount'
                        : tabLabel[selectedTagIndex],
                        textController: firstTextController,
                        errorText: firstError,
                        inputFormatter: selectedTagIndex == 3
                        ? [FilteringTextInputFormatter.digitsOnly]
                        : null,
                        onChange: (value) => _checkSearchBloc.add(OnChangeFirstFieldEvent(
                          value: value, 
                          otherMessage: secondError, 
                          tagIndex: selectedTagIndex
                        )),
                      ),
                    ),
                    const SizedBox(height: AppSize.s20),
                    Visibility(
                      visible: selectedTagIndex == advanceCheckTagList.length - 1,
                      child: Column(
                        children: [
                          SizedBox(
                            width: context.screenWidth * 0.60,
                            child: CustomTextField(
                              verPadding: AppSize.s12,
                              horPadding: AppSize.s12,
                              hint: 'Enter Amount',
                              label: 'End Amount',
                              textController: secondTextController,
                              inputFormatter: selectedTagIndex == 3
                              ? [FilteringTextInputFormatter.digitsOnly]
                              : null,
                              errorText: secondError,
                              onChange: (value) => _checkSearchBloc.add(OnChangeSecondFieldEvent(value: value, otherMessage: firstError)),
                            ),
                          ),
                          const SizedBox(height: AppSize.s20),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: context.screenWidth * 0.60,
                      child: CustomTextField(
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s12,
                        suffixImagePath: AppImages.dateIcon,
                        hint: 'Enter Date',
                        label: selectedTagIndex == advanceCheckTagList.length - 1
                        ? 'Start Date'
                        : 'Select Date',
                        readOnly: true,
                        onTap: () => showDatePickerDialog(context),
                        textController: dateTextController,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s20),
                Align(
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: 120,
                    child: CustomSolidButton(
                      onPressed: () => _checkSearchBloc.add(OnSearchCheckEvent(
                        firstField: firstTextController.text.trim(),
                        secondField: secondTextController.text.trim(),
                        date: dateTextController.text.trim(),
                        searchType: selectedTagIndex
                      )),
                      verPadding: AppSize.s18,
                      text: AppStrings.search
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}){
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSize.s20, 
                  vertical: AppSize.s20
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.advancedCheckScreen,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s20,
                                color: Helper.isDark 
                                ? AppColors.white 
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomSolidButton(
                              onPressed: () => _checkSearchBloc.add(OnSwitchUserCheckSearchEvent()),
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                              text: AppStrings.switchUser
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ////Order Hub View
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(AppSize.s25),
                  shrinkWrap: true,
                  children: [
                    const SizedBox(height: AppSize.s2),
                    Row(
                      children: List.generate(
                        advanceCheckTagList.length, 
                        (index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: AppSize.s10),
                            child: InkWell(
                              onTap: () => _checkSearchBloc.add(OnSelectCheckTagEvent(selectedIndex: index)),
                              borderRadius: BorderRadius.circular(AppSize.s25),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  vertical: AppSize.s8,
                                  horizontal: AppSize.s12
                                ),
                                decoration: BoxDecoration(
                                  color: selectedTagIndex == index 
                                  ? AppColors.primaryColor
                                  :AppColors.transparent,
                                  border: Border.all(width: 0.5, color: AppColors.grey),
                                  borderRadius: BorderRadius.circular(AppSize.s5)
                                ),
                                child: Row(
                                  children: [
                                    Visibility(
                                      visible: index == selectedTagIndex,
                                      child: const Row(
                                        children: [
                                          Icon(Icons.check, size: AppSize.s18, color: AppColors.white),
                                          SizedBox(width: AppSize.s6),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      advanceCheckTagList[index], 
                                      style: TextStyle(
                                        color: selectedTagIndex == index 
                                        ?AppColors.white
                                        : Helper.isDark ? AppColors.white : AppColors.black,
                                        fontWeight: FontWeight.w500
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }
                      )
                    ),
                    const SizedBox(height: AppSize.s20),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: context.screenWidth * 0.16,
                          child: CustomTextField(
                            verPadding: AppSize.s12,
                            horPadding: AppSize.s12,
                            hint: selectedTagIndex == advanceCheckTagList.length - 1
                            ? 'Enter Amount'
                            : tabLabel[selectedTagIndex],
                            label: selectedTagIndex == advanceCheckTagList.length - 1
                            ? 'Start Amount'
                            : tabLabel[selectedTagIndex],
                            textController: firstTextController,
                            errorText: firstError,
                            inputFormatter: selectedTagIndex == 3
                            ? [FilteringTextInputFormatter.digitsOnly]
                            : null,
                            onChange: (value) => _checkSearchBloc.add(OnChangeFirstFieldEvent(
                              value: value, 
                              otherMessage: secondError, 
                              tagIndex: selectedTagIndex
                            )),
                            prefixImagePath: AppImages.dollar,
                            prefixImageColor: AppColors.grey,
                            prefixImageSize: AppSize.s16,
                          ),
                        ),
                        const SizedBox(width: AppSize.s20),
                        Visibility(
                          visible: selectedTagIndex == advanceCheckTagList.length - 1,
                          child: Row(
                            children: [
                              SizedBox(
                                width: context.screenWidth * 0.16,
                                child: CustomTextField(
                                  verPadding: AppSize.s12,
                                  horPadding: AppSize.s12,
                                  hint: 'Enter Amount',
                                  label: 'End Amount',
                                  textController: secondTextController,
                                  inputFormatter: selectedTagIndex == 3
                                  ? [FilteringTextInputFormatter.digitsOnly]
                                  : null,
                                  errorText: secondError,
                                  onChange: (value) => _checkSearchBloc.add(OnChangeSecondFieldEvent(value: value, otherMessage: firstError)),
                                  prefixImagePath: AppImages.dollar,
                                  prefixImageColor: AppColors.grey,
                                  prefixImageSize: AppSize.s16,
                                ),
                              ),
                              const SizedBox(width: AppSize.s20),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: context.screenWidth * 0.16,
                          child: CustomTextField(
                            verPadding: AppSize.s10,
                            horPadding: AppSize.s12,
                            suffixImagePath: AppImages.dateIcon,
                            hint: 'Enter Date',
                            label: selectedTagIndex == advanceCheckTagList.length - 1
                            ? 'Date'
                            : 'Select Date',
                            readOnly: true,
                            onTap: () => showDatePickerDialog(context),
                            textController: dateTextController,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s20),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: 120,
                        child: CustomSolidButton(
                          onPressed: () => _checkSearchBloc.add(OnSearchCheckEvent(
                            firstField: firstTextController.text.trim(),
                            secondField: secondTextController.text.trim(),
                            date: dateTextController.text.trim().formatDateYYYYMMDD,
                            searchType: selectedTagIndex
                          )),
                          verPadding: AppSize.s18,
                          text: AppStrings.search
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> showDatePickerDialog(BuildContext context) async {
    var tempDate = await showDatePicker(
      context: context, 
      firstDate: DateTime.parse('2012-02-27'), 
      lastDate: DateTime.now(),
      initialDate: initialDate
    );
    if(tempDate != null) {
      initialDate = tempDate;
      dateTextController.text = tempDate.toString().substring(0, 11).formatDateMMDDYYY;
    }
  }
  
}