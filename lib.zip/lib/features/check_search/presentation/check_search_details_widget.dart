import '../../../constants/app_icons.dart';
import '../domain/check_search_response.dart';
import '../../../routes/route.dart';
import '../../../utils/app_extension_method.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_text.dart';

class CheckSearchDetailsWidget extends StatelessWidget {

  final CheckSearchResult checkSearchResult;

  const CheckSearchDetailsWidget({
    super.key, 
    required this.checkSearchResult
  });

  @override
  Widget build(BuildContext context) {
    final screenType = context.screenWidth.screenType;
    return Container(
      width: screenType == ScreenType.mobile 
      ? context.screenWidth
      : context.screenWidth * 0.80,
      height: screenType == ScreenType.mobile
      ? context.screenHeight * 0.94
      : context.screenHeight * 0.80,
      padding: const EdgeInsets.symmetric(
        vertical: AppSize.s16,
        horizontal: AppSize.s16
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppSize.s12),
        color: Helper.isDark 
        ? AppColors.contentColorDark 
        : AppColors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Transform.translate(
                    offset: const Offset(-10, 0),
                    child: IconButton(
                      onPressed: () => context.pop(), 
                      icon: const Icon(Icons.west),
                    ),
                  ),
                  CustomText(
                    title: AppStrings.orderDetails,
                    textStyle: getMediumStyle(
                      fontSize: AppSize.s18
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: () => context.pop(), 
                icon: const Icon(AppIcons.closeIcon),
              ),
            ],
          ),
          const SizedBox(height: AppSize.s15),
          CustomText(
            title: checkSearchResult.orderNumber!,
            textStyle: getMediumStyle(
              fontWeight: FontWeight.w500
              )
            ),
          const SizedBox(height: AppSize.s10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                title: '${AppStrings.guest} : ${checkSearchResult.totalGuest!}',
                textStyle: getMediumStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: AppSize.s12
                ),
              ),
              CustomText(
                title: 'Check Count : ${checkSearchResult.checkCount!}',
                textStyle: getMediumStyle(
                  fontWeight: FontWeight.w500, 
                  fontSize: AppSize.s12
                ),
              ),
              CustomText(
                title: '${AppStrings.table} : ${checkSearchResult.tableName!}',
                textStyle: getMediumStyle(
                  fontWeight: FontWeight.w500, 
                  fontSize: AppSize.s12
                ),
              ),
            ],
          ),
          CustomText(
            title: '${AppStrings.name} : ${checkSearchResult.checkTerminalDetails!.first.customerName!.captializedWord}',
            textStyle: getMediumStyle(
              fontWeight: FontWeight.w500, 
              fontSize: AppSize.s12
            ),
          ),
          const SizedBox(height: AppSize.s15),
          CustomText(title: AppStrings.checkDetails, textStyle: getRegularStyle(fontWeight: FontWeight.w500)),
          const SizedBox(height: AppSize.s8),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: List.generate(
                  checkSearchResult.checkTerminalDetails!.length, 
                  (index) {
                    var rowData = checkSearchResult.checkTerminalDetails![index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: AppSize.s10),
                      padding: const EdgeInsets.all(AppSize.s10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(AppSize.s4),
                        border: Border.all(
                          width: AppSize.s05, 
                          color: AppColors.grey
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            title: "${AppStrings.check} #${index+1} (${rowData.balanceDue! <= 0.0 ? AppStrings.closed : AppStrings.open})",
                            textStyle: getMediumStyle(
                              fontWeight: FontWeight.w500, 
                              fontSize: AppSize.s12,
                              color: rowData.balanceDue! <= 0.0 ? AppColors.green : AppColors.red
                            ),
                          ),
                          const SizedBox(height: AppSize.s10),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.time, 
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            textAlign: TextAlign.end,
                                            title: rowData.timeOpened!.toString().convertDateTimeClockOut,
                                            maxLines: 1,
                                          )
                                        )
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: 'Serving', 
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        const CustomText(title: 'Offline Ordering')
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.subTotal,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.subTotal!.roundTwo.toString()}')
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.discount,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.discount!.roundTwo.toString()}')
                                      ]
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: AppSize.s20),
                              Expanded(
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.tax,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.tax!.roundTwo.toString()}')
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.tip,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.tip!.roundTwo.toString()}')
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.grandTotal,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.grandTotal!.roundTwo.toString()}')
                                      ]
                                    ),
                                    const SizedBox(height: AppSize.s4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        CustomText(
                                          title: AppStrings.balanceDue,
                                          textStyle: getMediumStyle(
                                            fontWeight: FontWeight.w500, 
                                            fontSize: AppSize.s12
                                          ),
                                        ),
                                        CustomText(title: '\$${rowData.balanceDue!.roundTwo.toString()}')
                                      ]
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}