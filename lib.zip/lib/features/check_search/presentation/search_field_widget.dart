import 'package:flutter/material.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../widgets/custom_text.dart';
import '../../../utils/helper.dart';

class SearchFieldWidget extends StatelessWidget {

  final String title;
  final String? hintText;
  final TextEditingController textController;
  final bool isSelected;
  final Function()? onTap;

  const SearchFieldWidget({
    required this.isSelected,
    required this.title,
    required this.textController,
    this.hintText,
    this.onTap,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: double.maxFinite,
            padding: const EdgeInsets.symmetric(
              horizontal: AppSize.s14,
              vertical: AppSize.s10
            ),
            decoration: BoxDecoration(
              color: isSelected 
              ? AppColors.primaryColor
              : Helper.isDark 
                ? AppColors.contentColorDark 
                : AppColors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10.0),
                topRight: Radius.circular(10.0),
              ),
            ),
            child: CustomText(
              title: title,
              textStyle: getMediumStyle(
                color: isSelected 
                ? AppColors.white
                : Helper.isDark ? AppColors.white : AppColors.black
              ),
            ),
          ),
        ),
        Visibility(
          visible: isSelected,
          child: TextField(
            controller: textController,
            style: const TextStyle(color: AppColors.black, fontSize: 14.0),
            decoration: InputDecoration(
              isDense: true,
              hintText: hintText ?? title,
              hintStyle: const TextStyle(color: AppColors.grey, fontSize: 14.0),
              enabledBorder:  OutlineInputBorder(
                borderSide: BorderSide(
                  color: Helper.isDark 
                  ? AppColors.lightGrey 
                  : AppColors.black,
                  width: AppSize.s05
                ),
                borderRadius: BorderRadius.circular(AppSize.s0),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Helper.isDark 
                  ? AppColors.lightGrey 
                  : AppColors.black,
                  width: AppSize.s05
                ),
                borderRadius: BorderRadius.circular(AppSize.s0)
              ),
            ),
          ),
        ),
      ],
    );
  }
}