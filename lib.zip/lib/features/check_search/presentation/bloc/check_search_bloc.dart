import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/check_search_repository.dart';
import '../../../../network/end_points.dart';
import '../../../../utils/check_connectivity.dart';
import '../../../../constants/app_strings.dart';
import '../../../../network/custom_exception.dart';
import '../../domain/check_search_response.dart';
part 'check_search_event.dart';
part 'check_search_state.dart';

class CheckSearchBloc extends Bloc<CheckSearchEvent, CheckSearchState>{
  
  late CheckConnectivity _checkConnectivity;
  late CheckSearchRepository _repository;

  CheckSearchBloc() : super(CheckSearchInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = CheckSearchRepository();
    on<CheckSearchOptionEvent>(_onSearchOptionEvent);
    on<OnSwitchUserCheckSearchEvent>(_onLogoutUser);
    on<OnSearchCheckEvent>(_onSearchCheck);
    on<OnSelectCheckTagEvent>(_onSelectCheckTag);
    on<OnChangeFirstFieldEvent>(_onChangeFirstField);
    on<OnChangeSecondFieldEvent>(_onChangeSecondField);
  }

  void _onChangeFirstField(OnChangeFirstFieldEvent event, Emitter emit){
    if(event.tagIndex  > 2){
      var firstMessage = '';
      if(event.value.isEmpty){
        firstMessage = 'Start amount required';
      }
      emit(CheckSearchInvalidFieldState(
        firstError: firstMessage,
        secondError: event.otherMessage
      ));
    }
  }

  void _onChangeSecondField(OnChangeSecondFieldEvent event, Emitter emit){
    var secondMessage = '';
    if(event.value.isEmpty){
      secondMessage = 'End amount required';
    }
    emit(CheckSearchInvalidFieldState(
      firstError: event.otherMessage,
      secondError: secondMessage
    ));
  }

  void _onSearchOptionEvent(CheckSearchOptionEvent event, Emitter emit){
    emit(CheckSearchOptionState(index: event.index, isOpen: event.isOpen));
  }

  void _onSelectCheckTag(OnSelectCheckTagEvent event, Emitter emit) {
    emit(OnSelectCheckTagState(selectedIndex: event.selectedIndex));
  }

  Future<void> _onLogoutUser(OnSwitchUserCheckSearchEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(CheckSearchLoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserCheckSearchState(isLogout: response));
      } on CustomException catch (e) {
        emit(CheckSearchFailedState(errorMsg: e.message));
      }
    }
  }

  Future<void> _onSearchCheck(OnSearchCheckEvent event, Emitter emit) async {
    if(event.searchType == 3 && (event.firstField.isEmpty || event.secondField.isEmpty)) {
      emit(CheckSearchInvalidFieldState(
        firstError: event.firstField.isEmpty ? 'Start amount required' : '',
        secondError: event.secondField.isEmpty ? 'End amount required' : ''
      ));
      return;
    }
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(CheckSearchLoadingState());
        String endPoint = "";
        switch (event.searchType) {
          case 0:
            if(event.firstField.isEmpty) {
              endPoint = "${EndPoints.searchCheckByDate}?date=${event.date}";
            } else {
              endPoint = "${EndPoints.searchCheckByCheckNumber}?ordNum=${event.firstField}&date=${event.date}";
            }
            break;
          case 1:
            if(event.firstField.isEmpty) {
              endPoint = "${EndPoints.searchCheckByDate}?date=${event.date}";
            } else {
              endPoint = "${EndPoints.searchCheckByCustomerName}?customerName=${event.firstField}&date=${event.date}";
            }
            break;
          case 2:
            if(event.firstField.isEmpty) {
              endPoint = "${EndPoints.searchCheckByDate}?date=${event.date}";
            } else {
              endPoint = "${EndPoints.searchCheckByCardNumber}?cardNum=${event.firstField}&date=${event.date}";
            }
            break;
          case 3:
            endPoint = "${EndPoints.advanceCheckSearch}?stratAmount=${event.firstField}&endAmount=${event.secondField}&date=${event.date}";
            break;
          default:
        }
        var checkSearchData = await _repository.onCheckSearch(endPoint: endPoint);
        emit(OnSearchCheckState(checkSearchList: checkSearchData));
      } on CustomException catch (e) {
        emit(CheckSearchFailedState(errorMsg: e.message));
      }
    } else {
      emit(CheckSearchFailedState(errorMsg: AppStrings.noInternetConnection));
    }
  }

}