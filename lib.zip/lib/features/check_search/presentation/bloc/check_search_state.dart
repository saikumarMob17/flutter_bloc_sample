part of 'check_search_bloc.dart';

sealed class CheckSearchState {}

class CheckSearchInitialState extends CheckSearchState {}

class CheckSearchLoadingState extends CheckSearchState {}

class CheckSearchFailedState extends CheckSearchState {
  String errorMsg;
  CheckSearchFailedState({this.errorMsg = ''});
}

class CheckSearchOptionState extends CheckSearchState {
  int index;
  bool isOpen;
  CheckSearchOptionState({this.index = -1, this.isOpen = false});
}

class OnSwitchUserCheckSearchState extends CheckSearchState {
  bool isLogout;

  OnSwitchUserCheckSearchState({this.isLogout = false});
}

class CheckSearchResultState extends CheckSearchState {
  CheckSearchResult? checkSearchResult;

  CheckSearchResultState({this.checkSearchResult});
}

class OnSearchCheckState extends CheckSearchState {
  List<CheckSearchResult> checkSearchList;

  OnSearchCheckState({required this.checkSearchList});
}

class OnSelectCheckTagState extends CheckSearchState {
  int selectedIndex;

  OnSelectCheckTagState({this.selectedIndex = 0});
}

class CheckSearchInvalidFieldState extends CheckSearchState {
  String firstError;
  String secondError;
  CheckSearchInvalidFieldState({this.firstError = '', this.secondError = ''});
}