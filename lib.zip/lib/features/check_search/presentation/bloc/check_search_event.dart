part of 'check_search_bloc.dart';

sealed class CheckSearchEvent {}

class CheckSearchOptionEvent extends CheckSearchEvent {
  int index;
  bool isOpen;
  CheckSearchOptionEvent({this.index = -1, this.isOpen = false});
}

class OnSwitchUserCheckSearchEvent extends CheckSearchEvent {}

class OnSearchCheckEvent extends CheckSearchEvent {
  String firstField;
  String secondField;
  String date;
  int searchType;

  OnSearchCheckEvent({this.firstField = '', this.secondField = '', this.date = '', this.searchType = -1});
}

class OnSelectCheckTagEvent extends CheckSearchEvent {
  int selectedIndex;

  OnSelectCheckTagEvent({this.selectedIndex = 0});
}

class OnChangeFirstFieldEvent extends CheckSearchEvent {
  String value;
  String otherMessage;
  int tagIndex;
  OnChangeFirstFieldEvent({this.value = '', this.otherMessage = '', this.tagIndex = 0});
}

class OnChangeSecondFieldEvent extends CheckSearchEvent {
  String value;
  String otherMessage;
  OnChangeSecondFieldEvent({this.value = '', this.otherMessage = ''});
}