import 'dart:convert';
import 'dart:io';
import 'package:cliqtechnologies_retl/network/custom_exception.dart';
import 'package:cliqtechnologies_retl/routes/route.dart';
import '../../../network/api/api_client.dart';
import '../../../network/end_points.dart';
import '../../table_services/domain/all_employees_response.dart';
import '../domain/payment_terminal_response.dart';

class PaymentTerminalRepository {

  late ApiClient _apiClient;

  PaymentTerminalRepository(){
    _apiClient = ApiClient();
  }

  Future<List<Payments>> getAllPendingOrders() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.paymentTerminal);
      var jsonResponse = jsonDecode(response.body);
      switch(response.statusCode){
        case HttpStatus.ok:
          var data =  paymentTerminalResponseFromJson(response.body);
          return data.data ?? [];
        default:
          throw CustomException(message: jsonResponse['message']);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<bool> onClockOutUser() async {
    try {
      return await Helper.clockOut(apiClient: _apiClient);
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<List<Employees>> getAllEmployees() async {
    try {
      var response = await _apiClient.getRequest(endPoint: EndPoints.allEmployees);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok){
            var data = allEmployeesResponseFromJson(response.body);
            return data.data ?? [];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> transferCheck({required String endPoint}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: endPoint, body: null);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok) {
            return jsonDecode(response.body)['message'];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

  Future<String> authorizeManagerProfile({required Map body}) async {
    try {
      var response = await _apiClient.postRequest(endPoint: EndPoints.authorizeManager, body: body);
      switch (response.statusCode) {
        case HttpStatus.ok:
          if(jsonDecode(response.body)['statusCode'] == HttpStatus.ok) {
            return jsonDecode(response.body)['message'];
          }
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.badRequest:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.notFound:
          throw CustomException(message: jsonDecode(response.body)['message']);
        case HttpStatus.internalServerError:
          throw CustomException(message: jsonDecode(response.body)['ErrorMessage']);
        default:
          throw CustomException(message: AppStrings.someThingWentWrong);
      }
    } on CustomException catch (e) {
      throw CustomException(message: e.message);
    }
  }

}