import 'payment_terminal_response.dart';

class PaymentOrderModel {
  String customerName;
  String customerEmail;
  String customerId;
  String orderNumber;
  String customerIdentity;
  String orderId;
  int totalGuest;
  int checkSequence;
  bool? hasCheckSequence;
  String? serverName;
  String? serverId;
  String? checkId;
  PreAuthDetails? preAuthDetails;
  DateTime? orderDate;
  List<TableDetail> tableList;
  List<SplitItem> productDetails;
  List<OrderedProductDetailsByOrderSequence> orderDetails;
  BillingDetails? billingDetails;
  BillingDetails? totalBillingDetails;
  CardDetails? cardDetails;


  PaymentOrderModel({
    required this.customerName,
    this.customerId = '',
    this.customerEmail = '',
    this.customerIdentity = '',
    this.checkId,
    this.preAuthDetails,
    this.orderNumber = '',
    this.orderId = '',
    this.serverId = '',
    this.serverName = '',
    this.totalGuest = 0,
    this.orderDate,
    this.checkSequence = 0,
    this.cardDetails,
    this.hasCheckSequence = false,
    required this.tableList,
    required this.productDetails,
    required this.orderDetails,
    required this.billingDetails,
    this.totalBillingDetails
  });
}

class CardDetails {
  String cardHolderName;
  String cardNumber;
  String cvv;
  int month;
  int year;

  CardDetails({
    this.cardHolderName = '',
    this.cardNumber = '',
    this.cvv = '',
    this.month = 1,
    this.year = 2024
  });
}