// To parse this JSON data, do
//
//     final paymentTerminalResponse = paymentTerminalResponseFromJson(jsonString);

import 'dart:convert';

PaymentTerminalResponse paymentTerminalResponseFromJson(String str) => PaymentTerminalResponse.fromJson(json.decode(str));


class PaymentTerminalResponse {
  final int? statusCode;
  final String? status;
  final String? message;
  final List<Payments>? data;

  PaymentTerminalResponse({
    this.statusCode,
    this.status,
    this.message,
    this.data,
  });

  factory PaymentTerminalResponse.fromJson(Map<String, dynamic> json) => PaymentTerminalResponse(
    statusCode: json["statusCode"],
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<Payments>.from(json["data"]!.map((x) => Payments.fromJson(x))),
  );
}

class Payments {
    final String? orderId;
    final String? orderNumber;
    final DateTime? orderDate;
    final List<TableDetail>? tableDetails;
    final PreAuthDetails? preAuthDetails;
    final String? customerId;
    final String? customerName;
    final String? customerEmail;
    final String? customerIdentity;
    final int? totalGuest;
    final bool? paymentStatus;
    final int? quantity;
    final List<OrderedProductDetailsByOrderSequence>? orderedProductDetailsByOrderSequence;
    final BillingDetails? totalBillingDetail;
    final List<CheckDetail>? checkDetails;
    final EmployeeDetails? employeeDetails; 

    Payments({
      this.orderId,
      this.orderNumber,
      this.orderDate,
      this.tableDetails,
      this.preAuthDetails,
      this.customerId,
      this.customerName,
      this.customerEmail,
      this.customerIdentity,
      this.totalGuest,
      this.paymentStatus,
      this.quantity,
      this.orderedProductDetailsByOrderSequence,
      this.totalBillingDetail,
      this.checkDetails,
      this.employeeDetails
    });

    factory Payments.fromJson(Map<String, dynamic> json) => Payments(
      orderId: json["orderId"],
      orderNumber: json["orderNumber"],
      orderDate: json["orderDate"] == null ? null : DateTime.parse(json["orderDate"]),
      preAuthDetails: PreAuthDetails.fromJson(json['preAuthDetails']),
      tableDetails: json["tableDetails"] == null ? [] : List<TableDetail>.from(json["tableDetails"]!.map((x) => TableDetail.fromJson(x))),
      customerId: json["customerId"],
      customerName: json["customerName"],
      customerEmail: json['customerEmail'],
      customerIdentity: json["customerIdentity"],
      totalGuest: json["totalGuest"],
      paymentStatus: json["paymentStatus"],
      quantity: json["quantity"],
      orderedProductDetailsByOrderSequence: json["orderedProductDetailsByOrderSequence"] == null ? [] : List<OrderedProductDetailsByOrderSequence>.from(json["orderedProductDetailsByOrderSequence"]!.map((x) => OrderedProductDetailsByOrderSequence.fromJson(x))),
      totalBillingDetail: json["totalBillingDetail"] == null ? null : BillingDetails.fromJson(json["totalBillingDetail"]),
      checkDetails: json["checkDetails"] == null ? [] : List<CheckDetail>.from(json["checkDetails"]!.map((x) => CheckDetail.fromJson(x))),
      employeeDetails: json['employeeDetails'] == null ? null : EmployeeDetails.fromJson(json['employeeDetails'])
    );
}

class PreAuthDetails {
  final bool? isPreAuth;
  final String? finixAuthorizationId;
  final String? paymentInstrumentId;
  final String? cardLastFourDegit;

  PreAuthDetails({
    this.isPreAuth,
    this.finixAuthorizationId,
    this.paymentInstrumentId,
    this.cardLastFourDegit
  });

  factory PreAuthDetails.fromJson(Map<String, dynamic> json){
    return PreAuthDetails(
      isPreAuth: json['isPreAuth'],
      finixAuthorizationId: json['authId'],
      paymentInstrumentId: json['paymentInstrumentId'],
      cardLastFourDegit: json['cardLastFourDegit']
    );
  }
}

class CheckDetail {
    final String? checkId;
    final String? customerName;
    final String? cardNumner;
    final String? cardType;
    final int? checkSequence;
    final List<SplitItem>? splitItems;
    final BillingDetails? billingDetails;

    CheckDetail({
        this.checkId,
        this.customerName,
        this.cardNumner,
        this.cardType,
        this.checkSequence,
        this.splitItems,
        this.billingDetails,
    });

    factory CheckDetail.fromJson(Map<String, dynamic> json) => CheckDetail(
        checkId: json['checkId'],
        customerName: json["customerName"],
        cardNumner: json["cardNumner"],
        cardType: json["cardType"],
        checkSequence: json["check_Sequence"],
        splitItems: json["splitItems"] == null ? [] : List<SplitItem>.from(json["splitItems"]!.map((x) => SplitItem.fromJson(x))),
        billingDetails: json["billingDetails"] == null ? null : BillingDetails.fromJson(json["billingDetails"]),
    );
}

class BillingDetails {
    final double? subTotal;
    final double? discount;
    final double? tax;
    final double? tip;
    final double? grandTotal;
    final bool? paymentStatus;
    final List<PaymentMode>? paymentMode;
    final double? balanceDue;

    BillingDetails({
        this.subTotal,
        this.discount,
        this.tax,
        this.tip,
        this.grandTotal,
        this.paymentStatus,
        this.paymentMode,
        this.balanceDue,
    });

    factory BillingDetails.fromJson(Map<String, dynamic> json) => BillingDetails(
        subTotal: json["subTotal"]?.toDouble(),
        discount: json["discount"]?.toDouble(),
        tax: json["tax"]?.toDouble(),
        tip: json["tip"]?.toDouble(),
        grandTotal: json["grandTotal"]?.toDouble(),
        paymentStatus: json["paymentStatus"],
        paymentMode: json["paymentMode"] == null ? [] : List<PaymentMode>.from(json["paymentMode"]!.map((item) => PaymentMode.fromJson(item))),
        balanceDue: json["balanceDue"]?.toDouble(),
    );

    Map get toJson => {
      "subTotal": subTotal,
      "discount":discount,
      "tax": tax,
      "tip": tip,
      "grandTotal": grandTotal,
      "paymentStatus": paymentStatus,
      "balanceDue": balanceDue
    };
}

class PaymentMode {
  final String? paymentMode;
  final double? amountPaid;
  final double? tip;
  final String? cardType;
  final String? cardNumber;

  PaymentMode({
    this.paymentMode,
    this.amountPaid,
    this.tip,
    this.cardType,
    this.cardNumber,
  });

  factory PaymentMode.fromJson(Map<String, dynamic> json){
    return PaymentMode(
      paymentMode: json['paymentMode'],
      amountPaid: json['ammountPaid'].toDouble(),
      tip: json['tip'].toDouble(),
      cardType: json['cardType'],
      cardNumber: json['cardNumber'],
    );
  }
}

class SplitItem {
    final String? checkItemId;
    final int? productId;
    final String? productName;
    int? quantity;
    final double? productPrice;

    SplitItem({
        this.checkItemId,
        this.productId,
        this.productName,
        this.quantity,
        this.productPrice,
    });

    factory SplitItem.fromJson(Map<String, dynamic> json) => SplitItem(
        checkItemId: json['checkItemId'] ?? '',
        productId: json["productId"],
        productName: json["productName"],
        quantity: json["quantity"],
        productPrice: json["productPrice"].toDouble(),
    );

    Map get toJson => {
      "checkItemId": checkItemId,
      "productId": productId,
      "productName": productName,
      "quantity": quantity,
      "productPrice": productPrice,
    };
}

class OrderedProductDetailsByOrderSequence {
    final int? orderSequence;
    final bool? isFinished;
    final List<SplitItem>? productDetails;
    final BillingDetails? billingDetails;

    OrderedProductDetailsByOrderSequence({
        this.orderSequence,
        this.isFinished,
        this.productDetails,
        this.billingDetails,
    });

    factory OrderedProductDetailsByOrderSequence.fromJson(Map<String, dynamic> json) => OrderedProductDetailsByOrderSequence(
        orderSequence: json["orderSequence"],
        isFinished: json["isFinished"],
        productDetails: json["productDetails"] == null ? [] : List<SplitItem>.from(json["productDetails"]!.map((x) => SplitItem.fromJson(x))),
        billingDetails: json["billingDetails"] == null ? null : BillingDetails.fromJson(json["billingDetails"]),
    );
}

class TableDetail {
    final String? tableName;
    final int? tableId;

    TableDetail({
        this.tableName,
        this.tableId,
    });

    factory TableDetail.fromJson(Map<String, dynamic> json) => TableDetail(
        tableName: json["tableName"],
        tableId: json["tableId"],
    );
}

class EmployeeDetails {
  String? employeeId;
  String? employeeName;
  String? location;
  String? role;
  String? lastClockedIn;

  EmployeeDetails({
    this.employeeId,
    this.employeeName,
    this.location,
    this.role,
    this.lastClockedIn
  });

  factory EmployeeDetails.fromJson(Map<String, dynamic> json){
    return EmployeeDetails(
      employeeId: json['employeeId'] ?? '',
      employeeName: json['employeeName'] ?? '',
      location: json['location'],
      role: json['role'],
      lastClockedIn: json['lastClockedIn']
    );
  }
}

