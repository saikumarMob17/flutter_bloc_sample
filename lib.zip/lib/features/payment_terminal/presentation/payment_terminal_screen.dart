import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'authorize_user_dialog_widget.dart';
import 'bloc/payment_terminal_bloc.dart';
import '../../table_services/domain/employee_drop_down_item.dart';
import '../../orders/domain/order_model.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_icons.dart';
import '../../../constants/app_images.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../utils/shared_pref.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../widgets/left_navigation_screen.dart';
import '../../../widgets/custom_empty_widget.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_extension_method.dart';
import '../../orders/domain/billing_model.dart';
import '../../payment/domain/payment_model.dart';
import '../domain/payment_order_model.dart';
import '../domain/payment_terminal_response.dart';
import 'close_check_widget.dart';
import 'transfer_check_widget.dart';

class PaymentTerminalScreen extends StatefulWidget {

  const PaymentTerminalScreen({super.key});

  @override
  State createState() => _PaymentTerminalScreenState();
}

class _PaymentTerminalScreenState extends State<PaymentTerminalScreen> with Helper {

  var tabTitleList = [
    AppStrings.openChecks,
    AppStrings.closeChecks
  ];

  var orderBillingLabel = <OrderBillingModel>[
    OrderBillingModel(title: AppStrings.subTotal, amount: 0.0),
    OrderBillingModel(title: AppStrings.discount, amount: 0.0),
    OrderBillingModel(title: AppStrings.tip, amount: 0.0),
    OrderBillingModel(title: AppStrings.tax, amount: 0.0),
    OrderBillingModel(title: AppStrings.total, amount: 0.0),
    OrderBillingModel(title: AppStrings.balanceDue, amount: 0.0),
  ];

  int tabSelectedIndex = 0;
  int selectedOrderIndex = -1;
  var orderList = <PaymentOrderModel>[];
  PaymentOrderModel? selectedOrder;
  bool isMostRecent = false;
  bool isLoading = true;
  bool isTransferCheck = false;
  int openCount = 0;
  int closeCount = 0;
  bool isAuthorizeDialogOpen = false;
  late PaymentTerminalBloc _paymentTerminalBloc;
  List<EmployeeDropdownItem> employeeDropDownItem = [];

  @override
  void initState() {
    _paymentTerminalBloc = context.read<PaymentTerminalBloc>();
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Helper.isDark 
      ? AppColors.backgroundColorDark 
      : AppColors.backgroundColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(toolbarHeight: 0),
      body: BlocConsumer<PaymentTerminalBloc, PaymentTerminalState>(
        builder: (context, state) {
          switch (state.runtimeType) {
            case OnChangeCheckTabState:
              state = state as OnChangeCheckTabState;
              selectedOrderIndex = -1;
              selectedOrder = null;
              tabSelectedIndex = state.tabIndex;
              break;
            case OnFetchOrdersState:
              state = state as OnFetchOrdersState;
              isMostRecent = state.isMostRecent;
              selectedOrderIndex = -1;
              selectedOrder = null;
              orderList.clear();
              orderList.addAll(state.orderList);
              openCount = orderList.where((element) => element.billingDetails!.balanceDue != 0.0).length;
              closeCount = orderList.length - openCount;
              break;
            case OnSelectPaymentOrderState:
              state = state as OnSelectPaymentOrderState;
              selectedOrderIndex = state.selectedIndex;
              selectedOrder = state.selectedOrder;
              if(selectedOrder != null) {
                calculateBillingAmount(orderDetails: selectedOrder!);
              }
              break;
            default:
          }
          return LayoutBuilder(
            builder: (_, constraints) {
              return constraints.maxWidth.screenType == ScreenType.mobile
              ? mobileView(bContext: context)
              : posView(bContext: context);
            }
          );
        }, 
        listener: (context, state) {
          switch (state.runtimeType) {
            case LoadingState:
              showLoadingDialog(context: context);
              break;
            case OnFetchOrdersState:
              isLoading = false;
              hideLoadingDialog(context: context);
              break;
            case OnSelectPaymentOrderState:
              state = state as OnSelectPaymentOrderState;
              selectedOrder = state.selectedOrder;
              isTransferCheck = state.forTransferCheck;
              if(MediaQuery.of(context).size.width <= 600 && selectedOrder != null && !state.forTransferCheck) {
                showOrderDetails(context: context, orderDetails: selectedOrder!);
              }
              if(state.forTransferCheck && selectedOrder != null) {
                isAuthorizeDialogOpen = true;
                if(Preferences.getString(key: AppStrings.prefUserRole) == 'Manager') {
                  showTransferCheck(orderDetails: selectedOrder!);
                } else {
                  authorizeUserDialog(orderDetails: selectedOrder!);
                }
              }
              break;
            case OnFailedState:
              isLoading = false;
              state = state as OnFailedState;
              hideLoadingDialog(context: context);
              if(isTransferCheck && !isAuthorizeDialogOpen) isTransferCheck = false;
              showSnackBar(context: context, title: state.msg);
              break;
            case OnSwitchUserPaymentTerminalState:
              isLoading = false;
              hideLoadingDialog(context: context);
              state = state as OnSwitchUserPaymentTerminalState;
              if(state.isLogout) {
                AppRoutes.onClickLogout(context: context);
              }
              break;
            case PaymentTerminalGetAllEmployeeState:
              state = state as PaymentTerminalGetAllEmployeeState;
              employeeDropDownItem.clear();
              for(var item in state.employeesList) {
                var name = '${item.user!.firstName!} ${item.user!.lastName!}';
                employeeDropDownItem.add(EmployeeDropdownItem(value: name, id: item.user!.id!));
              }
              break;
            case PaymentTerminalSuccessState:
              state = state as PaymentTerminalSuccessState;
              if(isTransferCheck && !isAuthorizeDialogOpen) isTransferCheck = false;
              hideLoadingDialog(context: context);
              showSnackBar(context: context, title: state.msg, color: AppColors.green);
              break;
            default:
          }
        },
      ),
    );
  }

  Widget mobileView({required BuildContext bContext}) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSize.s20,
        vertical: AppSize.s20
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => context.pop(),
                        icon: const Icon(Icons.west)
                      ),
                      const SizedBox(width: AppSize.s4),
                      CustomText(
                        title: AppStrings.paymentTerminal,
                        textStyle: getMediumStyle(
                          fontSize: AppSize.s18,
                          color: Helper.isDark
                          ? AppColors.white
                          : AppColors.black
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      CustomImageView(
                        imagePath: AppImages.shoppingCart,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => context.pushReplacement(AppRoutes.tableViewScreen),
                      ),
                      const SizedBox(width: AppSize.s10),
                       CustomImageView(
                        imagePath: AppImages.switchIcon,
                        height: AppSize.s24,
                        width: AppSize.s24,
                        onTap: () => _paymentTerminalBloc.add(OnSwitchUserPaymentTerminalEvent()),
                        color: Helper.isDark
                        ? AppColors.white
                        : AppColors.black,
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: AppSize.s10),
                      child: CustomTextField(
                        hint: AppStrings.searchHere,
                        prefixImagePath: AppImages.searchIcon,
                        prefixImageColor: AppColors.lightGrey,
                        prefixImageSize: AppSize.s22,
                        horPadding: AppSize.s10,
                        verPadding: AppSize.s10,
                        onChange: (value) => _paymentTerminalBloc.add(OnSearchEvent(text: value)),
                      ),
                    ),
                    Container(
                      height: AppSize.s45,
                      width: context.screenWidth,
                      decoration: BoxDecoration(
                        color: Helper.isDark
                        ? AppColors.contentColorDark
                        : AppColors.white,
                        borderRadius: BorderRadius.circular(AppSize.s10),
                        boxShadow: [BoxShadow(
                          color: AppColors.grey.withOpacity(0.2), 
                          blurRadius: AppSize.s1, 
                          offset: const Offset(0, 2)
                          ),
                        ]
                      ),
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s18),
                        children: List.generate(
                          tabTitleList.length, 
                          (index) => GestureDetector(
                            onTap: () => _paymentTerminalBloc.add(OnChangeCheckTabEvent(tabIndex: index)), 
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                              margin: const EdgeInsets.only(right: AppSize.s20),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    width: 3.0, 
                                    color: tabSelectedIndex == index 
                                    ? AppColors.primaryColor 
                                    : AppColors.transparent
                                  ),
                                ),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: CustomText(
                                  title: ' ${tabTitleList[index]} (${index == 0 ? openCount : closeCount}) ',
                                  textStyle: getMediumStyle(
                                    color: tabSelectedIndex == index 
                                    ? AppColors.primaryColor 
                                    : Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s15),
                    filterChecks(orderList, tabSelectedIndex).isEmpty
                    ? Expanded(
                      child: CustomEmptyWidget(
                        imagePath: AppImages.notFound, 
                        emptyTitle: AppStrings.noCheckFound, 
                        isVisible: !isLoading
                      ))
                    : Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: filterChecks(orderList, tabSelectedIndex).length,
                        itemBuilder: (context, index){
                          var subData = filterChecks(orderList, tabSelectedIndex);
                          var data = subData[index];
                          return GestureDetector(
                            onTap: () => _paymentTerminalBloc.add(OnSelectPaymentOrderEvent(selectOrder: data, selectedIndex: index)),
                            child: Container(
                              width: context.screenWidth * 0.22,
                              padding: const EdgeInsets.all(AppSize.s15),
                              margin: const EdgeInsets.only(bottom: AppSize.s15),
                              decoration: BoxDecoration(
                                color: Helper.isDark ? AppColors.headerColorDark : AppColors.white,
                                borderRadius: BorderRadius.circular(AppSize.s10),
                                border: Border.all(
                                  color: selectedOrderIndex == index 
                                  ? AppColors.primaryColor
                                  : AppColors.transparent, 
                                  width: 1.0
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          CustomText(
                                            title: 'Table : ${data.tableList.fold('', (p0, p1) => p0.isEmpty ? p0+p1.tableName! : '$p0,${p1.tableName}')}', 
                                            color: Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                          ),
                                        ],
                                      ),
                                      Container(
                                        padding: const EdgeInsets.all(4),
                                        color: AppColors.primaryColor,
                                        child: const CustomText(
                                          title: 'D-IN',
                                          fontSize: AppSize.s8,
                                          color: AppColors.white,
                                        )
                                      )
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s20),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: data.customerName, 
                                        textStyle: getMediumStyle(
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                      CustomText(
                                        title: '#${data.checkSequence}', 
                                        textStyle: getMediumStyle(
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Divider(color: AppColors.grey, thickness: AppSize.s1, height: AppSize.s8),
                                  const SizedBox(height: AppSize.s10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: CustomText(
                                          title: data.productDetails.fold('', (p0, p1) => p0.isEmpty ? p0+p1.productName! : '$p0,${p1.productName}'), 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                      const SizedBox(width: AppSize.s20),
                                      CustomText(
                                        title: '\$${data.billingDetails!.grandTotal!.roundTwo}', 
                                        textStyle: getMediumStyle(
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        }
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget posView({required BuildContext bContext}) {
    return Row(
      children: [
        const LeftNavigationScreen(
          selectedLeftNavigationItem: 0,
        ),
        Expanded(
          child: Column(
            children: [
              Container(
                color: Helper.isDark 
                ? AppColors.black 
                : AppColors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSize.s18, 
                  vertical: AppSize.s18
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              onPressed: () => context.pop(),
                              icon: const Icon(Icons.west)
                            ),
                            CustomText(
                              title: AppStrings.paymentTerminal,
                              textStyle: getMediumStyle(
                                fontSize: AppSize.s20,
                                color: Helper.isDark 
                                ? AppColors.white 
                                : AppColors.black
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => context.pushReplacement(AppRoutes.tableViewScreen),
                              text: AppStrings.newOrder,
                              textColor: AppColors.blue,
                              preFixWidget: const Icon(
                                AppIcons.addIcon, 
                                size: AppSize.s18, 
                                color: AppColors.blue
                              ),
                            ),
                            const SizedBox(width: AppSize.s10),
                            CustomSolidButton(
                              onPressed: () => _paymentTerminalBloc.add(OnSwitchUserPaymentTerminalEvent()),
                              prefix: const Icon(Icons.swap_horiz_rounded, color: AppColors.white),
                              verPadding: AppSize.s15,
                              text: AppStrings.switchUser
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s18),
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: AppSize.s38,
                            width: context.screenWidth,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(horizontal: AppSize.s10),
                              children: List.generate(
                                tabTitleList.length, 
                                (index) => InkWell(
                                  onTap: () => _paymentTerminalBloc.add(OnChangeCheckTabEvent(tabIndex: index)),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: AppSize.s8),
                                    margin: const EdgeInsets.only(right: AppSize.s20),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: AppSize.s2, 
                                          color: tabSelectedIndex == index
                                          ? AppColors.blue
                                          : AppColors.transparent
                                        ),
                                      ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: CustomText(
                                        title: ' ${tabTitleList[index]} (${index == 0 ? openCount : closeCount}) ',
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s16,
                                          color: tabSelectedIndex == index 
                                          ? AppColors.blue 
                                          : Helper.isDark 
                                            ? AppColors.white 
                                            : AppColors.black
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            CustomOutlinedButton(
                              onPressed: () => _paymentTerminalBloc.add(PaymentTerminalMostRecentEvent(isMostRecent: !isMostRecent)),
                              text: AppStrings.mostRecent,
                              backgroundColor: isMostRecent 
                              ? AppColors.primaryColor 
                              : null,
                              suffixWidget: Icon(
                                AppIcons.swapVerIcon, 
                                color: isMostRecent 
                                ? AppColors.white 
                                : AppColors.blue
                              ),
                              widgetSpacing: AppSize.s4,
                              textColor: isMostRecent 
                              ? AppColors.white 
                              : AppColors.blue,
                            ),
                            const SizedBox(width: AppSize.s10),
                            SizedBox(
                              width: context.screenWidth * 0.18,
                              child: CustomTextField(
                                prefixImagePath: AppImages.searchIcon,
                                prefixImageColor: AppColors.lightTextGrey,
                                prefixImageSize: AppSize.s16,
                                horPadding: AppSize.s14,
                                verPadding: 9,
                                hint: AppStrings.search,
                                onChange: (value) => _paymentTerminalBloc.add(OnSearchEvent(text: value)),
                              ),
                            )
                          ]
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ////Order Hub View
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(AppSize.s18),
                  child: Row(
                    children: [
                      Expanded(
                        child: filterChecks(orderList, tabSelectedIndex).isEmpty
                        ? CustomEmptyWidget(
                            imagePath: AppImages.notFound, 
                            emptyTitle: AppStrings.noCheckFound, 
                            isVisible: !isLoading
                          )
                        : ListView(
                          children: [
                            Wrap(
                              spacing: 11,
                              runSpacing: 11,
                              children: List.generate(
                                filterChecks(orderList, tabSelectedIndex).length, 
                                (index) {
                                  var tempOrder = filterChecks(orderList, tabSelectedIndex);
                                  var data = tempOrder[index];
                                  return InkWell(
                                    onTap: () => _paymentTerminalBloc.add(OnSelectPaymentOrderEvent(selectOrder: data, selectedIndex: index)),
                                    onLongPress: () => _paymentTerminalBloc.add(OnSelectPaymentOrderEvent(selectOrder: data, selectedIndex: index, forTransferCheck: true)),
                                    borderRadius: BorderRadius.circular(AppSize.s10),
                                    child: Ink(
                                      width: context.screenWidth * 0.22,
                                      padding: const EdgeInsets.all(AppSize.s12),
                                      decoration: BoxDecoration(
                                        color: selectedOrderIndex == index && isTransferCheck
                                        ? AppColors.primaryColor
                                        : Helper.isDark 
                                          ? AppColors.headerColorDark 
                                          : AppColors.white,
                                        borderRadius: BorderRadius.circular(AppSize.s10),
                                        border: Border.all(
                                          color: selectedOrderIndex == index 
                                          ? AppColors.primaryColor
                                          : AppColors.transparent, 
                                          width: 1.5
                                        ),
                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              CustomText(
                                                title: 'Table : ${data.tableList.fold('', (p0, p1) => p0.isEmpty ? p0+p1.tableName! : '$p0,${p1.tableName}')}',
                                                textStyle: getRegularStyle(
                                                  fontWeight: FontWeight.w500,
                                                  color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : null
                                                ),
                                              ),
                                              CustomText(
                                                title: data.orderNumber,
                                                textStyle: getMediumStyle(
                                                  color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : null
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: AppSize.s20),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              CustomText(
                                                title: data.customerName, 
                                                textStyle: getMediumStyle(
                                                  color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : null
                                                ),
                                              ),
                                              CustomText(
                                                title: '#${data.checkSequence}', 
                                                textStyle: getMediumStyle(
                                                  color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : null
                                                ),
                                              ),
                                            ],
                                          ),
                                          Divider(
                                            color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : AppColors.grey, 
                                            thickness: AppSize.s1, 
                                            height: AppSize.s8
                                          ),
                                          const SizedBox(height: AppSize.s8),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: CustomText(
                                                  title: '${data.productDetails.fold('', (p0, p1) => p0.isEmpty ? p0+p1.productName! : '$p0, ${p1.productName}')}\n', 
                                                  maxLines: 2,
                                                  textOverflow: TextOverflow.ellipsis,
                                                  fontSize: 11,
                                                  color: selectedOrderIndex == index && isTransferCheck 
                                                  ? AppColors.white : null
                                                ),
                                              ),
                                              const SizedBox(width: AppSize.s20),
                                              CustomText(
                                                title: '\$${calculateGrandTotal(data.billingDetails)}', 
                                                textStyle: getMediumStyle(
                                                  color: selectedOrderIndex == index && isTransferCheck ? AppColors.white : null
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }
                              ),
                            ),
                          ],
                        ),
                      ),
                      ///Right Layout
                      ///Order Details Screen
                      Container(
                        width: context.screenWidth * 0.25, 
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(AppSize.s12),
                          color: Helper.isDark 
                          ? AppColors.headerColorDark 
                          : AppColors.white,
                        ),
                        child: selectedOrder == null
                        ? const CustomEmptyWidget(
                            imagePath: AppImages.foodRestaurantOrder,
                            emptyTitle: AppStrings.noSelectedOrders,
                            imageColor: AppColors.primaryColor,
                          )
                        : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: AppSize.s14,
                                horizontal: AppSize.s14,
                              ),
                              decoration: BoxDecoration(
                                color: Helper.isDark 
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(AppSize.s10),
                                  topRight: Radius.circular(AppSize.s10)
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          CustomText(
                                            title: 'Table : ${selectedOrder!.tableList.fold("", (p1, element) => p1.isEmpty ? p1+element.tableName! : '$p1-${element.tableName}')}', 
                                            textStyle: getRegularStyle(
                                              fontWeight: FontWeight.w500
                                            ),
                                          ),
                                          const SizedBox(width: AppSize.s6),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: AppSize.s4,
                                              vertical: AppSize.s2
                                            ),
                                            decoration: BoxDecoration(
                                              color: AppColors.primaryColor,
                                              borderRadius: BorderRadius.circular(AppSize.s4)
                                            ),
                                            child: const CustomText(
                                              title: 'D-IN',
                                              fontSize: AppSize.s10,
                                              color: AppColors.white,
                                            ),
                                          ),
                                        ],
                                      ),
                                      CustomText(
                                        title: selectedOrder!.serverName!, 
                                        textStyle: getRegularStyle(
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: AppSize.s18),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        title: selectedOrder == null
                                        ? ''
                                        : selectedOrder!.customerName, 
                                        textStyle: getMediumStyle(
                                          fontSize: AppSize.s16, 
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                      CustomText(
                                        title: '${selectedOrder!.orderNumber}  |  #${selectedOrder!.checkSequence}', 
                                        textStyle: getMediumStyle(
                                          color: Helper.isDark 
                                          ? AppColors.white 
                                          : AppColors.black
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Expanded(
                              child: ListView.builder(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                itemCount: selectedOrder == null 
                                ? 0 
                                : selectedOrder!.productDetails.length,
                                itemBuilder: (_, index) {
                                  var data = selectedOrder!.productDetails[index];
                                  return Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: AppSize.s14, 
                                      vertical: AppSize.s14
                                    ),
                                    decoration: const BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                          width: AppSize.s05, 
                                          color: AppColors.grey
                                        ),
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        ///Product Name
                                        Expanded(
                                          flex: 2,
                                          child: CustomText(
                                            title: data.productName!,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14, 
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              CustomText(
                                                title: '\$${data.productPrice} x  ',
                                                textAlign: TextAlign.center,
                                                textStyle: getRegularStyle(fontSize: AppSize.s14, color: AppColors.grey)
                                              ),
                                              CustomText(
                                                title: data.quantity.toString(),
                                                textAlign: TextAlign.center,
                                                textStyle: getRegularStyle(
                                                  fontSize: AppSize.s14, 
                                                  color: Helper.isDark 
                                                  ? AppColors.white 
                                                  : AppColors.black
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: CustomText(
                                            title: '\$${data.productPrice! * data.quantity!.toDouble()}',
                                            textAlign: TextAlign.end,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? AppColors.white 
                                              : AppColors.black
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Container(
                              padding: const EdgeInsets.only(
                                left: AppSize.s14,
                                right: AppSize.s14,
                                top: AppSize.s12,
                                bottom: AppSize.s4
                              ),
                              decoration: BoxDecoration(
                                color: Helper.isDark 
                                ? AppColors.contentColorDark
                                : AppColors.white,
                              ),
                              child: Column(
                                children: List.generate(
                                  orderBillingLabel.length, 
                                  (index) {
                                    var data = orderBillingLabel[index];
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: AppSize.s6),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          CustomText(
                                            title: data.title,
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? index == 5 ? AppColors.red : AppColors.white
                                              : index == 5 ? AppColors.red : AppColors.black
                                            ),
                                          ),
                                          CustomText(
                                            title: '\$${data.amount.roundTwo}',
                                            textStyle: getRegularStyle(
                                              fontSize: AppSize.s14,
                                              color: Helper.isDark 
                                              ? index == 5 ? AppColors.red : AppColors.white 
                                              : index == 5 ? AppColors.red : AppColors.black
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }
                                ),
                              ),
                            ),
                            Divider(
                              color: Helper.isDark
                              ? AppColors.backgroundColorDark
                              : AppColors.backgroundColor, 
                              height: AppSize.s4, 
                              thickness: AppSize.s4
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: AppSize.s14,
                                horizontal: AppSize.s14,
                              ),
                              decoration: BoxDecoration(
                                color: Helper.isDark 
                                ? AppColors.contentColorDark
                                : AppColors.white,
                                borderRadius: const BorderRadius.only(
                                  bottomLeft: Radius.circular(AppSize.s10),
                                  bottomRight: Radius.circular(AppSize.s10)
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Visibility(
                                    visible: tabSelectedIndex == 1 
                                    ? true 
                                    : !selectedOrder!.hasCheckSequence!,
                                    child: Expanded(
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: CustomOutlinedButton(
                                              onPressed: () {
                                                if(selectedOrder != null) {
                                                  var tableList = <Map>[];
                                                  for(var item in selectedOrder!.tableList){
                                                    tableList.add({
                                                      'table_name': item.tableName,
                                                      'table_id': item.tableId
                                                    });
                                                  }
                                                  var addOnData = {
                                                    'from': AppRoutes.paymentTerminalScreen,
                                                    'type': tabSelectedIndex == 0 ? AppStrings.openChecks : AppStrings.closeChecks,
                                                    'total_guest': selectedOrder!.totalGuest,
                                                    'product_list': selectedOrder!.productDetails,
                                                    'order_sequence': selectedOrder!.orderDetails.length,
                                                    'customer_name': selectedOrder!.customerName,
                                                    'customer_identity': selectedOrder!.customerIdentity,
                                                    "customer_email": "",
                                                    'selected_server_id': selectedOrder!.serverId,
                                                    'order_id': selectedOrder!.orderId,
                                                    'table_list': tableList,
                                                    'order_details': selectedOrder!.orderDetails,
                                                    'total_billing_details': selectedOrder!.totalBillingDetails,
                                                    'selected_table': tableList.fold("", (p0, p1) => p0.isBlank ? p0+p1['table_name'] : '$p0-${p1['table_name']}')
                                                  };
                                                  context.pushReplacement(AppRoutes.ordersScreen, extra: addOnData);
                                                }
                                              },
                                              text: tabSelectedIndex == 0
                                              ? AppStrings.update
                                              : AppStrings.duplicateOrder,
                                              textColor: AppColors.blue
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: tabSelectedIndex == 0 ?
                                          !selectedOrder!.hasCheckSequence! ? AppSize.s6 : AppSize.s0
                                          : AppSize.s6
                                        ),
                                        Expanded(
                                          child: tabSelectedIndex == 0 
                                          ? CustomSolidButton(
                                            onPressed: () {
                                              // var orderItems = <OrderModel>[];
                                              // for(var item in selectedOrder!.productDetails){
                                              //   orderItems.add(OrderModel(
                                              //     itemId: item.productId!,
                                              //     title: item.productName!,
                                              //     price: item.productPrice!.toDouble(),
                                              //     totalPrice: (item.quantity! * item.productPrice!.toDouble()).roundTwo,
                                              //     quantity: item.quantity!
                                              //   ));
                                              // }
                                              // var tableList = <Map>[];
                                              // for(var item in selectedOrder!.tableList){
                                              //   tableList.add({
                                              //     'table_name': item.tableName,
                                              //     'table_id': item.tableId
                                              //   });
                                              // }
                                              // var paymentDetails = PaymentModel(
                                              //   isFirstOrder: false,
                                              //   orderedItem: orderItems,
                                              //   orderId: selectedOrder!.orderId,
                                              //   customerName: selectedOrder!.customerName,
                                              //   customerId: selectedOrder!.customerId,
                                              //   customerEmail: "",
                                              //   customerPhone: "",
                                              //   customerCreditCard: "",
                                              //   hasCheckSequence: selectedOrder!.hasCheckSequence,
                                              //   totalGuest: selectedOrder!.totalGuest,
                                              //   employeeId: Preferences.getString(key: AppStrings.prefUserId),
                                              //   tableName: tableList.fold("", (p0, item) => p0.isBlank ? p0+item['table_name'] : '$p0-${item['table_name']}'), 
                                              //   totalAmount: orderBillingLabel[5].amount,
                                              //   subTotal: orderBillingLabel[0].amount,
                                              //   discount: orderBillingLabel[1].amount,
                                              //   tax: orderBillingLabel[3].amount,
                                              //   balanceDue: orderBillingLabel[4].amount,
                                              //   orderSequence: selectedOrder!.checkSequence,
                                              //   selectedTableList: tableList
                                              // );
                                              context.push(AppRoutes.paymentScreen, extra: {'orderId': selectedOrder!.orderId, 'pageIndex': selectedOrder!.checkSequence - 1});
                                            },
                                            text: "${AppStrings.pay} (\$${orderBillingLabel[5].amount})",
                                          )
                                          : CustomOutlinedButton(
                                              onPressed: () => showCloseCheckReceiptDialog(context: bContext, orderDetails: selectedOrder!),
                                              text: AppStrings.print,
                                              textColor: AppColors.blue
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void calculateBillingAmount({required PaymentOrderModel orderDetails}) {
    var grandTotal = ((orderDetails.billingDetails!.subTotal! + orderDetails.billingDetails!.tax! + orderDetails.billingDetails!.tip!) - orderDetails.billingDetails!.discount!).roundTwo;
    orderBillingLabel[0].amount = orderDetails.billingDetails!.subTotal!;
    orderBillingLabel[1].amount = orderDetails.billingDetails!.discount!;
    orderBillingLabel[3].amount = orderDetails.billingDetails!.tax!;
    orderBillingLabel[2].amount = orderDetails.billingDetails!.tip!;
    orderBillingLabel[5].amount = orderDetails.billingDetails!.balanceDue!;
    orderBillingLabel[4].amount = grandTotal;
  }

  double calculateGrandTotal(BillingDetails? billingDetails) {
    if(billingDetails == null) {
      return 0.0;
    } else {
      try {
        var grandTotal = (billingDetails.subTotal! + billingDetails.tax! + billingDetails.tip!) - billingDetails.discount!;
        return grandTotal.roundTwo;
      } catch (e) {
        return 0.0;
      }
    }
  }

  void showOrderDetails({required BuildContext context, required PaymentOrderModel orderDetails}) {
    calculateBillingAmount(orderDetails: orderDetails);
    showModalBottomSheet(
      context: context, 
      isScrollControlled: true,
      builder: (_){
        return Container(
          height: context.screenHeight * 0.90,
          padding: const EdgeInsets.all(AppSize.s12),
          decoration: BoxDecoration(
            color: Helper.isDark 
            ? AppColors.contentColorDark
            : AppColors.white,
            borderRadius: BorderRadius.circular(AppSize.s18)
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: context.screenWidth * 0.20,
                    height: AppSize.s4,
                    decoration: BoxDecoration(
                      color: AppColors.grey,
                      borderRadius: BorderRadius.circular(AppSize.s15)
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSize.s12),
              Container(
                padding: const EdgeInsets.all(AppSize.s10),
                decoration: BoxDecoration(
                  color: Helper.isDark 
                  ? AppColors.backgroundColorDark 
                  : AppColors.backgroundColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(AppSize.s10),
                    topRight: Radius.circular(AppSize.s10)
                  )
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            CustomText(
                              title: 'Table : ${selectedOrder!.tableList.fold("", (p1, element) => p1.isEmpty ? p1+element.tableName! : '$p1, ${element.tableName}')}', 
                              color: Helper.isDark 
                              ? AppColors.white 
                              : AppColors.black
                            ),
                            const SizedBox(width: AppSize.s5),
                            Container(
                              padding: const EdgeInsets.all(4),
                              color: AppColors.primaryColor,
                              child: const CustomText(
                                title: 'D-IN',
                                fontSize: AppSize.s8,
                                color: AppColors.white,
                              ),
                            ),
                          ],
                        ),
                        CustomText(
                          title: '', 
                          color: Helper.isDark 
                          ? AppColors.white 
                          : AppColors.black
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSize.s20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          title: selectedOrder == null
                          ? ''
                          : selectedOrder!.customerName, 
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16, 
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                        CustomText(
                          title: '#${selectedOrder!.checkSequence}', 
                          textStyle: getMediumStyle(
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSize.s5),
              Expanded(
                child: Container(
                  color: Helper.isDark
                  ? AppColors.backgroundColorDark
                  : AppColors.backgroundColor,
                  child: ListView.builder(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    itemCount: selectedOrder == null 
                    ? 0 
                    : selectedOrder!.productDetails.length,
                    itemBuilder: (_, index){
                      var data = selectedOrder!.productDetails[index];
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: AppSize.s12, vertical: AppSize.s12),
                        decoration: const BoxDecoration(
                          border: Border(bottom: BorderSide(color: AppColors.grey, width: AppSize.s1))
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: CustomText(
                                title: data.productName!,
                                maxLines: 1,
                                textStyle: getRegularStyle(
                                  fontSize: AppSize.s14, 
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                ),
                              ),
                            ),
                            Expanded(
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CustomText(
                                    title: '\$${data.productPrice}  x  ',
                                    textAlign: TextAlign.center,
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14, 
                                      color: AppColors.grey
                                    ),
                                  ),
                                  CustomText(
                                    title: data.quantity.toString(),
                                    textAlign: TextAlign.center,
                                    textStyle: getRegularStyle(
                                      fontSize: AppSize.s14, 
                                      color: Helper.isDark 
                                      ? AppColors.white 
                                      : AppColors.black
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: CustomText(
                                title: '\$${data.productPrice! * data.quantity!.toDouble()}',
                                textAlign: TextAlign.end,
                                textStyle: getRegularStyle(
                                  fontSize: AppSize.s14,
                                  color: Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                                )
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s5),
              Container(
                padding: const EdgeInsets.only(
                  left: AppSize.s12,
                  right: AppSize.s12,
                  top: AppSize.s12
                ),
                decoration: BoxDecoration(
                  color: Helper.isDark
                  ? AppColors.backgroundColorDark
                  : AppColors.backgroundColor,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(AppSize.s8),
                    bottomRight: Radius.circular(AppSize.s8)
                  )
                ),
                child: Column(
                  children: List.generate(
                    orderBillingLabel.length, 
                    (index) {
                      var data = orderBillingLabel[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: AppSize.s10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: data.title,
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: index == 5 
                                ? AppColors.red
                                : Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                              ),
                            ),
                            CustomText(
                              title: '\$${data.amount.roundTwo}',
                              textStyle: getRegularStyle(
                                fontSize: AppSize.s14,
                                color: index == 5 
                                ? AppColors.red
                                : Helper.isDark 
                                  ? AppColors.white 
                                  : AppColors.black
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                  ),
                ),
              ),
              const SizedBox(height: AppSize.s8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: CustomOutlinedButton(
                      onPressed: () {
                        if(selectedOrder != null) {
                          var tableList = <Map>[];
                          for(var item in selectedOrder!.tableList){
                            tableList.add({
                              'table_name': item.tableName,
                              'table_id': item.tableId
                            });
                          }
                          var addOnData = {
                            'from': AppRoutes.paymentTerminalScreen,
                            'type': tabSelectedIndex == 0 ? AppStrings.openChecks : AppStrings.closeChecks,
                            'total_guest': selectedOrder!.totalGuest,
                            'product_list': selectedOrder!.productDetails,
                            'order_sequence': selectedOrder!.orderDetails.length,
                            'customer_name': selectedOrder!.customerName,
                            "customer_email": "",
                            "customer_phone": "",
                            "customer_credit_card": "",
                            'order_id': selectedOrder!.orderId,
                            'table_list': tableList,
                            'order_details': selectedOrder!.orderDetails,
                            'selected_table': tableList.fold("", (p0, item) => p0.isBlank ? p0+item['table_name'] : '$p0-${item['table_name']}')
                          };
                          context.pushReplacement(AppRoutes.ordersScreen, extra: addOnData);
                        }
                      },
                      text: tabSelectedIndex == 0
                      ? AppStrings.update
                      : AppStrings.duplicateOrder,
                      textColor: AppColors.primaryColor
                    ),
                  ),
                  Visibility(
                    visible: tabSelectedIndex == 0,
                    child: Expanded(
                      child: Row(
                        children: [
                          const SizedBox(width: AppSize.s10),
                          Expanded(
                            child: CustomSolidButton(
                              onPressed: () {
                                var orderItems = <OrderModel>[];
                                for(var item in selectedOrder!.productDetails) {
                                  orderItems.add(OrderModel(
                                    itemId: item.productId!,
                                    title: item.productName!,
                                    price: item.productPrice!.toDouble(),
                                    totalPrice: (item.quantity! * item.productPrice!.toDouble()).roundTwo,
                                    quantity: item.quantity!
                                  ));
                                }
                                var tableList = <Map>[];
                                for(var item in selectedOrder!.tableList) {
                                  tableList.add({
                                    'table_name': item.tableName,
                                    'table_id': item.tableId
                                  });
                                }
                                var paymentDetails = PaymentModel(
                                  isFirstOrder: false,
                                  orderedItem: orderItems,
                                  orderId: selectedOrder!.orderId,
                                  customerName: selectedOrder!.customerName,
                                  customerId: selectedOrder!.customerId,
                                  customerEmail: "",
                                  // customerPhone: "",
                                  // customerCreditCard: "",
                                  hasCheckSequence: selectedOrder!.hasCheckSequence,
                                  totalGuest: selectedOrder!.totalGuest,
                                  employeeId: Preferences.getString(key: AppStrings.prefUserId),
                                  tableName: tableList.fold("", (p0, item) => p0.isBlank ? p0+item['table_name'] : '$p0-${item['table_name']}'), 
                                  totalAmount: orderBillingLabel[5].amount,
                                  subTotal: orderBillingLabel[0].amount,
                                  discount: orderBillingLabel[1].amount,
                                  tax: orderBillingLabel[3].amount,
                                  balanceDue: orderBillingLabel[4].amount,
                                  orderSequence: selectedOrder!.checkSequence,
                                  selectedTableList: tableList
                                );
                                context.pop();
                                context.push(AppRoutes.paymentScreen, extra: {'orderId': selectedOrder!.orderId, 'pageIndex': selectedOrder!.checkSequence - 1});
                              },
                              text: '${AppStrings.pay} (\$${selectedOrder!.billingDetails!.grandTotal!.roundTwo})',
                              verPadding: AppSize.s20,
                              horPadding: AppSize.s18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }
    );
  } 

  void showCloseCheckReceiptDialog({required BuildContext context, required PaymentOrderModel orderDetails}) {
    showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          titlePadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: CloseCheckWidget(
            paymentOrderModel: orderDetails,
          ),
        );
      }
    );
  }

  List<PaymentOrderModel> filterChecks(List<PaymentOrderModel> checks, int tab) {
    switch (tab) {
      case 0:
        return orderList.where((element) => element.billingDetails!.balanceDue != 0.0).toList();
      case 1:
        return orderList.where((element) => element.billingDetails!.balanceDue == 0.0).toList();
      default:
        return [];
    }
  }

  Future<void> authorizeUserDialog({required PaymentOrderModel orderDetails}) async {
    var closeFlag = await showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          surfaceTintColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: AuthorizeUserDialogWidget(
            paymentTerminalBloc: _paymentTerminalBloc,
          ),
        );
      }
    ) ?? false;
    isAuthorizeDialogOpen = false;
    if(!closeFlag) {
      _paymentTerminalBloc.add(OnSelectPaymentOrderEvent(selectOrder: orderDetails, selectedIndex: selectedOrderIndex));
    } else {
      showTransferCheck(orderDetails: orderDetails);
    }
  }

  Future<void> showTransferCheck({required PaymentOrderModel orderDetails}) async {
    var closeFlag = await showDialog(
      context: context, 
      builder: (_) {
        return AlertDialog(
          backgroundColor: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSize.s12)
          ),
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.symmetric(horizontal: context.screenWidth < 600.0 ? AppSize.s14 : AppSize.s0),
          content: TransferCheckWidget(
            orderDetails: orderDetails, 
            paymentTerminalBloc: _paymentTerminalBloc, 
            employeeDropdownList: employeeDropDownItem,
            onChangeServer: (serverId) {
              context.pop(true);
              _paymentTerminalBloc.add(PaymentTerminalOnChangeServerEvent(serverId: serverId, orderId: orderDetails.orderId));
            },
          ),
        );
      }
    ) ?? false;
    if(!closeFlag) {
      _paymentTerminalBloc.add(OnSelectPaymentOrderEvent(selectOrder: orderDetails, selectedIndex: selectedOrderIndex));
    }
  }

}