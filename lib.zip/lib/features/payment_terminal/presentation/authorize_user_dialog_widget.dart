import 'package:cliqtechnologies_retl/constants/app_images.dart';
import 'package:cliqtechnologies_retl/constants/app_size.dart';
import 'package:cliqtechnologies_retl/constants/app_style.dart';
import 'package:cliqtechnologies_retl/routes/route.dart';
import 'package:cliqtechnologies_retl/utils/app_extension_method.dart';
import 'package:flutter/services.dart';
import '../../../constants/app_colors.dart';
import '../../../widgets/custom_checkbox.dart';
import '../../../widgets/custom_keypad_widget.dart';
import '../../../widgets/custom_text.dart';
import '../../../widgets/custom_text_field.dart';

class AuthorizeUserDialogWidget extends StatelessWidget {
  
  final PaymentTerminalBloc paymentTerminalBloc;
  const AuthorizeUserDialogWidget({super.key, required this.paymentTerminalBloc});

  @override
  Widget build(BuildContext context) {
    final emailTextController = TextEditingController();
    final passwordTextController = TextEditingController();
    final screenType = context.screenWidth.screenType;
    var enteredPin = <int>[];
    bool isLoading = false;
    LoginType loginType = LoginType.userName;
    String emailError = '';
    String passwordError = '';
    // String validationError = '';
    return BlocProvider<PaymentTerminalBloc>.value(
      value: paymentTerminalBloc,
      child: Container(
        width: screenType == ScreenType.mobile 
        ? context.screenWidth
        : context.screenWidth * 0.35,
        // height: context.screenHeight * 0.54,
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s16,
          horizontal: AppSize.s16
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSize.s12),
          color: Helper.isDark 
          ? AppColors.transparent 
          : AppColors.transparent,
        ),
        child: BlocConsumer<PaymentTerminalBloc, PaymentTerminalState>(
          builder: (context, state) {
            return ListView(
              shrinkWrap: true,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.lock_outline, size: 22),
                        const SizedBox(width: 4),
                        CustomText(
                          title:  "Manager Authentication Required",
                          textStyle: getMediumStyle(
                            fontSize: AppSize.s16, 
                            color: Helper.isDark 
                            ? AppColors.white 
                            : AppColors.black
                          ),
                        ),
                      ],
                    ),
                    Transform.translate(
                      offset: const Offset(12,0),
                      child: IconButton(
                        onPressed: () => context.pop(), 
                        icon: const Icon(Icons.clear_sharp)
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSize.s5),
                Container(
                  padding: const EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    color: AppColors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4)
                  ),
                  child: CustomText(
                    title: 'Manager authentication is required to transfer any check, so you must have to validate with manager credentials',
                    textStyle: getRegularStyle(fontSize: 12, color: AppColors.red),
                  ),
                ),
                Visibility(
                  visible: loginType == LoginType.userName,
                  child: Column(
                    children: [
                      const SizedBox(height: 10.0),
                      CustomTextField(
                        textController: emailTextController,
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s12,
                        prefixImagePath: AppImages.personIcon,
                        label: AppStrings.username,
                        errorText: emailError,
                        onChange: (value) => paymentTerminalBloc.add(PaymentTerminalEmailChangeEvent(email: value))
                      ),
                      ///Password Field
                      const SizedBox(height: AppSize.s10),
                      CustomTextField(
                        textController: passwordTextController,
                        verPadding: AppSize.s10,
                        horPadding: AppSize.s12,
                        obscureText: true,
                        label: AppStrings.password,
                        prefixImagePath: AppImages.passwordIcon,
                        inputFormatter: [FilteringTextInputFormatter.deny(Helper.restrictSpaceRegExp)],
                        // suffixImagePath: showPassword ? AppImages.eyeOpenIcon : AppImages.eyeCloseIcon,
                        // suffixCallBack: () => bContext.read<LoginBloc>().add(LoginShowPasswordEvent(passwordVisible: showPassword)),
                        errorText: passwordError,
                        onChange: (value) => paymentTerminalBloc.add(PaymentTerminalPasswordChangeEvent(password: value)),
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: loginType == LoginType.pin,
                  child: Column(
                    children: [
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: List.generate(
                          6, 
                          (index) {
                            return Container(
                              height: AppSize.s18,
                              width: AppSize.s18,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: enteredPin.length >= index + 1 
                                ? AppColors.primaryColor 
                                : Helper.isDark 
                                  ? AppColors.lightTextGrey 
                                  : AppColors.white,
                                boxShadow: [BoxShadow(color: AppColors.primaryColor.withOpacity(0.2), blurRadius: 4)]
                              ),
                            );
                          }
                        ),
                      ),
                      CustomKeypadWidget(
                        onTap: (value) => paymentTerminalBloc.add(PaymentTerminalPinEnterEvent(value: value))
                      ),
                    ],
                  )
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    CustomCheckBox(
                      value: loginType == LoginType.pin,
                      onChange: (value) => paymentTerminalBloc.add(PaymentTerminalChangeAuthorizationEvent(
                        loginType: value! ? LoginType.pin : LoginType.userName 
                      )),
                    ),
                    const SizedBox(width: AppSize.s2),
                    CustomText(
                      title: 'Authorize with Pin', 
                      textStyle: getRegularStyle(
                        fontWeight: FontWeight.w400,
                        color: Helper.isDark 
                        ? AppColors.lightGrey 
                        : AppColors.black
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.maxFinite,
                  child: ElevatedButton(
                    onPressed: () => paymentTerminalBloc.add(PaymentTerminalAuthorizeEvent(
                      loginType: loginType,
                      firstText: emailTextController.text,
                      secondText: passwordTextController.text
                    )),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: AppColors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppSize.s5))
                    ),
                    ///uncomment this to show circular loader
                    child: isLoading 
                    ? const SizedBox(
                        height: AppSize.s25,
                        width: AppSize.s25,
                        child: CircularProgressIndicator(color: AppColors.white, strokeWidth: 1.8)
                      )
                    : const Text('Authorize'),
                  ),
                ),
              ],
            );
          },
          listener: (context, state) {
            switch (state.runtimeType) {
              case PaymentTerminalChangeAuthorizationState:
                state = state as PaymentTerminalChangeAuthorizationState;
                loginType = state.loginType;
                break;
              case PaymentTerminalEmailChangeState:
                state = state as PaymentTerminalEmailChangeState;
                emailError = state.message;
                break;
              case PaymentTerminalPasswordChangeState:
                state = state as PaymentTerminalPasswordChangeState;
                passwordError = state.message;
                break;
              case PaymentTerminalPinEnterState:
                state = state as PaymentTerminalPinEnterState;
                enteredPin.clear();
                enteredPin.addAll(state.pin);
                break;
              case PaymentTerminalDialogLoadingState:
                isLoading = true;
                break;
              case OnFailedState:
                state = state as OnFailedState;
                isLoading = false;
                break;
              case PaymentTerminalSuccessState:
                context.pop(true);
                break;
              default:
            }
          },
        ),
      ),
    );
  }
}