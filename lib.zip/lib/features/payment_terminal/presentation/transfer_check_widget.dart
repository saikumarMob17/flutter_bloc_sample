import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../table_services/domain/employee_drop_down_item.dart';
import '../../../utils/app_extension_method.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../constants/app_strings.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_style.dart';
import '../../../utils/helper.dart';
import '../../../widgets/custom_employee_dropdown_widget.dart';
import '../../../widgets/custom_text.dart';
import '../domain/payment_order_model.dart';
import '../domain/payment_terminal_response.dart';
import 'bloc/payment_terminal_bloc.dart';

class TransferCheckWidget extends StatelessWidget {

  final PaymentOrderModel orderDetails;
  final PaymentTerminalBloc paymentTerminalBloc;
  final List<EmployeeDropdownItem> employeeDropdownList;
  final Function(String) onChangeServer;
  
  const TransferCheckWidget({ 
    required this.orderDetails, 
    required this.paymentTerminalBloc, 
    required this.employeeDropdownList,
    required this.onChangeServer,
    super.key
  });

  @override
  Widget build(BuildContext context) {
    final screenType = context.screenWidth.screenType;
    String selectedEmployeeId = orderDetails.serverId!;
    return BlocProvider<PaymentTerminalBloc>.value(
      value: paymentTerminalBloc,
      child: Container(
        width: screenType == ScreenType.mobile 
        ? context.screenWidth
        : context.screenWidth * 0.38,
        height: context.screenHeight * 0.51,
        padding: const EdgeInsets.symmetric(
          vertical: AppSize.s16,
          horizontal: AppSize.s16
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSize.s12),
          color: Helper.isDark 
          ? AppColors.contentColorDark 
          : AppColors.white,
        ),
        child: ListView(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomText(
                  title:  AppStrings.transferCheck,
                  textStyle: getMediumStyle(
                    fontSize: AppSize.s16, 
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                ),
               Transform.translate(
                  offset: const Offset(12,0),
                  child: IconButton(
                    onPressed: () => context.pop(), 
                    icon: const Icon(Icons.clear_sharp)
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSize.s10),
            CustomText(
              title: AppStrings.currentCheckDetails,
               textStyle: getMediumStyle(
                fontSize: AppSize.s12, 
                color: AppColors.grey
              ),
            ),
            const SizedBox(height: AppSize.s8),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(AppSize.s12),
              decoration: BoxDecoration(
                color: Helper.isDark 
                  ? AppColors.headerColorDark 
                  : AppColors.backgroundColor,
                borderRadius: BorderRadius.circular(AppSize.s10),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: '${AppStrings.table} : ${orderDetails.tableList.fold('', (p0, p1) => p0.isEmpty ? p0+p1.tableName! : '$p0,${p1.tableName}')}',
                        textStyle: getRegularStyle(
                          fontWeight: FontWeight.w500
                        ),
                      ),
                      CustomText(
                        title: '${AppStrings.server} : ${orderDetails.serverName ?? ''}',
                        textStyle: getRegularStyle(),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSize.s20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomText(
                        title: orderDetails.customerName, 
                        textStyle: getMediumStyle(),
                      ),
                      CustomText(
                        title: '${orderDetails.orderNumber}  |  #${orderDetails.checkSequence}', 
                        textStyle: getMediumStyle(),
                      ),
                    ],
                  ),
                  const Divider(
                    color: AppColors.grey, 
                    thickness: AppSize.s1, 
                    height: AppSize.s8
                  ),
                  const SizedBox(height: AppSize.s8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: CustomText(
                          title: '${orderDetails.productDetails.fold('', (p0, p1) => p0.isEmpty ? p0+p1.productName! : '$p0, ${p1.productName}')}\n', 
                          maxLines: 2,
                          textOverflow: TextOverflow.ellipsis,
                          fontSize: 11
                        ),
                      ),
                      const SizedBox(width: AppSize.s20),
                      CustomText(
                        title: '\$${calculateGrandTotal(orderDetails.billingDetails)}', 
                        textStyle: getMediumStyle(),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 15),
            BlocBuilder<PaymentTerminalBloc, PaymentTerminalState>(
              builder: (context, state) {
                if(state is PaymentTerminalOnChangeServerState){
                  selectedEmployeeId = state.serverId;
                }
                return CustomEmployeeDropdownWidget(
                  items: employeeDropdownList, 
                  value: selectedEmployeeId,
                  label: AppStrings.selectServer,
                  isExpanded: true,
                  labelStyle: getRegularStyle(
                    color: Helper.isDark 
                    ? AppColors.white 
                    : AppColors.black
                  ),
                  onChange: (value) => paymentTerminalBloc.add(PaymentTerminalOnSelectServerEvent(serverId: value!)),
                );
              }
            ),
            const SizedBox(height: 15),
            SizedBox(
              width: double.maxFinite,
              child: CustomSolidButton(
                text: AppStrings.changeServer,
                onPressed: () => onChangeServer(selectedEmployeeId),
                verPadding: AppSize.s18,
              ),
            ),
          ],
        ),
      ),
    );
  }

  double calculateGrandTotal(BillingDetails? billingDetails) {
    if(billingDetails == null) {
      return 0.0;
    } else {
      try {
        var grandTotal = (billingDetails.subTotal! + billingDetails.tax! + billingDetails.tip!) - billingDetails.discount!;
        return grandTotal;
      } catch (e) {
        return 0.0;
      }
    }
  }
}