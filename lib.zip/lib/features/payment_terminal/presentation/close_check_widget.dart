import '../../../constants/app_style.dart';
import '../../../utils/app_extension_method.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_size.dart';
import '../../../constants/app_strings.dart';
import '../../../widgets/custom_outlined_button.dart';
import '../../../widgets/custom_solid_button.dart';
import '../../../widgets/custom_text.dart';
import '../../orders/domain/billing_model.dart';
import '../domain/payment_order_model.dart';

class CloseCheckWidget extends StatelessWidget {

  final PaymentOrderModel paymentOrderModel;

  const CloseCheckWidget({super.key, required this.paymentOrderModel});

  @override
  Widget build(BuildContext context) {
    var orderBillingLabel = <OrderBillingModel>[
      OrderBillingModel(title: AppStrings.subTotal, amount: 0.0),
      OrderBillingModel(title: AppStrings.tip, amount: 0.0),
      OrderBillingModel(title: AppStrings.tax, amount: 0.0),
      OrderBillingModel(title: AppStrings.total, amount: 0.0),
    ];
    calculateBillingAmount(orderBillingLabel, orderDetails: paymentOrderModel);
    return Container(
      height: context.screenHeight * 0.74,
      width: context.screenWidth * 0.32,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: AppColors.white
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(
                vertical: 20.0,
                horizontal: 20.0
              ),
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CustomText(
                      title: 'Vendom',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: '743 Washington Ave',
                      fontSize: AppSize.s14,
                    ),
                    const CustomText(
                      title: 'Miami Beach, FL 33139',
                      fontSize: AppSize.s14,
                    ),
                    const SizedBox(height: AppSize.s10),
                    CustomText(
                      title: '*** CLOSE CHECK ***',
                      textStyle: getMediumStyle(),
                    )
                  ],
                ),
                const SizedBox(height: AppSize.s18),
                Padding(
                  padding: const EdgeInsets.only(bottom: AppSize.s10),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: paymentOrderModel.customerName,
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: paymentOrderModel.orderDate!.toString().convertDateTimeClockOut,
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                const SizedBox(height: AppSize.s2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      title: 'Check #${paymentOrderModel.checkSequence}',
                      fontSize: AppSize.s14,
                    ),
                    CustomText(
                      title: 'Table ${paymentOrderModel.tableList.fold('', (p0, p1) => p0.isBlank ? p1.tableName! : '$p0 ${p1.tableName}')}',
                      fontSize: AppSize.s14,
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s10, bottom: AppSize.s18),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Column(
                  children: List.generate(
                    paymentOrderModel.productDetails.length, 
                    (index) {
                      var orderData = paymentOrderModel.productDetails[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: AppSize.s5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: '${orderData.quantity}  ${orderData.productName}',
                              fontSize: AppSize.s14,
                            ),
                            CustomText(
                              title: '\$${(orderData.productPrice! * orderData.quantity!).roundTwo}',
                              fontSize: AppSize.s14,
                            )
                          ],
                        ),
                      );
                    }
                  ),
                ),
                const SizedBox(height: AppSize.s12),
                Column(
                  children: List.generate(
                    orderBillingLabel.length, 
                    (index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: AppSize.s2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              title: orderBillingLabel[index].title,
                              fontSize: AppSize.s14,
                            ),
                            CustomText(
                              title: '\$${orderBillingLabel[index].amount}',
                              fontSize: AppSize.s14,
                            )
                          ],
                        ),
                      ); 
                    }
                  )
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s24, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  children: [
                    const Expanded(flex: 2, child: SizedBox()),
                    Expanded(child: CustomText(title: 'Amount',textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: 'Tip', textAlign: TextAlign.center, textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: 'Payment', textAlign: TextAlign.end,textStyle: getMediumStyle())),
                  ],
                ),
                const SizedBox(height: AppSize.s2),
                Column(
                  children: List.generate(
                    paymentOrderModel.billingDetails == null || paymentOrderModel.billingDetails!.paymentMode == null || paymentOrderModel.billingDetails!.paymentMode!.isEmpty
                    ? 0
                    : paymentOrderModel.billingDetails!.paymentMode!.length,
                    (index) {
                      var data = paymentOrderModel.billingDetails!.paymentMode![index];
                      return Row(
                        children: [
                          Expanded(flex: 2, child: CustomText(title: data.paymentMode!)),
                          Expanded(child: CustomText(title: '\$${data.amountPaid}')),
                          Expanded(child: CustomText(title: data.tip! <= 0.0 ? '--' : '\$${data.tip!}', textAlign: TextAlign.center)),
                          Expanded(child: CustomText(title: '\$${data.amountPaid! + data.tip!}', textAlign: TextAlign.end,)),
                        ],
                      );
                    }
                  )
                ),
                Padding(
                  padding: const EdgeInsets.only(top: AppSize.s12, bottom: AppSize.s12),
                  child: CustomPaint(painter: DashedLinePainter())
                ),
                Row(
                  children: [
                    Expanded(flex: 2, child: CustomText(title: 'Total', textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: '\$${orderBillingLabel[0].amount + orderBillingLabel[2].amount}',textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: orderBillingLabel[1].amount <= 0.0 ? 'N/A' : '\$${orderBillingLabel[1].amount}', textAlign: TextAlign.center, textStyle: getMediumStyle())),
                    Expanded(child: CustomText(title: '\$${orderBillingLabel[3].amount}', textAlign: TextAlign.end, textStyle: getMediumStyle())),
                  ],
                ),
              ],
            )
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              vertical: 10.0,
              horizontal: 14.0
            ),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10.0),
                bottomRight: Radius.circular(10.0),
              ),
              color: AppColors.backgroundColor,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CustomOutlinedButton(
                  onPressed: () => context.pop(),
                  text: 'Cancel',
                  textColor: AppColors.red,
                  borderColor: AppColors.red,
                ),
                const SizedBox(width: AppSize.s10),
                CustomSolidButton(
                  onPressed: () => debugPrint('Click here to print receipt'),
                  text: ' Print ',
                ),
              ],
            )
          )
        ],
      ),
    );
  }

  void calculateBillingAmount(List<OrderBillingModel> orderBillingLabel, {required PaymentOrderModel orderDetails}) {
    var grandTotal = ((orderDetails.billingDetails!.subTotal! + orderDetails.billingDetails!.tax! + orderDetails.billingDetails!.tip!) - orderDetails.billingDetails!.discount!).roundTwo;
    orderBillingLabel[0].amount = orderDetails.billingDetails!.subTotal!;
    orderBillingLabel[1].amount = orderDetails.billingDetails!.tip!;
    orderBillingLabel[2].amount = orderDetails.billingDetails!.tax!;
    orderBillingLabel[3].amount = grandTotal;
  }
}

class DashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    double dashWidth = 9, dashSpace = 5, startX = 0;
    final paint = Paint()
      ..color = AppColors.black
      ..strokeWidth = 1;
    while (startX < size.width) {
      canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
      startX += dashWidth + dashSpace;
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}