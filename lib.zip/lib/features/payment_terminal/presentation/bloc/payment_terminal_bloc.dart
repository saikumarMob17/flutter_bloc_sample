import '../../../../network/end_points.dart';
import '../../../../routes/route.dart';
import '../../../../utils/app_extension_method.dart';
import '../../data/payment_terminal_repository.dart';
import '../../../../utils/check_connectivity.dart';
import '../../domain/payment_terminal_response.dart' as payment_terminal;
import '../../../../network/custom_exception.dart';
import '../../../table_services/domain/all_employees_response.dart';
import '../../domain/payment_order_model.dart';
part 'payment_terminal_event.dart';
part 'payment_terminal_state.dart';


class PaymentTerminalBloc extends Bloc<PaymentTerminalEvent, PaymentTerminalState> {

  late CheckConnectivity _checkConnectivity;
  late PaymentTerminalRepository _repository;
  var orderList = <PaymentOrderModel>[];
  var originalOrderList = <PaymentOrderModel>[];
  List<Employees> employeesList = [];
  List<int> enteredPin = [];
  bool isMostRecent = false;

  PaymentTerminalBloc() : super(PaymentTerminalInitialState()){
    _checkConnectivity = CheckConnectivity();
    _repository = PaymentTerminalRepository();
    on<OnFetchOrdersEvent>(_onFetchOrders);
    on<OnChangeCheckTabEvent>(_onChangeTabIndex);
    on<OnSelectPaymentOrderEvent>(_onSelectPaymentOrder);
    on<OnSearchEvent>(_onSearchPaymentTerminal);
    on<OnSwitchUserPaymentTerminalEvent>(_onSwitchUser);
    on<PaymentTerminalMostRecentEvent>(_onFilterMostRecentOrders);
    on<PaymentTerminalGetAllEmployeeEvent>(_onGetAllEmployees);
    on<PaymentTerminalOnSelectServerEvent>(_onSelectServerName);
    on<PaymentTerminalOnChangeServerEvent>(_onChangeServer);
    on<PaymentTerminalChangeAuthorizationEvent>(_onChangeAuthorizationType);
    on<PaymentTerminalEmailChangeEvent>(_onAuthorizationEmailChange);
    on<PaymentTerminalPasswordChangeEvent>(_onAuthorizationPasswordChange);
    on<PaymentTerminalAuthorizeEvent>(_onAuthorizeUser);
    on<PaymentTerminalPinEnterEvent>(_onChangePinEnter);
  }

  void _onChangePinEnter(PaymentTerminalPinEnterEvent event, Emitter emit) {
    if(event.value.isNegative) {
      if(enteredPin.isNotEmpty){
        enteredPin.removeLast();
      }
    } else {
      if(enteredPin.length < 6) {
        enteredPin.add(event.value);
      }
    }
    emit(PaymentTerminalPinEnterState(pin: enteredPin));
  }

  void _onAuthorizationEmailChange(PaymentTerminalEmailChangeEvent event, Emitter emit) {
    if(event.email.isEmpty){
      emit(PaymentTerminalEmailChangeState(message: AppStrings.emptyEmailMsg));
    } else if(!event.email.isValidEmail){
      emit(PaymentTerminalEmailChangeState(message: AppStrings.invalidEmail));
    } else {
      emit(PaymentTerminalEmailChangeState(message: AppStrings.emptyString));
    }
  }

  void _onAuthorizationPasswordChange(PaymentTerminalPasswordChangeEvent event, Emitter emit) {
    if(event.password.isEmpty){
      emit(PaymentTerminalPasswordChangeState(message: AppStrings.emptyPasswordMsg));
    } else if(event.password.length < 8){
      emit(PaymentTerminalPasswordChangeState(message: AppStrings.invalidPassword));
    } else {
      emit(PaymentTerminalPasswordChangeState(message: AppStrings.emptyString));
    }
  }

  Future<void> _onAuthorizeUser(PaymentTerminalAuthorizeEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      if(event.loginType == LoginType.userName) {
        if(userNameValidation(emit, email: event.firstText, password: event.secondText)){
          try {
            var body = {
              'userEmailID': event.firstText,
              'password': event.secondText
            };
            emit(PaymentTerminalDialogLoadingState());
            var response = await _repository.authorizeManagerProfile(body: body);
            emit(PaymentTerminalSuccessState(msg: response));
          } on CustomException catch (e) {
            emit(OnFailedState(msg: e.message));
          }
        }
      } else {
        
      }
    }
  }

  bool userNameValidation(Emitter emit, {String email = '', String password = ''}) {
    if(email.isBlank){
      emit(PaymentTerminalEmailChangeState(message: AppStrings.emptyEmailMsg));
      return false;
    } else if(!email.isValidEmail){
      emit(PaymentTerminalEmailChangeState(message: AppStrings.invalidEmail));
      return false;
    } else if(password.isBlank){
      emit(PaymentTerminalPasswordChangeState(message: AppStrings.emptyPasswordMsg));
      return false;
    } else if(password.length < 8){
      emit(PaymentTerminalPasswordChangeState(message: AppStrings.invalidPassword));
      return false;
    } else {
      return true;
    }
  }

  void _onSelectServerName(PaymentTerminalOnSelectServerEvent event, Emitter emit) {
    emit(PaymentTerminalOnChangeServerState(serverId: event.serverId));
  }

  void _onChangeAuthorizationType(PaymentTerminalChangeAuthorizationEvent event, Emitter emit) {
    emit(PaymentTerminalChangeAuthorizationState(loginType: event.loginType));
  }

  void _onFilterMostRecentOrders(PaymentTerminalMostRecentEvent event, Emitter emit){
    if(orderList.isNotEmpty){
      if(event.isMostRecent){
        orderList.sort((a,b) => b.orderDate!.compareTo(a.orderDate!));
      } else {
        orderList.sort((a,b) => a.orderDate!.compareTo(b.orderDate!));
      }
      emit(OnFetchOrdersState(orderList: orderList, isMostRecent: event.isMostRecent));
    }
  }

  Future<void> _onChangeServer(PaymentTerminalOnChangeServerEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(LoadingState());
        var response = await _repository.transferCheck(endPoint: '${EndPoints.assignOrder}?ordId=${event.orderId}&eployeeIdWhomToAssign=${event.serverId}');
        emit(PaymentTerminalSuccessState(msg: response));
        add(OnFetchOrdersEvent());
      } on CustomException catch (e) {
        emit(OnFailedState(msg: e.message));
      }
    } else {
      emit(OnFailedState(msg: AppStrings.noInternetConnection));
    }
  }

  Future<void> _onFetchOrders(OnFetchOrdersEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection) {
      try {
        emit(LoadingState());
        var data = await _repository.getAllPendingOrders();
        if(data.isNotEmpty) {
          orderList.clear();
          originalOrderList.clear();
          var temp = <PaymentOrderModel>[];
          for(var item in data) {
            var customerName = item.customerName.toString();
            var orderNumber = item.orderNumber.toString();
            var orderId = item.orderId.toString();
            var tableList = item.tableDetails!;
            ///Check Details Length
            if(item.checkDetails!.isEmpty) {
              List<payment_terminal.SplitItem> tempProductDetails = [];
              double subTotal = 0.0;
              double discount = 0.0;
              double tax = 0.0;
              double tip = 0.0;
              double grandTotal = 0.0;
              for(var subItem in item.orderedProductDetailsByOrderSequence!) {
                tempProductDetails.addAll(subItem.productDetails!);
                subTotal+=subItem.billingDetails!.subTotal!;
                discount+=subItem.billingDetails!.discount!;
                tax+=subItem.billingDetails!.tax!;
                tip+=subItem.billingDetails!.tip!;
                grandTotal+=subItem.billingDetails!.grandTotal!;
              }
              temp.add(PaymentOrderModel(
                customerName: customerName, 
                totalGuest: item.totalGuest!,
                orderNumber: orderNumber, 
                customerIdentity: item.customerIdentity!,
                orderId: orderId, 
                orderDate: item.orderDate,
                customerId: item.customerId ?? '', 
                tableList: tableList,
                orderDetails: item.orderedProductDetailsByOrderSequence!, 
                serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                checkSequence: 1,
                productDetails: tempProductDetails,
                totalBillingDetails: item.totalBillingDetail!,
                billingDetails: payment_terminal.BillingDetails(
                  subTotal: subTotal,
                  discount: discount,
                  tax: tax,
                  tip: tip,
                  grandTotal: grandTotal,
                  balanceDue: grandTotal,
                  paymentStatus: item.totalBillingDetail!.paymentStatus
                )
              ));
            } else {
              if(item.checkDetails!.every((element) => element.splitItems!.isEmpty)) {
                List<payment_terminal.SplitItem> tempProductDetails = [];
                for(var subItem in item.orderedProductDetailsByOrderSequence!) {
                  tempProductDetails.addAll(subItem.productDetails!);
                }
                temp.add(PaymentOrderModel(
                  customerName: customerName, 
                  totalGuest: item.totalGuest!,
                  orderNumber: orderNumber, 
                  orderId: orderId, 
                  orderDate: item.orderDate,
                  customerId: item.customerId ?? '', 
                  tableList: tableList,
                  serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                  serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                  orderDetails: item.orderedProductDetailsByOrderSequence!, 
                  checkSequence: item.checkDetails!.length,
                  hasCheckSequence: true,
                  productDetails: tempProductDetails,
                  totalBillingDetails: item.totalBillingDetail!,
                  billingDetails: payment_terminal.BillingDetails(
                    subTotal: item.totalBillingDetail!.subTotal!.toDouble(),
                    discount: item.totalBillingDetail!.discount!.toDouble(),
                    tax: item.totalBillingDetail!.tax!,
                    tip: item.totalBillingDetail!.tip!.toDouble(),
                    grandTotal: item.totalBillingDetail!.grandTotal!.toDouble(),
                    balanceDue: item.totalBillingDetail!.balanceDue!.toDouble(),
                    paymentStatus: item.totalBillingDetail!.paymentStatus
                  )
                ));
              } else {
                payment_terminal.BillingDetails? billingDetails;
                for(var subItem in item.checkDetails!) {
                  billingDetails = payment_terminal.BillingDetails(
                    subTotal: subItem.billingDetails!.subTotal!.toDouble(),
                    discount: subItem.billingDetails!.discount!.toDouble(),
                    tax: subItem.billingDetails!.tax!,
                    tip: subItem.billingDetails!.tip!.toDouble(),
                    grandTotal: subItem.billingDetails!.grandTotal!.toDouble(),
                    balanceDue: subItem.billingDetails!.balanceDue!.toDouble(),
                    paymentStatus: subItem.billingDetails!.paymentStatus,
                    paymentMode: subItem.billingDetails!.paymentMode
                  );
                  temp.add(PaymentOrderModel(
                    customerName: customerName, 
                    totalGuest: item.totalGuest!,
                    customerIdentity: item.customerIdentity!,
                    orderDate: item.orderDate,
                    orderNumber: orderNumber, 
                    orderId: orderId, 
                    customerId: item.customerId ?? '', 
                    tableList: tableList,
                    serverName: item.employeeDetails == null ? '' : item.employeeDetails!.employeeName,
                    serverId: item.employeeDetails == null ? '' : item.employeeDetails!.employeeId,
                    orderDetails: item.orderedProductDetailsByOrderSequence!, 
                    checkSequence: subItem.checkSequence!,
                    hasCheckSequence: true,
                    productDetails: subItem.splitItems!,
                    billingDetails: billingDetails,
                    totalBillingDetails: item.totalBillingDetail!,
                  ));
                }
              }
            }
          }
          for (var i = 0; i < temp.length; i++) {
            var map = <int, payment_terminal.SplitItem>{};
            for(var item in temp[i].productDetails) {
              if(map[item.productId] == null) {
                map[item.productId!] = item;
              } else {
                map[item.productId]!.quantity = map[item.productId]!.quantity! + item.quantity!;
              }
            }
            temp[i].productDetails = map.entries.map((e) => e.value).toList();
          }
          orderList.addAll(temp);
          originalOrderList.addAll(temp);
        }
        emit(OnFetchOrdersState(orderList: orderList));
      } on CustomException catch(e) {
        emit(OnFailedState(msg: e.message));
      } finally {
        add(PaymentTerminalGetAllEmployeeEvent());
      }
    }
  }

  void _onChangeTabIndex(OnChangeCheckTabEvent event, Emitter emit) {
    emit(OnChangeCheckTabState(tabIndex: event.tabIndex));
  }

  void _onSelectPaymentOrder(OnSelectPaymentOrderEvent event, Emitter emit) {
    emit(OnSelectPaymentOrderState(selectedOrder: event.selectOrder, selectedIndex: event.selectedIndex, forTransferCheck: event.forTransferCheck));
  }

  void _onSearchPaymentTerminal(OnSearchEvent event, Emitter emit) {
    orderList.clear();
    if(event.text.isNotEmpty) {
      var searchText = event.text.toLowerCase();
      for(var item in originalOrderList) {
        if(item.customerName.toLowerCase().contains(searchText) || item.orderNumber.toLowerCase().contains(searchText) || item.serverName!.toLowerCase().contains(searchText)){
          orderList.add(item);
        }
      }
    } else {
      orderList.addAll(originalOrderList);
    }
    emit(OnFetchOrdersState(orderList: orderList));
  }


  Future<void> _onSwitchUser(OnSwitchUserPaymentTerminalEvent event, Emitter emit) async {
    if(await _checkConnectivity.hasConnection){
      try {
        emit(LoadingState());
        var response = await _repository.onClockOutUser();
        emit(OnSwitchUserPaymentTerminalState(isLogout: response));
      } on CustomException catch (e) {
        emit(OnFailedState(msg: e.message));
      }
    }
  }

  Future<void> _onGetAllEmployees(PaymentTerminalGetAllEmployeeEvent event, Emitter emit) async {
    try {
      var data = await _repository.getAllEmployees();
      employeesList.clear();
      employeesList.addAll(data);
      emit(PaymentTerminalGetAllEmployeeState(employeesList: employeesList));
    } on CustomException catch(e) {
      emit(OnFailedState(msg: e.message));
    } 
  }

}