// import '../../domain/payment_order_model.dart';
part of 'payment_terminal_bloc.dart';
sealed class PaymentTerminalEvent {}

class OnChangeCheckTabEvent extends PaymentTerminalEvent {
  int tabIndex;

  OnChangeCheckTabEvent({this.tabIndex = -1});
}

class OnFetchOrdersEvent extends PaymentTerminalEvent {}

class OnSelectPaymentOrderEvent extends PaymentTerminalEvent {
  PaymentOrderModel selectOrder;
  int selectedIndex;
  bool forTransferCheck;

  OnSelectPaymentOrderEvent({
    required this.selectOrder, 
    required this.selectedIndex,
    this.forTransferCheck = false
  });
}

class OnSearchEvent extends PaymentTerminalEvent {
  String text;

  OnSearchEvent({this.text = ''});
}

class OnSwitchUserPaymentTerminalEvent extends PaymentTerminalEvent {}

class PaymentTerminalMostRecentEvent extends PaymentTerminalEvent {
  bool isMostRecent;

  PaymentTerminalMostRecentEvent({this.isMostRecent = false});
}

class PaymentTerminalGetAllEmployeeEvent extends PaymentTerminalEvent {}

class PaymentTerminalOnSelectServerEvent extends PaymentTerminalEvent {
  String serverId;

  PaymentTerminalOnSelectServerEvent({this.serverId = ''});
} 

class PaymentTerminalOnChangeServerEvent extends PaymentTerminalEvent {
  String serverId;
  String orderId;
  PaymentTerminalOnChangeServerEvent({required this.serverId, required this.orderId});
} 

class PaymentTerminalChangeAuthorizationEvent extends PaymentTerminalEvent {
  LoginType loginType;

  PaymentTerminalChangeAuthorizationEvent({this.loginType = LoginType.userName});
}

class PaymentTerminalEmailChangeEvent extends PaymentTerminalEvent {
  String email;
  PaymentTerminalEmailChangeEvent({this.email = ''});
}

class PaymentTerminalPasswordChangeEvent extends PaymentTerminalEvent {
  String password;
  PaymentTerminalPasswordChangeEvent({this.password = ''});
}

class PaymentTerminalAuthorizeEvent extends PaymentTerminalEvent {
  
  LoginType loginType;
  String firstText;
  String secondText;

  PaymentTerminalAuthorizeEvent({
    required this.loginType,
    this.firstText = '',
    this.secondText = '',
  });
}

class PaymentTerminalPinEnterEvent extends PaymentTerminalEvent {
  int value;
  PaymentTerminalPinEnterEvent({required this.value});
}