// import '../../domain/payment_order_model.dart';
part of 'payment_terminal_bloc.dart';
sealed class PaymentTerminalState {}

class PaymentTerminalInitialState extends PaymentTerminalState {}

class OnChangeCheckTabState extends PaymentTerminalState {
  int tabIndex;

  OnChangeCheckTabState({this.tabIndex = -1});
}

class LoadingState extends PaymentTerminalState {}

class OnFetchOrdersState extends PaymentTerminalState {
  List<PaymentOrderModel> orderList;
  bool isMostRecent;

  OnFetchOrdersState({required this.orderList, this.isMostRecent = false});
}

class OnFailedState extends PaymentTerminalState {
  String msg;

  OnFailedState({this.msg = ''});
}
class PaymentTerminalSuccessState extends PaymentTerminalState {
  String msg;

  PaymentTerminalSuccessState({this.msg = ''});
}

class OnSelectPaymentOrderState extends PaymentTerminalState {
  PaymentOrderModel selectedOrder;
  int selectedIndex;
  bool forTransferCheck;

  OnSelectPaymentOrderState({required this.selectedOrder, required this.selectedIndex, this.forTransferCheck = false});
}

class OnSwitchUserPaymentTerminalState extends PaymentTerminalState {
  bool isLogout;

  OnSwitchUserPaymentTerminalState({this.isLogout = false});
}

class PaymentTerminalGetAllEmployeeState extends PaymentTerminalState {
  List<Employees> employeesList = [];

  PaymentTerminalGetAllEmployeeState({required this.employeesList});
}

class PaymentTerminalOnChangeServerState extends PaymentTerminalState {
  String serverId;

  PaymentTerminalOnChangeServerState({this.serverId = ''});
}

class PaymentTerminalChangeAuthorizationState extends PaymentTerminalState {
  LoginType loginType;

  PaymentTerminalChangeAuthorizationState({this.loginType = LoginType.userName});
}

class PaymentTerminalEmailChangeState extends PaymentTerminalState {
  String message;
  PaymentTerminalEmailChangeState({this.message = ''});
}

class PaymentTerminalPasswordChangeState extends PaymentTerminalState {
  String message;
  PaymentTerminalPasswordChangeState({this.message = ''});
}

class PaymentTerminalPinEnterState extends PaymentTerminalState {
  List<int> pin;

  PaymentTerminalPinEnterState({required this.pin});
}

class PaymentTerminalDialogLoadingState extends PaymentTerminalState {}