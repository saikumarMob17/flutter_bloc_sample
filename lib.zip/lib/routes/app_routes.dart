import 'dart:developer';
import '../features/payment/presentation/bloc/payment_bloc.dart';
import 'route.dart';

class AppRoutes {
  
  AppRoutes._();

  static const String initialRoute = '/';
  static const String emptyRoute = '';
  static const String loginScreen = '/login_screen';
  static const String dashboardScreen = '/dashboard_screen';
  static const String ordersScreen = '/orders_screen';
  static const String tableViewScreen = '/table_view_screen';
  static const String paymentTerminalScreen = '/payment_terminal_screen';
  static const String orderHubScreen = '/order_hub_screen';
  static const String fastServiceScreen = '/fast_services_screen';
  static const String pendingOrderScreen = '/pending_order_screen';
  static const String wasteTrackingScreen = '/waste_tracking_screen';
  static const String signupScreen = '/sign_up_screen';
  static const String homeScreen = '/home_screen';
  static const String transactionScreen = '/transaction_screen';
  static const String paymentScreen = '/payment_screen';
  static const String kitchenDisplayScreen = '/kitchen_display_screen';
  static const String closeOutDayScreen = '/close_out_day_screen';
  static const String employeeShiftScreen = '/employee_shift_screen';
  static const String lookUpCustomerScreen = '/look_up_customer_screen';
  static const String customerScreen = '/customer_screen';
  static const String timeCardScreen = '/time_card_screen';
  static const String clockInOutScreen = '/clock_in_out_screen';
  static const String cashDrawerScreen = '/cash_drawer_screen';
  static const String depositsScreen = '/deposits_screen';
  static const String serviceStatusScreen = '/service_status_screen';
  static const String splitCheckScreen = '/split_check_screen';
  static const String salesReportScreen = '/sales_report_screen';
  static const String laborReportScreen = '/labor_report_screen';
  static const String selectedOrderScreen = '/selected_order_screen';
  static const String checkSearchScreen = '/check_search_screen';
  static const String createFloorPlanScreen = '/create_floor_plan_screen';
  static const String menuReportScreen = '/menu_report_screen';
  static const String printerSetupScreen = '/printer_setup_screen';
  static const String shiftDetailsScreen = '/shfit_details_screen';

  static final GoRouter router = GoRouter(
    initialLocation: initialRoute,
    navigatorKey: GlobalKey<NavigatorState>(),
    redirect: (context, state) {
      var brightness = Theme.of(context).brightness;
      if(brightness == Brightness.dark){
        Helper.isDark = true;
      } else {
        Helper.isDark = false;
      }
      return null;
    },
    observers: [GoRouterObserver()],
    routes: [
      GoRoute(
        path: initialRoute,
        builder: (BuildContext context, GoRouterState state) => const SplashScreen()
      ),
      GoRoute(
        path: loginScreen,
        builder: (context, state) => BlocProvider(create: (_) => LoginBloc(), child: const LoginScreen())
      ),
      GoRoute(
        path: dashboardScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => DashboardBloc()..add(DashboardMenuItemEvent()), child: const DashboardScreen()
        ),
      ),
      GoRoute(
        path: ordersScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => OrdersBloc(tableData: state.extra == null ? {} : state.extra as Map)..add(OrdersProductSubCategoryEvent(duplicateData: state.extra == null ? {} : state.extra as Map)), 
          child: const OrdersScreen()
        ),
      ),
      GoRoute(
        path: tableViewScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => TableViewBloc()..add(TableViewGetFloorPlanEvent()), 
          child: const TableViewScreen()
        ),
      ),
      GoRoute(
        path: paymentScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => PaymentBloc(orderDetails: state.extra as Map)..add(PaymentStatusEvent()), 
          child: const PaymentScreen()
        ),
      ),
      GoRoute(
        path: kitchenDisplayScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => KitchenDisplayBloc()..add(KitchenDisplayDataEvent()), 
          child: const KitchenDisplayScreen()
        ),
      ),
      GoRoute(
        path: closeOutDayScreen,
        builder: (context, state) => BlocProvider(create: (_) => CloseOutDayBloc()..add(CloseOutDayDetailsEvent()), child: const CloseOutDayScreen())
      ),
      GoRoute(
        path: employeeShiftScreen,
        builder: (context, state) => BlocProvider(create: (_) => EmployeeShiftBloc()..add(EmployeeShiftListEvent()), child: const EmployeeShiftScreen())
      ),
      GoRoute(
        path: lookUpCustomerScreen,
        builder: (context, state) => BlocProvider(create: (_) => LookUpCustomerBloc(), child: const LookUpCustomerScreen())
      ),
      GoRoute(
        path: customerScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => CustomerBloc(), 
          child: CustomerScreen(customerInfo: state.extra as LookupCustomer)
        ),
      ),
      GoRoute(
        path: timeCardScreen,
        builder: (context, state) => BlocProvider(create: (_) => TimeCardBloc()..add(FetchTimeCardDetailsEvent()), child: const TimeCardScreen())
      ),
      GoRoute(
        path: clockInOutScreen,
        builder: (context, state) => BlocProvider(create: (_) => ClockInOutBloc()..add(FetchUserDetailsEvent(employeeId: state.extra as String)), child: ClockInOutScreen(employeeId: state.extra as String))
      ),
      GoRoute(
        path: cashDrawerScreen,
        builder: (context, state) => BlocProvider(create: (_) => CashDrawerBloc(), child: const CashDrawerScreen())
      ),
      GoRoute(
        path: depositsScreen,
        builder: (context, state) => BlocProvider(create: (_) => DepositsBloc(), child: const DepositsScreen())
      ),
      GoRoute(
        path: orderHubScreen,
        builder: (context, state) => BlocProvider(create: (_) => OrderHubBloc(), child: const OrderHubScreen())
      ),
      GoRoute(
        path: paymentTerminalScreen,
        builder: (context, state) => BlocProvider(create: (_) => PaymentTerminalBloc()..add(OnFetchOrdersEvent()), child: const PaymentTerminalScreen())
      ),
      GoRoute(
        path: serviceStatusScreen,
        builder: (context, state) => BlocProvider(create: (_) => ServiceStatusBloc(), child: const ServiceStatusScreen())
      ),
      GoRoute(
        path: splitCheckScreen,
        builder: (context, state) => BlocProvider(create: (_) => SplitCheckBloc(paymentDetails: state.extra as PaymentModel)..add(OnFetchProductDetailsEvent()), 
        child: const SplitCheckScreen())
      ),
      GoRoute(
        path: salesReportScreen,
        builder: (context, state) => BlocProvider(create: (_) => SalesReportBloc(), child: const SalesReportScreen())
      ),
      GoRoute(
        path: pendingOrderScreen,
        builder: (context, state) => BlocProvider(create: (_) => PendingOrdersBloc()..add(PendingOrdersFetchEvent()), child: const PendingOrdersScreen())
      ),
      GoRoute(
        path: laborReportScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => LaborReportBloc(), 
          child: const LaborReportScreen()
        ),
      ),
      GoRoute(
        path: createFloorPlanScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => FloorBloc()..add(FloorPlanFetchEvent()),
          child: const SetupFloorPlanScreen()
        ),
      ),
      GoRoute(
        path: checkSearchScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => CheckSearchBloc(),
          child: const CheckSearchScreen()
        ),
      ),
      GoRoute(
        path: menuReportScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => MenuReportBloc(),
          child: const MenuReportScreen()
        ),
      ),
      GoRoute(
        path: printerSetupScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => PrinterBloc(),
          child: const PrinterSetupScreen()
        ),
      ),
      GoRoute(
        path: shiftDetailsScreen,
        builder: (context, state) => BlocProvider(
          create: (_) => ShiftDetailsBloc(employeeId: state.extra as String)..add(FetchShiftDetailsEvent()),
          child: const ShiftDetailsScreen()
        ),
      ),
    ],
  );

  static Future<void> onClickLogout({required BuildContext context}) async {
    Preferences.setBool(key: AppStrings.prefBiometricAuthentication, value: false);
    await Preferences.clearPreferences(key: AppStrings.prefEmail);
    await Preferences.clearPreferences(key: AppStrings.prefUserId);
    await Preferences.clearPreferences(key: AppStrings.prefToken);
    await Preferences.clearPreferences(key: AppStrings.prefBiometric);
    await Preferences.clearPreferences(key: AppStrings.prefUserRole);
    await Preferences.clearPreferences(key: AppStrings.prefLocation);
    await Preferences.clearPreferences(key: AppStrings.prefTenantName);
    if(context.mounted){
      while (GoRouter.of(context).canPop()) {
        GoRouter.of(context).pop();
      }
      GoRouter.of(context).pushReplacement(AppRoutes.loginScreen);
    }
  }

}

class GoRouterObserver extends RouteObserver {
  
  late DateTime startTime;

  @override
  void didPop(Route route, Route? previousRoute) {
    if(route.settings.name != null){
      var endTime = DateTime.now();
      log('Call API Here to capture activity log of ${route.settings.name} $startTime $endTime');
      postData(moduleName: route.settings.name!, startTime: startTime.toString(), endTime: endTime.toString());
    }
  }

  @override
  void didPush(Route route, Route? previousRoute) {
    if(route.settings.name != null){
      startTime = DateTime.now();
    }
    log("Route Push => ${route.settings.name}");
  }

  @override
  void didRemove(Route route, Route? previousRoute) {}

  @override
  void didReplace({Route? newRoute, Route? oldRoute}) {}

  @override
  void didStartUserGesture(Route route, Route? previousRoute) {}

  @override
  void didStopUserGesture() {}

  Future<void> postData({required String moduleName, required String startTime, required String endTime}) async {
    // Sample POST data
    var data = {
      "moduleName": moduleName.captializedWord,
      "createdBy": Preferences.getString(key: AppStrings.prefUserId),
      "startedAt": startTime.replaceAll(' ','T'),
      "endedAt": endTime.replaceAll(' ','T')
    };

    var headers = <String, String>{
      NetworkConstants.contentTypeKey: NetworkConstants.contentType, 
      'Authorization': 'Bearer ${Preferences.getString(key: AppStrings.prefToken)}', 
      'tenant': Preferences.getString(key: AppStrings.prefTenantId)
    };

    try {
      var response = await post(Uri.parse(EndPoints.logActivityServer), body: json.encode(data),headers: headers);
      if (response.statusCode == 201) {
        debugPrint('Post successful! Response: ${response.body}');
      } else {
        debugPrint('Error: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Error: $e');
    }
  }


}